const { withXcodeProject } = require('@expo/config-plugins');

function applyIphoneOnlySettings(buildSettings) {
  buildSettings.TARGETED_DEVICE_FAMILY = '1';
  buildSettings.SUPPORTS_MACCATALYST = 'NO';
  buildSettings.SUPPORTS_MAC_DESIGNED_FOR_IPHONE_IPAD = 'NO';
}

module.exports = function withIphoneOnlyIos(config) {
  return withXcodeProject(config, (cfg) => {
    const configurations = cfg.modResults.pbxXCBuildConfigurationSection();

    for (const configuration of Object.values(configurations)) {
      if (!configuration || !configuration.buildSettings) {
        continue;
      }

      const bundleIdentifier = configuration.buildSettings.PRODUCT_BUNDLE_IDENTIFIER;
      if (bundleIdentifier === 'com.parcelman.parcelman') {
        applyIphoneOnlySettings(configuration.buildSettings);
      }
    }

    return cfg;
  });
};
