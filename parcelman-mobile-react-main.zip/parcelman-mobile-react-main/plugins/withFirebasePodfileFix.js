const { withDangerousMod } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

const MARKER = '# withFirebasePodfileFix';
const MODULAR_ANCHOR = 'use_expo_modules!';
const POST_INSTALL_ANCHOR = 'react_native_post_install(';

const MODULAR_INJECTION = `use_modular_headers!
  ${MARKER}
`;

const POST_INSTALL_INJECTION = `installer.pods_project.targets.each do |target|
      if target.name.start_with?('RNFB')
        target.build_configurations.each do |bc|
          bc.build_settings['CLANG_ALLOW_NON_MODULAR_INCLUDES_IN_FRAMEWORK_MODULES'] = 'YES'
        end
      end
    end

    `;

module.exports = function withFirebasePodfileFix(config) {
  return withDangerousMod(config, [
    'ios',
    async (cfg) => {
      const podfilePath = path.join(cfg.modRequest.platformProjectRoot, 'Podfile');
      let contents = fs.readFileSync(podfilePath, 'utf8');

      if (contents.includes(MARKER)) {
        return cfg;
      }

      const modularIdx = contents.indexOf(MODULAR_ANCHOR);
      if (modularIdx === -1) {
        throw new Error(
          `withFirebasePodfileFix: could not find "${MODULAR_ANCHOR}" in Podfile`,
        );
      }
      const modularInsertPoint = modularIdx + MODULAR_ANCHOR.length + 1;
      contents =
        contents.slice(0, modularInsertPoint) +
        '  ' +
        MODULAR_INJECTION +
        contents.slice(modularInsertPoint);

      const postInstallIdx = contents.indexOf(POST_INSTALL_ANCHOR);
      if (postInstallIdx === -1) {
        throw new Error(
          `withFirebasePodfileFix: could not find "${POST_INSTALL_ANCHOR}" in Podfile`,
        );
      }
      contents =
        contents.slice(0, postInstallIdx) +
        POST_INSTALL_INJECTION +
        contents.slice(postInstallIdx);

      fs.writeFileSync(podfilePath, contents);
      return cfg;
    },
  ]);
};
