const { withGradleProperties } = require('@expo/config-plugins');

const OVERRIDES = {
  'newArchEnabled': 'true',
  'org.gradle.parallel': 'false',
  'reactNativeArchitectures': 'armeabi-v7a,arm64-v8a',
  'expo.useLegacyPackaging': 'true',
};

module.exports = function withGradlePropertiesFixes(config) {
  return withGradleProperties(config, (cfg) => {
    for (const [key, value] of Object.entries(OVERRIDES)) {
      const existing = cfg.modResults.find(
        (item) => item.type === 'property' && item.key === key,
      );
      if (existing) {
        existing.value = value;
      } else {
        cfg.modResults.push({ type: 'property', key, value });
      }
    }
    return cfg;
  });
};
