const { withDangerousMod, withXcodeProject } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

const PHASE_NAME = 'Generate Prebuilt Framework dSYMs';
const SCRIPT_RELATIVE_PATH = 'scripts/generate-prebuilt-framework-dsyms.sh';
const SCRIPT_CONTENT = `#!/bin/sh

set -u

if [ "\${CONFIGURATION:-}" = "Debug" ]; then
  exit 0
fi

FRAMEWORKS_DIR="\${TARGET_BUILD_DIR:-}/\${FRAMEWORKS_FOLDER_PATH:-}"
DSYM_DIR="\${DWARF_DSYM_FOLDER_PATH:-}"

if [ ! -d "$FRAMEWORKS_DIR" ] || [ -z "$DSYM_DIR" ]; then
  echo "warning: Cannot generate prebuilt framework dSYMs; Xcode build paths are unavailable."
  exit 0
fi

mkdir -p "$DSYM_DIR"

generate_dsym() {
  FRAMEWORK_NAME="$1"
  BINARY_PATH="$FRAMEWORKS_DIR/$FRAMEWORK_NAME.framework/$FRAMEWORK_NAME"
  OUTPUT_PATH="$DSYM_DIR/$FRAMEWORK_NAME.framework.dSYM"

  if [ ! -f "$BINARY_PATH" ]; then
    echo "note: Skipping $FRAMEWORK_NAME dSYM; binary was not embedded."
    return 0
  fi

  echo "note: Generating dSYM for $FRAMEWORK_NAME.framework"
  rm -rf "$OUTPUT_PATH"

  if xcrun dsymutil "$BINARY_PATH" -o "$OUTPUT_PATH"; then
    dwarfdump --uuid "$OUTPUT_PATH" || true
  else
    echo "warning: Failed to generate dSYM for $FRAMEWORK_NAME.framework"
  fi
}

generate_dsym "React"
generate_dsym "ReactNativeDependencies"
generate_dsym "hermesvm"
`;

function hasBuildPhase(project) {
  const section = project.pbxShellScriptBuildPhaseSection();
  return Object.values(section).some((phase) => {
    if (!phase || typeof phase !== 'object') {
      return false;
    }

    return phase.name === `"${PHASE_NAME}"`;
  });
}

module.exports = function withPrebuiltFrameworkDsyms(config) {
  config = withDangerousMod(config, [
    'ios',
    async (cfg) => {
      const scriptPath = path.join(cfg.modRequest.platformProjectRoot, SCRIPT_RELATIVE_PATH);
      fs.mkdirSync(path.dirname(scriptPath), { recursive: true });
      fs.writeFileSync(scriptPath, SCRIPT_CONTENT);
      fs.chmodSync(scriptPath, 0o755);
      return cfg;
    },
  ]);

  return withXcodeProject(config, (cfg) => {
    const project = cfg.modResults;

    if (hasBuildPhase(project)) {
      return cfg;
    }

    project.addBuildPhase([], 'PBXShellScriptBuildPhase', PHASE_NAME, project.getFirstTarget().uuid, {
      inputPaths: [
        '"${TARGET_BUILD_DIR}/${FRAMEWORKS_FOLDER_PATH}/React.framework/React"',
        '"${TARGET_BUILD_DIR}/${FRAMEWORKS_FOLDER_PATH}/ReactNativeDependencies.framework/ReactNativeDependencies"',
        '"${TARGET_BUILD_DIR}/${FRAMEWORKS_FOLDER_PATH}/hermesvm.framework/hermesvm"',
        '"${SRCROOT}/scripts/generate-prebuilt-framework-dsyms.sh"',
      ],
      outputPaths: [
        '"${DWARF_DSYM_FOLDER_PATH}/React.framework.dSYM"',
        '"${DWARF_DSYM_FOLDER_PATH}/ReactNativeDependencies.framework.dSYM"',
        '"${DWARF_DSYM_FOLDER_PATH}/hermesvm.framework.dSYM"',
      ],
      shellPath: '/bin/sh',
      shellScript: '"${SRCROOT}/scripts/generate-prebuilt-framework-dsyms.sh"\n',
    });

    return cfg;
  });
};
