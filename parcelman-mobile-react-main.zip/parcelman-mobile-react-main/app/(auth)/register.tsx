import { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import AppBar from "../../src/components/common/AppBar";
import Input from "../../src/components/common/Input";
import Button from "../../src/components/common/Button";
import { colors } from "../../src/constants/colors";
import { fontFamily, fontSize } from "../../src/constants/typography";
import { spacing } from "../../src/constants/spacing";
import { register } from "../../src/api/v1/auth";
import { useAuthStore } from "../../src/stores/auth.store";
import { showError, getErrorMessage } from "../../src/utils/toast";

export default function RegisterScreen() {
  const insets = useSafeAreaInsets();
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const login = useAuthStore((s) => s.login);

  const [name, setName] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleRegister = async () => {
    if (!name.trim()) {
      setErrors({ name: "Name is required" });
      return;
    }

    setErrors({});
    setLoading(true);
    try {
      const res = await register({
        name: name.trim(),
        business_name: businessName.trim() || undefined,
        phone,
        email: email.trim() || undefined,
      });
      await login(res.data.token, res.data.user, "vendor");
      router.replace("/(vendor)/(tabs)/home" as any);
    } catch (err: any) {
      if (err?.errors) {
        const fieldErrors: Record<string, string> = {};
        for (const [key, messages] of Object.entries(err.errors)) {
          fieldErrors[key] = (messages as string[])[0];
        }
        setErrors(fieldErrors);
      } else {
        showError(getErrorMessage(err));
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <AppBar showBack title="Create Account" />

      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: insets.bottom + 20 },
        ]}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.header}>
          <Text style={styles.title}>Almost there!</Text>
          <Text style={styles.subtitle}>
            Tell us a bit about yourself to complete your account
          </Text>
        </View>

        <Input
          label="Full Name"
          required
          placeholder="Enter your name"
          value={name}
          onChangeText={setName}
          error={errors.name}
          autoCapitalize="words"
        />

        <Input
          label="Business Name"
          placeholder="Enter business name (optional)"
          value={businessName}
          onChangeText={setBusinessName}
          error={errors.business_name}
          autoCapitalize="words"
        />

        <Input
          label="Email"
          placeholder="Enter email (optional)"
          value={email}
          onChangeText={setEmail}
          error={errors.email}
          keyboardType="email-address"
          autoCapitalize="none"
        />

        <Button
          title="Create Account"
          onPress={handleRegister}
          loading={loading}
          disabled={!name.trim()}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  content: {
    paddingHorizontal: spacing["4xl"],
    gap: spacing["3xl"],
  },
  header: {
    gap: spacing.sm,
  },
  title: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.headingSm,
    color: colors.dark,
  },
  subtitle: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.textMuted,
  },
});
