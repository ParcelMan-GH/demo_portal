import { useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import PhoneInput from "../../src/components/common/PhoneInput";
import Button from "../../src/components/common/Button";
import { colors } from "../../src/constants/colors";
import { fontFamily, fontSize } from "../../src/constants/typography";
import { spacing } from "../../src/constants/spacing";
import { sendOtp } from "../../src/api/v1/auth";
import { isValidGhanaPhone, toApiPhone } from "../../src/utils/format";
import { showError, getErrorMessage } from "../../src/utils/toast";

export default function PhoneScreen() {
  const insets = useSafeAreaInsets();
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSendCode = async () => {
    if (!isValidGhanaPhone(phone)) {
      setError("Enter a valid 10-digit Ghana phone number");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const apiPhone = toApiPhone(phone);
      await sendOtp(apiPhone);
      router.push({ pathname: "/(auth)/verify", params: { phone: apiPhone } } as any);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={[
            styles.scrollContent,
            { paddingTop: insets.top + 40 },
          ]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Image
            source={require("../../assets/images/logo.png")}
            style={styles.logoImage}
            resizeMode="contain"
          />

          <View style={styles.header}>
            <Text style={styles.title}>Welcome</Text>
            <Text style={styles.subtitle}>
              Enter your phone number to get started
            </Text>
          </View>

          <PhoneInput
            label="Phone Number"
            required
            value={phone}
            onChangeText={(text) => {
              setPhone(text);
              setError(text.length === 10 && !isValidGhanaPhone(text) ? "Enter a valid 10-digit Ghana phone number" : "");
            }}
            error={error}
          />

          <Button
            title="Send Code"
            onPress={handleSendCode}
            loading={loading}
            disabled={!isValidGhanaPhone(phone)}
          />
        </ScrollView>
      </KeyboardAvoidingView>

      {/* Rider link pinned to bottom */}
      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <Text style={styles.footerText}>Are you a rider? </Text>
        <TouchableOpacity onPress={() => router.push("/(auth)/driver-login" as any)}>
          <Text style={styles.footerLink}>Log in here</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  flex: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: spacing["4xl"],
    gap: spacing["3xl"],
  },
  logoImage: {
    width: 120,
    height: 120,
    alignSelf: "center",
    marginBottom: spacing.xl,
  },
  header: {
    gap: spacing.sm,
  },
  title: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.headingMd,
    color: colors.dark,
  },
  subtitle: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.textMuted,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: spacing.lg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.white,
  },
  footerText: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.textMuted,
  },
  footerLink: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodyMd,
    color: colors.primary,
  },
});
