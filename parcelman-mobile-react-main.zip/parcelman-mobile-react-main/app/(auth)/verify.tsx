import { useState, useEffect } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import AppBar from "../../src/components/common/AppBar";
import OtpInput from "../../src/components/common/OtpInput";
import Button from "../../src/components/common/Button";
import { colors } from "../../src/constants/colors";
import { fontFamily, fontSize } from "../../src/constants/typography";
import { spacing } from "../../src/constants/spacing";
import { verifyPhone, sendOtp } from "../../src/api/v1/auth";
import { useAuthStore } from "../../src/stores/auth.store";
import { showError, showSuccess, getErrorMessage } from "../../src/utils/toast";
import { maskPhone } from "../../src/utils/format";

export default function VerifyScreen() {
  const insets = useSafeAreaInsets();
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const login = useAuthStore((s) => s.login);
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [resendCountdown, setResendCountdown] = useState(60);

  useEffect(() => {
    if (resendCountdown <= 0) return;
    const timer = setInterval(() => {
      setResendCountdown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [resendCountdown]);

  const handleVerify = async (code: string) => {
    setError("");
    setLoading(true);
    try {
      const res = await verifyPhone(phone, code);
      if (res.data.user_exists && res.data.token) {
        await login(res.data.token, res.data.user, "vendor");
        router.replace("/(vendor)/(tabs)/home" as any);
      } else {
        // New user — go to register
        router.push({
          pathname: "/(auth)/register",
          params: { phone },
        } as any);
      }
    } catch (err: any) {
      setError(getErrorMessage(err, "Invalid verification code"));
      setOtp("");
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    try {
      await sendOtp(phone);
      setResendCountdown(60);
      showSuccess("Code sent again");
    } catch (err: any) {
      showError(getErrorMessage(err));
    }
  };

  return (
    <View style={[styles.container, { paddingBottom: insets.bottom + 20 }]}>
      <AppBar showBack title="Verify Phone" />

      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Enter verification code</Text>
          <Text style={styles.subtitle}>
            We sent a 6-digit code to {maskPhone(phone)}
          </Text>
        </View>

        <OtpInput
          value={otp}
          onChangeText={(text) => {
            setOtp(text);
            setError("");
          }}
          onComplete={handleVerify}
          error={error}
        />

        <View style={styles.resendRow}>
          {resendCountdown > 0 ? (
            <Text style={styles.resendText}>
              Resend code in {resendCountdown}s
            </Text>
          ) : (
            <TouchableOpacity onPress={handleResend}>
              <Text style={styles.resendLink}>Resend Code</Text>
            </TouchableOpacity>
          )}
        </View>

        <Button
          title="Verify"
          onPress={() => handleVerify(otp)}
          loading={loading}
          disabled={otp.length < 6}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing["4xl"],
    gap: spacing["3xl"],
  },
  header: {
    gap: spacing.sm,
  },
  title: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.headingSm,
    color: colors.dark,
  },
  subtitle: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.textMuted,
  },
  resendRow: {
    alignItems: "center",
  },
  resendText: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodySm,
    color: colors.textMuted,
  },
  resendLink: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodySm,
    color: colors.primary,
  },
});
