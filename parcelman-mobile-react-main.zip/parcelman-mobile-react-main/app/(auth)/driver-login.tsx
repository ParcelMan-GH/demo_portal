import { useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import Input from "../../src/components/common/Input";
import Button from "../../src/components/common/Button";
import { colors } from "../../src/constants/colors";
import { fontFamily, fontSize } from "../../src/constants/typography";
import { spacing } from "../../src/constants/spacing";
import { driverLogin } from "../../src/api/v1/driver-auth";
import { useAuthStore } from "../../src/stores/auth.store";
import { showError, getErrorMessage } from "../../src/utils/toast";
import { isValidGhanaPhone, sanitizeLocalPhoneInput } from "../../src/utils/format";

export default function DriverLoginScreen() {
  const insets = useSafeAreaInsets();
  const phoneRoute = "/(auth)/phone" as const;
  const leaveDriverLogin = () => {
    if (router.canGoBack()) router.back();
    else router.replace(phoneRoute as any);
  };
  const login = useAuthStore((s) => s.login);
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [phoneError, setPhoneError] = useState("");

  const handleLogin = async () => {
    const cleanedPhone = phone.trim();
    if (!cleanedPhone || !password) {
      showError("Please enter your phone number and password");
      return;
    }
    if (!isValidGhanaPhone(cleanedPhone)) {
      setPhoneError("Enter a valid 10-digit Ghana phone number");
      return;
    }
    setPhoneError("");

    setLoading(true);
    try {
      const res = await driverLogin(cleanedPhone, password);
      await login(res.data.token, res.data.user, "driver");
      router.replace("/(driver)/(tabs)/home" as any);
    } catch (err: any) {
      showError(getErrorMessage(err, "Invalid phone or password"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <Image
          source={require("../../assets/images/logo.png")}
          style={styles.logoImage}
          resizeMode="contain"
        />

        <View style={styles.header}>
          <Text style={styles.title}>Rider Login</Text>
          <Text style={styles.subtitle}>
            Sign in with your rider credentials
          </Text>
        </View>

        <Input
          label="Phone Number"
          required
          placeholder="e.g. 0241234567"
          value={phone}
          onChangeText={(text) => {
            const next = sanitizeLocalPhoneInput(text);
            setPhone(next);
            setPhoneError(next.length === 10 && !isValidGhanaPhone(next) ? "Enter a valid 10-digit Ghana phone number" : "");
          }}
          keyboardType="phone-pad"
          maxLength={10}
          autoCapitalize="none"
          autoComplete="tel"
          error={phoneError}
          leftIcon={<Ionicons name="call-outline" size={18} color={colors.textMuted} />}
        />

        <Input
          label="Password"
          required
          placeholder="Enter your password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry={!showPassword}
          leftIcon={<Ionicons name="lock-closed-outline" size={18} color={colors.textMuted} />}
          rightIcon={
            <Ionicons
              name={showPassword ? "eye-off-outline" : "eye-outline"}
              size={20}
              color={colors.textMuted}
            />
          }
          onRightIconPress={() => setShowPassword(!showPassword)}
        />

        <Button
          title="Login"
          onPress={handleLogin}
          loading={loading}
          disabled={!isValidGhanaPhone(phone) || !password}
        />
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: insets.bottom + 20 }]}>
        <Text style={styles.footerText}>Not a rider? </Text>
        <TouchableOpacity onPress={leaveDriverLogin}>
          <Text style={styles.footerLink}>Go back</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: spacing["4xl"],
    paddingTop: 40,
    paddingBottom: 300,
    gap: spacing["3xl"],
  },
  logoImage: {
    width: 120,
    height: 120,
    alignSelf: "center",
    marginBottom: spacing.xl,
  },
  header: {
    gap: spacing.sm,
  },
  title: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.headingMd,
    color: colors.dark,
  },
  subtitle: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.textMuted,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: spacing.xl,
    backgroundColor: colors.white,
  },
  footerText: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.textMuted,
  },
  footerLink: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodyMd,
    color: colors.primary,
  },
});
