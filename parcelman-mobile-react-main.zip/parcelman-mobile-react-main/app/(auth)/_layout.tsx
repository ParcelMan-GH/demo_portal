import { Stack } from "expo-router";
import { colors } from "../../src/constants/colors";

export default function AuthLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        presentation: "card",
        animation: "none",
        gestureEnabled: false,
        contentStyle: { backgroundColor: colors.background },
      }}
    >
      <Stack.Screen name="phone" />
      <Stack.Screen name="verify" />
      <Stack.Screen name="register" />
      <Stack.Screen name="driver-login" />
    </Stack>
  );
}
