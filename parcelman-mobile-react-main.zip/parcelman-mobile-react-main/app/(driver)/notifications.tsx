import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity, Dimensions } from "react-native";
import { useState, useCallback } from "react";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../src/components/common/EmptyState";
import ShimmerLoading from "../../src/components/common/ShimmerLoading";
import { colors } from "../../src/constants/colors";
import { fontFamily } from "../../src/constants/typography";
import { getDriverNotifications, markDriverNotificationAsRead, markAllDriverNotificationsAsRead } from "../../src/api/v1/driver/notifications";
import { showSuccess, showError, getErrorMessage } from "../../src/utils/toast";
import { getRouteForNotification } from "../../src/hooks/useNotifications";

const { width } = Dimensions.get("window");

const typeIcons: Record<string, { icon: keyof typeof Ionicons.glyphMap; bg: string; color: string }> = {
  driver_assigned: { icon: "car-outline", bg: "#e0e7ff", color: "#6366f1" },
  pickup_assigned: { icon: "car-outline", bg: "#e0e7ff", color: "#6366f1" },
  transport_assigned: { icon: "bus-outline", bg: "#ffedd5", color: colors.primary },
  delivery_assigned: { icon: "bicycle-outline", bg: "#dcfce7", color: colors.success },
  pickup_unassigned: { icon: "car-outline", bg: "#fee2e2", color: colors.error },
  transport_unassigned: { icon: "bus-outline", bg: "#fee2e2", color: colors.error },
  delivery_unassigned: { icon: "bicycle-outline", bg: "#fee2e2", color: colors.error },
  shipment_status: { icon: "cube-outline", bg: "#e0e7ff", color: "#6366f1" },
  default: { icon: "notifications-outline", bg: colors.neutral100, color: colors.textMuted },
};

function getTimeAgo(dateStr: string): string {
  const now = new Date();
  const date = new Date(dateStr);
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return "Just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDay = Math.floor(diffHr / 24);
  if (diffDay < 7) return `${diffDay}d ago`;
  return date.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}

export default function DriverNotificationsScreen() {
  const insets = useSafeAreaInsets();
  const homeRoute = "/(driver)/(tabs)/home" as const;
  const leaveNotifications = () => {
    if (router.canGoBack()) router.back();
    else router.replace(homeRoute as any);
  };
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState("all");
  const [unreadCount, setUnreadCount] = useState(0);

  const fetchNotifications = useCallback(async () => {
    try {
      const res = await getDriverNotifications({ limit: 50 });
      const d = res.data as any;
      const items = d.notifications || d.items || d.data || [];
      setNotifications(items);
      setUnreadCount(d.unread_count ?? items.filter((n: any) => !n.read_at && !n.is_read).length);
    } catch (err: any) { showError(getErrorMessage(err)); }
    finally { setLoading(false); setRefreshing(false); }
  }, []);

  useFocusEffect(useCallback(() => { setLoading(true); fetchNotifications(); }, [fetchNotifications]));

  const readCount = notifications.filter((n) => !!n.read_at || n.is_read).length;
  const filteredNotifications = filter === "all" ? notifications
    : filter === "unread" ? notifications.filter((n) => !n.read_at && !n.is_read)
    : notifications.filter((n) => !!n.read_at || n.is_read);

  const handleMarkRead = async (id: number) => {
    try {
      await markDriverNotificationAsRead(id);
      setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, is_read: true, read_at: new Date().toISOString() } : n));
      setUnreadCount((c) => Math.max(0, c - 1));
    } catch {}
  };

  const handleMarkAllRead = async () => {
    try {
      await markAllDriverNotificationsAsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true, read_at: new Date().toISOString() })));
      setUnreadCount(0);
      showSuccess("All notifications marked as read");
    } catch (err: any) { showError(getErrorMessage(err)); }
  };

  const handleNotificationPress = (item: any) => {
    if (!item.read_at && !item.is_read) void handleMarkRead(item.id);
    const route = getRouteForNotification(item.type, item.data || {});
    if (route) router.push(route as any);
  };

  const getTypeConfig = (type: string) => {
    const key = Object.keys(typeIcons).find((k) => type?.includes(k));
    return typeIcons[key || "default"] || typeIcons.default;
  };

  return (
    <View style={s.container}>
      <LinearGradient colors={["#0f172a", "#1e3a5f", "#0f172a"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
        <View style={s.heroDecor1} />
        <View style={s.heroDecor2} />
        <View style={s.headerRow}>
          <TouchableOpacity onPress={leaveNotifications} style={s.backBtn}>
            <Ionicons name="arrow-back" size={22} color={colors.white} />
          </TouchableOpacity>
          <View style={s.headerIconWrap}><Ionicons name="notifications" size={22} color={colors.white} /></View>
          <View style={{ flex: 1 }}>
            <Text style={s.headerTitle}>Notifications</Text>
            <Text style={s.headerSub}>
              {unreadCount > 0 ? `${unreadCount} unread notification${unreadCount > 1 ? "s" : ""}` : "You're all caught up!"}
            </Text>
          </View>
          {unreadCount > 0 && (
            <TouchableOpacity style={s.markAllBtn} onPress={handleMarkAllRead}>
              <Ionicons name="checkmark-done-outline" size={14} color={colors.white} />
              <Text style={s.markAllText}>Read all</Text>
            </TouchableOpacity>
          )}
        </View>
        <View style={s.filterWrap}>
          {[
            { label: "All", value: "all", count: notifications.length },
            { label: "Unread", value: "unread", count: unreadCount },
            { label: "Read", value: "read", count: readCount },
          ].map((f) => {
            const isActive = f.value === filter;
            return (
              <TouchableOpacity key={f.value} style={[s.filterChip, isActive && s.filterChipActive]} onPress={() => setFilter(f.value)}>
                <Text style={[s.filterText, isActive && s.filterTextActive]}>{f.label}</Text>
                <View style={[s.filterCount, isActive && s.filterCountActive]}>
                  <Text style={[s.filterCountText, isActive && s.filterCountTextActive]}>{f.count}</Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      </LinearGradient>

      {loading && notifications.length === 0 ? (
        <NotificationListSkeleton />
      ) : (
        <FlatList
          data={filteredNotifications}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={s.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchNotifications(); }} colors={[colors.primary]} />}
          ItemSeparatorComponent={null}
          renderItem={({ item, index }) => {
            const isUnread = !item.read_at && !item.is_read;
            const config = getTypeConfig(item.type);

            const prevDate = index > 0 ? new Date(filteredNotifications[index - 1].created_at).toDateString() : null;
            const thisDate = new Date(item.created_at).toDateString();
            const showDateHeader = index === 0 || thisDate !== prevDate;
            const today = new Date().toDateString();
            const yesterday = new Date(Date.now() - 86400000).toDateString();
            const dateLabel = thisDate === today ? "Today" : thisDate === yesterday ? "Yesterday" : new Date(item.created_at).toLocaleDateString("en-GB", { day: "numeric", month: "long" });

            return (
              <>
                {showDateHeader && (
                  <View style={s.dateHeader}>
                    <Text style={s.dateLabel}>{dateLabel}</Text>
                  </View>
                )}
                <TouchableOpacity
                  style={s.notifRow}
                  onPress={() => { handleNotificationPress(item); }}
                  activeOpacity={0.7}
                >
                  {isUnread && <View style={s.unreadDot} />}
                  <View style={s.notifIcon}>
                    <Ionicons name={config.icon} size={18} color={config.color} />
                  </View>
                  <View style={s.notifContent}>
                    <View style={s.notifTitleRow}>
                      <Text style={[s.notifTitle, isUnread && s.notifTitleUnread]} numberOfLines={2}>{item.title}</Text>
                      <Text style={s.notifTime}>{getTimeAgo(item.created_at)}</Text>
                    </View>
                    <Text style={s.notifBody} numberOfLines={2}>{item.body}</Text>
                  </View>
                </TouchableOpacity>
              </>
            );
          }}
          ListEmptyComponent={<EmptyState icon="notifications-off-outline" title="No notifications" subtitle="You're all caught up!" illustration="notifications" />}
        />
      )}
    </View>
  );
}

function NotificationListSkeleton() {
  return (
    <View style={s.skeletonList}>
      <View style={s.skeletonDateHeader}>
        <ShimmerLoading width={54} height={10} borderRadius={5} />
      </View>
      {[0, 1, 2, 3, 4].map((item) => (
        <View key={item} style={s.skeletonNotifRow}>
          <ShimmerLoading width={24} height={24} borderRadius={12} style={s.skeletonIcon} />
          <View style={s.skeletonNotifContent}>
            <View style={s.skeletonTitleRow}>
              <ShimmerLoading width={item % 2 === 0 ? "66%" : "52%"} height={14} borderRadius={7} />
              <ShimmerLoading width={38} height={10} borderRadius={5} />
            </View>
            <ShimmerLoading width={item % 2 === 0 ? "88%" : "74%"} height={11} borderRadius={6} />
            <ShimmerLoading width={item % 3 === 0 ? "58%" : "46%"} height={11} borderRadius={6} />
          </View>
          {item < 2 ? <View style={s.skeletonUnreadDot} /> : null}
        </View>
      ))}
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 16, gap: 12, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  heroDecor2: { position: "absolute", bottom: -60, left: -40, width: width * 0.4, height: width * 0.4, borderWidth: 40, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.2 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerIconWrap: { width: 44, height: 44, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  markAllBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: "rgba(255,255,255,0.12)", paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  markAllText: { fontFamily: fontFamily.medium, fontSize: 11, color: "rgba(255,255,255,0.8)" },
  filterWrap: { flexDirection: "row", gap: 8 },
  filterChip: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "rgba(255,255,255,0.06)", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 7, borderWidth: 1, borderColor: "rgba(255,255,255,0.08)" },
  filterChipActive: { backgroundColor: "rgba(255,255,255,0.15)", borderColor: "rgba(255,255,255,0.25)" },
  filterText: { fontFamily: fontFamily.medium, fontSize: 12, color: "rgba(255,255,255,0.5)" },
  filterTextActive: { color: colors.white },
  filterCount: { backgroundColor: "rgba(255,255,255,0.1)", borderRadius: 10, minWidth: 22, height: 20, justifyContent: "center", alignItems: "center", paddingHorizontal: 5 },
  filterCountActive: { backgroundColor: "rgba(255,255,255,0.2)" },
  filterCountText: { fontFamily: fontFamily.semibold, fontSize: 10, color: "rgba(255,255,255,0.5)" },
  filterCountTextActive: { color: colors.white },
  list: { flexGrow: 1, paddingHorizontal: 16, paddingTop: 8, paddingBottom: 30 },
  dateHeader: { marginTop: 14, marginBottom: 4, alignSelf: "flex-start" },
  dateLabel: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.primary, textTransform: "uppercase", letterSpacing: 0.5 },
  notifRow: { flexDirection: "row", alignItems: "flex-start", gap: 12, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.neutral200 },
  unreadDot: { position: "absolute", top: 18, right: 0, width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary },
  notifIcon: { width: 24, height: 24, justifyContent: "center", alignItems: "center" },
  notifContent: { flex: 1, gap: 4, paddingRight: 14 },
  notifTitleRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  notifTitle: { flex: 1, fontFamily: fontFamily.medium, fontSize: 14, color: colors.dark, lineHeight: 19 },
  notifTitleUnread: { fontFamily: fontFamily.bold },
  notifBody: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, lineHeight: 17 },
  notifTime: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textLight, marginTop: 2 },
  skeletonList: { flexGrow: 1, paddingHorizontal: 16, paddingTop: 8, paddingBottom: 30 },
  skeletonDateHeader: { marginTop: 14, marginBottom: 4, alignSelf: "flex-start" },
  skeletonNotifRow: { flexDirection: "row", alignItems: "flex-start", gap: 12, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.neutral200 },
  skeletonIcon: { backgroundColor: colors.neutral200 },
  skeletonNotifContent: { flex: 1, gap: 7, paddingRight: 14 },
  skeletonTitleRow: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 10 },
  skeletonUnreadDot: { position: "absolute", top: 18, right: 0, width: 8, height: 8, borderRadius: 4, backgroundColor: colors.neutral200 },
});
