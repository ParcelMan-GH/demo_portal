import { useCallback, useMemo, useState } from "react";
import { ActivityIndicator, FlatList, Modal, Pressable, RefreshControl, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../src/components/common/EmptyState";
import ShimmerLoading from "../../src/components/common/ShimmerLoading";
import {
  acceptPackageTransfer,
  cancelPackageTransfer,
  getIncomingPackageTransfers,
  getOutgoingPackageTransfers,
  recallPackageTransfer,
  rejectPackageTransfer,
} from "../../src/api/v1/driver/custody";
import { colors } from "../../src/constants/colors";
import { fontFamily } from "../../src/constants/typography";
import { formatDateTimeAmPm, formatPhone } from "../../src/utils/format";
import { getErrorMessage, showError, showSuccess } from "../../src/utils/toast";

type TransferTab = "incoming" | "outgoing";

interface PackageTransfer {
  id: number;
  status: string;
  tracking_code: string | null;
  description: string | null;
  delivery_town: string | null;
  recipient_name: string | null;
  requested_at: string | null;
  responded_at?: string | null;
  from_driver?: { name: string; phone: string | null } | null;
  to_driver?: { name: string; phone: string | null } | null;
  can_cancel?: boolean;
  can_recall?: boolean;
  is_open?: boolean;
}

export default function PackageTransfersScreen() {
  const insets = useSafeAreaInsets();
  const homeRoute = "/(driver)/(tabs)/home" as const;
  const leavePackageTransfers = () => {
    if (router.canGoBack()) router.back();
    else router.replace(homeRoute as any);
  };
  const [activeTab, setActiveTab] = useState<TransferTab>("incoming");
  const [incoming, setIncoming] = useState<PackageTransfer[]>([]);
  const [outgoing, setOutgoing] = useState<PackageTransfer[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [confirmAction, setConfirmAction] = useState<{ transfer: PackageTransfer; action: "cancel" | "recall" } | null>(null);

  const load = async () => {
    try {
      const [incomingRes, outgoingRes] = await Promise.all([
        getIncomingPackageTransfers(),
        getOutgoingPackageTransfers(),
      ]);
      const incomingData = (incomingRes as any)?.data || incomingRes;
      const outgoingData = (outgoingRes as any)?.data || outgoingRes;
      setIncoming(incomingData?.transfers || []);
      setOutgoing(outgoingData?.transfers || []);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(useCallback(() => {
    setLoading(true);
    load();
  }, []));

  const transfers = activeTab === "incoming" ? incoming : outgoing;
  const incomingCount = incoming.length;
  const outgoingOpenCount = useMemo(
    () => outgoing.filter((transfer) => transfer.is_open === true || transfer.can_cancel === true || transfer.can_recall === true).length,
    [outgoing],
  );

  const respondIncoming = async (transfer: PackageTransfer, action: "accept" | "reject") => {
    setBusyId(transfer.id);
    try {
      if (action === "accept") {
        await acceptPackageTransfer(transfer.id);
        showSuccess("Transfer accepted.");
      } else {
        await rejectPackageTransfer(transfer.id);
        showSuccess("Transfer rejected.");
      }
      await load();
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  const respondOutgoing = (transfer: PackageTransfer, action: "cancel" | "recall") => {
    setConfirmAction({ transfer, action });
  };

  const submitOutgoingAction = async () => {
    if (!confirmAction) return;

    const { transfer, action } = confirmAction;
    const isRecall = action === "recall";
    setBusyId(transfer.id);
    try {
      if (isRecall) {
        await recallPackageTransfer(transfer.id);
        showSuccess("Transfer recalled.");
      } else {
        await cancelPackageTransfer(transfer.id);
        showSuccess("Transfer cancelled.");
      }
      setConfirmAction(null);
      await load();
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  if (loading && incoming.length === 0 && outgoing.length === 0) {
    return (
      <View style={s.container}>
        <LinearGradient colors={["#1e293b", "#334155", "#1e293b"]} style={[s.header, { paddingTop: insets.top + 14 }]}>
          <View style={s.headerRow}>
            <View style={s.backBtn}><ShimmerLoading width={18} height={18} borderRadius={9} style={{ backgroundColor: "rgba(255,255,255,0.2)" }} /></View>
            <View style={{ gap: 8 }}>
              <ShimmerLoading width={170} height={24} borderRadius={8} style={{ backgroundColor: "rgba(255,255,255,0.2)" }} />
              <ShimmerLoading width={130} height={12} borderRadius={6} style={{ backgroundColor: "rgba(255,255,255,0.16)" }} />
            </View>
          </View>
        </LinearGradient>
      </View>
    );
  }

  return (
    <View style={s.container}>
      <LinearGradient colors={["#1e293b", "#334155", "#1e293b"]} style={[s.header, { paddingTop: insets.top + 14 }]}>
        <View style={s.headerRow}>
          <TouchableOpacity style={s.backBtn} onPress={leavePackageTransfers} activeOpacity={0.75}>
            <Ionicons name="arrow-back" size={20} color={colors.white} />
          </TouchableOpacity>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={s.title}>Package Transfers</Text>
            <Text style={s.sub}>{incomingCount} incoming · {outgoingOpenCount} outgoing open</Text>
          </View>
        </View>
      </LinearGradient>

      <View style={s.tabsWrap}>
        <TransferTabButton label="Incoming" count={incomingCount} active={activeTab === "incoming"} onPress={() => setActiveTab("incoming")} />
        <TransferTabButton label="Outgoing" count={outgoingOpenCount} active={activeTab === "outgoing"} onPress={() => setActiveTab("outgoing")} />
      </View>

      <FlatList
        data={transfers}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={[s.list, { paddingBottom: insets.bottom + 24 }]}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} colors={[colors.primary]} />}
        ListEmptyComponent={(
          <EmptyState
            icon="swap-horizontal-outline"
            title={activeTab === "incoming" ? "No incoming transfers" : "No outgoing transfers"}
            subtitle={activeTab === "incoming" ? "Transfer requests sent to you will appear here." : "Transfers you send to other riders will appear here."}
            illustration="onTheWay"
          />
        )}
        renderItem={({ item }) => (
          <TransferCard
            transfer={item}
            tab={activeTab}
            busy={busyId === item.id}
            onIncoming={respondIncoming}
            onOutgoing={respondOutgoing}
          />
        )}
      />

      <TransferConfirmModal
        visible={!!confirmAction}
        transfer={confirmAction?.transfer || null}
        action={confirmAction?.action || "cancel"}
        loading={!!confirmAction && busyId === confirmAction.transfer.id}
        onCancel={() => setConfirmAction(null)}
        onConfirm={submitOutgoingAction}
      />
    </View>
  );
}

function TransferTabButton({ label, count, active, onPress }: { label: string; count: number; active: boolean; onPress: () => void }) {
  return (
    <TouchableOpacity style={[s.tabBtn, active && s.tabBtnActive]} onPress={onPress} activeOpacity={0.75}>
      <Text style={[s.tabText, active && s.tabTextActive]}>{label}</Text>
      <View style={[s.tabBadge, active && s.tabBadgeActive]}>
        <Text style={[s.tabBadgeText, active && s.tabBadgeTextActive]}>{count}</Text>
      </View>
    </TouchableOpacity>
  );
}

function TransferCard({
  transfer,
  tab,
  busy,
  onIncoming,
  onOutgoing,
}: {
  transfer: PackageTransfer;
  tab: TransferTab;
  busy: boolean;
  onIncoming: (transfer: PackageTransfer, action: "accept" | "reject") => void;
  onOutgoing: (transfer: PackageTransfer, action: "cancel" | "recall") => void;
}) {
  const status = String(transfer.status || "pending").toLowerCase();
  const otherDriver = tab === "incoming" ? transfer.from_driver : transfer.to_driver;
  const otherLabel = tab === "incoming" ? "From" : "To";
  const canCancel = tab === "outgoing" && transfer.can_cancel === true;
  const canRecall = tab === "outgoing" && transfer.can_recall === true;

  return (
    <View style={s.card}>
      <View style={s.cardTop}>
        <View style={s.cardIcon}><Ionicons name="cube" size={20} color={colors.primary} /></View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <View style={s.titleRow}>
            <Text style={s.cardTitle} numberOfLines={1}>{transfer.description || "Package"}</Text>
            <StatusPill status={status} />
          </View>
          <Text style={s.cardCode}>{transfer.tracking_code || "-"}</Text>
        </View>
      </View>
      <View style={s.metaBlock}>
        <InfoRow icon="person-outline" text={`${otherLabel}: ${otherDriver ? `${otherDriver.name}${otherDriver.phone ? ` · ${formatPhone(otherDriver.phone)}` : ""}` : "Rider"}`} />
        <InfoRow icon="location-outline" text={transfer.delivery_town || "No delivery location"} />
        <InfoRow icon="time-outline" text={transfer.requested_at ? formatDateTimeAmPm(transfer.requested_at) : "Just now"} />
      </View>

      {tab === "incoming" && status === "pending" ? (
        <View style={s.actions}>
          <TouchableOpacity style={[s.rejectBtn, busy && s.disabled]} disabled={busy} onPress={() => onIncoming(transfer, "reject")}>
            <Text style={s.rejectText}>Reject</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.acceptBtn, busy && s.disabled]} disabled={busy} onPress={() => onIncoming(transfer, "accept")}>
            <Text style={s.acceptText}>{busy ? "Working..." : "Accept"}</Text>
          </TouchableOpacity>
        </View>
      ) : null}

      {(canCancel || canRecall) ? (
        <View style={s.actions}>
          <TouchableOpacity
            style={[canRecall ? s.recallBtn : s.rejectBtn, busy && s.disabled]}
            disabled={busy}
            onPress={() => onOutgoing(transfer, canRecall ? "recall" : "cancel")}
          >
            <Ionicons name={canRecall ? "return-up-back" : "close"} size={16} color={canRecall ? colors.primary : colors.dark} />
            <Text style={canRecall ? s.recallText : s.rejectText}>{busy ? "Working..." : canRecall ? "Recall" : "Cancel request"}</Text>
          </TouchableOpacity>
        </View>
      ) : null}
    </View>
  );
}

function TransferConfirmModal({
  visible,
  transfer,
  action,
  loading,
  onCancel,
  onConfirm,
}: {
  visible: boolean;
  transfer: PackageTransfer | null;
  action: "cancel" | "recall";
  loading: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  const isRecall = action === "recall";

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <Pressable style={s.confirmOverlay} onPress={onCancel}>
        <Pressable style={s.confirmCard} onPress={(event) => event.stopPropagation()}>
          <View style={s.confirmHeader}>
            <View style={[s.confirmIcon, isRecall ? s.confirmIconRecall : s.confirmIconCancel]}>
              <Ionicons name={isRecall ? "return-up-back" : "close"} size={24} color={isRecall ? colors.primary : colors.errorDark} />
            </View>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={s.confirmTitle}>{isRecall ? "Recall Transfer?" : "Cancel Transfer?"}</Text>
              <Text style={s.confirmMessage}>
                {isRecall
                  ? "Move this package back to your custody if delivery has not started."
                  : "Cancel this pending request before the other rider accepts."}
              </Text>
            </View>
          </View>

          <View style={s.confirmPackage}>
            <Text style={s.confirmPackageName} numberOfLines={1}>{transfer?.description || "Package"}</Text>
            <Text style={s.confirmPackageCode} numberOfLines={1}>{transfer?.tracking_code || "-"}</Text>
            <Text style={s.confirmPackageMeta} numberOfLines={1}>
              To: {transfer?.to_driver?.name || "Rider"}{transfer?.to_driver?.phone ? ` · ${formatPhone(transfer.to_driver.phone)}` : ""}
            </Text>
          </View>

          <View style={s.confirmFooter}>
            <TouchableOpacity style={s.confirmCancelBtn} onPress={onCancel} disabled={loading} activeOpacity={0.8}>
              <Text style={s.confirmCancelText}>Keep</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[s.confirmPrimaryBtn, loading && s.disabled]} onPress={onConfirm} disabled={loading} activeOpacity={0.8}>
              {loading ? (
                <ActivityIndicator size="small" color={colors.white} />
              ) : (
                <Text style={s.confirmPrimaryText}>{isRecall ? "Recall" : "Cancel request"}</Text>
              )}
            </TouchableOpacity>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

function StatusPill({ status }: { status: string }) {
  const isOpen = ["pending", "accepted"].includes(status);
  return (
    <View style={[s.statusPill, isOpen ? s.statusPillOpen : s.statusPillClosed]}>
      <Text style={[s.statusText, isOpen ? s.statusTextOpen : s.statusTextClosed]}>{statusLabel(status)}</Text>
    </View>
  );
}

function InfoRow({ icon, text }: { icon: keyof typeof Ionicons.glyphMap; text: string }) {
  return (
    <View style={s.infoRow}>
      <Ionicons name={icon} size={14} color={colors.textMuted} />
      <Text style={s.infoText}>{text}</Text>
    </View>
  );
}

function statusLabel(status: string) {
  return status.replace(/_/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 16, paddingBottom: 18 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 44, height: 44, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  title: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white },
  sub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.62)", marginTop: 2 },
  tabsWrap: { flexDirection: "row", gap: 10, padding: 16, paddingBottom: 0 },
  tabBtn: { flex: 1, minHeight: 48, borderRadius: 15, borderWidth: 1.5, borderColor: colors.border, backgroundColor: colors.white, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  tabBtnActive: { backgroundColor: colors.primary, borderColor: colors.primary, shadowColor: colors.primary, shadowOpacity: 0.18, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, elevation: 3 },
  tabText: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.textMuted },
  tabTextActive: { color: colors.white },
  tabBadge: { minWidth: 24, height: 24, borderRadius: 12, paddingHorizontal: 7, alignItems: "center", justifyContent: "center", backgroundColor: colors.neutral100 },
  tabBadgeActive: { backgroundColor: "rgba(255,255,255,0.2)" },
  tabBadgeText: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.textMuted },
  tabBadgeTextActive: { color: colors.white },
  list: { flexGrow: 1, padding: 16, gap: 12 },
  card: { backgroundColor: colors.white, borderRadius: 18, padding: 16, borderWidth: 1, borderColor: colors.border, shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 2 },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  cardIcon: { width: 46, height: 46, borderRadius: 14, backgroundColor: colors.warmSurface, justifyContent: "center", alignItems: "center" },
  titleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  cardTitle: { flex: 1, fontFamily: fontFamily.bold, fontSize: 16, color: colors.dark },
  cardCode: { fontFamily: "monospace", fontSize: 12, color: colors.textMuted, marginTop: 2 },
  statusPill: { borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 },
  statusPillOpen: { backgroundColor: colors.warmSurface },
  statusPillClosed: { backgroundColor: colors.neutral100 },
  statusText: { fontFamily: fontFamily.bold, fontSize: 11 },
  statusTextOpen: { color: colors.primary },
  statusTextClosed: { color: colors.textMuted },
  metaBlock: { marginTop: 14, gap: 7, borderLeftWidth: 2, borderLeftColor: colors.neutral200, paddingLeft: 12 },
  infoRow: { flexDirection: "row", alignItems: "flex-start", gap: 7 },
  infoText: { flex: 1, fontFamily: fontFamily.regular, fontSize: 13, color: colors.textMuted, lineHeight: 18 },
  actions: { flexDirection: "row", gap: 10, marginTop: 16 },
  rejectBtn: { flex: 1, minHeight: 46, borderRadius: 14, borderWidth: 1.5, borderColor: colors.border, justifyContent: "center", alignItems: "center", flexDirection: "row", gap: 6 },
  rejectText: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  recallBtn: { flex: 1, minHeight: 46, borderRadius: 14, borderWidth: 1.5, borderColor: colors.accentLighter, backgroundColor: colors.warmSurface, justifyContent: "center", alignItems: "center", flexDirection: "row", gap: 6 },
  recallText: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.primary },
  acceptBtn: { flex: 1.2, minHeight: 46, borderRadius: 14, backgroundColor: colors.primary, justifyContent: "center", alignItems: "center" },
  acceptText: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.white },
  confirmOverlay: { flex: 1, backgroundColor: "rgba(15,23,42,0.58)", justifyContent: "center", padding: 22 },
  confirmCard: { backgroundColor: colors.white, borderRadius: 28, overflow: "hidden", shadowColor: colors.black, shadowOpacity: 0.22, shadowRadius: 24, shadowOffset: { width: 0, height: 14 }, elevation: 12 },
  confirmHeader: { flexDirection: "row", alignItems: "center", gap: 14, padding: 20, paddingBottom: 16 },
  confirmIcon: { width: 60, height: 60, borderRadius: 18, justifyContent: "center", alignItems: "center" },
  confirmIconCancel: { backgroundColor: colors.errorLight },
  confirmIconRecall: { backgroundColor: colors.warmSurface },
  confirmTitle: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.dark, letterSpacing: -0.2 },
  confirmMessage: { fontFamily: fontFamily.regular, fontSize: 14, color: colors.textMuted, lineHeight: 20, marginTop: 3 },
  confirmPackage: { marginHorizontal: 20, marginBottom: 18, borderRadius: 18, borderWidth: 1.5, borderColor: colors.border, backgroundColor: colors.surface, padding: 16, gap: 3 },
  confirmPackageName: { fontFamily: fontFamily.bold, fontSize: 16, color: colors.dark },
  confirmPackageCode: { fontFamily: "monospace", fontSize: 13, color: colors.textMuted },
  confirmPackageMeta: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.textMuted, marginTop: 4 },
  confirmFooter: { flexDirection: "row", gap: 12, borderTopWidth: 1, borderTopColor: colors.border, backgroundColor: colors.surface, padding: 20 },
  confirmCancelBtn: { flex: 1, minHeight: 54, borderRadius: 16, backgroundColor: colors.white, borderWidth: 1.5, borderColor: colors.border, justifyContent: "center", alignItems: "center" },
  confirmCancelText: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark },
  confirmPrimaryBtn: { flex: 1.25, minHeight: 54, borderRadius: 16, backgroundColor: colors.primary, justifyContent: "center", alignItems: "center", shadowColor: colors.primary, shadowOpacity: 0.2, shadowRadius: 10, shadowOffset: { width: 0, height: 5 }, elevation: 4 },
  confirmPrimaryText: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.white },
  disabled: { opacity: 0.65 },
});
