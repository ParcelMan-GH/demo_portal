import { useCallback, useState } from "react";
import { ActivityIndicator, Alert, Dimensions, KeyboardAvoidingView, Modal, Platform, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { router, useFocusEffect, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../../src/components/common/EmptyState";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import Input from "../../../src/components/common/Input";
import { addRiderTeamMember, getRiderTeam, getRiderTeamHandovers, lookupRiderTeamMember, removeRiderTeamMember } from "../../../src/api/v1/driver/rider-teams";
import type { RiderTeam, RiderTeamHandover, RiderTeamMember } from "../../../src/types/driver";
import { isValidGhanaPhone, sanitizeLocalPhoneInput, toApiPhone } from "../../../src/utils/format";
import { getErrorMessage, showError, showSuccess } from "../../../src/utils/toast";

const { height: screenHeight } = Dimensions.get("window");

export default function RiderTeamDetailScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const teamsRoute = "/(driver)/teams" as const;
  const leaveTeamDetail = () => {
    if (router.canGoBack()) router.back();
    else router.replace(teamsRoute as any);
  };
  const [team, setTeam] = useState<RiderTeam | null>(null);
  const [handovers, setHandovers] = useState<RiderTeamHandover[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [phone, setPhone] = useState("");
  const [phoneError, setPhoneError] = useState("");
  const [adding, setAdding] = useState(false);
  const [addMemberOpen, setAddMemberOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"handovers" | "members">("handovers");

  const load = async () => {
    try {
      const [teamRes, handoversRes] = await Promise.all([
        getRiderTeam(String(id)),
        getRiderTeamHandovers({ limit: 50 }),
      ]);
      const loadedTeam = teamRes?.data?.team || null;
      setTeam(loadedTeam);
      const allHandovers: RiderTeamHandover[] = handoversRes?.data?.handovers || [];
      setHandovers(allHandovers.filter((handover) => Number(handover.team?.id) === Number(loadedTeam?.id)));
    } catch (err: any) {
      showError(getErrorMessage(err, "Could not load rider team"));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(useCallback(() => { load(); }, [id]));

  const canManage = team?.role === "leader";

  const addMember = async () => {
    const value = phone.trim();
    if (!value || !team) return;
    if (!isValidGhanaPhone(value)) {
      setPhoneError("Enter a valid 10-digit Ghana phone number");
      return;
    }
    setPhoneError("");
    setAdding(true);
    try {
      const lookup = await lookupRiderTeamMember(team.id, toApiPhone(value));
      const rider = lookup?.data?.rider;
      await addRiderTeamMember(team.id, { driver_id: rider.id, role: "member" });
      setPhone("");
      setPhoneError("");
      setAddMemberOpen(false);
      showSuccess("Rider added to team");
      load();
    } catch (err: any) {
      setPhoneError(getErrorMessage(err, "No registered rider found with this phone number"));
    } finally {
      setAdding(false);
    }
  };

  const removeMember = (member: RiderTeamMember) => {
    if (!team || !member.driver) return;
    Alert.alert("Remove rider", `Remove ${member.driver.name} from this team?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Remove",
        style: "destructive",
        onPress: async () => {
          try {
            await removeRiderTeamMember(team.id, member.driver!.id);
            showSuccess("Rider removed");
            load();
          } catch (err: any) {
            showError(getErrorMessage(err, "Could not remove rider"));
          }
        },
      },
    ]);
  };

  const heldCount = team?.totals.still_with_leader ?? team?.totals.with_receiver ?? 0;

  return (
    <View style={s.screen}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} colors={[colors.primary]} />}
        showsVerticalScrollIndicator={false}
      >
        <LinearGradient
          colors={["#0f172a", "#1e293b", "#0f172a"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[s.hero, { paddingTop: insets.top + 14 }]}
        >
          <View style={s.heroDecor1} />
          <View style={s.heroDecor2} />
          <View style={s.headerTop}>
            <TouchableOpacity style={s.backBtn} onPress={leaveTeamDetail} activeOpacity={0.72}>
              <Ionicons name="arrow-back" size={22} color={colors.white} />
            </TouchableOpacity>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={s.title} numberOfLines={1}>{team?.name || "Rider Team"}</Text>
              <Text style={s.subtitle} numberOfLines={1}>{team?.warehouse?.name || (team?.role === "leader" ? "Leader workspace" : "Team summary")}</Text>
            </View>
            {team?.role ? (
              <View style={[s.heroRolePill, team.role === "leader" && s.heroRolePillLeader]}>
                <Text style={[s.heroRoleText, team.role === "leader" && s.heroRoleTextLeader]}>{team.role}</Text>
              </View>
            ) : null}
          </View>

          {loading ? (
            <View style={s.heroLoading}><ActivityIndicator color={colors.white} /></View>
          ) : (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.statStrip}>
              <HeroSummaryCard label="Assigned" value={team?.totals.assigned || 0} icon="archive-outline" />
              <HeroSummaryCard label="Received" value={team?.totals.received || 0} icon="download-outline" />
              <HeroSummaryCard label="Held" value={heldCount} icon="person-outline" />
              <HeroSummaryCard label="Claimed" value={team?.totals.claimed || 0} icon="checkmark-done-outline" />
              <HeroSummaryCard label="Delivered" value={team?.totals.delivered || 0} icon="flag-outline" />
            </ScrollView>
          )}
        </LinearGradient>

        <View style={s.content}>
          {loading ? (
            <View style={s.loading}><ActivityIndicator color={colors.primary} /></View>
          ) : (
            <>
              <View style={s.tabsCard}>
                <TabButton
                  label="Handovers"
                  count={handovers.length}
                  active={activeTab === "handovers"}
                  onPress={() => setActiveTab("handovers")}
                />
                <TabButton
                  label="Members"
                  count={(team?.members || []).length}
                  active={activeTab === "members"}
                  onPress={() => setActiveTab("members")}
                />
              </View>

              {activeTab === "handovers" ? (
                <HandoverList handovers={handovers} />
              ) : (
                <MembersList
                  members={team?.members || []}
                  canManage={Boolean(canManage)}
                  onAdd={() => setAddMemberOpen(true)}
                  onRemove={removeMember}
                />
              )}
            </>
          )}
        </View>
      </ScrollView>

      <AddMemberModal
        visible={addMemberOpen}
        phone={phone}
        phoneError={phoneError}
        adding={adding}
        onPhoneChange={(value) => {
          const next = sanitizeLocalPhoneInput(value);
          setPhone(next);
          setPhoneError(next.length === 10 && !isValidGhanaPhone(next) ? "Enter a valid 10-digit Ghana phone number" : "");
        }}
        onClose={() => {
          if (adding) return;
          setAddMemberOpen(false);
          setPhone("");
          setPhoneError("");
        }}
        onSubmit={addMember}
      />
    </View>
  );
}

function HeroSummaryCard({ label, value, icon }: { label: string; value: number; icon: keyof typeof Ionicons.glyphMap }) {
  return (
    <View style={s.heroSummaryCard}>
      <View style={s.heroSummaryIcon}>
        <Ionicons name={icon} size={17} color={colors.white} />
      </View>
      <Text style={s.heroSummaryValue}>{value}</Text>
      <Text style={s.heroSummaryLabel} numberOfLines={1}>{label}</Text>
    </View>
  );
}

function TabButton({
  label,
  count,
  active,
  onPress,
}: {
  label: "Handovers" | "Members";
  count: number;
  active: boolean;
  onPress: () => void;
}) {
  return (
    <TouchableOpacity style={[s.tabButton, active && s.tabButtonActive]} onPress={onPress} activeOpacity={0.72}>
      <Ionicons name={label === "Handovers" ? "file-tray-full-outline" : "people-outline"} size={16} color={active ? colors.white : colors.textMuted} />
      <Text style={[s.tabText, active && s.tabTextActive]}>{label}</Text>
      <View style={[s.tabCount, active && s.tabCountActive]}>
        <Text style={[s.tabCountText, active && s.tabCountTextActive]}>{count}</Text>
      </View>
    </TouchableOpacity>
  );
}

function HandoverList({ handovers }: { handovers: RiderTeamHandover[] }) {
  if (handovers.length === 0) {
    return (
      <View style={s.handoverEmptyWrap}>
        <EmptyState
          icon="file-tray-full-outline"
          title="No handovers yet"
          subtitle="Team handovers will appear here when packages are assigned."
          illustration="packages"
          compact
          minHeight={screenHeight * 0.52}
        />
      </View>
    );
  }

  return (
    <View style={s.listCard}>
      {handovers.map((handover, index) => (
        <TouchableOpacity
          key={handover.id}
          style={s.listRow}
          onPress={() =>
            router.push({
              pathname: "/(driver)/team-handover/[id]",
              params: { id: String(handover.id) },
            } as any)
          }
          activeOpacity={0.72}
        >
          <View style={s.handoverIcon}>
            <Ionicons name="file-tray-full-outline" size={18} color={colors.primary} />
          </View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={s.handoverTitle} numberOfLines={1}>{handover.handover_number}</Text>
            <Text style={s.handoverMeta} numberOfLines={1}>{String(handover.status || "pending").replaceAll("_", " ")}</Text>
          </View>
          <View style={s.handoverCountPill}>
            <Text style={s.handoverCount}>{handover.counts?.assigned || 0}</Text>
          </View>
          {index < handovers.length - 1 ? <View style={s.rowDivider} /> : null}
        </TouchableOpacity>
      ))}
    </View>
  );
}

function MembersList({
  members,
  canManage,
  onAdd,
  onRemove,
}: {
  members: RiderTeamMember[];
  canManage: boolean;
  onAdd: () => void;
  onRemove: (member: RiderTeamMember) => void;
}) {
  return (
    <View style={s.listCard}>
      <View style={s.membersHeader}>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.membersHeaderTitle}>Team Members</Text>
          <Text style={s.membersHeaderSub}>{canManage ? "Manage registered riders in this team." : "Team member list."}</Text>
        </View>
        {canManage ? (
          <TouchableOpacity style={s.addMemberBtn} onPress={onAdd} activeOpacity={0.72}>
            <Ionicons name="add" size={16} color={colors.white} />
            <Text style={s.addMemberText}>Add</Text>
          </TouchableOpacity>
        ) : null}
      </View>

      {members.length === 0 ? (
        <View style={s.inlineEmpty}>
          <EmptyState
            icon="people-outline"
            title={canManage ? "No members yet" : "Members hidden"}
            subtitle={canManage ? "Add registered riders to this team." : "Only team leaders can view members."}
            illustration="team"
            compact
          />
        </View>
      ) : members.map((member, index) => (
        <View key={member.id} style={s.memberRow}>
          <View style={s.avatar}><Ionicons name={member.role === "leader" ? "star" : "person"} size={18} color={colors.primary} /></View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={s.memberName} numberOfLines={1}>{member.driver?.name || "-"}</Text>
            <Text style={s.memberPhone}>{member.driver?.phone || "-"}</Text>
          </View>
          <Text style={s.memberRole}>{member.role}</Text>
          {canManage && member.role !== "leader" ? (
            <TouchableOpacity style={s.removeBtn} onPress={() => onRemove(member)}>
              <Ionicons name="close" size={18} color="#e11d48" />
            </TouchableOpacity>
          ) : null}
          {index < members.length - 1 ? <View style={s.rowDivider} /> : null}
        </View>
      ))}
    </View>
  );
}

function AddMemberModal({
  visible,
  phone,
  phoneError,
  adding,
  onPhoneChange,
  onClose,
  onSubmit,
}: {
  visible: boolean;
  phone: string;
  phoneError: string;
  adding: boolean;
  onPhoneChange: (value: string) => void;
  onClose: () => void;
  onSubmit: () => void;
}) {
  const phoneDigits = sanitizeLocalPhoneInput(phone);
  const phoneHelper = phoneDigits.length === 0
    ? "Enter the rider's registered phone number."
    : phoneDigits.length < 10
      ? `${phoneDigits.length}/10 digits entered`
      : !isValidGhanaPhone(phoneDigits)
        ? "Enter a valid Ghana phone number, e.g. 0551234567"
        : "Registered riders only.";
  const canSubmit = isValidGhanaPhone(phoneDigits) && !adding;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={s.modalRoot}>
        <Pressable style={s.modalOverlay} onPress={onClose}>
          <Pressable style={s.modalCard} onPress={(event) => event.stopPropagation()}>
            <View style={s.modalHeader}>
              <View style={s.modalIcon}>
                <Ionicons name="person-add-outline" size={24} color={colors.white} />
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={s.modalTitle}>Add Team Member</Text>
                <Text style={s.modalSub}>Find a registered rider by phone.</Text>
              </View>
              <TouchableOpacity style={s.modalCloseBtn} onPress={onClose} disabled={adding}>
                <Ionicons name="close" size={22} color={colors.textMuted} />
              </TouchableOpacity>
            </View>

            <View style={s.modalBody}>
              <View style={s.memberLookupBox}>
                <Input
                  label="Rider Phone"
                  required
                  placeholder="e.g. 0551234567"
                  value={phone}
                  onChangeText={onPhoneChange}
                  keyboardType="phone-pad"
                  maxLength={10}
                  autoFocus
                  error={phoneError}
                  leftIcon={<Ionicons name="call-outline" size={18} color={colors.textMuted} />}
                />
                {!!phoneHelper && !phoneError && (
                  <View style={s.phoneHelperRow}>
                    <Ionicons name="information-circle-outline" size={14} color={colors.textMuted} />
                    <Text style={s.phoneHelperText}>{phoneHelper}</Text>
                  </View>
                )}
              </View>
              <View style={s.memberLookupHint}>
                <Ionicons name="shield-checkmark-outline" size={16} color={colors.primary} />
                <Text style={s.memberLookupHintText}>Only active riders already registered in Parcelman can be added.</Text>
              </View>
            </View>

            <View style={s.modalFooter}>
              <TouchableOpacity style={s.modalCancelBtn} onPress={onClose} disabled={adding}>
                <Text style={s.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.modalSaveBtn, !canSubmit && s.disabled]} onPress={onSubmit} disabled={!canSubmit}>
                {adding ? <ActivityIndicator size="small" color={colors.white} /> : <Text style={s.modalSaveText}>Add Member</Text>}
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  hero: { paddingHorizontal: 18, paddingBottom: 18, gap: 16, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -72, right: -76, width: 220, height: 220, borderRadius: 110, borderWidth: 48, borderColor: "rgba(255,255,255,0.035)" },
  heroDecor2: { position: "absolute", bottom: -96, left: -82, width: 210, height: 210, borderRadius: 105, borderWidth: 44, borderColor: "rgba(249,115,22,0.06)" },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 44, height: 44, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.1)", borderWidth: 1, borderColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" },
  title: { fontFamily: fontFamily.extrabold, fontSize: 26, color: colors.white },
  subtitle: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 13, color: "rgba(255,255,255,0.68)" },
  heroRolePill: { borderRadius: 999, backgroundColor: "rgba(255,255,255,0.12)", borderWidth: 1, borderColor: "rgba(255,255,255,0.12)", paddingHorizontal: 11, paddingVertical: 7 },
  heroRolePillLeader: { backgroundColor: "rgba(249,115,22,0.16)", borderColor: "rgba(253,186,116,0.25)" },
  heroRoleText: { fontFamily: fontFamily.extrabold, fontSize: 11, color: "rgba(255,255,255,0.72)", textTransform: "capitalize" },
  heroRoleTextLeader: { color: "#fdba74" },
  heroLoading: { height: 108, alignItems: "center", justifyContent: "center" },
  statStrip: { gap: 8, paddingRight: 4 },
  heroSummaryCard: { width: 82, minHeight: 86, borderRadius: 15, borderWidth: 1, borderColor: "rgba(255,255,255,0.14)", backgroundColor: "rgba(255,255,255,0.1)", padding: 9, justifyContent: "center", alignItems: "center", gap: 5 },
  heroSummaryIcon: { width: 30, height: 30, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.16)", justifyContent: "center", alignItems: "center" },
  heroSummaryValue: { width: "100%", fontFamily: fontFamily.bold, fontSize: 20, color: colors.white, textAlign: "center" },
  heroSummaryLabel: { fontFamily: fontFamily.semibold, fontSize: 9, color: "rgba(255,255,255,0.76)", textAlign: "center" },
  loading: { minHeight: 220, borderRadius: 22, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" },
  content: { padding: 16, gap: 12 },
  tabsCard: { flexDirection: "row", gap: 8, borderRadius: 18, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, padding: 6 },
  tabButton: { flex: 1, minHeight: 48, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: 8 },
  tabButtonActive: { backgroundColor: colors.primary },
  tabText: { fontFamily: fontFamily.extrabold, fontSize: 12, color: colors.textMuted },
  tabTextActive: { color: colors.white },
  tabCount: { minWidth: 22, height: 22, borderRadius: 11, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center", paddingHorizontal: 5 },
  tabCountActive: { backgroundColor: "rgba(255,255,255,0.18)" },
  tabCountText: { fontFamily: fontFamily.extrabold, fontSize: 10, color: colors.textMuted },
  tabCountTextActive: { color: colors.white },
  disabled: { opacity: 0.55 },
  listCard: { borderRadius: 20, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, overflow: "hidden" },
  handoverEmptyWrap: { flexGrow: 1, alignItems: "center", justifyContent: "center" },
  listRow: { minHeight: 74, flexDirection: "row", alignItems: "center", gap: 10, padding: 14 },
  rowDivider: { position: "absolute", left: 68, right: 14, bottom: 0, height: StyleSheet.hairlineWidth, backgroundColor: colors.border },
  handoverIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  handoverTitle: { fontFamily: fontFamily.extrabold, fontSize: 12.5, color: colors.dark, letterSpacing: -0.2 },
  handoverMeta: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted, textTransform: "capitalize" },
  handoverCountPill: { minWidth: 42, height: 42, borderRadius: 14, backgroundColor: colors.surface, paddingHorizontal: 8, alignItems: "center", justifyContent: "center" },
  handoverCount: { fontFamily: fontFamily.extrabold, fontSize: 17, color: colors.primary },
  membersHeader: { minHeight: 72, flexDirection: "row", alignItems: "center", gap: 12, padding: 14, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  membersHeaderTitle: { fontFamily: fontFamily.extrabold, fontSize: 16, color: colors.dark },
  membersHeaderSub: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  addMemberBtn: { minHeight: 38, flexDirection: "row", alignItems: "center", gap: 4, borderRadius: 13, backgroundColor: colors.primary, paddingHorizontal: 12 },
  addMemberText: { fontFamily: fontFamily.extrabold, fontSize: 12, color: colors.white },
  memberRow: { minHeight: 72, flexDirection: "row", alignItems: "center", gap: 12, padding: 14 },
  avatar: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#fff7ed", alignItems: "center", justifyContent: "center" },
  memberName: { fontFamily: fontFamily.extrabold, fontSize: 16, color: colors.dark },
  memberPhone: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  memberRole: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.primary, textTransform: "capitalize" },
  removeBtn: { width: 36, height: 36, borderRadius: 12, borderWidth: 1, borderColor: "#fecdd3", alignItems: "center", justifyContent: "center" },
  inlineEmpty: { padding: 14 },
  modalRoot: { flex: 1 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(15,23,42,0.58)", justifyContent: "center", padding: 18 },
  modalCard: { borderRadius: 28, backgroundColor: colors.white, overflow: "hidden" },
  modalHeader: { flexDirection: "row", alignItems: "center", gap: 12, padding: 18, borderBottomWidth: 1, borderBottomColor: colors.border },
  modalIcon: { width: 56, height: 56, borderRadius: 18, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
  modalTitle: { fontFamily: fontFamily.extrabold, fontSize: 22, color: colors.dark },
  modalSub: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 13, color: colors.textMuted },
  modalCloseBtn: { width: 42, height: 42, borderRadius: 14, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" },
  modalBody: { padding: 18, gap: 12 },
  memberLookupBox: { borderRadius: 20, borderWidth: 1, borderColor: colors.accentLighter, backgroundColor: "#fffaf2", padding: 12 },
  phoneHelperRow: { marginTop: 9, flexDirection: "row", alignItems: "center", gap: 5 },
  phoneHelperText: { flex: 1, fontFamily: fontFamily.medium, fontSize: 11, color: colors.textMuted },
  memberLookupHint: { flexDirection: "row", alignItems: "flex-start", gap: 7, borderRadius: 16, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, padding: 12 },
  memberLookupHintText: { flex: 1, fontFamily: fontFamily.medium, fontSize: 12, lineHeight: 17, color: colors.textMuted },
  modalFooter: { flexDirection: "row", gap: 10, padding: 18, borderTopWidth: 1, borderTopColor: colors.border },
  modalCancelBtn: { flex: 1, minHeight: 52, borderRadius: 16, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" },
  modalCancelText: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.text },
  modalSaveBtn: { flex: 1.25, minHeight: 52, borderRadius: 16, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
  modalSaveText: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.white },
});
