import { useCallback, useState } from "react";
import { RefreshControl, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../../src/components/common/EmptyState";
import ShimmerLoading from "../../../src/components/common/ShimmerLoading";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { getRiderTeams } from "../../../src/api/v1/driver/rider-teams";
import type { RiderTeam } from "../../../src/types/driver";
import { getErrorMessage, showError } from "../../../src/utils/toast";

export default function RiderTeamsScreen() {
  const insets = useSafeAreaInsets();
  const homeRoute = "/(driver)/(tabs)/home" as const;
  const leaveTeams = () => {
    if (router.canGoBack()) router.back();
    else router.replace(homeRoute as any);
  };
  const [teams, setTeams] = useState<RiderTeam[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    try {
      const teamsRes = await getRiderTeams();
      setTeams(teamsRes?.data?.teams || []);
    } catch (err: any) {
      showError(getErrorMessage(err, "Could not load rider teams"));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(useCallback(() => { load(); }, []));

  return (
    <View style={s.screen}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} colors={[colors.primary]} />}
        showsVerticalScrollIndicator={false}
      >
        <LinearGradient
          colors={["#0f172a", "#1e293b", "#0f172a"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[s.hero, { paddingTop: insets.top + 14 }]}
        >
          <View style={s.heroDecor1} />
          <View style={s.heroDecor2} />
          <View style={s.headerTop}>
            <TouchableOpacity style={s.backBtn} onPress={leaveTeams} activeOpacity={0.72}>
              <Ionicons name="arrow-back" size={22} color={colors.white} />
            </TouchableOpacity>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={s.title}>Rider Teams</Text>
              <Text style={s.subtitle} numberOfLines={1}>Team custody and handovers</Text>
            </View>
          </View>

        </LinearGradient>

        <View style={s.content}>
          {loading ? (
            <TeamListSkeleton />
          ) : (
            <>
              <SectionHeader title="My Teams" count={teams.length} />
              {teams.length === 0 ? (
                <EmptyState
                  icon="people-outline"
                  title="No rider teams yet"
                  subtitle="Teams assigned to you will show here."
                  illustration="team"
                  compact
                />
              ) : teams.map((team) => (
                <TeamCard key={team.id} team={team} />
              ))}

            </>
          )}
        </View>
      </ScrollView>
    </View>
  );
}

function SectionHeader({ title, count }: { title: string; count: number }) {
  return (
    <View style={s.sectionHeader}>
      <Text style={s.sectionTitle}>{title}</Text>
      <View style={s.sectionCount}>
        <Text style={s.sectionCountText}>{count}</Text>
      </View>
    </View>
  );
}

function TeamListSkeleton() {
  return (
    <>
      <View style={s.sectionHeader}>
        <ShimmerLoading width={110} height={16} borderRadius={8} />
        <ShimmerLoading width={30} height={26} borderRadius={13} />
      </View>
      {[0, 1].map((item) => (
        <View key={item} style={s.teamCard}>
          <View style={[s.teamAccent, s.skeletonAccent]} />
          <View style={s.teamTop}>
            <ShimmerLoading width={46} height={46} borderRadius={16} />
            <View style={{ flex: 1, minWidth: 0, gap: 8 }}>
              <ShimmerLoading width="72%" height={20} borderRadius={10} />
              <ShimmerLoading width="54%" height={12} borderRadius={6} />
            </View>
            <ShimmerLoading width={72} height={32} borderRadius={16} />
            <ShimmerLoading width={18} height={18} borderRadius={9} />
          </View>
          <View style={s.metrics}>
            {[0, 1, 2, 3].map((metric) => (
              <View key={metric} style={s.metric}>
                <ShimmerLoading width="45%" height={19} borderRadius={9} />
                <ShimmerLoading width="82%" height={10} borderRadius={5} style={{ marginTop: 6 }} />
              </View>
            ))}
          </View>
        </View>
      ))}
    </>
  );
}

function TeamCard({ team }: { team: RiderTeam }) {
  const held = team.totals?.still_with_leader ?? team.totals?.with_receiver ?? 0;

  return (
    <TouchableOpacity
      style={s.teamCard}
      onPress={() =>
        router.push({
          pathname: "/(driver)/teams/[id]",
          params: { id: String(team.id) },
        } as any)
      }
      activeOpacity={0.72}
    >
      <View style={s.teamAccent} />
      <View style={s.teamTop}>
        <View style={s.teamIcon}>
          <Ionicons name="people" size={21} color={colors.primary} />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.cardTitle} numberOfLines={1}>{team.name}</Text>
          <View style={s.metaRow}>
            <Ionicons name="business-outline" size={12} color={colors.textMuted} />
            <Text style={s.cardMeta} numberOfLines={1}>{team.zone || team.warehouse?.name || "Rider team"}</Text>
          </View>
        </View>
        <View style={[s.rolePill, team.role === "leader" && s.rolePillLeader]}>
          <Text style={[s.roleText, team.role === "leader" && s.roleTextLeader]}>{team.role}</Text>
        </View>
        <Ionicons name="chevron-forward" size={18} color={colors.textLight} />
      </View>
      <View style={s.metrics}>
        <Metric label="Assigned" value={team.totals?.assigned || 0} />
        <Metric label="Received" value={team.totals?.received || 0} />
        <Metric label="Held" value={held} />
        <Metric label="Claimed" value={team.totals?.claimed || 0} />
      </View>
    </TouchableOpacity>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <View style={s.metric}>
      <Text style={s.metricValue}>{value}</Text>
      <Text style={s.metricLabel} numberOfLines={1}>{label}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  hero: { paddingHorizontal: 18, paddingBottom: 18, gap: 16, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -72, right: -76, width: 220, height: 220, borderRadius: 110, borderWidth: 48, borderColor: "rgba(255,255,255,0.035)" },
  heroDecor2: { position: "absolute", bottom: -96, left: -82, width: 210, height: 210, borderRadius: 105, borderWidth: 44, borderColor: "rgba(249,115,22,0.06)" },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 44, height: 44, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.1)", borderWidth: 1, borderColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" },
  title: { marginTop: 2, fontFamily: fontFamily.extrabold, fontSize: 27, color: colors.white },
  subtitle: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 13, color: "rgba(255,255,255,0.68)" },
  content: { padding: 16, gap: 12 },
  sectionHeader: { marginTop: 8, flexDirection: "row", alignItems: "center", gap: 10 },
  sectionTitle: { flex: 1, fontFamily: fontFamily.extrabold, fontSize: 13, letterSpacing: 1.7, color: colors.textMuted, textTransform: "uppercase" },
  sectionCount: { minWidth: 30, height: 26, borderRadius: 13, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" },
  sectionCountText: { fontFamily: fontFamily.extrabold, fontSize: 12, color: colors.text },
  teamCard: { position: "relative", overflow: "hidden", borderRadius: 22, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, padding: 15, gap: 14, shadowColor: colors.dark, shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.06, shadowRadius: 9, elevation: 2 },
  teamAccent: { position: "absolute", left: 0, top: 0, bottom: 0, width: 5, backgroundColor: colors.primary },
  skeletonAccent: { backgroundColor: colors.neutral200 },
  teamTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  teamIcon: { width: 46, height: 46, borderRadius: 16, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  cardTitle: { fontFamily: fontFamily.extrabold, fontSize: 19, color: colors.dark },
  metaRow: { marginTop: 4, flexDirection: "row", alignItems: "center", gap: 5 },
  cardMeta: { flex: 1, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  rolePill: { borderRadius: 999, backgroundColor: "#f1f5f9", paddingHorizontal: 10, paddingVertical: 6 },
  rolePillLeader: { backgroundColor: "#ffedd5" },
  roleText: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.textMuted, textTransform: "capitalize" },
  roleTextLeader: { color: colors.primary },
  metrics: { flexDirection: "row", gap: 8 },
  metric: { flex: 1, borderRadius: 15, backgroundColor: colors.surface, paddingVertical: 10, paddingHorizontal: 8 },
  metricValue: { fontFamily: fontFamily.extrabold, fontSize: 19, color: colors.dark },
  metricLabel: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 10, color: colors.textMuted },
});
