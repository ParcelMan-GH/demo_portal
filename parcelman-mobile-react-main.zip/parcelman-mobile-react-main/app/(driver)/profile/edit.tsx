import { useState, useEffect } from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions, KeyboardAvoidingView, Platform } from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import Input from "../../../src/components/common/Input";
import Button from "../../../src/components/common/Button";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { useAuthStore } from "../../../src/stores/auth.store";
import { getDriverProfile, updateDriverProfile } from "../../../src/api/v1/driver/profile";
import { showSuccess, showError, getErrorMessage } from "../../../src/utils/toast";

const { width } = Dimensions.get("window");

export default function DriverEditProfileScreen() {
  const insets = useSafeAreaInsets();
  const accountRoute = "/(driver)/(tabs)/account" as const;
  const user = useAuthStore((s) => s.user) as any;
  const setUser = useAuthStore((s) => s.setUser);
  const [name, setName] = useState(user?.name || "");
  const [vehicleType, setVehicleType] = useState(user?.vehicle_type || "");
  const [vehicleNumber, setVehicleNumber] = useState(user?.vehicle_number || "");
  const [licenseNumber, setLicenseNumber] = useState(user?.license_number || "");
  const [loading, setLoading] = useState(false);
  const leaveEditProfile = () => {
    if (router.canGoBack()) router.back();
    else router.replace(accountRoute as any);
  };

  useEffect(() => {
    getDriverProfile().then((res) => {
      const u = (res.data as any)?.user || res.data;
      setName(u.name || "");
      setVehicleType(u.vehicle_type || "");
      setVehicleNumber(u.vehicle_number || "");
      setLicenseNumber(u.license_number || "");
    }).catch(() => {});
  }, []);

  const handleSave = async () => {
    setLoading(true);
    try {
      const res = await updateDriverProfile({ name, vehicle_type: vehicleType, vehicle_number: vehicleNumber, license_number: licenseNumber });
      setUser((res.data as any)?.user || res.data);
      showSuccess("Profile updated!");
      router.replace(accountRoute as any);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={s.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={0}
    >
      <LinearGradient colors={["#0f172a", "#1e3a5f", "#0f172a"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
        <View style={s.heroDecor1} />
        <View style={s.headerRow}>
          <TouchableOpacity onPress={leaveEditProfile} style={s.backBtn}>
            <Ionicons name="arrow-back" size={22} color={colors.white} />
          </TouchableOpacity>
          <Text style={s.headerTitle}>Edit Profile</Text>
        </View>
      </LinearGradient>

      <ScrollView
        contentContainerStyle={s.form}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
        automaticallyAdjustKeyboardInsets={Platform.OS === "ios"}
      >
        <View style={s.card}>
          <View style={s.cardHeader}>
            <View style={[s.cardIconWrap, { backgroundColor: "#dbeafe" }]}>
              <Ionicons name="person" size={18} color="#3b82f6" />
            </View>
            <Text style={s.cardTitle}>PERSONAL INFO</Text>
          </View>
          <Input label="Full Name" required value={name} onChangeText={setName} placeholder="Your full name"
            leftIcon={<Ionicons name="person-outline" size={18} color={colors.textMuted} />} />
        </View>

        <View style={s.card}>
          <View style={s.cardHeader}>
            <View style={[s.cardIconWrap, { backgroundColor: "#ffedd5" }]}>
              <Ionicons name="car" size={18} color={colors.primary} />
            </View>
            <Text style={s.cardTitle}>VEHICLE INFO</Text>
          </View>
          <Input label="Vehicle Type" value={vehicleType} onChangeText={setVehicleType} placeholder="e.g. Motorcycle, Van"
            leftIcon={<Ionicons name="car-sport-outline" size={18} color={colors.textMuted} />} />
          <Input label="Vehicle Number" value={vehicleNumber} onChangeText={setVehicleNumber} placeholder="e.g. GR-1234-21"
            leftIcon={<Ionicons name="pricetag-outline" size={18} color={colors.textMuted} />} />
          <Input label="License Number" value={licenseNumber} onChangeText={setLicenseNumber} placeholder="Rider's license number"
            leftIcon={<Ionicons name="card-outline" size={18} color={colors.textMuted} />} />
        </View>

        <Button title="Save Changes" onPress={handleSave} loading={loading} disabled={!name.trim()} />
        <View style={{ height: 40 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, gap: 12, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.white },
  form: { padding: 16, gap: 16 },
  card: { backgroundColor: colors.white, borderRadius: 16, padding: 16, gap: 14 },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 4 },
  cardIconWrap: { width: 34, height: 34, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, letterSpacing: 0.5 },
});
