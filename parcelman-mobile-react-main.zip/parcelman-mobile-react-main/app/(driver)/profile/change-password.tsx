import { useState } from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions, KeyboardAvoidingView, Platform } from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import Input from "../../../src/components/common/Input";
import Button from "../../../src/components/common/Button";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { changePassword } from "../../../src/api/v1/driver/profile";
import { useAuthStore } from "../../../src/stores/auth.store";
import { showSuccess, showError, getErrorMessage } from "../../../src/utils/toast";

const { width } = Dimensions.get("window");

export default function ChangePasswordScreen() {
  const insets = useSafeAreaInsets();
  const accountRoute = "/(driver)/(tabs)/account" as const;
  const setUser = useAuthStore((state) => state.setUser);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [loading, setLoading] = useState(false);
  const leaveChangePassword = () => {
    if (router.canGoBack()) router.back();
    else router.replace(accountRoute as any);
  };

  const handleSubmit = async () => {
    if (newPassword !== confirmPassword) {
      showError("Passwords do not match");
      return;
    }
    if (newPassword.length < 8) {
      showError("Password must be at least 8 characters");
      return;
    }
    setLoading(true);
    try {
      const response = await changePassword({
        current_password: currentPassword,
        new_password: newPassword,
        confirm_password: confirmPassword,
      });
      if (response.data?.user) setUser(response.data.user);
      showSuccess("Password changed successfully!");
      router.replace(accountRoute as any);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const canSubmit = currentPassword.length > 0 && newPassword.length >= 8 && confirmPassword.length > 0;

  return (
    <KeyboardAvoidingView
      style={s.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={0}
    >
      <LinearGradient colors={["#0f172a", "#1e3a5f", "#0f172a"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
        <View style={s.heroDecor1} />
        <View style={s.headerRow}>
          <TouchableOpacity onPress={leaveChangePassword} style={s.backBtn}>
            <Ionicons name="arrow-back" size={22} color={colors.white} />
          </TouchableOpacity>
          <Text style={s.headerTitle}>Change Password</Text>
        </View>
        <View style={s.infoCard}>
          <Ionicons name="shield-checkmark-outline" size={20} color="rgba(255,255,255,0.6)" />
          <Text style={s.infoText}>Choose a strong password with at least 8 characters</Text>
        </View>
      </LinearGradient>

      <ScrollView
        contentContainerStyle={s.form}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
        automaticallyAdjustKeyboardInsets={Platform.OS === "ios"}
      >
        <View style={s.card}>
          <View style={s.cardHeader}>
            <View style={[s.cardIconWrap, { backgroundColor: "#fef3c7" }]}>
              <Ionicons name="lock-closed" size={18} color="#d97706" />
            </View>
            <Text style={s.cardTitle}>UPDATE PASSWORD</Text>
          </View>

          <Input label="Current Password" required value={currentPassword} onChangeText={setCurrentPassword}
            placeholder="Enter current password" secureTextEntry={!showCurrent}
            leftIcon={<Ionicons name="lock-closed-outline" size={18} color={colors.textMuted} />}
            rightIcon={<Ionicons name={showCurrent ? "eye-off-outline" : "eye-outline"} size={18} color={colors.textMuted} />}
            onRightIconPress={() => setShowCurrent(!showCurrent)} />

          <Input label="New Password" required value={newPassword} onChangeText={setNewPassword}
            placeholder="At least 8 characters" secureTextEntry={!showNew}
            leftIcon={<Ionicons name="key-outline" size={18} color={colors.textMuted} />}
            rightIcon={<Ionicons name={showNew ? "eye-off-outline" : "eye-outline"} size={18} color={colors.textMuted} />}
            onRightIconPress={() => setShowNew(!showNew)} />

          <Input label="Confirm New Password" required value={confirmPassword} onChangeText={setConfirmPassword}
            placeholder="Repeat new password" secureTextEntry
            leftIcon={<Ionicons name="checkmark-circle-outline" size={18} color={colors.textMuted} />}
            error={confirmPassword.length > 0 && newPassword !== confirmPassword ? "Passwords do not match" : undefined} />
        </View>

        <Button title="Change Password" onPress={handleSubmit} loading={loading} disabled={!canSubmit} />
        <View style={{ height: 40 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, gap: 12, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.white },
  infoCard: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: "rgba(255,255,255,0.08)", borderRadius: 12, padding: 12 },
  infoText: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", flex: 1 },
  form: { padding: 16, gap: 16 },
  card: { backgroundColor: colors.white, borderRadius: 16, padding: 16, gap: 14 },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 4 },
  cardIconWrap: { width: 34, height: 34, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, letterSpacing: 0.5 },
});
