import { useCallback, useMemo, useState } from "react";
import { ActivityIndicator, Image, KeyboardAvoidingView, Modal, Platform, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { router, useFocusEffect, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../../src/components/common/EmptyState";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { allocateRiderTeamHandoverLabels, getRiderTeam, getRiderTeamHandover, scanReceiveRiderTeamHandover } from "../../../src/api/v1/driver/rider-teams";
import type { RiderTeam, RiderTeamHandover, RiderTeamHandoverItem, RiderTeamMember } from "../../../src/types/driver";
import { getErrorMessage, showError, showSuccess } from "../../../src/utils/toast";
import { useAuthStore } from "../../../src/stores/auth.store";

type AssignableRider = {
  id: number;
  name: string;
  phone: string | null;
  isSelf?: boolean;
};

export default function RiderTeamHandoverScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const teamsRoute = "/(driver)/teams" as const;
  const leaveTeamHandover = () => {
    if (router.canGoBack()) router.back();
    else router.replace(teamsRoute as any);
  };
  const user = useAuthStore((state) => state.user) as any;
  const currentDriverId = Number(user?.id || user?.driver_id || 0);
  const [handover, setHandover] = useState<RiderTeamHandover | null>(null);
  const [team, setTeam] = useState<RiderTeam | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [receiveCode, setReceiveCode] = useState("");
  const [distributionMemberId, setDistributionMemberId] = useState<number | null>(null);
  const [selectedPackageIds, setSelectedPackageIds] = useState<number[]>([]);
  const [riderDropdownOpen, setRiderDropdownOpen] = useState(false);
  const [riderSearch, setRiderSearch] = useState("");
  const [evenSplitConfirmOpen, setEvenSplitConfirmOpen] = useState(false);
  const [evenSplitError, setEvenSplitError] = useState("");
  const [detailItem, setDetailItem] = useState<RiderTeamHandoverItem | null>(null);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      const res = await getRiderTeamHandover(String(id));
      const nextHandover = res?.data?.handover || null;
      setHandover(nextHandover);
      if (nextHandover?.team?.id && (nextHandover?.can_manage || nextHandover?.can_distribute)) {
        const teamRes = await getRiderTeam(nextHandover.team.id);
        setTeam(teamRes?.data?.team || null);
      }
    } catch (err: any) {
      showError(getErrorMessage(err, "Could not load handover"));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(useCallback(() => { load(); }, [id]));

  const members: RiderTeamMember[] = (team?.members || []).filter((member) => member.role === "member" && member.driver);
  const assignmentRiders = useMemo<AssignableRider[]>(() => {
    const currentDriverId = Number(user?.id || user?.driver_id || 0);
    const currentPhone = user?.phone || null;
    const fromMembers = members
      .map((member) => member.driver)
      .filter((driver): driver is NonNullable<RiderTeamMember["driver"]> => Boolean(driver))
      .map((driver) => ({
        id: Number(driver.id),
        name: Number(driver.id) === currentDriverId ? "Myself" : (driver.name || "Rider"),
        phone: driver.phone || null,
        isSelf: Number(driver.id) === currentDriverId,
      }));

    if (currentDriverId > 0 && !fromMembers.some((rider) => rider.id === currentDriverId)) {
      fromMembers.unshift({
        id: currentDriverId,
        name: "Myself",
        phone: currentPhone,
        isSelf: true,
      });
    }

    return fromMembers.sort((left, right) => {
      if (left.isSelf && !right.isSelf) return -1;
      if (!left.isSelf && right.isSelf) return 1;
      return left.name.localeCompare(right.name);
    });
  }, [members, user?.id, user?.driver_id, user?.name, user?.phone]);
  const packageDisplay = useMemo(() => buildPackageDisplay(handover?.items || []), [handover?.items]);
  const shareableItems = packageDisplay.items.filter(isShareable);
  const selectedMember = assignmentRiders.find((member) => member.id === distributionMemberId) || null;
  const filteredMembers = assignmentRiders.filter((member) => {
    const needle = riderSearch.trim().toLowerCase();
    if (!needle) return true;
    return `${member.name || ""} ${member.phone || ""}`.toLowerCase().includes(needle);
  });
  const evenSplitCount = members.length > 0 ? Math.floor(shareableItems.length / members.length) : 0;
  const evenSplitRemainder = members.length > 0 ? shareableItems.length - (evenSplitCount * members.length) : shareableItems.length;

  const scanReceive = async () => {
    const barcode = receiveCode.trim();
    if (!barcode || !handover) return;
    setSaving(true);
    try {
      await scanReceiveRiderTeamHandover(handover.id, barcode);
      setReceiveCode("");
      showSuccess("Package received into handover");
      load();
    } catch (err: any) {
      showError(getErrorMessage(err, "Could not receive package"));
    } finally {
      setSaving(false);
    }
  };

  const togglePackageSelection = (itemId: number) => {
    setSelectedPackageIds((current) => (
      current.includes(itemId)
        ? current.filter((id) => id !== itemId)
        : [...current, itemId]
    ));
  };

  const toggleGroupSelection = (itemIds: number[]) => {
    if (itemIds.length === 0) return;
    setSelectedPackageIds((current) => {
      const allSelected = itemIds.every((itemId) => current.includes(itemId));
      if (allSelected) {
        return current.filter((itemId) => !itemIds.includes(itemId));
      }

      return Array.from(new Set([...current, ...itemIds]));
    });
  };

  const selectFirstPackages = (count: number) => {
    setSelectedPackageIds(shareableItems.slice(0, count).map((item) => item.id));
  };

  const clearSelection = () => {
    setSelectedPackageIds([]);
    setDistributionMemberId(null);
    setRiderDropdownOpen(false);
    setRiderSearch("");
  };

  const startReassignFromDetails = (item: RiderTeamHandoverItem) => {
    if (!isShareable(item)) return;
    setSelectedPackageIds([item.id]);
    setDistributionMemberId(null);
    setRiderDropdownOpen(true);
    setDetailItem(null);
  };

  const allocateSelected = async () => {
    if (!handover || !distributionMemberId) return;
    const barcodes = shareableItems
      .filter((item) => selectedPackageIds.includes(item.id))
      .map((item) => item.barcode)
      .filter((barcode): barcode is string => Boolean(barcode));
    if (barcodes.length === 0) return;

    setSaving(true);
    try {
      await allocateRiderTeamHandoverLabels(handover.id, { driver_id: distributionMemberId, barcodes });
      setDistributionMemberId(null);
      setSelectedPackageIds([]);
      showSuccess(`${barcodes.length} packages shared`);
      load();
    } catch (err: any) {
      showError(getErrorMessage(err, "Could not share packages"));
    } finally {
      setSaving(false);
    }
  };

  const distributeEvenly = async () => {
    setEvenSplitError("");
    if (!handover) return;
    if (members.length === 0) {
      setEvenSplitError("Add team members before distributing packages.");
      return;
    }
    if (shareableItems.length === 0) {
      setEvenSplitError("No packages are available to distribute.");
      return;
    }

    const perMember = Math.floor(shareableItems.length / members.length);
    if (perMember < 1) {
      setEvenSplitError("Not enough packages to split across all members.");
      return;
    }

    setSaving(true);
    try {
      let cursor = 0;
      for (const member of members) {
        const driverId = member.driver?.id;
        const barcodes = shareableItems
          .slice(cursor, cursor + perMember)
          .map((item) => item.barcode)
          .filter((barcode): barcode is string => Boolean(barcode));
        cursor += perMember;

        if (driverId && barcodes.length > 0) {
          await allocateRiderTeamHandoverLabels(handover.id, { driver_id: driverId, barcodes });
        }
      }

      const remainder = shareableItems.length - cursor;
      setDistributionMemberId(null);
      setSelectedPackageIds([]);
      setEvenSplitConfirmOpen(false);
      showSuccess(remainder > 0 ? `Distributed evenly. ${remainder} left with you.` : "Distributed evenly.");
      load();
    } catch (err: any) {
      setEvenSplitError(getErrorMessage(err, "Could not distribute packages"));
    } finally {
      setSaving(false);
    }
  };

  const canReceive = Boolean(handover?.can_receive);
  const canDistribute = Boolean(handover?.can_distribute);
  const needsReceiving = (handover?.counts.assigned || 0) > (handover?.counts.received || 0);

  return (
    <KeyboardAvoidingView
      style={s.screen}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={0}
    >
      {loading ? (
        <View style={s.loading}><ActivityIndicator color={colors.primary} /></View>
      ) : (
        <ScrollView
          contentContainerStyle={[s.scrollContent, { paddingBottom: insets.bottom + (selectedPackageIds.length > 0 ? 190 : 32) }]}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
          automaticallyAdjustKeyboardInsets={Platform.OS === "ios"}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} colors={[colors.primary]} />}
          showsVerticalScrollIndicator={false}
        >
          <LinearGradient
            colors={["#0f172a", "#1e293b", "#0f172a"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={[s.hero, { paddingTop: insets.top + 14 }]}
          >
            <View style={s.heroDecor1} />
            <View style={s.heroDecor2} />
            <View style={s.headerTop}>
              <TouchableOpacity style={s.backBtn} onPress={leaveTeamHandover} activeOpacity={0.72}>
                <Ionicons name="arrow-back" size={22} color={colors.white} />
              </TouchableOpacity>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={s.title} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7}>{handover?.handover_number || "Handover"}</Text>
                <Text style={s.subtitle} numberOfLines={1}>{handover?.team?.name || "Rider team handover"}</Text>
              </View>
              <View style={s.statusPillDark}>
                <Text style={s.statusPillDarkText}>{handover?.status?.replaceAll("_", " ") || "active"}</Text>
              </View>
            </View>
            <View style={s.statStrip}>
              <Count label="Total" value={handover?.counts.assigned || 0} sublabel="labels" />
              <Count label="With Me" value={handover?.counts.with_receiver ?? handover?.counts.still_with_leader ?? 0} sublabel="not shared" />
              <Count label="Progress" value={handover?.counts.claimed || 0} sublabel={`${handover?.counts.delivered || 0} delivered`} />
            </View>
          </LinearGradient>

          <View style={s.content}>
            {canReceive && needsReceiving ? (
              <ActionPanel
                value={receiveCode}
                onChange={setReceiveCode}
                onSubmit={scanReceive}
                disabled={saving}
              />
            ) : null}

            <View style={s.sectionHeader}>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={s.sectionTitle}>{canDistribute ? "Packages to Share" : "My Assigned Packages"}</Text>
                <Text style={s.sectionSub}>{canDistribute ? "Assign a package to a team member, or let them scan to claim." : "Packages assigned to you from this handover."}</Text>
              </View>
            </View>
            {canDistribute && shareableItems.length > 0 ? (
              <DistributionToolbar
                availableCount={shareableItems.length}
                saving={saving}
                membersCount={members.length}
                onSelectFirst={selectFirstPackages}
                onDistributeEvenly={() => {
                  setEvenSplitError("");
                  setEvenSplitConfirmOpen(true);
                }}
              />
            ) : null}

            <View style={s.packageList}>
              {packageDisplay.items.length === 0 ? (
                <EmptyState
                  icon="cube-outline"
                  title="No packages yet"
                  subtitle="Packages received into this handover will appear here."
                  illustration="packages"
                  compact
                />
              ) : packageDisplay.rows.map((row) => {
                if (row.type === "group") {
                  return (
                    <PackageGroupHeader
                      key={row.key}
                      title={row.title}
                      subtitle={row.subtitle}
                      count={row.count}
                      highlighted={row.highlighted}
                      selectableIds={canDistribute ? row.selectableIds : []}
                      selectedCount={row.selectableIds.filter((itemId) => selectedPackageIds.includes(itemId)).length}
                      onToggle={() => toggleGroupSelection(row.selectableIds)}
                    />
                  );
                }

                return (
                  <PackageRow
                    key={row.item.id}
                    item={row.item}
                    currentDriverId={currentDriverId}
                    selectable={canDistribute && isShareable(row.item)}
                    selected={selectedPackageIds.includes(row.item.id)}
                    onToggle={() => togglePackageSelection(row.item.id)}
                    onOpen={() => setDetailItem(row.item)}
                    isLast={row.isLastInGroup}
                  />
                );
              })}
            </View>
          </View>
        </ScrollView>
      )}

      {canDistribute && selectedPackageIds.length > 0 && riderDropdownOpen ? (
        <RiderDropdown
          bottomOffset={insets.bottom + 126}
          members={filteredMembers}
          search={riderSearch}
          selectedMemberId={distributionMemberId}
          onSearch={setRiderSearch}
          onSelect={(driverId) => {
            setDistributionMemberId(driverId);
            setRiderDropdownOpen(false);
          }}
        />
      ) : null}

      {canDistribute && selectedPackageIds.length > 0 ? (
        <View style={[s.stickyAssign, { paddingBottom: insets.bottom + 10 }]}>
          <View style={s.stickyTop}>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={s.stickyTitle}>Assign selected</Text>
              <Text style={s.stickySub}>{selectedPackageIds.length} package{selectedPackageIds.length === 1 ? "" : "s"} selected</Text>
            </View>
            <TouchableOpacity style={s.stickyClearBtn} onPress={clearSelection} activeOpacity={0.72}>
              <Ionicons name="close" size={16} color={colors.text} />
              <Text style={s.stickyClearText}>Clear</Text>
            </TouchableOpacity>
          </View>

          <View style={s.stickyControls}>
            <TouchableOpacity style={s.riderSelect} onPress={() => setRiderDropdownOpen((open) => !open)} activeOpacity={0.72}>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={s.riderSelectLabel}>Rider</Text>
                <Text style={s.riderSelectValue} numberOfLines={1}>{selectedMember?.name || "Choose rider"}</Text>
              </View>
              <Ionicons name={riderDropdownOpen ? "chevron-up" : "chevron-down"} size={18} color={colors.textMuted} />
            </TouchableOpacity>
            <TouchableOpacity
              style={[s.stickyAssignBtn, (!distributionMemberId || saving) && s.disabled]}
              onPress={allocateSelected}
              disabled={!distributionMemberId || saving}
              activeOpacity={0.72}
            >
              {saving ? <ActivityIndicator size="small" color={colors.white} /> : <Text style={s.stickyAssignText}>Assign</Text>}
            </TouchableOpacity>
          </View>
        </View>
      ) : null}

      <ConfirmEvenSplitModal
        visible={evenSplitConfirmOpen}
        saving={saving}
        memberCount={members.length}
        packageCount={shareableItems.length}
        perMember={evenSplitCount}
        remainder={evenSplitRemainder}
        error={evenSplitError}
        onCancel={() => {
          setEvenSplitError("");
          if (!saving) setEvenSplitConfirmOpen(false);
        }}
        onConfirm={distributeEvenly}
      />

      <PackageDetailsDrawer
        item={detailItem}
        currentDriverId={currentDriverId}
        bottomInset={insets.bottom}
        canReassign={canDistribute && !!detailItem && isShareable(detailItem)}
        onClose={() => setDetailItem(null)}
        onReassign={() => detailItem && startReassignFromDetails(detailItem)}
      />
    </KeyboardAvoidingView>
  );
}

function Count({ label, value, sublabel }: { label: string; value: number; sublabel: string }) {
  return (
    <View style={s.countCard}>
      <Text style={s.countValue}>{value}</Text>
      <Text style={s.countLabel}>{label}</Text>
      <Text style={s.countSubLabel} numberOfLines={1}>{sublabel}</Text>
    </View>
  );
}

function ActionPanel({
  value, onChange, onSubmit, disabled,
}: {
  value: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
  disabled?: boolean;
}) {
  return (
    <View style={s.panel}>
      <View style={s.panelHeader}>
        <View style={s.panelIcon}><Ionicons name="scan-outline" size={18} color={colors.primary} /></View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.panelTitle}>Receive Missing Labels</Text>
          <Text style={s.panelSub}>Scan or type a label to confirm custody.</Text>
        </View>
      </View>
      <View style={s.inputRow}>
        <TextInput value={value} onChangeText={onChange} placeholder="Label barcode" style={s.input} autoCapitalize="characters" />
        <TouchableOpacity style={[s.actionBtn, disabled && s.disabled]} onPress={onSubmit} disabled={disabled}>
          <Text style={s.actionText}>Receive</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function DistributionToolbar({
  availableCount,
  saving,
  membersCount,
  onSelectFirst,
  onDistributeEvenly,
}: {
  availableCount: number;
  saving: boolean;
  membersCount: number;
  onSelectFirst: (count: number) => void;
  onDistributeEvenly: () => void;
}) {
  const perMember = membersCount > 0 ? Math.floor(availableCount / membersCount) : 0;

  return (
    <View style={s.distributionTools}>
      <TouchableOpacity
        style={s.selectAllBtn}
        onPress={() => onSelectFirst(availableCount)}
        activeOpacity={0.72}
      >
        <Ionicons name="checkbox-outline" size={17} color={colors.primary} />
        <Text style={s.selectAllText}>Select all</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[s.evenSplitBtn, (saving || perMember < 1) && s.disabled]}
        onPress={onDistributeEvenly}
        disabled={saving || perMember < 1}
        activeOpacity={0.72}
      >
        <Ionicons name="git-branch-outline" size={16} color={colors.white} />
        <Text style={s.evenSplitTitle}>Distribute evenly</Text>
      </TouchableOpacity>
    </View>
  );
}

function RiderDropdown({
  bottomOffset,
  members,
  search,
  selectedMemberId,
  onSearch,
  onSelect,
}: {
  bottomOffset: number;
  members: AssignableRider[];
  search: string;
  selectedMemberId: number | null;
  onSearch: (value: string) => void;
  onSelect: (id: number | null) => void;
}) {
  return (
    <View style={[s.riderDropdown, { bottom: bottomOffset }]}>
      <View style={s.dropdownSearchWrap}>
        <Ionicons name="search" size={17} color={colors.textMuted} />
        <TextInput
          value={search}
          onChangeText={onSearch}
          placeholder="Search rider..."
          placeholderTextColor={colors.textLight}
          style={s.dropdownSearch}
          autoCapitalize="none"
        />
      </View>
      <ScrollView style={s.dropdownList} nestedScrollEnabled keyboardShouldPersistTaps="handled">
        {members.length === 0 ? (
          <View style={s.dropdownEmpty}>
            <Text style={s.emptyText}>No matching riders.</Text>
          </View>
        ) : members.map((member, index) => {
          const driverId = member.id || null;
          const selected = selectedMemberId === driverId;
          return (
            <TouchableOpacity
              key={member.isSelf ? `self-${member.id}` : `rider-${member.id}`}
              style={s.dropdownOption}
              onPress={() => onSelect(driverId)}
              activeOpacity={0.72}
            >
              <View style={[s.dropdownAvatar, member.isSelf && s.dropdownAvatarSelf]}>
                <Ionicons name={member.isSelf ? "person-circle" : "person"} size={16} color={colors.primary} />
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={s.dropdownName} numberOfLines={1}>{member.name || "-"}</Text>
                <Text style={s.dropdownPhone} numberOfLines={1}>
                  {member.phone ? `${member.phone}${member.isSelf ? " · assign to myself" : ""}` : member.isSelf ? "Assign to myself" : "-"}
                </Text>
              </View>
              <Ionicons name={selected ? "radio-button-on" : "radio-button-off"} size={21} color={selected ? colors.primary : colors.textLight} />
              {index < members.length - 1 ? <View style={s.dropdownDivider} /> : null}
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
}

function ConfirmEvenSplitModal({
  visible,
  saving,
  memberCount,
  packageCount,
  perMember,
  remainder,
  error,
  onCancel,
  onConfirm,
}: {
  visible: boolean;
  saving: boolean;
  memberCount: number;
  packageCount: number;
  perMember: number;
  remainder: number;
  error: string;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <Pressable style={s.confirmOverlay} onPress={onCancel}>
        <Pressable style={s.confirmCard} onPress={(event) => event.stopPropagation()}>
          <View style={s.confirmHeader}>
            <View style={s.confirmIcon}>
              <Ionicons name="git-branch-outline" size={22} color={colors.white} />
            </View>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={s.confirmTitle}>Distribute evenly?</Text>
              <Text style={s.confirmSub}>This will assign packages to all team members now.</Text>
            </View>
          </View>

          <View style={s.confirmStats}>
            <View style={s.confirmStat}>
              <Text style={s.confirmStatLabel}>Packages</Text>
              <Text style={s.confirmStatValue}>{packageCount}</Text>
            </View>
            <View style={s.confirmStat}>
              <Text style={s.confirmStatLabel}>Members</Text>
              <Text style={s.confirmStatValue}>{memberCount}</Text>
            </View>
            <View style={s.confirmStat}>
              <Text style={s.confirmStatLabel}>Each</Text>
              <Text style={s.confirmStatValue}>{perMember}</Text>
            </View>
          </View>

          {remainder > 0 ? (
            <View style={s.remainderNotice}>
              <Text style={s.remainderText}>
                {remainder} extra package{remainder === 1 ? "" : "s"} will stay with you.
              </Text>
            </View>
          ) : null}

          {error ? (
            <View style={s.confirmError}>
              <Ionicons name="alert-circle-outline" size={18} color={colors.errorDark} />
              <Text style={s.confirmErrorText}>{error}</Text>
            </View>
          ) : null}

          <View style={s.confirmFooter}>
            <TouchableOpacity style={s.confirmCancelBtn} onPress={onCancel} disabled={saving}>
              <Text style={s.confirmCancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[s.confirmPrimaryBtn, saving && s.disabled]} onPress={onConfirm} disabled={saving || perMember < 1}>
              {saving ? <ActivityIndicator size="small" color={colors.white} /> : <Text style={s.confirmPrimaryText}>Confirm</Text>}
            </TouchableOpacity>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

type PackageDisplayRow =
  | { type: "group"; key: string; title: string; subtitle: string; count: number; highlighted: boolean; selectableIds: number[] }
  | { type: "item"; item: RiderTeamHandoverItem; isLastInGroup: boolean };

function PackageGroupHeader({
  title,
  subtitle,
  count,
  highlighted,
  selectableIds,
  selectedCount,
  onToggle,
}: {
  title: string;
  subtitle: string;
  count: number;
  highlighted: boolean;
  selectableIds: number[];
  selectedCount: number;
  onToggle: () => void;
}) {
  const selectable = selectableIds.length > 0;
  const selected = selectable && selectedCount === selectableIds.length;
  const partial = selectable && selectedCount > 0 && selectedCount < selectableIds.length;
  const checkboxIcon = selected ? "checkbox" : partial ? "remove-circle" : "square-outline";

  return (
    <TouchableOpacity
      style={[s.groupHeader, highlighted && s.groupHeaderHighlighted]}
      onPress={selectable ? onToggle : undefined}
      activeOpacity={selectable ? 0.72 : 1}
    >
      <Ionicons
        name={checkboxIcon}
        size={23}
        color={selected || partial ? colors.primary : colors.textLight}
      />
      <View style={s.groupIcon}>
        <Ionicons name="location-outline" size={17} color={colors.primary} />
      </View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.groupTitle} numberOfLines={1}>{title}</Text>
        <Text style={s.groupSub} numberOfLines={1}>{subtitle}</Text>
      </View>
      <View style={s.groupCountPill}>
        <Text style={s.groupCountText}>{count} label{count === 1 ? "" : "s"}</Text>
      </View>
    </TouchableOpacity>
  );
}

function PackageRow({
  item,
  currentDriverId,
  selectable,
  selected,
  onToggle,
  onOpen,
  isLast,
}: {
  item: RiderTeamHandoverItem;
  currentDriverId: number;
  selectable: boolean;
  selected: boolean;
  onToggle: () => void;
  onOpen: () => void;
  isLast: boolean;
}) {
  const deliveryLocation = getDeliveryLocation(item);
  const assignedToSelf = currentDriverId > 0 && Number(item.allocated_to?.id) === currentDriverId;
  const assignedLabel = assignedToSelf ? "Assigned to myself" : `Assigned to ${item.allocated_to?.name || "rider"}`;

  return (
    <TouchableOpacity
      style={[s.packageRow, selected && s.packageRowSelected]}
      onPress={onOpen}
      activeOpacity={0.72}
    >
      {selectable ? (
        <TouchableOpacity onPress={onToggle} hitSlop={10} activeOpacity={0.72}>
          <Ionicons name={selected ? "checkbox" : "square-outline"} size={23} color={selected ? colors.primary : colors.textLight} />
        </TouchableOpacity>
      ) : (
        <View style={s.packageIcon}>
          <Ionicons name="cube-outline" size={18} color={colors.primary} />
        </View>
      )}
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.packageTitle} numberOfLines={1}>{item.package?.description || "Package"}</Text>
        <Text style={s.packageCode} numberOfLines={1}>{item.barcode || "-"}</Text>
        {item.package?.recipient_name ? (
          <Text style={s.packageMeta} numberOfLines={1}>{item.package.recipient_name} / {item.package.recipient_phone || "-"}</Text>
        ) : null}
        <View style={s.packageLocationLine}>
          <Ionicons name="location-outline" size={13} color={colors.textMuted} />
          <Text style={s.packageLocationText} numberOfLines={1}>{deliveryLocation}</Text>
        </View>
        {item.allocated_to ? (
          <Text style={s.allocatedText} numberOfLines={1}>{assignedLabel}</Text>
        ) : null}
      </View>
      {(!selectable || item.status === "allocated_to_member") ? (
        <View style={s.statusPill}><Text style={s.statusText}>{handoverItemStatusLabel(item.status)}</Text></View>
      ) : null}
      {!isLast ? <View style={s.rowDivider} /> : null}
    </TouchableOpacity>
  );
}

function handoverItemStatusLabel(status: string) {
  if (status === "allocated_to_member") return "Assigned";
  if (status === "member_claimed") return "Claimed";
  if (status === "in_delivery") return "In delivery";
  return status.replaceAll("_", " ");
}

function isShareable(item: RiderTeamHandoverItem) {
  return ["leader_received", "receiver_received", "assigned_to_leader", "allocated_to_member"].includes(item.status);
}

function isTerminalOrMovingStatus(status: string) {
  return ["member_claimed", "in_delivery", "delivered", "failed", "returned", "recalled"].includes(status);
}

function PackageDetailsDrawer({
  item,
  currentDriverId,
  bottomInset,
  canReassign,
  onClose,
  onReassign,
}: {
  item: RiderTeamHandoverItem | null;
  currentDriverId: number;
  bottomInset: number;
  canReassign: boolean;
  onClose: () => void;
  onReassign: () => void;
}) {
  if (!item) return null;

  const assignedToSelf = currentDriverId > 0 && Number(item.allocated_to?.id) === currentDriverId;
  const assignedText = item.allocated_to
    ? assignedToSelf
      ? "Assigned to myself"
      : `Assigned to ${item.allocated_to.name || "rider"}`
    : "Not assigned to rider";
  const images = item.package?.images || [];
  const photoSource = images[0]?.source ? `${images[0].source} photo` : null;
  const statusLabel = handoverItemStatusLabel(item.status);
  const locked = isTerminalOrMovingStatus(item.status);

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={s.drawerOverlay} onPress={onClose}>
        <Pressable style={s.drawer} onPress={(event) => event.stopPropagation()}>
          <View style={s.drawerHandle} />
          <View style={s.drawerHeader}>
            <View style={s.drawerIcon}>
              <Ionicons name="cube-outline" size={22} color={colors.primary} />
            </View>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={s.drawerTitle} numberOfLines={1}>{item.package?.description || "Package"}</Text>
              <View style={s.drawerSubRow}>
                <Text style={s.drawerSub} numberOfLines={1}>{item.barcode || "-"}</Text>
                {photoSource ? (
                  <View style={s.drawerPhotoPill}>
                    <Text style={s.drawerPhotoPillText}>{photoSource}</Text>
                  </View>
                ) : null}
              </View>
            </View>
            <TouchableOpacity style={s.drawerClose} onPress={onClose}>
              <Ionicons name="close" size={20} color={colors.textMuted} />
            </TouchableOpacity>
          </View>

          <ScrollView contentContainerStyle={s.drawerBody} showsVerticalScrollIndicator={false}>
            {images.length > 0 ? (
              <View style={s.photoPanel}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.photoStrip}>
                  {images.map((image, index) => (
                    <Image key={`${image.id || index}`} source={{ uri: image.url }} style={s.packagePhoto} resizeMode="cover" />
                  ))}
                </ScrollView>
              </View>
            ) : (
              <View style={s.noPhotoBox}>
                <Ionicons name="image-outline" size={22} color={colors.textMuted} />
                <Text style={s.noPhotoText}>No package photo</Text>
              </View>
            )}

            <View style={s.detailGrid}>
              <DetailTile label="State" value={statusLabel} tone={locked ? "dark" : "primary"} />
              <DetailTile label="Custody" value={assignedText} />
            </View>

            <View style={s.detailCard}>
              <Text style={s.detailCardTitle}>Delivery</Text>
              <DetailLine icon="person-outline" value={`${item.package?.recipient_name || "-"} / ${item.package?.recipient_phone || "-"}`} />
              <DetailLine icon="location-outline" value={getDeliveryLocation(item)} />
              {item.package?.delivery_landmark ? <DetailLine icon="flag-outline" value={item.package.delivery_landmark} /> : null}
              {item.package?.delivery_instructions ? <DetailLine icon="document-text-outline" value={item.package.delivery_instructions} /> : null}
            </View>

            <View style={s.detailCard}>
              <Text style={s.detailCardTitle}>Timeline</Text>
              <DetailLine icon="archive-outline" value={`Assigned: ${formatEventDate(item.assigned_at)}`} />
              <DetailLine icon="download-outline" value={`Received: ${formatEventDate(item.receiver_received_at || item.leader_received_at)}`} />
              {item.allocated_at ? <DetailLine icon="person-add-outline" value={`Rider assigned: ${formatEventDate(item.allocated_at)}`} /> : null}
              {item.member_claimed_at ? <DetailLine icon="checkmark-done-outline" value={`Claimed: ${formatEventDate(item.member_claimed_at)}`} /> : null}
            </View>
          </ScrollView>

          <View style={[s.drawerFooter, { paddingBottom: Math.max(bottomInset, 10) + 12 }]}>
            <View style={s.drawerFooterRow}>
              <TouchableOpacity style={s.drawerSecondaryBtn} onPress={onClose}>
                <Text style={s.drawerSecondaryText}>Close</Text>
              </TouchableOpacity>
              {canReassign ? (
                <TouchableOpacity style={s.drawerPrimaryBtn} onPress={onReassign}>
                  <Text style={s.drawerPrimaryText}>{item.allocated_to ? "Reassign" : "Assign"}</Text>
                </TouchableOpacity>
              ) : (
                <View style={s.drawerLockedPill}>
                  <Ionicons name="lock-closed-outline" size={14} color={colors.textMuted} />
                  <Text style={s.drawerLockedText}>{locked ? "Delivery already started" : "Cannot reassign"}</Text>
                </View>
              )}
            </View>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

function DetailTile({ label, value, tone = "muted" }: { label: string; value: string; tone?: "primary" | "dark" | "muted" }) {
  return (
    <View style={s.detailTile}>
      <Text style={s.detailTileLabel}>{label}</Text>
      <Text style={[s.detailTileValue, tone === "primary" && { color: colors.primary }, tone === "dark" && { color: colors.dark }]} numberOfLines={2}>{value}</Text>
    </View>
  );
}

function DetailLine({ icon, value }: { icon: keyof typeof Ionicons.glyphMap; value: string }) {
  return (
    <View style={s.detailLine}>
      <Ionicons name={icon} size={15} color={colors.textMuted} />
      <Text style={s.detailLineText}>{value}</Text>
    </View>
  );
}

function formatEventDate(value?: string | null) {
  if (!value) return "-";
  try {
    return new Date(value).toLocaleString("en-GH", {
      day: "2-digit",
      month: "short",
      hour: "numeric",
      minute: "2-digit",
    });
  } catch {
    return "-";
  }
}

function buildPackageDisplay(items: RiderTeamHandoverItem[]): { items: RiderTeamHandoverItem[]; rows: PackageDisplayRow[] } {
  const sortedItems = [...items].sort((a, b) => {
    const groupCompare = getPackageGroupKey(a).localeCompare(getPackageGroupKey(b));
    if (groupCompare !== 0) return groupCompare;
    return String(a.barcode || a.id).localeCompare(String(b.barcode || b.id));
  });
  const groupCounts = sortedItems.reduce<Record<string, number>>((counts, item) => {
    const key = getPackageGroupKey(item);
    counts[key] = (counts[key] || 0) + 1;
    return counts;
  }, {});
  const groupSelectableIds = sortedItems.reduce<Record<string, number[]>>((ids, item) => {
    if (!isShareable(item)) return ids;
    const key = getPackageGroupKey(item);
    ids[key] = [...(ids[key] || []), item.id];
    return ids;
  }, {});
  const rows: PackageDisplayRow[] = [];

  sortedItems.forEach((item, index) => {
    const key = getPackageGroupKey(item);
    const previousKey = index > 0 ? getPackageGroupKey(sortedItems[index - 1]) : null;
    const nextKey = index < sortedItems.length - 1 ? getPackageGroupKey(sortedItems[index + 1]) : null;

    if (key !== previousKey) {
      rows.push({
        type: "group",
        key: `group-${key}`,
        title: getPackageGroupTitle(item),
        subtitle: getPackageGroupSubtitle(item),
        count: groupCounts[key] || 1,
        highlighted: (groupCounts[key] || 1) > 1,
        selectableIds: groupSelectableIds[key] || [],
      });
    }

    rows.push({
      type: "item",
      item,
      isLastInGroup: key !== nextKey,
    });
  });

  return { items: sortedItems, rows };
}

function getPackageGroupKey(item: RiderTeamHandoverItem) {
  const phone = normalizePhone(item.package?.recipient_phone);
  if (phone) return `phone:${phone}`;

  const recipient = normalizeText(item.package?.recipient_name);
  const location = normalizeText(item.package?.delivery_town);
  if (recipient || location) return `recipient:${recipient}|location:${location}`;

  return `label:${item.barcode || item.id}`;
}

function getPackageGroupTitle(item: RiderTeamHandoverItem) {
  const recipient = item.package?.recipient_name?.trim();
  const phone = item.package?.recipient_phone?.trim();
  if (recipient && phone) return `${recipient} / ${phone}`;
  if (recipient) return recipient;
  if (phone) return phone;
  return "Unassigned recipient";
}

function getPackageGroupSubtitle(item: RiderTeamHandoverItem) {
  return getDeliveryLocation(item);
}

function getDeliveryLocation(item: RiderTeamHandoverItem) {
  return item.package?.delivery_town?.trim() || "No delivery location";
}

function normalizePhone(value?: string | null) {
  return (value || "").replace(/\D/g, "");
}

function normalizeText(value?: string | null) {
  return (value || "").trim().toLowerCase();
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  scrollContent: { paddingBottom: 40 },
  hero: { paddingHorizontal: 18, paddingBottom: 18, gap: 16, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -72, right: -76, width: 220, height: 220, borderRadius: 110, borderWidth: 48, borderColor: "rgba(255,255,255,0.035)" },
  heroDecor2: { position: "absolute", bottom: -96, left: -82, width: 210, height: 210, borderRadius: 105, borderWidth: 44, borderColor: "rgba(249,115,22,0.06)" },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 44, height: 44, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.1)", borderWidth: 1, borderColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" },
  eyebrow: { fontFamily: fontFamily.extrabold, fontSize: 10, letterSpacing: 1.6, color: "#fdba74", textTransform: "uppercase" },
  title: { fontFamily: fontFamily.extrabold, fontSize: 18, lineHeight: 22, color: colors.white },
  subtitle: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 13, color: "rgba(255,255,255,0.68)" },
  statusPillDark: { borderRadius: 999, backgroundColor: "rgba(255,255,255,0.12)", borderWidth: 1, borderColor: "rgba(255,255,255,0.12)", paddingHorizontal: 11, paddingVertical: 7 },
  statusPillDarkText: { fontFamily: fontFamily.extrabold, fontSize: 11, color: "rgba(255,255,255,0.78)", textTransform: "capitalize" },
  statStrip: { flexDirection: "row", gap: 8 },
  countCard: { flex: 1, minWidth: 0, minHeight: 76, borderRadius: 16, borderWidth: 1, borderColor: "rgba(255,255,255,0.12)", backgroundColor: "rgba(255,255,255,0.1)", paddingHorizontal: 8, paddingVertical: 10, justifyContent: "center", alignItems: "center" },
  countValue: { width: "100%", fontFamily: fontFamily.extrabold, fontSize: 24, color: colors.white, textAlign: "center" },
  countLabel: { marginTop: 2, width: "100%", fontFamily: fontFamily.extrabold, fontSize: 10, color: "rgba(255,255,255,0.82)", textAlign: "center" },
  countSubLabel: { marginTop: 1, width: "100%", fontFamily: fontFamily.medium, fontSize: 9, color: "rgba(255,255,255,0.62)", textAlign: "center" },
  content: { padding: 16, gap: 12 },
  panel: { borderRadius: 20, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, padding: 14, gap: 12 },
  panelHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  panelIcon: { width: 40, height: 40, borderRadius: 14, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  panelTitle: { fontFamily: fontFamily.extrabold, fontSize: 16, color: colors.dark },
  panelSub: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  inputRow: { flexDirection: "row", gap: 10 },
  input: { flex: 1, minHeight: 50, borderRadius: 14, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 14, fontFamily: fontFamily.bold, color: colors.dark },
  actionBtn: { minWidth: 92, borderRadius: 14, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", paddingHorizontal: 14 },
  actionText: { fontFamily: fontFamily.bold, color: colors.white },
  disabled: { opacity: 0.55 },
  sectionHeader: { flexDirection: "row", alignItems: "flex-end", gap: 12, marginTop: 2 },
  sectionTitle: { fontFamily: fontFamily.extrabold, fontSize: 13, letterSpacing: 1.4, color: colors.textMuted, textTransform: "uppercase" },
  sectionSub: { marginTop: 3, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted, lineHeight: 17 },
  distributionTools: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 },
  distributionHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  distributionTitle: { fontFamily: fontFamily.extrabold, fontSize: 16, color: colors.dark },
  distributionSub: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  selectAllBtn: { flex: 1, minHeight: 48, borderRadius: 15, borderWidth: 1, borderColor: colors.accentLighter, backgroundColor: colors.warmSurface, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, paddingHorizontal: 12 },
  selectAllText: { fontFamily: fontFamily.extrabold, fontSize: 13, color: colors.primary },
  clearSmallBtn: { minHeight: 36, borderRadius: 12, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 12, alignItems: "center", justifyContent: "center" },
  clearSmallText: { fontFamily: fontFamily.extrabold, fontSize: 12, color: colors.text },
  bulkActions: { flexDirection: "row", gap: 10 },
  bulkBtn: { flex: 1, minHeight: 48, borderRadius: 15, borderWidth: 1, borderColor: colors.accentLighter, backgroundColor: colors.warmSurface, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, paddingHorizontal: 10 },
  bulkBtnText: { fontFamily: fontFamily.extrabold, fontSize: 13, color: colors.primary },
  bulkBtnDark: { flex: 1.2, minHeight: 48, borderRadius: 15, backgroundColor: colors.dark, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, paddingHorizontal: 10 },
  bulkBtnDarkText: { fontFamily: fontFamily.extrabold, fontSize: 13, color: colors.white },
  evenSplitBtn: { flex: 1.15, minHeight: 48, borderRadius: 15, backgroundColor: colors.dark, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, paddingHorizontal: 12 },
  evenSplitTitle: { fontFamily: fontFamily.extrabold, fontSize: 13, color: colors.white },
  evenSplitSub: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 11, color: "rgba(255,255,255,0.72)" },
  stickyAssign: { position: "absolute", left: 0, right: 0, bottom: 0, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12, paddingHorizontal: 14, gap: 10, shadowColor: "#0f172a", shadowOpacity: 0.18, shadowRadius: 18, shadowOffset: { width: 0, height: -6 }, elevation: 18, zIndex: 20 },
  stickyTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  stickyTitle: { fontFamily: fontFamily.extrabold, fontSize: 15, color: colors.dark },
  stickySub: { marginTop: 1, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  stickyClearBtn: { minHeight: 34, borderRadius: 12, borderWidth: 1, borderColor: colors.border, flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 10 },
  stickyClearText: { fontFamily: fontFamily.extrabold, fontSize: 12, color: colors.text },
  stickyControls: { flexDirection: "row", alignItems: "center", gap: 10 },
  riderSelect: { flex: 1, minHeight: 54, borderRadius: 16, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 12 },
  riderSelectLabel: { fontFamily: fontFamily.extrabold, fontSize: 10, letterSpacing: 1.1, textTransform: "uppercase", color: colors.textMuted },
  riderSelectValue: { marginTop: 1, fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.dark },
  stickyAssignBtn: { minHeight: 54, minWidth: 96, borderRadius: 16, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", paddingHorizontal: 18 },
  stickyAssignText: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.white },
  riderDropdown: { position: "absolute", left: 14, right: 14, borderRadius: 20, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, padding: 10, gap: 8, shadowColor: "#0f172a", shadowOpacity: 0.18, shadowRadius: 18, shadowOffset: { width: 0, height: 8 }, elevation: 20, zIndex: 25 },
  dropdownSearchWrap: { minHeight: 46, borderRadius: 15, borderWidth: 1, borderColor: colors.border, flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 12 },
  dropdownSearch: { flex: 1, fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark, paddingVertical: 0 },
  dropdownList: { maxHeight: 238 },
  dropdownEmpty: { minHeight: 74, alignItems: "center", justifyContent: "center" },
  dropdownOption: { minHeight: 60, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 8 },
  dropdownAvatar: { width: 38, height: 38, borderRadius: 13, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  dropdownAvatarSelf: { borderWidth: 1, borderColor: colors.accentLighter },
  dropdownName: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.dark },
  dropdownPhone: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  dropdownDivider: { position: "absolute", left: 56, right: 8, bottom: 0, height: StyleSheet.hairlineWidth, backgroundColor: colors.border },
  inlineAssign: { borderRadius: 20, borderWidth: 1, borderColor: colors.accentLighter, backgroundColor: "#fffaf2", padding: 14, gap: 12 },
  inlineAssignHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  inlineAssignTitle: { fontFamily: fontFamily.extrabold, fontSize: 16, color: colors.dark },
  inlineAssignSub: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  inlineAssignBtn: { minHeight: 44, borderRadius: 14, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", paddingHorizontal: 18 },
  inlineAssignBtnText: { fontFamily: fontFamily.extrabold, fontSize: 13, color: colors.white },
  memberChips: { gap: 8, paddingRight: 4 },
  memberChip: { width: 142, minHeight: 58, borderRadius: 15, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white, justifyContent: "center", paddingHorizontal: 12 },
  memberChipActive: { borderColor: colors.primary, backgroundColor: colors.warmSurface },
  memberChipName: { fontFamily: fontFamily.extrabold, fontSize: 13, color: colors.dark },
  memberChipNameActive: { color: colors.primary },
  memberChipPhone: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 11, color: colors.textMuted },
  memberChipPhoneActive: { color: colors.primary },
  packageList: { borderRadius: 20, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, overflow: "hidden" },
  groupHeader: { minHeight: 64, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 14, paddingVertical: 11, backgroundColor: "#f8fafc", borderBottomWidth: 1, borderBottomColor: colors.border },
  groupHeaderHighlighted: { backgroundColor: "#fff7ed" },
  groupIcon: { width: 38, height: 38, borderRadius: 14, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.accentLighter, alignItems: "center", justifyContent: "center" },
  groupTitle: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.dark },
  groupSub: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  groupCountPill: { borderRadius: 999, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.accentLighter, paddingHorizontal: 10, paddingVertical: 6 },
  groupCountText: { fontFamily: fontFamily.extrabold, fontSize: 11, color: colors.primary },
  packageRow: { minHeight: 106, flexDirection: "row", alignItems: "center", gap: 12, padding: 14 },
  packageRowSelected: { backgroundColor: "#fff7ed" },
  packageIcon: { width: 44, height: 44, borderRadius: 15, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  packageTitle: { fontFamily: fontFamily.extrabold, fontSize: 16, color: colors.dark },
  packageCode: { marginTop: 2, fontFamily: fontFamily.bold, fontSize: 12, color: colors.textMuted },
  packageMeta: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  packageLocationLine: { marginTop: 4, flexDirection: "row", alignItems: "center", gap: 4 },
  packageLocationText: { flex: 1, fontFamily: fontFamily.bold, fontSize: 12, color: colors.textMuted },
  allocatedText: { marginTop: 4, fontFamily: fontFamily.bold, fontSize: 11, color: colors.success },
  shareBtn: { minHeight: 40, flexDirection: "row", alignItems: "center", gap: 5, borderRadius: 14, backgroundColor: colors.primary, paddingHorizontal: 12 },
  shareText: { fontFamily: fontFamily.extrabold, fontSize: 12, color: colors.white },
  statusPill: { maxWidth: 118, borderRadius: 999, backgroundColor: "#f1f5f9", paddingHorizontal: 10, paddingVertical: 7 },
  statusText: { fontFamily: fontFamily.bold, fontSize: 10, color: colors.textMuted, textTransform: "capitalize" },
  rowDivider: { position: "absolute", left: 70, right: 14, bottom: 0, height: StyleSheet.hairlineWidth, backgroundColor: colors.border },
  emptyText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.textMuted },
  drawerOverlay: { flex: 1, backgroundColor: "rgba(15,23,42,0.58)", justifyContent: "flex-end" },
  drawer: { maxHeight: "88%", borderTopLeftRadius: 28, borderTopRightRadius: 28, backgroundColor: colors.white, overflow: "hidden" },
  drawerHandle: { width: 42, height: 5, borderRadius: 999, backgroundColor: colors.neutral300, alignSelf: "center", marginTop: 10, marginBottom: 6 },
  drawerHeader: { minHeight: 74, flexDirection: "row", alignItems: "center", gap: 11, paddingHorizontal: 18, paddingBottom: 13, backgroundColor: colors.white },
  drawerIcon: { width: 46, height: 46, borderRadius: 16, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  drawerTitle: { fontFamily: fontFamily.extrabold, fontSize: 18, color: colors.dark },
  drawerSubRow: { marginTop: 4, flexDirection: "row", alignItems: "center", gap: 7 },
  drawerSub: { flexShrink: 1, fontFamily: fontFamily.bold, fontSize: 12, color: colors.textMuted },
  drawerPhotoPill: { borderRadius: 999, backgroundColor: "#f1f5f9", paddingHorizontal: 8, paddingVertical: 4 },
  drawerPhotoPillText: { fontFamily: fontFamily.bold, fontSize: 10, color: colors.textMuted },
  drawerClose: { width: 40, height: 40, borderRadius: 14, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white, alignItems: "center", justifyContent: "center" },
  drawerBody: { backgroundColor: colors.background, padding: 16, gap: 12, paddingBottom: 18, borderTopWidth: 1, borderTopColor: colors.border },
  photoPanel: { borderRadius: 20, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, padding: 10 },
  photoStrip: { gap: 10, paddingRight: 4 },
  packagePhoto: { width: 136, height: 102, borderRadius: 16, backgroundColor: colors.neutral100 },
  noPhotoBox: { minHeight: 92, borderRadius: 18, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white, alignItems: "center", justifyContent: "center", gap: 6 },
  noPhotoText: { fontFamily: fontFamily.bold, fontSize: 12, color: colors.textMuted },
  detailGrid: { flexDirection: "row", gap: 10 },
  detailTile: { flex: 1, minHeight: 76, borderRadius: 18, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, padding: 12, justifyContent: "center" },
  detailTileLabel: { fontFamily: fontFamily.extrabold, fontSize: 10, letterSpacing: 1, textTransform: "uppercase", color: colors.textMuted },
  detailTileValue: { marginTop: 6, fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.text },
  detailCard: { borderRadius: 20, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, padding: 14, gap: 10 },
  detailCardTitle: { fontFamily: fontFamily.extrabold, fontSize: 13, letterSpacing: 0.5, textTransform: "uppercase", color: colors.dark },
  detailLine: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  detailLineText: { flex: 1, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted, lineHeight: 17 },
  drawerFooter: { backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12, paddingHorizontal: 18 },
  drawerFooterRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  drawerSecondaryBtn: { flex: 1, minHeight: 50, borderRadius: 16, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" },
  drawerSecondaryText: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.text },
  drawerPrimaryBtn: { flex: 1.25, minHeight: 50, borderRadius: 16, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
  drawerPrimaryText: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.white },
  drawerLockedPill: { flex: 1.25, minHeight: 50, borderRadius: 16, backgroundColor: "#f1f5f9", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 6, paddingHorizontal: 10 },
  drawerLockedText: { fontFamily: fontFamily.bold, fontSize: 12, color: colors.textMuted },
  confirmOverlay: { flex: 1, backgroundColor: "rgba(15,23,42,0.58)", justifyContent: "center", padding: 18 },
  confirmCard: { borderRadius: 26, backgroundColor: colors.white, overflow: "hidden" },
  confirmHeader: { flexDirection: "row", alignItems: "center", gap: 12, padding: 18, borderBottomWidth: 1, borderBottomColor: colors.border },
  confirmIcon: { width: 52, height: 52, borderRadius: 17, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
  confirmTitle: { fontFamily: fontFamily.extrabold, fontSize: 21, color: colors.dark },
  confirmSub: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 13, color: colors.textMuted },
  confirmStats: { flexDirection: "row", padding: 18, gap: 8 },
  confirmStat: { flex: 1, borderRadius: 16, borderWidth: 1, borderColor: colors.border, padding: 12 },
  confirmStatLabel: { fontFamily: fontFamily.extrabold, fontSize: 10, letterSpacing: 1, textTransform: "uppercase", color: colors.textMuted },
  confirmStatValue: { marginTop: 6, fontFamily: fontFamily.extrabold, fontSize: 22, color: colors.dark },
  remainderNotice: { marginHorizontal: 18, marginBottom: 4, borderRadius: 16, backgroundColor: colors.warmSurface, borderWidth: 1, borderColor: colors.accentLighter, padding: 12 },
  remainderText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.primary },
  confirmError: { marginHorizontal: 18, marginTop: 4, marginBottom: 4, borderRadius: 16, backgroundColor: colors.errorLight, borderWidth: 1, borderColor: "#fecaca", paddingHorizontal: 12, paddingVertical: 11, flexDirection: "row", alignItems: "flex-start", gap: 8 },
  confirmErrorText: { flex: 1, fontFamily: fontFamily.bold, fontSize: 12, lineHeight: 17, color: colors.errorDark },
  confirmFooter: { flexDirection: "row", gap: 10, padding: 18, borderTopWidth: 1, borderTopColor: colors.border },
  confirmCancelBtn: { flex: 1, minHeight: 50, borderRadius: 16, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" },
  confirmCancelText: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.text },
  confirmPrimaryBtn: { flex: 1.2, minHeight: 50, borderRadius: 16, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
  confirmPrimaryText: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.white },
  modalRoot: { flex: 1 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(15,23,42,0.58)", justifyContent: "center", padding: 18 },
  modalCard: { borderRadius: 28, backgroundColor: colors.white, overflow: "hidden" },
  modalHeader: { flexDirection: "row", alignItems: "center", gap: 12, padding: 18, borderBottomWidth: 1, borderBottomColor: colors.border },
  modalIcon: { width: 56, height: 56, borderRadius: 18, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
  modalTitle: { fontFamily: fontFamily.extrabold, fontSize: 22, color: colors.dark },
  modalSub: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 13, color: colors.textMuted },
  modalCloseBtn: { width: 42, height: 42, borderRadius: 14, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" },
  modalBody: { padding: 18, gap: 12 },
  sharePackageBox: { borderRadius: 18, borderWidth: 1, borderColor: colors.accentLighter, backgroundColor: "#fffaf2", padding: 14 },
  sharePackageName: { fontFamily: fontFamily.extrabold, fontSize: 16, color: colors.dark },
  sharePackageMeta: { marginTop: 3, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  smartSplitBox: { minHeight: 84, borderRadius: 18, borderWidth: 1, borderColor: colors.accentLighter, backgroundColor: "#fffaf2", padding: 14, flexDirection: "row", alignItems: "center", gap: 12 },
  smartSplitTitle: { fontFamily: fontFamily.extrabold, fontSize: 16, color: colors.dark },
  smartSplitSub: { marginTop: 3, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  smartSplitBtn: { minHeight: 42, borderRadius: 14, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", paddingHorizontal: 16 },
  smartSplitText: { fontFamily: fontFamily.extrabold, fontSize: 13, color: colors.white },
  modalSectionLabel: { fontFamily: fontFamily.extrabold, fontSize: 12, letterSpacing: 1.2, color: colors.textMuted, textTransform: "uppercase" },
  quantityChips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  quantityChip: { minHeight: 40, minWidth: 62, borderRadius: 14, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white, alignItems: "center", justifyContent: "center", paddingHorizontal: 12 },
  quantityChipActive: { borderColor: colors.primary, backgroundColor: colors.warmSurface },
  quantityChipText: { fontFamily: fontFamily.extrabold, fontSize: 13, color: colors.textMuted },
  quantityChipTextActive: { color: colors.primary },
  packagePickList: { maxHeight: 238, borderRadius: 18, borderWidth: 1, borderColor: colors.border, overflow: "hidden" },
  packagePickRow: { minHeight: 62, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 14 },
  packagePickTitle: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.dark },
  packagePickMeta: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 11, color: colors.textMuted },
  packagePickDivider: { position: "absolute", left: 46, right: 14, bottom: 0, height: StyleSheet.hairlineWidth, backgroundColor: colors.border },
  memberList: { borderRadius: 18, borderWidth: 1, borderColor: colors.border, overflow: "hidden" },
  memberEmpty: { minHeight: 86, alignItems: "center", justifyContent: "center", padding: 14 },
  memberOption: { minHeight: 64, flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 14 },
  memberAvatar: { width: 38, height: 38, borderRadius: 13, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  memberName: { fontFamily: fontFamily.extrabold, fontSize: 15, color: colors.dark },
  memberPhone: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  memberDivider: { position: "absolute", left: 64, right: 14, bottom: 0, height: StyleSheet.hairlineWidth, backgroundColor: colors.border },
  modalFooter: { flexDirection: "row", gap: 10, padding: 18, borderTopWidth: 1, borderTopColor: colors.border },
  modalCancelBtn: { flex: 1, minHeight: 52, borderRadius: 16, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" },
  modalCancelText: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.text },
  modalSaveBtn: { flex: 1.25, minHeight: 52, borderRadius: 16, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
  modalSaveText: { fontFamily: fontFamily.extrabold, fontSize: 14, color: colors.white },
});
