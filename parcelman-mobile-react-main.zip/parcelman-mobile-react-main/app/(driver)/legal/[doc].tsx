import { useLocalSearchParams } from "expo-router";
import LegalWebView from "../../../src/components/common/LegalWebView";

const DOCS: Record<string, { title: string; subtitle: string }> = {
  "privacy-policy": { title: "Privacy Policy", subtitle: "How we handle your data" },
  "terms-of-service": { title: "Terms & Conditions", subtitle: "Read our terms of service" },
};

export default function DriverLegalScreen() {
  const { doc } = useLocalSearchParams<{ doc: string }>();
  const slug = doc && DOCS[doc] ? doc : "privacy-policy";
  const meta = DOCS[slug];

  return (
    <LegalWebView
      slug={slug}
      title={meta.title}
      subtitle={meta.subtitle}
      fallbackRoute="/(driver)/(tabs)/account"
    />
  );
}
