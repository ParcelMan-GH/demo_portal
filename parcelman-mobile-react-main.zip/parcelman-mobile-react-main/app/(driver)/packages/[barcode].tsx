import { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  Linking,
  Dimensions,
} from "react-native";
import { router, useLocalSearchParams, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { formatDateTimeAmPm, formatPhone } from "../../../src/utils/format";
import { showSuccess, showError, getErrorMessage } from "../../../src/utils/toast";
import { ListSkeleton } from "../../../src/components/common/ShimmerLoading";
import ConfirmDialog from "../../../src/components/common/ConfirmDialog";
import { getMyPackages, releasePackage, getPackageHistory } from "../../../src/api/v1/driver/custody";
import type { DriverHeldPackage, DriverPackageHistoryEvent } from "../../../src/types/driver";

const { width } = Dimensions.get("window");

function getRouteLabel(pkg: Pick<DriverHeldPackage, "delivery_method" | "route_label" | "recipient_name">): string {
  if (pkg.delivery_method === "bus_handoff") {
    return pkg.route_label || "Bus Station";
  }

  return pkg.route_label || pkg.recipient_name || "Unknown";
}

function getRouteIcon(deliveryMethod: DriverHeldPackage["delivery_method"]) {
  return deliveryMethod === "bus_handoff" ? "bus-outline" : "person-outline";
}

export default function PackageDetailScreen() {
  const insets = useSafeAreaInsets();
  const { barcode: trackingCode } = useLocalSearchParams<{ barcode: string }>();
  const packagesRoute = "/(driver)/packages" as const;
  const leavePackageDetail = () => {
    if (router.canGoBack()) router.back();
    else router.replace(packagesRoute as any);
  };
  const [labels, setLabels] = useState<DriverHeldPackage[]>([]);
  const [history, setHistory] = useState<DriverPackageHistoryEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [releaseTarget, setReleaseTarget] = useState<DriverHeldPackage | null>(null);
  const [releaseLoading, setReleaseLoading] = useState(false);

  const fetchData = async () => {
    try {
      // Get all held labels for this tracking code
      const res = await getMyPackages();
      const d = (res as any).data || res;
      const all: DriverHeldPackage[] = d.packages || d.items || [];
      const matching = all.filter((p) => (p.tracking_code || p.barcode) === trackingCode);
      setLabels(matching);

      // Get history for the first label
      if (matching.length > 0) {
        try {
          const histRes = await getPackageHistory(matching[0].barcode);
          const histData = (histRes as any).data || histRes;
          setHistory((histData.history || []) as DriverPackageHistoryEvent[]);
        } catch {
          // history not critical
        }
      }
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      fetchData();
    }, [trackingCode])
  );

  const handleRelease = async () => {
    if (!releaseTarget) return;
    setReleaseLoading(true);
    try {
      await releasePackage({ barcode: releaseTarget.barcode });
      setLabels((prev) => prev.filter((l) => l.barcode !== releaseTarget.barcode));
      showSuccess(`Released ${releaseTarget.barcode}`);
      setReleaseTarget(null);
      // Go back if no labels left
      if (labels.length <= 1) {
        router.replace(packagesRoute as any);
      }
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setReleaseLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={s.container}>
        <View style={{ backgroundColor: "#0f172a", height: insets.top + 60 }} />
        <View style={{ padding: 16 }}><ListSkeleton count={4} /></View>
      </View>
    );
  }

  const first = labels[0];
  const title = first?.description || "Package";
  const recipientPhone = first?.recipient_phone;
  const routeLabel = first ? getRouteLabel(first) : "Unknown";
  const isBusHandoff = first?.delivery_method === "bus_handoff";

  return (
    <View style={s.container}>
      <ScrollView
        refreshControl={<RefreshControl refreshing={false} onRefresh={fetchData} colors={[colors.primary]} />}
        contentContainerStyle={{ paddingBottom: insets.bottom + 80 }}
      >
        <View style={{ backgroundColor: "#0f172a", height: insets.top }} />

        {/* Header */}
        <LinearGradient
          colors={["#0f172a", "#1e3a5f", "#0f172a"]}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={s.header}
        >
          <View style={s.heroDecor} />
          <View style={s.headerTop}>
            <TouchableOpacity onPress={leavePackageDetail} style={s.backBtn}>
              <Ionicons name="arrow-back" size={22} color={colors.white} />
            </TouchableOpacity>
            <View style={{ flex: 1 }}>
              <Text style={s.headerTitle} numberOfLines={1}>{title}</Text>
              <Text style={s.headerSub}>{trackingCode}</Text>
            </View>
            <View style={s.badge}>
              <Text style={s.badgeText}>{labels.length}</Text>
            </View>
          </View>

          {/* Recipient summary */}
          {first && (
            <View style={s.heroMeta}>
              <View style={s.metaItem}>
                <Ionicons name={getRouteIcon(first.delivery_method)} size={13} color={isBusHandoff ? "#c4b5fd" : "rgba(255,255,255,0.5)"} />
                <Text style={s.metaText}>{routeLabel}</Text>
              </View>
              <View style={s.metaItem}>
                <Ionicons name="location-outline" size={13} color="rgba(255,255,255,0.5)" />
                <Text style={s.metaText}>{first.delivery_town || "Unknown"}</Text>
              </View>
              {first.labels_total && (
                <View style={s.metaItem}>
                  <Ionicons name="pricetag-outline" size={13} color="rgba(255,255,255,0.5)" />
                  <Text style={s.metaText}>{labels.length} of {first.labels_total} labels held</Text>
                </View>
              )}
            </View>
          )}
        </LinearGradient>

        <View style={s.body}>
          {/* Labels Card */}
          <View style={s.card}>
            <View style={s.cardHeader}>
              <View style={[s.cardIconWrap, { backgroundColor: "#dbeafe" }]}>
                <Ionicons name="pricetags" size={18} color="#3b82f6" />
              </View>
              <Text style={[s.cardTitle, { flex: 1 }]}>LABELS ({labels.length})</Text>
            </View>

            {labels.map((label, i) => (
              <View key={label.barcode} style={[s.labelCard, i < labels.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.neutral100 }]}>
                <View style={s.labelRow}>
                  <View style={s.labelIcon}>
                    <Ionicons name="barcode-outline" size={16} color="#3b82f6" />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={s.labelBarcode}>{label.barcode}</Text>
                    {label.label_index && label.labels_total && (
                      <Text style={s.labelIndex}>Label {label.label_index} of {label.labels_total}</Text>
                    )}
                  </View>
                  <TouchableOpacity
                    style={s.releaseBtn}
                    onPress={() => setReleaseTarget(label)}
                    activeOpacity={0.7}
                  >
                    <Ionicons name="arrow-undo-outline" size={13} color={colors.error} />
                    <Text style={s.releaseBtnText}>Release</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>

          {/* Recipient Card */}
          {first && (
            <View style={s.card}>
              <View style={s.cardHeader}>
                <View style={[s.cardIconWrap, { backgroundColor: isBusHandoff ? "#ede9fe" : "#ffedd5" }]}>
                  <Ionicons name={isBusHandoff ? "bus" : "person"} size={18} color={isBusHandoff ? "#7c3aed" : colors.primary} />
                </View>
                <Text style={s.cardTitle}>{isBusHandoff ? "ROUTING DETAILS" : "RECIPIENT"}</Text>
              </View>
              <InfoRow label="Delivery Method" value={isBusHandoff ? "Bus Station Handoff" : "Direct Delivery"} />
              <InfoRow label={isBusHandoff ? "Route To" : "Name"} value={isBusHandoff ? routeLabel : first.recipient_name} />
              {isBusHandoff && first.recipient_name ? (
                <InfoRow label="Recipient" value={first.recipient_name} />
              ) : null}
              {recipientPhone ? (
                <TouchableOpacity onPress={() => Linking.openURL(`tel:${recipientPhone}`)} activeOpacity={0.6}>
                  <View style={s.infoRow}>
                    <Text style={s.infoLabel}>{isBusHandoff ? "RECIPIENT PHONE" : "PHONE"}</Text>
                    <View style={s.phoneRow}>
                      <Text style={[s.infoValue, { color: colors.infoDark }]}>{formatPhone(recipientPhone)}</Text>
                      <Ionicons name="call-outline" size={14} color={colors.infoDark} />
                    </View>
                  </View>
                </TouchableOpacity>
              ) : (
                <InfoRow label="Phone" value={undefined} />
              )}
              <InfoRow label="Delivery Town" value={first.delivery_town} />
              <InfoRow label="Shipment" value={first.shipment_number} />
            </View>
          )}

          {/* Custody History */}
          {history.length > 0 && (
            <View style={s.card}>
              <View style={s.cardHeader}>
                <View style={[s.cardIconWrap, { backgroundColor: "#dcfce7" }]}>
                  <Ionicons name="git-network" size={18} color={colors.success} />
                </View>
                <Text style={s.cardTitle}>CUSTODY HISTORY</Text>
              </View>

              {history.map((event, i) => {
                const isClaimed = event.event_type === "claimed";
                const iconName = isClaimed ? "arrow-down" : "arrow-up";
                const iconColor = isClaimed ? colors.success : "#f97316";
                const dotBg = isClaimed ? "#dcfce7" : "#ffedd5";
                const isLast = i === history.length - 1;

                return (
                  <View key={i} style={s.timelineRow}>
                    <View style={s.timelineDotCol}>
                      <View style={[s.timelineDot, { backgroundColor: dotBg }]}>
                        <Ionicons name={iconName} size={14} color={iconColor} />
                      </View>
                      {!isLast && <View style={s.timelineLine} />}
                    </View>
                    <View style={[s.timelineContent, !isLast && { paddingBottom: 16 }]}>
                      <View style={s.timelineEventRow}>
                        <Text style={s.timelineEventType}>{isClaimed ? "Claimed" : "Released"}</Text>
                        <Text style={s.timelineTime}>{formatDateTimeAmPm(event.created_at)}</Text>
                      </View>
                      <Text style={s.timelineDriver}>{event.driver_name}</Text>
                      {!!event.notes && <Text style={s.timelineNotes}>{event.notes}</Text>}
                    </View>
                  </View>
                );
              })}
            </View>
          )}
        </View>
      </ScrollView>

      {/* Footer */}
      {recipientPhone && (
        <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
          <TouchableOpacity style={s.callBtn} onPress={() => Linking.openURL(`tel:${recipientPhone}`)} activeOpacity={0.8}>
            <LinearGradient colors={[colors.primary, colors.primaryLight]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={s.callBtnGradient}>
              <Ionicons name="call" size={18} color={colors.white} />
              <Text style={s.callBtnText}>Call Recipient</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}

      <ConfirmDialog
        visible={!!releaseTarget}
        type="error"
        title="Release Label"
        message={`Release ${releaseTarget?.barcode}? It will go back to the warehouse.`}
        confirmText="Release"
        onConfirm={handleRelease}
        onCancel={() => setReleaseTarget(null)}
        loading={releaseLoading}
      />
    </View>
  );
}

function InfoRow({ label, value, mono }: { label: string; value?: string | null; mono?: boolean }) {
  return (
    <View style={s.infoRow}>
      <Text style={s.infoLabel}>{label.toUpperCase()}</Text>
      <Text style={[s.infoValue, mono && { fontFamily: "monospace" }]}>{value || "\u2014"}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, gap: 10, overflow: "hidden" },
  heroDecor: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.white },
  headerSub: { fontFamily: "monospace", fontSize: 11, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  badge: { backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 12, minWidth: 32, height: 28, justifyContent: "center", alignItems: "center", paddingHorizontal: 10, borderWidth: 1, borderColor: "rgba(255,255,255,0.2)" },
  badgeText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.white },
  heroMeta: { gap: 4 },
  metaItem: { flexDirection: "row", alignItems: "center", gap: 6 },
  metaText: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.6)" },
  body: { padding: 16, gap: 14 },
  card: { backgroundColor: colors.white, borderRadius: 14, padding: 16, gap: 8, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 4 },
  cardIconWrap: { width: 34, height: 34, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, letterSpacing: 0.5 },
  // Labels
  labelCard: { paddingVertical: 12 },
  labelRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  labelIcon: { width: 32, height: 32, borderRadius: 8, backgroundColor: "#eff6ff", justifyContent: "center", alignItems: "center" },
  labelBarcode: { fontFamily: "monospace", fontSize: 13, color: colors.dark },
  labelIndex: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, marginTop: 1 },
  releaseBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.errorLight, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 6 },
  releaseBtnText: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.error },
  // Info rows
  infoRow: { paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  infoLabel: { fontFamily: fontFamily.medium, fontSize: 10, color: colors.textMuted, letterSpacing: 0.8, textTransform: "uppercase", marginBottom: 2 },
  infoValue: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.dark },
  phoneRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  // Timeline
  timelineRow: { flexDirection: "row" },
  timelineDotCol: { width: 32, alignItems: "center" },
  timelineDot: { width: 26, height: 26, borderRadius: 13, justifyContent: "center", alignItems: "center" },
  timelineLine: { width: 2, flex: 1, backgroundColor: colors.neutral200, marginVertical: 2 },
  timelineContent: { flex: 1, marginLeft: 10, paddingBottom: 4 },
  timelineEventRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  timelineEventType: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.dark },
  timelineTime: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted },
  timelineDriver: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.text, marginTop: 2 },
  timelineNotes: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, fontStyle: "italic", marginTop: 3 },
  // Footer
  footer: { paddingHorizontal: 16, paddingTop: 12, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.border },
  callBtn: { borderRadius: 12, overflow: "hidden" },
  callBtnGradient: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 14, borderRadius: 12 },
  callBtnText: { fontFamily: fontFamily.semibold, fontSize: 15, color: colors.white },
});
