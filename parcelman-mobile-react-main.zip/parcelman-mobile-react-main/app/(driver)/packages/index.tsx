import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity, Dimensions, TextInput, Modal, Pressable, Platform, ScrollView, Linking, KeyboardAvoidingView } from "react-native";
import { useState, useCallback, useEffect } from "react";
import { router, useFocusEffect } from "expo-router";
import DateTimePicker from "@react-native-community/datetimepicker";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../../src/components/common/EmptyState";
import ShimmerLoading from "../../../src/components/common/ShimmerLoading";
import Button from "../../../src/components/common/Button";
import SlideToConfirm from "../../../src/components/common/SlideToConfirm";
import ImagePickerButton from "../../../src/components/common/ImagePickerButton";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { showSuccess, showError, getErrorMessage } from "../../../src/utils/toast";
import { formatDateTimeAmPm, formatPhone, isValidGhanaPhone, sanitizeLocalPhoneInput, toApiPhone } from "../../../src/utils/format";
import { changePackageLocation, getMyPackages, requestPackageTransfer, searchDriverLocations, startDeliveries } from "../../../src/api/v1/driver/custody";
import type { DriverHeldPackage } from "../../../src/types/driver";

const { width } = Dimensions.get("window");
const getToday = () => new Date().toISOString().split("T")[0];

const DATE_FILTERS = [
  { label: "Today", value: "today" },
  { label: "All Time", value: "all" },
];

const STATUS_FILTERS = [
  { label: "Ready", value: "available" },
  { label: "Team", value: "team_assigned" },
  { label: "In Delivery", value: "in_delivery" },
  { label: "All", value: "all" },
];

interface PackageGroup {
  tracking_code: string;
  description: string;
  route_label: string;
  recipient_name: string | null;
  delivery_town: string;
  labels_total: number;
  delivery_method: DriverHeldPackage["delivery_method"];
  claimed_at: string | null;
  team_name: string | null;
  assigned_by_name: string | null;
  source_label: string | null;
  labels: DriverHeldPackage[];
  availableCount: number;
  inRunCount: number;
  teamAssignedCount: number;
  teamPackageCount: number;
  hasPendingTransfer: boolean;
  pendingTransfer: DriverHeldPackage["pending_transfer"] | null;
  canChangeLocation: boolean;
  canTransfer: boolean;
}

interface LocationSuggestion {
  id: number;
  name: string;
  display?: string;
  district?: { id: number; name: string };
  region?: { id: number; name: string };
}

function getRouteLabel(pkg: Pick<DriverHeldPackage, "delivery_method" | "route_label" | "recipient_name">): string {
  if (pkg.delivery_method === "bus_handoff") {
    return pkg.route_label || "Bus Station";
  }

  return pkg.route_label || pkg.recipient_name || "Unknown";
}

function getRouteIcon(deliveryMethod: DriverHeldPackage["delivery_method"]) {
  return deliveryMethod === "bus_handoff" ? "bus-outline" : "person-outline";
}

function groupPackages(packages: DriverHeldPackage[]): PackageGroup[] {
  const map = new Map<string, PackageGroup>();
  for (const pkg of packages) {
    const key = pkg.tracking_code || pkg.barcode;
    if (!map.has(key)) {
      map.set(key, {
        tracking_code: key,
        description: pkg.description || "Package",
        route_label: getRouteLabel(pkg),
        recipient_name: pkg.recipient_name,
        delivery_town: pkg.delivery_town || "",
        labels_total: pkg.labels_total || 1,
        delivery_method: pkg.delivery_method || "direct",
        claimed_at: pkg.claimed_at || null,
        team_name: pkg.team?.name || null,
        assigned_by_name: pkg.assigned_by?.name || null,
        source_label: pkg.claim_source === "rider_team_assigned"
          ? "Team assigned"
          : pkg.claim_source === "rider_team_claimed"
            ? "From team"
            : null,
        labels: [],
        availableCount: 0,
        inRunCount: 0,
        teamAssignedCount: 0,
        teamPackageCount: 0,
        hasPendingTransfer: false,
        pendingTransfer: null,
        canChangeLocation: false,
        canTransfer: false,
      });
    }
    const group = map.get(key)!;
    group.labels.push(pkg);
    if (pkg.pending_transfer) {
      group.hasPendingTransfer = true;
      group.pendingTransfer = pkg.pending_transfer;
    }
    if (pkg.in_delivery_run) group.inRunCount++;
    else if (pkg.can_start_delivery !== false && !pkg.pending_transfer) group.availableCount++;
    if (pkg.can_change_location) group.canChangeLocation = true;
    if (pkg.can_transfer) group.canTransfer = true;
    if (pkg.claim_source === "rider_team_assigned" || (pkg.team && pkg.is_claimed === false)) group.teamAssignedCount++;
    if (pkg.team || pkg.claim_source === "rider_team_assigned" || pkg.claim_source === "rider_team_claimed") group.teamPackageCount++;
  }
  return Array.from(map.values());
}

export default function MyPackagesScreen() {
  const insets = useSafeAreaInsets();
  const homeRoute = "/(driver)/(tabs)/home" as const;
  const leavePackages = () => {
    if (router.canGoBack()) router.back();
    else router.replace(homeRoute as any);
  };
  const [packages, setPackages] = useState<DriverHeldPackage[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [startingDeliveries, setStartingDeliveries] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState<PackageGroup | null>(null);
  const [locationTarget, setLocationTarget] = useState<PackageGroup | null>(null);
  const [transferTarget, setTransferTarget] = useState<PackageGroup | null>(null);
  const [filter, setFilter] = useState("today");
  const [statusFilter, setStatusFilter] = useState("available");
  const [search, setSearch] = useState("");
  const [dateFrom, setDateFrom] = useState<Date | null>(null);
  const [dateTo, setDateTo] = useState<Date | null>(null);
  const [pendingDateFrom, setPendingDateFrom] = useState<Date | null>(null);
  const [pendingDateTo, setPendingDateTo] = useState<Date | null>(null);
  const [showDateModal, setShowDateModal] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState<"from" | "to" | null>(null);

  const fetchPackages = async (overrideFilter?: string, overrideDateFrom?: Date | null, overrideDateTo?: Date | null) => {
    const f = overrideFilter ?? filter;
    const df = overrideDateFrom !== undefined ? overrideDateFrom : dateFrom;
    const dt = overrideDateTo !== undefined ? overrideDateTo : dateTo;
    try {
      const params: any = { limit: 100 };
      if (df) {
        params.from_date = df.toISOString().split("T")[0];
      } else if (f === "today") {
        params.from_date = getToday();
        params.to_date = getToday();
      }
      if (dt) {
        params.to_date = dt.toISOString().split("T")[0];
      }
      const res = await getMyPackages(params);
      const d = (res as any)?.data || res;
      const items: DriverHeldPackage[] = d?.packages || d?.items || [];
      setPackages(items);

      // If no available packages, switch to "All" so the list isn't empty on first load
      const hasAvailable = items.some((p) => !p.in_delivery_run && p.can_start_delivery !== false && !p.pending_transfer);
      if (!hasAvailable && items.length > 0 && statusFilter === "available") {
        setStatusFilter("all");
      }
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Re-fetch every time screen gains focus
  useFocusEffect(
    useCallback(() => {
      setLoading(true);
      fetchPackages();
    }, [filter, dateFrom, dateTo]) // eslint-disable-line react-hooks/exhaustive-deps
  );

  const handleStartDeliveries = async () => {
    const availableBarcodes = packages
      .filter((p) => !p.in_delivery_run && p.can_start_delivery !== false && !p.pending_transfer)
      .map((p) => p.barcode)
      .filter(Boolean);

    setStartingDeliveries(true);
    try {
      const res = await startDeliveries({ barcodes: availableBarcodes });
      const d = (res as any)?.data || res;
      const deliveryRunId = d.delivery_run_id || d.id;
      if (d.existing) {
        showSuccess("Continuing existing delivery run");
      } else {
        showSuccess("Delivery run started!");
      }
      router.push({
        pathname: "/(driver)/delivery/[id]",
        params: { id: String(deliveryRunId) },
      } as any);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setStartingDeliveries(false);
    }
  };

  const groups = groupPackages(packages);
  const statusFiltered = statusFilter === "all"
    ? groups
    : statusFilter === "in_delivery"
      ? groups.filter((g) => g.inRunCount > 0)
      : statusFilter === "team_assigned"
        ? groups.filter((g) => g.teamPackageCount > 0)
      : groups.filter((g) => g.availableCount > 0);
  const filtered = search.trim()
    ? statusFiltered.filter((g) =>
        g.description.toLowerCase().includes(search.toLowerCase()) ||
        g.tracking_code.toLowerCase().includes(search.toLowerCase()) ||
        (g.route_label || "").toLowerCase().includes(search.toLowerCase()) ||
        (g.recipient_name || "").toLowerCase().includes(search.toLowerCase()) ||
        g.delivery_town.toLowerCase().includes(search.toLowerCase()) ||
        (g.team_name || "").toLowerCase().includes(search.toLowerCase()) ||
        (g.assigned_by_name || "").toLowerCase().includes(search.toLowerCase())
      )
    : statusFiltered;
  const availableLabelCount = packages.filter((p) => !p.in_delivery_run && p.can_start_delivery !== false && !p.pending_transfer).length;
  const teamAssignedLabelCount = packages.filter((p) => p.team || p.claim_source === "rider_team_assigned" || p.claim_source === "rider_team_claimed").length;
  const inRunLabelCount = packages.filter((p) => p.in_delivery_run).length;
  const renderItem = ({ item }: { item: PackageGroup }) => {
    const heldCount = item.labels.length;

    const allInRun = item.inRunCount > 0 && item.availableCount === 0 && item.teamAssignedCount === 0;
    const someInRun = item.inRunCount > 0 && item.availableCount > 0;
    const isTeamAssigned = item.teamAssignedCount > 0 && item.availableCount === 0;

    return (
      <TouchableOpacity style={[s.card, allInRun && s.cardInRun]} activeOpacity={0.7} onPress={() => setSelectedGroup(item)}>
        <View style={[s.cardAccent, allInRun && { backgroundColor: colors.success }]} />
        <View style={s.cardBody}>
          <View style={s.cardTop}>
            <View style={[s.cardIcon, allInRun && { backgroundColor: "#dcfce7" }]}>
              <Ionicons name={allInRun ? "checkmark-circle" : isTeamAssigned ? "people" : "cube"} size={18} color={allInRun ? colors.success : colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                <Text style={s.cardTitle} numberOfLines={1}>{item.description} ({heldCount})</Text>
                {item.source_label && (
                  <View style={s.teamBadge}>
                    <Ionicons name="people" size={10} color={colors.primary} />
                    <Text style={s.teamBadgeText}>{item.source_label}</Text>
                  </View>
                )}
                {allInRun && (
                  <View style={s.inRunBadge}>
                    <Text style={s.inRunBadgeText}>In Delivery</Text>
                  </View>
                )}
                {someInRun && (
                  <View style={s.mixedBadge}>
                    <Text style={s.mixedBadgeText}>{item.inRunCount} in delivery</Text>
                  </View>
                )}
                {item.hasPendingTransfer && (
                  <View style={s.pendingTransferBadge}>
                    <Ionicons name="swap-horizontal" size={10} color="#b45309" />
                    <Text style={s.pendingTransferBadgeText}>Transfer pending</Text>
                  </View>
                )}
                {item.delivery_method === "bus_handoff" && (
                  <View style={s.handoffBadge}>
                    <Ionicons name="bus" size={10} color="#7c3aed" />
                    <Text style={s.handoffBadgeText}>Bus Handoff</Text>
                  </View>
                )}
              </View>
              <View style={s.cardMeta}>
                <Ionicons name={getRouteIcon(item.delivery_method)} size={12} color={item.delivery_method === "bus_handoff" ? "#7c3aed" : colors.textMuted} />
                <Text style={s.cardMetaText}>
                  {item.delivery_method === "bus_handoff" || !item.delivery_town
                    ? item.route_label
                    : `${item.route_label} → ${item.delivery_town}`}
                </Text>
              </View>
              {item.team_name ? (
                <View style={s.cardMeta}>
                  <Ionicons name="people-outline" size={12} color={colors.primary} />
                  <Text style={s.cardMetaText}>
                    {item.assigned_by_name ? `From ${item.assigned_by_name} · ${item.team_name}` : item.team_name}
                  </Text>
                </View>
              ) : null}
              <View style={s.cardMeta}>
                <Ionicons name="pricetag-outline" size={12} color={colors.textMuted} />
                <Text style={s.cardMetaText}>{heldCount} of {item.labels_total} labels</Text>
                {item.claimed_at && (
                  <>
                    <Ionicons name="time-outline" size={12} color={colors.textMuted} />
                    <Text style={s.cardMetaText}>{formatDateTimeAmPm(item.claimed_at)}</Text>
                  </>
                )}
              </View>
            </View>
          </View>
          <View style={s.cardBottom}>
            {item.hasPendingTransfer ? (
              <Text style={s.pendingTransferText} numberOfLines={1}>Waiting for {item.pendingTransfer?.to_driver?.name || "rider"}</Text>
            ) : item.availableCount > 0 ? (
              <Text style={s.readyText}>{item.availableCount} ready</Text>
            ) : <View />}
            <TouchableOpacity style={s.viewBtn} onPress={() => setSelectedGroup(item)}>
              <Text style={s.viewBtnText}>View Details</Text>
              <Ionicons name="arrow-forward" size={14} color={colors.primary} />
            </TouchableOpacity>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  if (loading && packages.length === 0) {
    return <MyPackagesSkeleton topInset={insets.top} bottomInset={insets.bottom} />;
  }

  return (
    <View style={s.container}>
      <LinearGradient colors={["#1e293b", "#334155", "#1e293b"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
        <View style={s.heroDecor1} />
        <View style={s.headerRow}>
          <TouchableOpacity style={s.headerIconWrap} onPress={leavePackages} activeOpacity={0.7}>
            <Ionicons name="arrow-back" size={20} color={colors.white} />
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={s.headerTitle}>My Packages</Text>
            <Text style={s.headerSub}>{packages.length} label{packages.length !== 1 ? "s" : ""} · {groups.length} package{groups.length !== 1 ? "s" : ""}</Text>
          </View>
          <View style={s.headerActions}>
            <TouchableOpacity style={s.headerActionBtn} onPress={() => router.push("/(driver)/package-transfers" as any)} activeOpacity={0.7}>
              <Ionicons name="swap-horizontal" size={18} color={colors.white} />
            </TouchableOpacity>
            <TouchableOpacity style={s.scanBtn} onPress={() => router.push("/(driver)/(tabs)/scan" as any)} activeOpacity={0.7}>
              <Ionicons name="scan" size={18} color={colors.white} />
              <Text style={s.scanBtnText}>Scan</Text>
            </TouchableOpacity>
          </View>
        </View>
        <View style={s.filterWrap}>
          {STATUS_FILTERS.map((f) => {
            const isActive = f.value === statusFilter;
            const count = f.value === "available"
              ? availableLabelCount
              : f.value === "team_assigned"
                ? teamAssignedLabelCount
                : f.value === "in_delivery"
                  ? inRunLabelCount
                  : packages.length;
            return (
              <TouchableOpacity key={f.value} style={[s.filterChip, isActive && s.filterChipActive]} onPress={() => setStatusFilter(f.value)}>
                <Text style={[s.filterText, isActive && s.filterTextActive]}>{f.label}</Text>
                <View style={[s.filterCount, isActive && s.filterCountActive]}>
                  <Text style={[s.filterCountText, isActive && s.filterCountTextActive]}>{count}</Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
        <View style={s.filterWrap}>
          {DATE_FILTERS.map((f) => {
            const isActive = f.value === filter && !dateFrom && !dateTo;
            return (
              <TouchableOpacity key={f.value} style={[s.filterChip, isActive && s.filterChipActive]} onPress={() => { setDateFrom(null); setDateTo(null); setFilter(f.value); }}>
                <Text style={[s.filterText, isActive && s.filterTextActive]}>{f.label}</Text>
              </TouchableOpacity>
            );
          })}
          <TouchableOpacity
            style={[s.calendarBtn, (dateFrom || dateTo) && s.calendarBtnActive]}
            onPress={() => { setPendingDateFrom(dateFrom); setPendingDateTo(dateTo); setShowDateModal(true); }}
          >
            <Ionicons name="calendar-outline" size={14} color={(dateFrom || dateTo) ? colors.primary : "rgba(255,255,255,0.5)"} />
            <Text style={[s.filterText, (dateFrom || dateTo) && { color: colors.primary }]}>Custom</Text>
          </TouchableOpacity>
        </View>
        <View style={s.searchRow}>
          <Ionicons name="search-outline" size={16} color="rgba(255,255,255,0.4)" />
          <TextInput style={s.searchInput} value={search} onChangeText={setSearch} placeholder="Search packages..." placeholderTextColor="rgba(255,255,255,0.3)" returnKeyType="search" />
          {search.length > 0 && <TouchableOpacity onPress={() => setSearch("")}><Ionicons name="close-circle" size={16} color="rgba(255,255,255,0.4)" /></TouchableOpacity>}
        </View>
      </LinearGradient>

      {/* Active date filter indicator */}
      {(dateFrom || dateTo) && (
        <TouchableOpacity style={s.activeFilter} onPress={() => { setDateFrom(null); setDateTo(null); }}>
          <Ionicons name="calendar" size={12} color={colors.primary} />
          <Text style={s.activeFilterText}>
            {dateFrom ? dateFrom.toLocaleDateString("en-GB", { day: "numeric", month: "short" }) : "Start"}
            {" → "}
            {dateTo ? dateTo.toLocaleDateString("en-GB", { day: "numeric", month: "short" }) : "Now"}
          </Text>
          <Ionicons name="close-circle" size={14} color={colors.textMuted} />
        </TouchableOpacity>
      )}

      <View style={s.body}>
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.tracking_code}
          renderItem={renderItem}
          contentContainerStyle={s.list}
          ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchPackages(); }} colors={[colors.primary]} />}
          ListEmptyComponent={<EmptyState icon="cube-outline" title="No packages" subtitle={search ? "No packages match your search" : "Scan packages to get started"} illustration="packages" />}
        />
      </View>

      {packages.length > 0 && (availableLabelCount > 0 || inRunLabelCount > 0) && (
        <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
          {inRunLabelCount > 0 && availableLabelCount === 0 ? (
            <Button
              title="View Deliveries"
              onPress={() => router.push("/(driver)/(tabs)/deliveries" as any)}
              leftIcon={<Ionicons name="navigate" size={18} color={colors.white} />}
              style={s.startBtn}
            />
          ) : (
            <SlideToConfirm
              title="Slide to start deliveries"
              onConfirm={handleStartDeliveries}
              loading={startingDeliveries}
              icon="car-outline"
            />
          )}
        </View>
      )}

      <PackageDetailsModal
        group={selectedGroup}
        onClose={() => setSelectedGroup(null)}
        onChangeLocation={(group) => {
          setSelectedGroup(null);
          requestAnimationFrame(() => setLocationTarget(group));
        }}
        onTransfer={(group) => {
          setSelectedGroup(null);
          requestAnimationFrame(() => setTransferTarget(group));
        }}
      />

      <ChangeLocationModal
        group={locationTarget}
        onClose={() => setLocationTarget(null)}
        onSaved={() => {
          setLocationTarget(null);
          setSelectedGroup(null);
          fetchPackages();
        }}
      />

      <TransferPackageModal
        group={transferTarget}
        onClose={() => setTransferTarget(null)}
        onSaved={() => {
          setTransferTarget(null);
          setSelectedGroup(null);
          fetchPackages();
        }}
      />

      {/* Date Range Sheet */}
      <Modal visible={showDateModal} transparent animationType="slide" onRequestClose={() => setShowDateModal(false)}>
        <Pressable style={s.modalOverlay} onPress={() => setShowDateModal(false)}>
          <Pressable style={s.sheet} onPress={() => {}}>
            <View style={s.sheetHandle} />
            <Text style={s.sheetTitle}>Filter by Date</Text>
            <Text style={s.sheetSub}>Select a date range to filter packages</Text>

            <View style={s.dateRow}>
              <TouchableOpacity style={s.dateTile} onPress={() => setShowDatePicker("from")}>
                <View style={s.dateTileIcon}>
                  <Ionicons name="calendar-outline" size={20} color={colors.primary} />
                </View>
                <Text style={s.dateTileLabel}>From</Text>
                <Text style={s.dateTileValue}>
                  {pendingDateFrom ? pendingDateFrom.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "Start date"}
                </Text>
              </TouchableOpacity>

              <Ionicons name="arrow-forward" size={16} color={colors.textMuted} />

              <TouchableOpacity style={s.dateTile} onPress={() => setShowDatePicker("to")}>
                <View style={s.dateTileIcon}>
                  <Ionicons name="calendar-outline" size={20} color={colors.primary} />
                </View>
                <Text style={s.dateTileLabel}>To</Text>
                <Text style={s.dateTileValue}>
                  {pendingDateTo ? pendingDateTo.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "End date"}
                </Text>
              </TouchableOpacity>
            </View>

            <View style={s.dateActions}>
              <TouchableOpacity style={s.dateClearBtn} onPress={() => { setPendingDateFrom(null); setPendingDateTo(null); setDateFrom(null); setDateTo(null); setShowDateModal(false); }}>
                <Text style={s.dateClearText}>Clear</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.dateApplyBtn} onPress={() => { setDateFrom(pendingDateFrom); setDateTo(pendingDateTo); setShowDateModal(false); }}>
                <Text style={s.dateApplyText}>Apply Filter</Text>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Native Date Picker */}
      {showDatePicker && (
        <DateTimePicker
          value={showDatePicker === "from" ? (pendingDateFrom || new Date()) : (pendingDateTo || new Date())}
          mode="date"
          display="default"
          maximumDate={new Date()}
          accentColor={colors.primary}
          onChange={(event, date) => {
            if (event.type === "dismissed") {
              setShowDatePicker(null);
              return;
            }
            setShowDatePicker(null);
            if (date) {
              if (showDatePicker === "from") setPendingDateFrom(date);
              else setPendingDateTo(date);
            }
          }}
        />
      )}
    </View>
  );
}

function PackageDetailsModal({
  group,
  onClose,
  onChangeLocation,
  onTransfer,
}: {
  group: PackageGroup | null;
  onClose: () => void;
  onChangeLocation: (group: PackageGroup) => void;
  onTransfer: (group: PackageGroup) => void;
}) {
  if (!group) return null;

  const first = group.labels[0];
  const isBusHandoff = group.delivery_method === "bus_handoff";
  const recipientPhone = first?.recipient_phone;

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={s.detailsOverlay} onPress={onClose}>
        <Pressable style={s.detailsSheet} onPress={() => {}}>
          <View style={s.sheetHandle} />
          <View style={s.detailsHeader}>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={s.detailsTitle} numberOfLines={2}>{group.description}</Text>
              <Text style={s.detailsSub} numberOfLines={1}>{group.tracking_code}</Text>
            </View>
            <TouchableOpacity style={s.detailsCloseBtn} onPress={onClose}>
              <Ionicons name="close" size={20} color={colors.textMuted} />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.detailsContent}>
            {group.hasPendingTransfer ? (
              <View style={s.pendingTransferNotice}>
                <Ionicons name="swap-horizontal" size={18} color="#b45309" />
                <View style={{ flex: 1 }}>
                  <Text style={s.pendingTransferNoticeTitle}>Transfer pending</Text>
                  <Text style={s.pendingTransferNoticeText}>Waiting for {group.pendingTransfer?.to_driver?.name || "the receiving rider"} to accept or reject.</Text>
                </View>
              </View>
            ) : (group.canChangeLocation || group.canTransfer) ? (
              <View style={s.detailsActionsCard}>
                <TouchableOpacity style={[s.detailsActionBtn, !group.canChangeLocation && { opacity: 0.5 }]} disabled={!group.canChangeLocation} onPress={() => onChangeLocation(group)} activeOpacity={0.75}>
                  <Ionicons name="location-outline" size={17} color={colors.primary} />
                  <Text style={s.detailsActionText}>Change Location</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.detailsActionBtn, !group.canTransfer && { opacity: 0.5 }]} disabled={!group.canTransfer} onPress={() => onTransfer(group)} activeOpacity={0.75}>
                  <Ionicons name="swap-horizontal" size={17} color={colors.primary} />
                  <Text style={s.detailsActionText}>Transfer Package</Text>
                </TouchableOpacity>
              </View>
            ) : null}

            <View style={s.detailsLocationCard}>
              <View style={s.detailsLocationHeader}>
                <View style={[s.detailsLocationIcon, { backgroundColor: isBusHandoff ? "#ede9fe" : "#ffedd5" }]}>
                  <Ionicons name={isBusHandoff ? "bus-outline" : "person-outline"} size={18} color={isBusHandoff ? "#7c3aed" : colors.primary} />
                </View>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={s.detailsLocationTitle}>{isBusHandoff ? "Routing Details" : "Recipient"}</Text>
                  <Text style={s.detailsLocationMain} numberOfLines={2}>
                    {isBusHandoff ? group.route_label : group.recipient_name || group.route_label}
                  </Text>
                </View>
              </View>

              <View style={s.detailsRows}>
                <ModalInfoRow icon="navigate-outline" value={isBusHandoff ? "Bus station handoff" : "Direct delivery"} />
                {recipientPhone ? (
                  <TouchableOpacity style={s.modalInfoRow} onPress={() => Linking.openURL(`tel:${recipientPhone}`)} activeOpacity={0.75}>
                    <Ionicons name="call-outline" size={14} color={colors.textMuted} />
                    <Text style={[s.modalInfoText, s.modalInfoPhone]}>{formatPhone(recipientPhone)}</Text>
                  </TouchableOpacity>
                ) : null}
                {group.delivery_method !== "bus_handoff" && group.delivery_town ? (
                  <ModalInfoRow icon="location-outline" value={group.delivery_town} />
                ) : null}
              </View>
            </View>

            <View style={s.detailsListCard}>
              <View style={s.detailsListHeader}>
                <Text style={s.detailsListTitle}>Labels</Text>
                <View style={s.detailsCountBadge}>
                  <Text style={s.detailsCountText}>{group.labels.length}</Text>
                </View>
              </View>
              {group.labels.map((label, index) => {
                return (
                  <View key={label.barcode} style={[s.detailsLabelRow, index === group.labels.length - 1 && { borderBottomWidth: 0, paddingBottom: 0 }]}>
                    <View style={s.detailsLabelNumber}>
                      <Text style={s.detailsLabelNumberText}>{index + 1}</Text>
                    </View>
                    <View style={{ flex: 1, minWidth: 0 }}>
                      <Text style={s.detailsLabelBarcode} numberOfLines={1}>{label.barcode}</Text>
                      <Text style={s.detailsLabelMeta}>
                        {label.label_index && label.labels_total ? `Label ${label.label_index} of ${label.labels_total}` : "Package label"}
                      </Text>
                      {label.team?.name ? (
                        <Text style={s.detailsLabelSource} numberOfLines={1}>
                          {label.claim_source === "rider_team_assigned" ? "Assigned from" : "From"} {label.assigned_by?.name ? `${label.assigned_by.name} · ` : ""}{label.team.name}
                        </Text>
                      ) : null}
                    </View>
                    {label.pending_transfer ? (
                      <Text style={s.detailsPendingText}>Pending transfer</Text>
                    ) : label.claim_source === "rider_team_assigned" ? (
                      <Text style={s.detailsAssignedText}>Assigned</Text>
                    ) : (
                      <Text style={s.detailsInRunText}>In delivery</Text>
                    )}
                  </View>
                );
              })}
            </View>
          </ScrollView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

function ModalInfoRow({ icon, value }: { icon: keyof typeof Ionicons.glyphMap; value: string }) {
  return (
    <View style={s.modalInfoRow}>
      <Ionicons name={icon} size={14} color={colors.textMuted} />
      <Text style={s.modalInfoText}>{value || "—"}</Text>
    </View>
  );
}

function ChangeLocationModal({
  group,
  onClose,
  onSaved,
}: {
  group: PackageGroup | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [locationText, setLocationText] = useState("");
  const [selectedLocation, setSelectedLocation] = useState<LocationSuggestion | null>(null);
  const [suggestions, setSuggestions] = useState<LocationSuggestion[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!group) return;
    setLocationText(group.delivery_town || "");
    setSelectedLocation(null);
    setSuggestions([]);
    setShowSuggestions(false);
    setPhotos([]);
  }, [group?.tracking_code]);

  if (!group) return null;

  const searchLocationsForText = async (text: string) => {
    setLocationText(text);
    setSelectedLocation(null);
    if (text.trim().length < 2) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }
    try {
      const res = await searchDriverLocations(text.trim());
      const d = (res as any)?.data || res;
      const items = Array.isArray(d?.locations) ? d.locations : [];
      setSuggestions(items);
      setShowSuggestions(items.length > 0);
    } catch {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const selectLocation = (item: LocationSuggestion) => {
    setSelectedLocation(item);
    setLocationText(item.display || item.name);
    setShowSuggestions(false);
  };

  const save = async () => {
    if (!locationText.trim()) {
      showError("Enter the new delivery location.");
      return;
    }
    if (photos.length === 0) {
      showError("Add a proof photo.");
      return;
    }
    setSaving(true);
    try {
      const formData = new FormData();
      formData.append("delivery_town", selectedLocation?.name || locationText.trim());
      if (selectedLocation?.region?.id) formData.append("delivery_region_id", String(selectedLocation.region.id));
      if (selectedLocation?.district?.id) formData.append("delivery_district_id", String(selectedLocation.district.id));
      formData.append("proof_photo", {
        uri: photos[0],
        name: "location_proof.jpg",
        type: "image/jpeg",
      } as any);
      await changePackageLocation(group.tracking_code, formData);
      showSuccess("Location updated.");
      setLocationText("");
      setSelectedLocation(null);
      setPhotos([]);
      onSaved();
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 12 : 0}
        style={s.centerAvoider}
      >
      <Pressable style={s.centerOverlay} onPress={onClose}>
        <Pressable style={s.centerModal} onPress={() => {}}>
          <View style={s.actionModalHeader}>
            <View style={s.actionModalIcon}><Ionicons name="location-outline" size={22} color={colors.primary} /></View>
            <View style={{ flex: 1 }}>
              <Text style={s.actionModalTitle}>Change Location</Text>
              <Text style={s.actionModalSub} numberOfLines={1}>{group.description} · {group.tracking_code}</Text>
            </View>
            <TouchableOpacity style={s.detailsCloseBtn} onPress={onClose}><Ionicons name="close" size={20} color={colors.textMuted} /></TouchableOpacity>
          </View>

          <View style={s.actionModalBody}>
            <View style={s.locationCombo}>
              <Text style={s.actionLabel}>New delivery location</Text>
              <View style={[s.locationInputWrap, showSuggestions && s.locationInputWrapOpen]}>
                <Ionicons name="location-outline" size={18} color={colors.textMuted} />
                <TextInput
                  value={locationText}
                  onChangeText={searchLocationsForText}
                  placeholder="Search or type the new location"
                  placeholderTextColor={colors.textLight}
                  style={s.locationInput}
                />
              </View>
              {showSuggestions && (
                <View style={s.locationResults}>
                  {suggestions.map((item) => (
                    <TouchableOpacity key={item.id} style={s.locationResultItem} onPress={() => selectLocation(item)}>
                      <Text style={s.locationResultText}>{item.display || item.name}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )}
            </View>

            <ImagePickerButton label="Proof Photo (required)" images={photos} onImagesChange={setPhotos} maxImages={1} />
          </View>

          <View style={s.actionModalFooter}>
            <TouchableOpacity style={s.cancelBtn} onPress={onClose}><Text style={s.cancelBtnText}>Cancel</Text></TouchableOpacity>
            <TouchableOpacity style={[s.primaryBtn, saving && { opacity: 0.65 }]} onPress={save} disabled={saving}>
              <Text style={s.primaryBtnText}>{saving ? "Saving..." : "Save Location"}</Text>
            </TouchableOpacity>
          </View>
        </Pressable>
      </Pressable>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function TransferPackageModal({
  group,
  onClose,
  onSaved,
}: {
  group: PackageGroup | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [phone, setPhone] = useState("");
  const [phoneError, setPhoneError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!group) return;
    setPhone("");
    setPhoneError("");
  }, [group?.tracking_code]);

  if (!group) return null;

  const submit = async () => {
    const clean = sanitizeLocalPhoneInput(phone);
    if (!isValidGhanaPhone(clean)) {
      setPhoneError("Enter a valid 10-digit Ghana phone number");
      return;
    }
    setPhoneError("");
    setSaving(true);
    try {
      await requestPackageTransfer(group.tracking_code, { receiver_phone: toApiPhone(clean) });
      showSuccess("Transfer request sent.");
      setPhone("");
      setPhoneError("");
      onSaved();
    } catch (err: any) {
      setPhoneError(getErrorMessage(err, "Could not send transfer request"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 12 : 0}
        style={s.centerAvoider}
      >
      <Pressable style={s.centerOverlay} onPress={onClose}>
        <Pressable style={s.centerModal} onPress={() => {}}>
          <View style={s.actionModalHeader}>
            <View style={s.actionModalIcon}><Ionicons name="swap-horizontal" size={22} color={colors.primary} /></View>
            <View style={{ flex: 1 }}>
              <Text style={s.actionModalTitle}>Transfer Package</Text>
              <Text style={s.actionModalSub} numberOfLines={1}>{group.description} · {group.tracking_code}</Text>
            </View>
            <TouchableOpacity style={s.detailsCloseBtn} onPress={onClose}><Ionicons name="close" size={20} color={colors.textMuted} /></TouchableOpacity>
          </View>
          <View style={s.actionModalBody}>
            <Text style={s.actionLabel}>Receiving rider phone</Text>
            <View style={s.phoneInputWrap}>
              <Ionicons name="call-outline" size={18} color={colors.textMuted} />
              <TextInput
                value={phone}
                onChangeText={(value) => {
                  const next = sanitizeLocalPhoneInput(value);
                  setPhone(next);
                  setPhoneError(next.length === 10 && !isValidGhanaPhone(next) ? "Enter a valid 10-digit Ghana phone number" : "");
                }}
                keyboardType="phone-pad"
                maxLength={10}
                placeholder="0241234567"
                placeholderTextColor={colors.textLight}
                style={s.phoneInput}
              />
            </View>
            {phoneError ? <Text style={s.errorText}>{phoneError}</Text> : null}
            <Text style={s.transferHelp}>The rider must accept before custody moves to them.</Text>
          </View>
          <View style={s.actionModalFooter}>
            <TouchableOpacity style={s.cancelBtn} onPress={onClose}><Text style={s.cancelBtnText}>Cancel</Text></TouchableOpacity>
            <TouchableOpacity style={[s.primaryBtn, (!isValidGhanaPhone(phone) || saving) && { opacity: 0.65 }]} onPress={submit} disabled={!isValidGhanaPhone(phone) || saving}>
              <Text style={s.primaryBtnText}>{saving ? "Sending..." : "Send Request"}</Text>
            </TouchableOpacity>
          </View>
        </Pressable>
      </Pressable>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function MyPackagesSkeleton({ topInset, bottomInset }: { topInset: number; bottomInset: number }) {
  const darkSkeleton = { backgroundColor: "rgba(255,255,255,0.2)" };

  return (
    <View style={s.container}>
      <LinearGradient colors={["#1e293b", "#334155", "#1e293b"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: topInset + 12 }]}>
        <View style={s.heroDecor1} />
        <View style={s.headerRow}>
          <View style={s.headerIconWrap}>
            <ShimmerLoading width={20} height={20} borderRadius={10} style={darkSkeleton} />
          </View>
          <View style={{ flex: 1, gap: 7 }}>
            <ShimmerLoading width={132} height={22} borderRadius={8} style={darkSkeleton} />
            <ShimmerLoading width={118} height={12} borderRadius={6} style={darkSkeleton} />
          </View>
          <View style={s.scanBtn}>
            <ShimmerLoading width={18} height={18} borderRadius={9} style={darkSkeleton} />
            <ShimmerLoading width={34} height={12} borderRadius={6} style={darkSkeleton} />
          </View>
        </View>

        <View style={s.filterWrap}>
          {[0, 1, 2].map((item) => (
            <View key={item} style={s.filterChip}>
              <ShimmerLoading width={item === 0 ? 62 : 54} height={12} borderRadius={6} style={darkSkeleton} />
              <ShimmerLoading width={22} height={20} borderRadius={10} style={darkSkeleton} />
            </View>
          ))}
        </View>

        <View style={s.filterWrap}>
          {[0, 1].map((item) => (
            <View key={item} style={s.filterChip}>
              <ShimmerLoading width={item === 0 ? 42 : 58} height={12} borderRadius={6} style={darkSkeleton} />
            </View>
          ))}
          <View style={s.calendarBtn}>
            <ShimmerLoading width={14} height={14} borderRadius={7} style={darkSkeleton} />
            <ShimmerLoading width={52} height={12} borderRadius={6} style={darkSkeleton} />
          </View>
        </View>

        <View style={s.searchRow}>
          <ShimmerLoading width={16} height={16} borderRadius={8} style={darkSkeleton} />
          <ShimmerLoading width="54%" height={14} borderRadius={7} style={darkSkeleton} />
        </View>
      </LinearGradient>

      <View style={s.body}>
        <View style={s.list}>
          {[0, 1, 2].map((item) => (
            <View key={item} style={[s.card, item > 0 && { marginTop: 12 }]}>
              <View style={s.cardAccent} />
              <View style={s.cardBody}>
                <View style={s.cardTop}>
                  <ShimmerLoading width={44} height={44} borderRadius={12} />
                  <View style={{ flex: 1, gap: 8 }}>
                    <ShimmerLoading width="76%" height={16} borderRadius={7} />
                    <ShimmerLoading width="62%" height={11} borderRadius={6} />
                    <ShimmerLoading width="82%" height={11} borderRadius={6} />
                  </View>
                </View>
                <View style={s.cardBottom}>
                  <ShimmerLoading width={78} height={30} borderRadius={15} />
                  <ShimmerLoading width={106} height={30} borderRadius={15} />
                </View>
              </View>
            </View>
          ))}
        </View>
      </View>

      <View style={[s.footer, { paddingBottom: bottomInset + 12 }]}>
        <ShimmerLoading width="100%" height={54} borderRadius={27} />
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 16, gap: 12, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  headerIconWrap: { width: 44, height: 44, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  headerActions: { flexDirection: "row", alignItems: "center", gap: 8 },
  headerActionBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  scanBtn: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: colors.primary, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12 },
  scanBtnText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.white },
  filterWrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  filterChip: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "rgba(255,255,255,0.06)", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 7, borderWidth: 1, borderColor: "rgba(255,255,255,0.08)" },
  filterChipActive: { backgroundColor: "rgba(255,255,255,0.15)", borderColor: "rgba(255,255,255,0.25)" },
  filterText: { fontFamily: fontFamily.medium, fontSize: 12, color: "rgba(255,255,255,0.5)" },
  filterTextActive: { color: colors.white },
  filterCount: { backgroundColor: "rgba(255,255,255,0.1)", borderRadius: 10, minWidth: 22, height: 20, justifyContent: "center", alignItems: "center", paddingHorizontal: 5 },
  filterCountActive: { backgroundColor: "rgba(255,255,255,0.2)" },
  filterCountText: { fontFamily: fontFamily.semibold, fontSize: 10, color: "rgba(255,255,255,0.5)" },
  filterCountTextActive: { color: colors.white },
  calendarBtn: { flexDirection: "row", gap: 5, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.06)", borderWidth: 1, borderColor: "rgba(255,255,255,0.08)", justifyContent: "center", alignItems: "center", paddingHorizontal: 12, paddingVertical: 7 },
  calendarBtnActive: { backgroundColor: colors.warmSurface, borderColor: colors.accentLighter },
  searchRow: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "rgba(255,255,255,0.1)", borderTopLeftRadius: 4, borderTopRightRadius: 4, borderBottomWidth: 2, borderBottomColor: colors.primary, paddingHorizontal: 12, height: 42 },
  searchInput: { flex: 1, fontFamily: fontFamily.regular, fontSize: fontSize.bodyMd, color: colors.white, paddingVertical: 0 },
  activeFilter: { flexDirection: "row", alignItems: "center", gap: 6, marginHorizontal: 16, marginTop: 10, marginBottom: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, borderWidth: 1, borderColor: colors.accentLighter, alignSelf: "flex-start" },
  activeFilterText: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.primary },
  body: { flex: 1, paddingTop: 14 },
  list: { flexGrow: 1, paddingHorizontal: 16, paddingBottom: 30 },
  card: { flexDirection: "row", backgroundColor: colors.white, borderRadius: 14, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 },
  cardInRun: { opacity: 0.7 },
  cardAccent: { width: 4, backgroundColor: colors.primary },
  cardBody: { flex: 1, padding: 14, gap: 10 },
  cardTop: { flexDirection: "row", gap: 12 },
  cardIcon: { width: 44, height: 44, borderRadius: 12, backgroundColor: colors.warmSurface, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  inRunBadge: { backgroundColor: "#dcfce7", paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 },
  inRunBadgeText: { fontFamily: fontFamily.medium, fontSize: 10, color: colors.success },
  mixedBadge: { backgroundColor: "#fef3c7", paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 },
  mixedBadgeText: { fontFamily: fontFamily.medium, fontSize: 10, color: "#d97706" },
  pendingTransferBadge: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: "#fef3c7", paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 },
  pendingTransferBadgeText: { fontFamily: fontFamily.medium, fontSize: 10, color: "#b45309" },
  teamBadge: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 },
  teamBadgeText: { fontFamily: fontFamily.medium, fontSize: 10, color: colors.primary },
  handoffBadge: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: "#ede9fe", paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 },
  handoffBadgeText: { fontFamily: fontFamily.medium, fontSize: 10, color: "#7c3aed" },
  cardMeta: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 4, marginTop: 3 },
  cardMetaText: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, marginRight: 8 },
  cardBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderTopWidth: 1, borderTopColor: colors.neutral100, paddingTop: 10 },
  readyText: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.success },
  pendingTransferText: { flex: 1, fontFamily: fontFamily.semibold, fontSize: 12, color: "#b45309" },
  viewBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  viewBtnText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.primary },
  footer: { paddingHorizontal: 16, paddingTop: 12, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.border },
  startBtn: { width: "100%" },
  // Date modal
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  sheet: { backgroundColor: colors.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingBottom: 34, paddingTop: 12 },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: colors.neutral300, alignSelf: "center", marginBottom: 16 },
  sheetTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.dark },
  sheetSub: { fontFamily: fontFamily.regular, fontSize: 13, color: colors.textMuted, marginTop: 4, marginBottom: 16 },
  dateRow: { flexDirection: "row", alignItems: "center", gap: 12, marginTop: 8, marginBottom: 20 },
  dateTile: { flex: 1, backgroundColor: colors.surface, borderRadius: 14, padding: 14, alignItems: "center", gap: 6, borderWidth: 1, borderColor: colors.border },
  dateTileIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: colors.warmSurface, justifyContent: "center", alignItems: "center" },
  dateTileLabel: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.5 },
  dateTileValue: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.dark, textAlign: "center" },
  dateActions: { flexDirection: "row", gap: 12 },
  dateClearBtn: { flex: 1, paddingVertical: 14, borderRadius: 14, borderWidth: 1.5, borderColor: colors.border, alignItems: "center" },
  dateClearText: { fontFamily: fontFamily.medium, fontSize: 14, color: colors.textMuted },
  dateApplyBtn: { flex: 1.5, paddingVertical: 14, borderRadius: 14, backgroundColor: colors.primary, alignItems: "center" },
  dateApplyText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  // Package details modal
  detailsOverlay: { flex: 1, backgroundColor: "rgba(15,23,42,0.45)", justifyContent: "flex-end" },
  detailsSheet: { maxHeight: "88%", backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 16, paddingTop: 10, paddingBottom: 22 },
  detailsHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10, marginBottom: 14 },
  detailsTitle: { fontFamily: fontFamily.bold, fontSize: 17, color: colors.dark, lineHeight: 22 },
  detailsSub: { fontFamily: "monospace", fontSize: 11, color: colors.textMuted, marginTop: 2 },
  detailsCountBadge: { borderWidth: 1, borderColor: colors.neutral200, backgroundColor: colors.white, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6 },
  detailsCountText: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.primary },
  detailsCloseBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.neutral200, justifyContent: "center", alignItems: "center" },
  detailsContent: { gap: 14, paddingBottom: 18 },
  pendingTransferNotice: { flexDirection: "row", gap: 10, alignItems: "flex-start", borderWidth: 1, borderColor: "#fde68a", borderRadius: 16, backgroundColor: "#fffbeb", padding: 12 },
  pendingTransferNoticeTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: "#92400e" },
  pendingTransferNoticeText: { fontFamily: fontFamily.regular, fontSize: 12, color: "#b45309", lineHeight: 17, marginTop: 2 },
  detailsActionsCard: { flexDirection: "row", gap: 10 },
  detailsActionBtn: { flex: 1, minHeight: 48, borderRadius: 14, borderWidth: 1.5, borderColor: colors.accentLighter, backgroundColor: colors.warmSurface, justifyContent: "center", alignItems: "center", flexDirection: "row", gap: 7, paddingHorizontal: 10 },
  detailsActionText: { fontFamily: fontFamily.bold, fontSize: 12, color: colors.primary },
  detailsLocationCard: { borderWidth: 1, borderColor: colors.neutral200, borderRadius: 16, padding: 14, backgroundColor: colors.white, shadowColor: colors.black, shadowOpacity: 0.04, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1, gap: 10 },
  detailsLocationHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  detailsLocationIcon: { width: 36, height: 36, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  detailsLocationTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, textTransform: "uppercase", letterSpacing: 0.4 },
  detailsLocationMain: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.dark, marginTop: 3, lineHeight: 18 },
  detailsRows: { borderLeftWidth: 2, borderLeftColor: colors.neutral200, marginLeft: 17, paddingLeft: 18, gap: 8 },
  modalInfoRow: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  modalInfoText: { flex: 1, fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, lineHeight: 17 },
  modalInfoPhone: { color: colors.primary },
  detailsListCard: { backgroundColor: colors.white, borderRadius: 18, paddingTop: 16, paddingBottom: 14, borderWidth: 1, borderColor: colors.border, overflow: "hidden" },
  detailsListHeader: { paddingHorizontal: 16, paddingBottom: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 },
  detailsListTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, letterSpacing: 0.5, textTransform: "uppercase" },
  detailsLabelRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  detailsLabelNumber: { width: 36, height: 36, borderRadius: 10, backgroundColor: "#dbeafe", justifyContent: "center", alignItems: "center" },
  detailsLabelNumberText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.primary },
  detailsLabelBarcode: { fontFamily: "monospace", fontSize: 12, color: colors.dark },
  detailsLabelMeta: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, marginTop: 2 },
  detailsLabelSource: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.primary, marginTop: 2 },
  detailsPendingText: { fontFamily: fontFamily.semibold, fontSize: 10, color: "#b45309", textTransform: "uppercase", letterSpacing: 0.3 },
  detailsAssignedText: { fontFamily: fontFamily.semibold, fontSize: 10, color: colors.primary, textTransform: "uppercase", letterSpacing: 0.3 },
  detailsInRunText: { fontFamily: fontFamily.semibold, fontSize: 10, color: colors.success, textTransform: "uppercase", letterSpacing: 0.3 },
  centerAvoider: { flex: 1 },
  centerOverlay: { flex: 1, backgroundColor: "rgba(15,23,42,0.58)", justifyContent: "center", paddingHorizontal: 18 },
  centerModal: { width: "100%", maxHeight: "88%", borderRadius: 24, backgroundColor: colors.white, overflow: "hidden" },
  actionModalHeader: { flexDirection: "row", alignItems: "center", gap: 12, padding: 18, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  actionModalIcon: { width: 48, height: 48, borderRadius: 14, backgroundColor: colors.warmSurface, justifyContent: "center", alignItems: "center" },
  actionModalTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.dark },
  actionModalSub: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: 2 },
  actionModalBody: { padding: 18, gap: 14 },
  actionLabel: { fontFamily: fontFamily.bold, fontSize: 12, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.4 },
  locationCombo: { gap: 8, zIndex: 3 },
  locationInputWrap: { flexDirection: "row", alignItems: "center", gap: 10, minHeight: 54, borderTopLeftRadius: 8, borderTopRightRadius: 8, backgroundColor: colors.warmSurface, borderBottomWidth: 2, borderBottomColor: colors.primary, paddingHorizontal: 12 },
  locationInputWrapOpen: { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 },
  locationInput: { flex: 1, fontFamily: fontFamily.medium, fontSize: 15, color: colors.dark, paddingVertical: 0 },
  locationResults: { borderWidth: 1, borderTopWidth: 0, borderColor: colors.border, borderBottomLeftRadius: 14, borderBottomRightRadius: 14, overflow: "hidden", backgroundColor: colors.white },
  locationResultItem: { paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  locationResultText: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.dark },
  phoneInputWrap: { flexDirection: "row", alignItems: "center", gap: 10, minHeight: 54, borderTopLeftRadius: 8, borderTopRightRadius: 8, backgroundColor: colors.warmSurface, borderBottomWidth: 2, borderBottomColor: colors.primary, paddingHorizontal: 12 },
  phoneInput: { flex: 1, fontFamily: fontFamily.medium, fontSize: 16, color: colors.dark, paddingVertical: 0 },
  errorText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.error },
  transferHelp: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, lineHeight: 18 },
  actionModalFooter: { flexDirection: "row", justifyContent: "flex-end", gap: 10, padding: 16, borderTopWidth: 1, borderTopColor: colors.neutral100 },
  cancelBtn: { minHeight: 46, borderRadius: 14, borderWidth: 1.5, borderColor: colors.border, paddingHorizontal: 18, justifyContent: "center", alignItems: "center" },
  cancelBtnText: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  primaryBtn: { minHeight: 46, borderRadius: 14, backgroundColor: colors.primary, paddingHorizontal: 20, justifyContent: "center", alignItems: "center" },
  primaryBtnText: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.white },
});
