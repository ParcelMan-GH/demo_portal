import { useCallback, useMemo, useState } from "react";
import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity, TextInput, Dimensions, Modal, Pressable } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import DateTimePicker from "@react-native-community/datetimepicker";
import EmptyState from "../../../src/components/common/EmptyState";
import ShimmerLoading from "../../../src/components/common/ShimmerLoading";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { getBusHandoffs, type BusHandoffFollowUp } from "../../../src/api/v1/driver/bus-handoffs";
import { formatDateTimeAmPm } from "../../../src/utils/format";
import { getErrorMessage, showError } from "../../../src/utils/toast";

const { width } = Dimensions.get("window");

const FILTERS = [
  { label: "All", value: "all" },
  { label: "To Follow", value: "needs_follow_up" },
  { label: "Issues", value: "issue_reported" },
  { label: "Done", value: "confirmed" },
];

const SORT_FIELDS = [
  { label: "Handoff Date", value: "handoff_at", icon: "time-outline" as const },
  { label: "Station", value: "station", icon: "business-outline" as const },
  { label: "Packages", value: "packages", icon: "cube-outline" as const },
  { label: "To Follow", value: "to_follow", icon: "alert-circle-outline" as const },
];

type HandoffGroup = {
  key: string;
  stopId: number | null;
  station: string;
  handedOffAt: string | null;
  courierPhone: string | null;
  packages: BusHandoffFollowUp[];
};

export default function BusHandoffFollowUpsScreen() {
  const insets = useSafeAreaInsets();
  const homeRoute = "/(driver)/(tabs)/home" as const;
  const leaveBusHandoffs = () => {
    if (router.canGoBack()) router.back();
    else router.replace(homeRoute as any);
  };
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [items, setItems] = useState<BusHandoffFollowUp[]>([]);
  const [status, setStatus] = useState("needs_follow_up");
  const [sortField, setSortField] = useState("handoff_at");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [dateFrom, setDateFrom] = useState<Date | null>(null);
  const [dateTo, setDateTo] = useState<Date | null>(null);
  const [pendingDateFrom, setPendingDateFrom] = useState<Date | null>(null);
  const [pendingDateTo, setPendingDateTo] = useState<Date | null>(null);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showDateModal, setShowDateModal] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState<"from" | "to" | null>(null);
  const [search, setSearch] = useState("");

  const fetchData = useCallback(async () => {
    try {
      const res = await getBusHandoffs({ limit: 100 });
      const data = (res as any)?.data || {};
      setItems(data.handoffs || []);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { setLoading(true); fetchData(); }, [fetchData]));

  const allGroups = useMemo(() => groupHandoffs(items), [items]);
  const dateGroups = useMemo(() => filterGroupsByDate(allGroups, dateFrom, dateTo), [allGroups, dateFrom, dateTo]);
  const groups = useMemo(() => sortGroups(filterGroups(dateGroups, status, search), sortField, sortOrder), [dateGroups, search, sortField, sortOrder, status]);
  const counts = useMemo(() => getGroupCounts(dateGroups), [dateGroups]);
  const isInitialLoading = loading && items.length === 0;

  const countForFilter = (value: string) => {
    if (value === "all") return counts.all;
    if (value === "needs_follow_up") return counts.needsFollowUp;
    if (value === "issue_reported") return counts.issues;
    if (value === "confirmed") return counts.done;
    return 0;
  };

  return (
    <View style={s.container}>
      <LinearGradient colors={["#1e293b", "#334155", "#1e293b"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
        <View style={s.heroDecor1} />
        {isInitialLoading ? (
          <HeaderSkeleton />
        ) : (
          <>
            <View style={s.headerRow}>
              <TouchableOpacity style={s.backBtn} onPress={leaveBusHandoffs}>
                <Ionicons name="arrow-back" size={20} color={colors.white} />
              </TouchableOpacity>
              <View style={{ flex: 1 }}>
                <Text style={s.headerTitle}>Bus Follow-ups</Text>
                <Text style={s.headerSub}>Confirm bus station handoffs</Text>
              </View>
            </View>

            <View style={s.heroSearchRow}>
              <View style={s.heroSearchInput}>
                <Ionicons name="search-outline" size={16} color="rgba(255,255,255,0.4)" />
                <TextInput
                  style={s.heroSearchText}
                  value={search}
                  onChangeText={setSearch}
                  placeholder="Search bus follow-ups..."
                  placeholderTextColor="rgba(255,255,255,0.3)"
                  returnKeyType="search"
                />
                {search.length > 0 && (
                  <TouchableOpacity onPress={() => setSearch("")}>
                    <Ionicons name="close-circle" size={16} color="rgba(255,255,255,0.4)" />
                  </TouchableOpacity>
                )}
              </View>
              <TouchableOpacity
                style={[s.heroIconBtn, (dateFrom || dateTo) && s.heroIconBtnActive]}
                onPress={() => { setPendingDateFrom(dateFrom); setPendingDateTo(dateTo); setShowDateModal(true); }}
              >
                <Ionicons name="calendar-outline" size={18} color={(dateFrom || dateTo) ? colors.primary : "rgba(255,255,255,0.6)"} />
              </TouchableOpacity>
              <TouchableOpacity style={[s.heroIconBtn, (status !== "all" || sortField !== "handoff_at" || sortOrder !== "desc") && s.heroIconBtnActive]} onPress={() => setShowFilterModal(true)}>
                <Ionicons name="filter-outline" size={18} color={(status !== "all" || sortField !== "handoff_at" || sortOrder !== "desc") ? colors.primary : "rgba(255,255,255,0.6)"} />
              </TouchableOpacity>
            </View>
          </>
        )}
      </LinearGradient>

      {(dateFrom || dateTo) && (
        <TouchableOpacity style={s.activeFilter} onPress={() => { setDateFrom(null); setDateTo(null); }}>
          <Ionicons name="calendar" size={12} color={colors.primary} />
          <Text style={s.activeFilterText}>
            {dateFrom ? dateFrom.toLocaleDateString("en-GB", { day: "numeric", month: "short" }) : "Start"}
            {" → "}
            {dateTo ? dateTo.toLocaleDateString("en-GB", { day: "numeric", month: "short" }) : "Now"}
          </Text>
          <Ionicons name="close-circle" size={14} color={colors.textMuted} />
        </TouchableOpacity>
      )}

      <View style={s.body}>
        {isInitialLoading ? (
          <HandoffListSkeleton />
        ) : (
          <FlatList
            data={groups}
            keyExtractor={(item) => item.key}
            renderItem={({ item }) => <HandoffGroupCard group={item} />}
            contentContainerStyle={groups.length ? s.list : s.emptyContent}
            ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} colors={[colors.primary]} />}
            ListEmptyComponent={<EmptyState icon="bus-outline" title="No bus follow-ups" subtitle="Packages you hand off to bus stations will appear here" illustration="deliveryTruck" />}
          />
        )}
      </View>

      <Modal visible={showFilterModal} transparent animationType="slide" onRequestClose={() => setShowFilterModal(false)}>
        <Pressable style={s.modalOverlay} onPress={() => setShowFilterModal(false)}>
          <Pressable style={s.sheet} onPress={() => {}}>
            <View style={s.sheetHandle} />
            <Text style={s.sheetTitle}>Filter Bus Follow-ups</Text>

            <Text style={s.sortSectionLabel}>Status</Text>
            <View style={s.filterSheetGrid}>
              {FILTERS.map((filter) => {
                const isActive = status === filter.value;
                return (
                  <TouchableOpacity
                    key={filter.value}
                    style={[s.filterSheetChip, isActive && s.filterSheetChipActive]}
                    onPress={() => setStatus(filter.value)}
                  >
                    <Text style={[s.filterSheetText, isActive && s.filterSheetTextActive]}>{filter.label}</Text>
                    <View style={[s.filterSheetCount, isActive && s.filterSheetCountActive]}>
                      <Text style={[s.filterSheetCountText, isActive && s.filterSheetCountTextActive]}>{countForFilter(filter.value)}</Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>

            <View style={s.orderToggle}>
              <TouchableOpacity
                style={[s.orderBtn, sortOrder === "desc" && s.orderBtnActive]}
                onPress={() => setSortOrder("desc")}
              >
                <Ionicons name="arrow-down" size={14} color={sortOrder === "desc" ? colors.white : colors.textMuted} />
                <Text style={[s.orderBtnText, sortOrder === "desc" && s.orderBtnTextActive]}>Newest</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[s.orderBtn, sortOrder === "asc" && s.orderBtnActive]}
                onPress={() => setSortOrder("asc")}
              >
                <Ionicons name="arrow-up" size={14} color={sortOrder === "asc" ? colors.white : colors.textMuted} />
                <Text style={[s.orderBtnText, sortOrder === "asc" && s.orderBtnTextActive]}>Oldest</Text>
              </TouchableOpacity>
            </View>

            <Text style={s.sortSectionLabel}>Sort by</Text>
            <View style={s.sortGrid}>
              {SORT_FIELDS.map((field) => (
                <TouchableOpacity
                  key={field.value}
                  style={[s.sortTile, sortField === field.value && s.sortTileActive]}
                  onPress={() => { setSortField(field.value); setShowFilterModal(false); }}
                >
                  <Ionicons name={field.icon} size={16} color={sortField === field.value ? colors.primary : colors.textMuted} />
                  <Text style={[s.sortTileText, sortField === field.value && s.sortTileTextActive]} numberOfLines={1}>{field.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      <Modal visible={showDateModal} transparent animationType="slide" onRequestClose={() => setShowDateModal(false)}>
        <Pressable style={s.modalOverlay} onPress={() => setShowDateModal(false)}>
          <Pressable style={s.sheet} onPress={() => {}}>
            <View style={s.sheetHandle} />
            <Text style={s.sheetTitle}>Filter by Handoff Date</Text>
            <Text style={s.sheetSub}>Select the bus handoff date range.</Text>

            <View style={s.dateRow}>
              <TouchableOpacity style={s.dateTile} onPress={() => setShowDatePicker("from")}>
                <View style={s.dateTileIcon}>
                  <Ionicons name="calendar-outline" size={20} color={colors.primary} />
                </View>
                <Text style={s.dateTileLabel}>From</Text>
                <Text style={s.dateTileValue}>
                  {pendingDateFrom ? pendingDateFrom.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "Start date"}
                </Text>
              </TouchableOpacity>

              <Ionicons name="arrow-forward" size={16} color={colors.textMuted} />

              <TouchableOpacity style={s.dateTile} onPress={() => setShowDatePicker("to")}>
                <View style={s.dateTileIcon}>
                  <Ionicons name="calendar-outline" size={20} color={colors.primary} />
                </View>
                <Text style={s.dateTileLabel}>To</Text>
                <Text style={s.dateTileValue}>
                  {pendingDateTo ? pendingDateTo.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "End date"}
                </Text>
              </TouchableOpacity>
            </View>

            <View style={s.dateActions}>
              <TouchableOpacity style={s.dateClearBtn} onPress={() => { setPendingDateFrom(null); setPendingDateTo(null); setDateFrom(null); setDateTo(null); setShowDateModal(false); }}>
                <Text style={s.dateClearText}>Clear</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.dateApplyBtn} onPress={() => { setDateFrom(pendingDateFrom); setDateTo(pendingDateTo); setShowDateModal(false); }}>
                <Text style={s.dateApplyText}>Apply Filter</Text>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {showDatePicker && (
        <DateTimePicker
          value={showDatePicker === "from" ? (pendingDateFrom || new Date()) : (pendingDateTo || new Date())}
          mode="date"
          display="default"
          maximumDate={new Date()}
          accentColor={colors.primary}
          onChange={(event, date) => {
            if (event.type === "dismissed") {
              setShowDatePicker(null);
              return;
            }
            setShowDatePicker(null);
            if (date) {
              if (showDatePicker === "from") setPendingDateFrom(date);
              else setPendingDateTo(date);
            }
          }}
        />
      )}
    </View>
  );
}

function HandoffGroupCard({ group }: { group: HandoffGroup }) {
  const packageCount = group.packages.length;
  const pendingCount = group.packages.filter((item) => ["pending", "code_sent"].includes(item.status)).length;
  const issueCount = group.packages.filter((item) => item.status === "issue_reported" || item.status === "failed").length;
  const confirmedCount = group.packages.filter((item) => item.status === "confirmed" || item.status === "admin_confirmed").length;
  const first = group.packages[0];
  const accent = issueCount > 0 ? colors.error : pendingCount > 0 ? colors.primary : colors.success;
  const openStop = () => {
    if (group.stopId) {
      router.push({
        pathname: "/(driver)/bus-handoffs/stop/[id]",
        params: { id: String(group.stopId) },
      } as any);
      return;
    }

    router.push({
      pathname: "/(driver)/bus-handoffs/[id]",
      params: { id: String(first.delivery_run_item_id) },
    } as any);
  };

  return (
    <TouchableOpacity style={s.card} activeOpacity={0.72} onPress={openStop}>
      <View style={[s.cardAccent, { backgroundColor: accent }]} />
      <View style={s.cardBody}>
        <View style={s.cardTop}>
          <View style={[s.cardIcon, { backgroundColor: issueCount > 0 ? "#fee2e2" : "#ede9fe" }]}>
            <Ionicons name="bus" size={18} color={issueCount > 0 ? colors.error : "#7c3aed"} />
          </View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={s.cardTitle} numberOfLines={1}>{group.station}</Text>
            <View style={s.cardMeta}>
              <Ionicons name="cube-outline" size={12} color={colors.textMuted} />
              <Text style={s.cardMetaText}>{packageCount} package{packageCount !== 1 ? "s" : ""}</Text>
              {group.handedOffAt ? (
                <>
                  <Ionicons name="calendar-outline" size={12} color={colors.textMuted} />
                  <Text style={s.cardMetaText}>{formatDateTimeAmPm(group.handedOffAt)}</Text>
                </>
              ) : null}
            </View>
          </View>
        </View>

        <View style={s.statusRow}>
          <MiniCount label="To follow" value={pendingCount} color={colors.primary} />
          <MiniCount label="Issues" value={issueCount} color={colors.error} />
          <MiniCount label="Done" value={confirmedCount} color={colors.success} />
        </View>

        <View style={s.cardBottom}>
          <Text style={s.cardHint}>Open this handoff to choose a package</Text>
          <View style={s.viewBtn}>
            <Text style={s.viewBtnText}>View Packages</Text>
            <Ionicons name="arrow-forward" size={14} color={colors.primary} />
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

function MiniCount({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <View style={s.miniCount}>
      <Text style={[s.miniValue, { color }]}>{value}</Text>
      <Text style={s.miniLabel}>{label}</Text>
    </View>
  );
}

function HeaderSkeleton() {
  const darkSkeleton = { backgroundColor: "rgba(255,255,255,0.2)" };

  return (
    <>
      <View style={s.headerRow}>
        <ShimmerLoading width={42} height={42} borderRadius={21} style={darkSkeleton} />
        <View style={{ flex: 1, gap: 8 }}>
          <ShimmerLoading width="52%" height={22} borderRadius={8} style={darkSkeleton} />
          <ShimmerLoading width="70%" height={12} borderRadius={6} style={darkSkeleton} />
        </View>
      </View>
      <View style={s.heroSearchRow}>
        <View style={s.heroSearchInput}>
          <ShimmerLoading width={16} height={16} borderRadius={8} style={darkSkeleton} />
          <ShimmerLoading width="52%" height={14} borderRadius={7} style={darkSkeleton} />
        </View>
        <ShimmerLoading width={42} height={42} borderRadius={10} style={darkSkeleton} />
        <ShimmerLoading width={42} height={42} borderRadius={10} style={darkSkeleton} />
      </View>
    </>
  );
}

function HandoffListSkeleton() {
  return (
    <View style={s.list}>
      {Array.from({ length: 4 }).map((_, index) => (
        <View key={index} style={s.card}>
          <View style={[s.cardAccent, { backgroundColor: colors.neutral200 }]} />
          <View style={s.cardBody}>
            <View style={s.cardTop}>
              <ShimmerLoading width={44} height={44} borderRadius={12} />
              <View style={s.skeletonCardContent}>
                <View style={s.skeletonTitleRow}>
                  <ShimmerLoading width="54%" height={16} borderRadius={7} />
                  <ShimmerLoading width={46} height={18} borderRadius={6} />
                </View>
                <View style={s.cardMeta}>
                  <ShimmerLoading width={12} height={12} borderRadius={6} />
                  <ShimmerLoading width={72} height={11} borderRadius={5} />
                  <ShimmerLoading width={12} height={12} borderRadius={6} />
                  <ShimmerLoading width={76} height={11} borderRadius={5} />
                </View>
              </View>
            </View>
            <View style={s.statusRow}>
              <ShimmerLoading width="31%" height={42} borderRadius={10} />
              <ShimmerLoading width="31%" height={42} borderRadius={10} />
              <ShimmerLoading width="31%" height={42} borderRadius={10} />
            </View>
            <View style={s.cardBottom}>
              <ShimmerLoading width="46%" height={12} borderRadius={6} />
              <ShimmerLoading width={122} height={32} borderRadius={8} />
            </View>
          </View>
        </View>
      ))}
    </View>
  );
}

function groupHandoffs(items: BusHandoffFollowUp[]): HandoffGroup[] {
  const map = new Map<string, HandoffGroup>();

  for (const item of items) {
    const key = item.delivery_run_stop_id
      ? `stop:${item.delivery_run_stop_id}`
      : [
          item.handoff?.bus_station || "Bus station",
          item.handoff?.handed_off_at || "",
          item.handoff?.courier_phone || "",
        ].join("|");

    if (!map.has(key)) {
      map.set(key, {
        key,
        stopId: item.delivery_run_stop_id || null,
        station: item.handoff?.bus_station || "Bus station",
        handedOffAt: item.handoff?.handed_off_at || null,
        courierPhone: item.handoff?.courier_phone || null,
        packages: [],
      });
    }

    map.get(key)!.packages.push(item);
  }

  return Array.from(map.values());
}

function filterGroupsByDate(groups: HandoffGroup[], dateFrom: Date | null, dateTo: Date | null): HandoffGroup[] {
  if (!dateFrom && !dateTo) return groups;

  const from = dateFrom ? startOfDay(dateFrom) : null;
  const to = dateTo ? endOfDay(dateTo) : null;

  return groups.filter((group) => {
    if (!group.handedOffAt) return false;
    const date = new Date(group.handedOffAt);
    if (Number.isNaN(date.getTime())) return false;
    if (from && date < from) return false;
    if (to && date > to) return false;
    return true;
  });
}

function filterGroups(groups: HandoffGroup[], status: string, search: string): HandoffGroup[] {
  const searchTerm = search.trim().toLowerCase();

  return groups.filter((group) => {
    const matchesStatus =
      status === "all" ||
      (status === "needs_follow_up" && group.packages.some(isNeedsFollowUpPackage)) ||
      (status === "issue_reported" && group.packages.some(isIssuePackage)) ||
      (status === "confirmed" && group.packages.length > 0 && group.packages.every(isDonePackage));

    if (!matchesStatus) return false;
    if (!searchTerm) return true;

    const searchable = [
      group.station,
      group.courierPhone,
      group.handedOffAt,
      ...group.packages.flatMap((item) => [
        item.package?.tracking_code,
        item.package?.description,
        item.recipient?.name,
        item.recipient?.phone,
        item.vendor?.name,
        item.vendor?.phone,
      ]),
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();

    return searchable.includes(searchTerm);
  });
}

function getGroupCounts(groups: HandoffGroup[]) {
  return {
    all: groups.length,
    needsFollowUp: groups.filter((group) => group.packages.some(isNeedsFollowUpPackage)).length,
    issues: groups.filter((group) => group.packages.some(isIssuePackage)).length,
    done: groups.filter((group) => group.packages.length > 0 && group.packages.every(isDonePackage)).length,
  };
}

function sortGroups(groups: HandoffGroup[], sortField: string, sortOrder: "asc" | "desc"): HandoffGroup[] {
  const direction = sortOrder === "asc" ? 1 : -1;

  return [...groups].sort((a, b) => {
    let left: number | string;
    let right: number | string;

    if (sortField === "station") {
      left = a.station.toLowerCase();
      right = b.station.toLowerCase();
    } else if (sortField === "packages") {
      left = a.packages.length;
      right = b.packages.length;
    } else if (sortField === "to_follow") {
      left = a.packages.filter(isNeedsFollowUpPackage).length;
      right = b.packages.filter(isNeedsFollowUpPackage).length;
    } else {
      left = a.handedOffAt ? new Date(a.handedOffAt).getTime() : 0;
      right = b.handedOffAt ? new Date(b.handedOffAt).getTime() : 0;
    }

    if (left < right) return -1 * direction;
    if (left > right) return 1 * direction;
    return 0;
  });
}

function isNeedsFollowUpPackage(item: BusHandoffFollowUp): boolean {
  return item.status === "pending" || item.status === "code_sent";
}

function isIssuePackage(item: BusHandoffFollowUp): boolean {
  return item.status === "issue_reported" || item.status === "failed";
}

function isDonePackage(item: BusHandoffFollowUp): boolean {
  return item.status === "confirmed" || item.status === "admin_confirmed";
}

function startOfDay(date: Date): Date {
  const next = new Date(date);
  next.setHours(0, 0, 0, 0);
  return next;
}

function endOfDay(date: Date): Date {
  const next = new Date(date);
  next.setHours(23, 59, 59, 999);
  return next;
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 16, gap: 12, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  heroSearchRow: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 6 },
  heroSearchInput: { flex: 1, flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "rgba(255,255,255,0.1)", borderTopLeftRadius: 4, borderTopRightRadius: 4, borderBottomWidth: 2, borderBottomColor: colors.primary, paddingHorizontal: 12, height: 42 },
  heroSearchText: { flex: 1, fontFamily: fontFamily.regular, fontSize: fontSize.bodyMd, color: colors.white, paddingVertical: 0 },
  heroIconBtn: { width: 42, height: 42, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.12)", justifyContent: "center", alignItems: "center" },
  heroIconBtnActive: { backgroundColor: colors.warmSurface },
  activeFilter: { flexDirection: "row", alignItems: "center", gap: 6, marginHorizontal: 16, marginTop: 10, marginBottom: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, borderWidth: 1, borderColor: colors.accentLighter, alignSelf: "flex-start" },
  activeFilterText: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.primary },
  body: { flex: 1, paddingTop: 14 },
  list: { flexGrow: 1, paddingHorizontal: 16, paddingBottom: 30 },
  emptyContent: { flexGrow: 1, justifyContent: "center", paddingHorizontal: 24 },
  card: { flexDirection: "row", backgroundColor: colors.white, borderRadius: 14, overflow: "hidden" },
  cardAccent: { width: 4 },
  cardBody: { flex: 1, padding: 14, gap: 10 },
  cardTop: { flexDirection: "row", gap: 12 },
  cardIcon: { width: 44, height: 44, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark },
  cardMeta: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 3, flexWrap: "wrap" },
  cardMetaText: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, marginRight: 8 },
  statusRow: { flexDirection: "row", gap: 8 },
  miniCount: { flex: 1, minHeight: 42, borderRadius: 10, backgroundColor: "#f8fafc", justifyContent: "center", paddingHorizontal: 10 },
  miniValue: { fontFamily: fontFamily.bold, fontSize: 15 },
  miniLabel: { marginTop: 1, fontFamily: fontFamily.medium, fontSize: 10, color: colors.textMuted },
  cardBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderTopWidth: 1, borderTopColor: colors.neutral100, paddingTop: 10, gap: 10 },
  cardHint: { flex: 1, fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted },
  viewBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  viewBtnText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.primary },
  skeletonCardContent: { flex: 1, gap: 6 },
  skeletonTitleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  sheet: { backgroundColor: colors.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingBottom: 34, paddingTop: 12 },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: colors.neutral300, alignSelf: "center", marginBottom: 16 },
  sheetTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.dark },
  sheetSub: { fontFamily: fontFamily.regular, fontSize: 13, color: colors.textMuted, marginTop: 4, marginBottom: 16 },
  sortSectionLabel: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.5, marginTop: 16, marginBottom: 10 },
  filterSheetGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  filterSheetChip: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: colors.surface, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 9, borderWidth: 1, borderColor: colors.border },
  filterSheetChipActive: { backgroundColor: colors.warmSurface, borderColor: colors.primary },
  filterSheetText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  filterSheetTextActive: { color: colors.primary },
  filterSheetCount: { minWidth: 22, height: 20, borderRadius: 10, backgroundColor: colors.neutral200, justifyContent: "center", alignItems: "center", paddingHorizontal: 5 },
  filterSheetCountActive: { backgroundColor: colors.primary },
  filterSheetCountText: { fontFamily: fontFamily.semibold, fontSize: 10, color: colors.textMuted },
  filterSheetCountTextActive: { color: colors.white },
  orderToggle: { flexDirection: "row", backgroundColor: colors.surface, borderRadius: 12, padding: 4, marginTop: 12, marginBottom: 16 },
  orderBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 10, borderRadius: 10 },
  orderBtnActive: { backgroundColor: colors.primary },
  orderBtnText: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.textMuted },
  orderBtnTextActive: { color: colors.white },
  sortGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  sortTile: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 10, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  sortTileActive: { backgroundColor: colors.warmSurface, borderColor: colors.primary },
  sortTileText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  sortTileTextActive: { color: colors.primary },
  dateRow: { flexDirection: "row", alignItems: "center", gap: 12, marginTop: 8, marginBottom: 20 },
  dateTile: { flex: 1, backgroundColor: colors.surface, borderRadius: 14, padding: 14, alignItems: "center", gap: 6, borderWidth: 1, borderColor: colors.border },
  dateTileIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: colors.warmSurface, justifyContent: "center", alignItems: "center" },
  dateTileLabel: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.5 },
  dateTileValue: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.dark, textAlign: "center" },
  dateActions: { flexDirection: "row", gap: 12 },
  dateClearBtn: { flex: 1, paddingVertical: 14, borderRadius: 14, borderWidth: 1.5, borderColor: colors.border, alignItems: "center" },
  dateClearText: { fontFamily: fontFamily.medium, fontSize: 14, color: colors.textMuted },
  dateApplyBtn: { flex: 1.5, paddingVertical: 14, borderRadius: 14, backgroundColor: colors.primary, alignItems: "center" },
  dateApplyText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
});
