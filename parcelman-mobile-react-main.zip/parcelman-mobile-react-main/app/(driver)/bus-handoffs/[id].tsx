import { useCallback, useEffect, useState } from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Linking, ActivityIndicator, Image, Modal, Dimensions, Pressable, KeyboardAvoidingView, Platform } from "react-native";
import { router, useLocalSearchParams, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import Button from "../../../src/components/common/Button";
import Dropdown from "../../../src/components/common/Dropdown";
import StatusBadge from "../../../src/components/common/StatusBadge";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { confirmBusHandoffCode, getBusHandoff, getDeliveryFailureReasons, reportBusHandoffIssue, sendBusHandoffConfirmation, type BusHandoffFollowUp, type DeliveryFailureReason } from "../../../src/api/v1/driver/bus-handoffs";
import { formatDateTimeAmPm, formatPhone } from "../../../src/utils/format";
import { getErrorMessage, showError, showSuccess } from "../../../src/utils/toast";

const { width } = Dimensions.get("window");

export default function BusHandoffDetailScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const itemId = Number(id);
  const busHandoffsRoute = "/(driver)/bus-handoffs" as const;
  const leaveBusHandoffDetail = () => {
    if (router.canGoBack()) router.back();
    else router.replace(busHandoffsRoute as any);
  };
  const [loading, setLoading] = useState(true);
  const [handoff, setHandoff] = useState<BusHandoffFollowUp | null>(null);
  const [reasons, setReasons] = useState<DeliveryFailureReason[]>([]);
  const [targetType, setTargetType] = useState<"recipient" | "vendor">("recipient");
  const [code, setCode] = useState("");
  const [reasonId, setReasonId] = useState<number | null>(null);
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [proofPreview, setProofPreview] = useState<string | null>(null);
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [codeSecondsLeft, setCodeSecondsLeft] = useState(0);

  const fetchData = async () => {
    try {
      const [handoffRes, reasonsRes] = await Promise.all([
        getBusHandoff(itemId),
        getDeliveryFailureReasons().catch(() => null),
      ]);
      setHandoff(((handoffRes as any)?.data || {}).handoff || null);
      const reasonRows = (((reasonsRes as any)?.data || {}).reasons || []) as DeliveryFailureReason[];
      setReasons(reasonRows);
      if (!reasonId && reasonRows.length) setReasonId(reasonRows[0].id);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(useCallback(() => { setLoading(true); fetchData(); }, [itemId]));

  useEffect(() => {
    const expiresAt = handoff?.code_expires_at ? new Date(handoff.code_expires_at).getTime() : 0;
    if (!expiresAt || Number.isNaN(expiresAt)) {
      setCodeSecondsLeft(0);
      return;
    }

    const syncCountdown = () => {
      setCodeSecondsLeft(Math.max(0, Math.ceil((expiresAt - Date.now()) / 1000)));
    };

    syncCountdown();
    const timer = setInterval(syncCountdown, 1000);
    return () => clearInterval(timer);
  }, [handoff?.code_expires_at]);

  const call = (phone?: string | null) => {
    if (phone) Linking.openURL(`tel:${phone}`);
  };

  const sendCode = async (target: "recipient" | "vendor" = targetType) => {
    const phone = target === "recipient" ? handoff?.recipient?.phone : handoff?.vendor?.phone;
    if (!phone) {
      showError(`${target === "recipient" ? "Recipient" : "Sender"} phone number is missing.`);
      return;
    }

    setBusy(true);
    try {
      setTargetType(target);
      await sendBusHandoffConfirmation(itemId, target);
      showSuccess(`Confirmation sent to ${target === "recipient" ? "recipient" : "sender"}`);
      await fetchData();
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const confirmCode = async () => {
    if (!code.trim()) {
      showError("Enter the confirmation code.");
      return;
    }
    setBusy(true);
    try {
      await confirmBusHandoffCode(itemId, code.trim().toUpperCase());
      setCode("");
      setShowCodeModal(false);
      showSuccess("Package confirmed as delivered");
      await fetchData();
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const reportIssue = async () => {
    if (!reasonId) {
      showError("Select a reason.");
      return;
    }
    setBusy(true);
    try {
      await reportBusHandoffIssue(itemId, { reason_id: reasonId, notes: notes.trim() || undefined });
      setNotes("");
      setShowIssueModal(false);
      showSuccess("Issue recorded for admin follow-up");
      await fetchData();
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <View style={[s.center, { paddingTop: insets.top }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  if (!handoff) {
    return (
      <View style={[s.center, { paddingTop: insets.top }]}>
        <Text style={s.emptyTitle}>Handoff not found</Text>
        <Button title="Go Back" onPress={leaveBusHandoffDetail} />
      </View>
    );
  }

  const recipientPhone = handoff.recipient?.phone;
  const vendorPhone = handoff.vendor?.phone;
  const courierPhone = handoff.handoff?.courier_phone;
  const finalState = ["confirmed", "admin_confirmed", "failed"].includes(handoff.status);
  const targetPhone = targetType === "recipient" ? recipientPhone : vendorPhone;
  const targetLabel = targetType === "recipient" ? "recipient" : "sender";
  const hasSentCode = Boolean(handoff.code_sent_at);
  const codeStillActive = hasSentCode && codeSecondsLeft > 0;
  const packageName = handoff.package?.description || "Package";
  const headerMeta = [
    handoff.package?.tracking_code,
    handoff.delivery_run_number,
    handoff.delivery_run_stop_id ? `Stop #${handoff.delivery_run_stop_id}` : null,
  ].filter(Boolean).join(" · ");
  const confirmedAtLabel = handoff.confirmed_at ? formatDateTimeAmPm(handoff.confirmed_at) : null;
  const confirmedByAdmin = handoff.status === "admin_confirmed" || handoff.source === "admin" || Boolean(handoff.confirmed_by_admin);
  const confirmedByName = handoff.confirmed_by_admin?.name || handoff.confirmed_by_driver?.name;
  const confirmedBySelf = Boolean(
    handoff.confirmed_by_driver?.id
    && handoff.handoff_driver?.id
    && handoff.confirmed_by_driver.id === handoff.handoff_driver.id
  );
  const shouldShowConfirmedBy = Boolean(confirmedByName && !confirmedBySelf);

  return (
    <View style={s.container}>
      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 28 }}>
        <LinearGradient colors={["#1e293b", "#334155", "#1e293b"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.hero, { paddingTop: insets.top + 8 }]}>
          <View style={s.heroDecor1} />
          <View style={s.heroDecor2} />
          <View style={s.heroTop}>
            <TouchableOpacity style={s.backBtn} onPress={leaveBusHandoffDetail}>
              <Ionicons name="arrow-back" size={22} color={colors.white} />
            </TouchableOpacity>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={s.heroTitle} numberOfLines={1}>{packageName}</Text>
              <Text style={s.heroSub} numberOfLines={1}>{headerMeta || "Bus handoff package"}</Text>
            </View>
            <StatusBadge status={handoff.status_label || handoff.status} />
          </View>

          <View style={s.heroSummaryGrid}>
            <HeroSummaryCard icon="business" label="Station" value={handoff.handoff?.bus_station || "-"} color="#93c5fd" bg="rgba(96,165,250,0.18)" />
            <HeroSummaryCard icon="time" label="Handed off" value={handoff.handoff?.handed_off_at ? formatDateTimeAmPm(handoff.handoff.handed_off_at) : "-"} color="#d8b4fe" bg="rgba(168,85,247,0.18)" />
            <HeroSummaryCard icon="person" label="Recipient" value={handoff.recipient?.name || "-"} color="#fdba74" bg="rgba(251,146,60,0.18)" />
          </View>
        </LinearGradient>

        <View style={s.content}>
          {!finalState ? <FollowUpGuide /> : null}

          <SectionTitle title="People to contact" />
          <ContactGroupCard
            recipientName={handoff.recipient?.name || "Recipient"}
            recipientPhone={recipientPhone}
            recipientDetail={handoff.recipient?.town || undefined}
            vendorName={handoff.vendor?.name || "Sender"}
            vendorPhone={vendorPhone}
            canFollowUp={!finalState}
            onCallRecipient={() => call(recipientPhone)}
            onCallVendor={() => call(vendorPhone)}
            onConfirmDelivery={() => setShowCodeModal(true)}
            onReportProblem={() => setShowIssueModal(true)}
          />

          <SectionTitle title="Handoff proof" />
          <View style={s.proofCard}>
            <ProofRow icon="business-outline" label="Station" value={handoff.handoff?.bus_station || "-"} />
            {courierPhone ? (
              <>
                <View style={s.proofDivider} />
                <ProofRow icon="call-outline" label="Courier" value={formatPhone(courierPhone)} onPress={() => call(courierPhone)} />
              </>
            ) : null}
            {handoff.handoff?.vehicle_number ? (
              <>
                <View style={s.proofDivider} />
                <ProofRow icon="car-outline" label="Vehicle" value={handoff.handoff.vehicle_number} />
              </>
            ) : null}
            <View style={s.proofDivider} />
            <ProofRow icon="cube-outline" label="Quantity" value={String(handoff.package?.quantity || 1)} />
            <View style={s.proofDivider} />
            {handoff.handoff?.proof_photo_url ? (
              <TouchableOpacity style={s.proofPhotoBtn} activeOpacity={0.72} onPress={() => setProofPreview(handoff.handoff?.proof_photo_url || null)}>
                <Ionicons name="image-outline" size={18} color={colors.primary} />
                <Text style={s.proofPhotoBtnText}>View proof photo</Text>
                <Ionicons name="arrow-forward" size={15} color={colors.primary} />
              </TouchableOpacity>
            ) : (
              <View style={s.proofPhotoMissing}>
                <Ionicons name="image-outline" size={18} color={colors.textMuted} />
                <Text style={s.proofPhotoMissingText}>No proof photo attached</Text>
              </View>
            )}
          </View>

          {finalState ? (
            <View style={s.resolvedCard}>
                <Ionicons name={handoff.status === "failed" ? "alert-circle" : "checkmark-circle"} size={22} color={handoff.status === "failed" ? colors.error : colors.success} />
              <View style={{ flex: 1 }}>
                <Text style={s.resolvedTitle}>{handoff.status === "failed" ? "Marked for admin follow-up" : "Delivery confirmed"}</Text>
                {handoff.status === "failed" ? (
                  <Text style={s.resolvedText}>This handoff has been marked for follow-up.</Text>
                ) : (
                  <View style={s.resolvedMeta}>
                    {confirmedAtLabel ? (
                      <View style={s.resolvedMetaRow}>
                        <Ionicons name="calendar-outline" size={14} color={colors.textMuted} />
                        <Text style={s.resolvedText}>{confirmedAtLabel}</Text>
                      </View>
                    ) : null}
                    {confirmedByAdmin ? (
                      <View style={s.resolvedMetaRow}>
                        <Ionicons name="business-outline" size={14} color={colors.textMuted} />
                        <Text style={s.resolvedText}>Back office</Text>
                      </View>
                    ) : null}
                    {shouldShowConfirmedBy ? (
                      <View style={s.resolvedMetaRow}>
                        <Ionicons name="person-outline" size={14} color={colors.textMuted} />
                        <Text style={s.resolvedText}>{confirmedByName}</Text>
                      </View>
                    ) : null}
                  </View>
                )}
              </View>
            </View>
          ) : null}
        </View>
      </ScrollView>

      <Modal visible={!!proofPreview} transparent animationType="fade" onRequestClose={() => setProofPreview(null)}>
        <View style={s.lightbox}>
          <TouchableOpacity style={[s.lightboxClose, { top: insets.top + 16 }]} onPress={() => setProofPreview(null)}>
            <Ionicons name="close" size={24} color={colors.white} />
          </TouchableOpacity>
          {proofPreview ? <Image source={{ uri: proofPreview }} style={s.lightboxImage} resizeMode="contain" /> : null}
        </View>
      </Modal>

      <Modal visible={showCodeModal} transparent animationType="fade" onRequestClose={() => setShowCodeModal(false)}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 12 : 0}
          style={s.modalAvoider}
        >
        <Pressable style={s.modalOverlay} onPress={() => setShowCodeModal(false)}>
          <Pressable style={s.modalCard} onPress={(event) => event.stopPropagation()}>
            <View style={s.modalHeader}>
              <View style={s.modalIconWrap}>
                <Ionicons name="checkmark-circle" size={21} color={colors.white} />
              </View>
              <Text style={s.modalTitle}>Confirm Delivery</Text>
              <Text style={s.modalSub}>Send a code to the recipient or sender, then enter the code they give you.</Text>
            </View>
            <Text style={s.modalInputLabel}>Send code to</Text>
            <View style={s.modalSendRow}>
              <View style={s.modalTargetSelect}>
                <Dropdown
                  placeholder="Select person"
                  options={[
                    { label: "Recipient", value: "recipient" },
                    { label: "Sender", value: "vendor" },
                  ]}
                  value={targetType}
                  onSelect={(value) => setTargetType(value as "recipient" | "vendor")}
                />
              </View>
              <TouchableOpacity style={[s.modalSendCodeBtn, (!targetPhone || busy) && s.modalSendDisabled]} disabled={!targetPhone || busy} onPress={() => sendCode(targetType)}>
                {busy ? (
                  <ActivityIndicator size="small" color={colors.white} />
                ) : (
                  <>
                    <Ionicons name="send" size={16} color={colors.white} />
                    <Text style={s.modalSendCodeText}>Send</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
            {!targetPhone ? <Text style={s.modalPhoneHint}>No {targetLabel} phone number available.</Text> : null}
            {hasSentCode ? (
              <Text style={[s.modalCountdownText, !codeStillActive && s.modalCountdownExpired]}>
                {codeStillActive ? `Code expires in ${formatCountdown(codeSecondsLeft)}` : "Code expired. Send a new code."}
              </Text>
            ) : null}
            <Text style={s.modalInputLabel}>Confirmation Code</Text>
            <TextInput
              value={code}
              onChangeText={(value) => setCode(value.toUpperCase())}
              placeholder="ABC234"
              placeholderTextColor={colors.textMuted}
              autoCapitalize="characters"
              style={s.modalInput}
            />
            <View style={s.modalBtnRow}>
              <TouchableOpacity style={s.modalCancelBtn} onPress={() => setShowCodeModal(false)}>
                <Text style={s.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.modalApplyBtn, (busy || !code.trim()) && s.modalApplyDisabled]} disabled={busy || !code.trim()} onPress={confirmCode}>
                {busy ? <ActivityIndicator size="small" color={colors.white} /> : <Text style={s.modalApplyText}>Confirm</Text>}
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
        </KeyboardAvoidingView>
      </Modal>

      <Modal visible={showIssueModal} transparent animationType="fade" onRequestClose={() => setShowIssueModal(false)}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 12 : 0}
          style={s.modalAvoider}
        >
        <Pressable style={s.modalOverlay} onPress={() => setShowIssueModal(false)}>
          <Pressable style={s.modalCard} onPress={(event) => event.stopPropagation()}>
            <View style={s.modalHeader}>
              <View style={[s.modalIconWrap, s.issueModalIconWrap]}>
                <Ionicons name="alert-circle" size={21} color={colors.white} />
              </View>
              <Text style={s.modalTitle}>Report a Problem</Text>
              <Text style={s.modalSub}>Use this if the package was not received or something is wrong.</Text>
            </View>
            <Dropdown
              label="Reason"
              required
              placeholder="Select a reason"
              options={reasons.map((reason) => ({ label: reason.label, value: reason.id }))}
              value={reasonId}
              onSelect={(value) => setReasonId(Number(value))}
            />
            <Text style={s.modalInputLabel}>Notes</Text>
            <TextInput
              value={notes}
              onChangeText={setNotes}
              placeholder="Add short notes"
              placeholderTextColor={colors.textMuted}
              multiline
              style={[s.modalInput, s.notesInput]}
            />
            <View style={s.modalBtnRow}>
              <TouchableOpacity style={s.modalCancelBtn} onPress={() => setShowIssueModal(false)}>
                <Text style={s.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.modalApplyBtn, s.issueApplyBtn, busy && s.modalApplyDisabled]} disabled={busy} onPress={reportIssue}>
                {busy ? <ActivityIndicator size="small" color={colors.white} /> : <Text style={s.modalApplyText}>Report</Text>}
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

function HeroSummaryCard({ icon, label, value, color, bg }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string; color: string; bg: string }) {
  return (
    <View style={s.heroSummaryCard}>
      <View style={[s.heroSummaryIcon, { backgroundColor: bg }]}>
        <Ionicons name={icon} size={18} color={color} />
      </View>
      <Text style={s.heroSummaryAmount} numberOfLines={1} adjustsFontSizeToFit>{value}</Text>
      <Text style={s.heroSummaryTitle}>{label}</Text>
    </View>
  );
}

function SectionTitle({ title }: { title: string }) {
  return <Text style={s.sectionTitle}>{title}</Text>;
}

function FollowUpGuide() {
  return (
    <View style={s.guideCard}>
      <View style={s.guideHeader}>
        <View style={s.guideIcon}>
          <Ionicons name="trail-sign-outline" size={19} color={colors.primary} />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.guideTitle}>Follow up this handoff</Text>
          <Text style={s.guideText}>Call first. If they say it arrived, tap Confirm Delivery, send the code, then enter it to close the handoff.</Text>
        </View>
      </View>
      <View style={s.guideSteps}>
        <GuideStep number="1" label="Call" />
        <GuideStep number="2" label="Confirm" />
        <GuideStep number="3" label="Enter code" />
      </View>
    </View>
  );
}

function GuideStep({ number, label }: { number: string; label: string }) {
  return (
    <View style={s.guideStep}>
      <Text style={s.guideStepNumber}>{number}</Text>
      <Text style={s.guideStepLabel}>{label}</Text>
    </View>
  );
}

function formatCountdown(totalSeconds: number): string {
  const seconds = Math.max(0, totalSeconds);
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;

  return `${minutes}:${String(remainingSeconds).padStart(2, "0")}`;
}

function ContactGroupCard({
  recipientName,
  recipientPhone,
  recipientDetail,
  vendorName,
  vendorPhone,
  canFollowUp,
  onCallRecipient,
  onCallVendor,
  onConfirmDelivery,
  onReportProblem,
}: {
  recipientName: string;
  recipientPhone?: string | null;
  recipientDetail?: string;
  vendorName: string;
  vendorPhone?: string | null;
  canFollowUp: boolean;
  onCallRecipient: () => void;
  onCallVendor: () => void;
  onConfirmDelivery: () => void;
  onReportProblem: () => void;
}) {
  return (
    <View style={s.contactGroupCard}>
      <ContactRow
        label="Recipient"
        name={recipientName}
        phone={recipientPhone}
        detail={recipientDetail}
        icon="person-outline"
        onPress={onCallRecipient}
      />
      <View style={s.contactDivider} />
      <ContactRow
        label="Sender"
        name={vendorName}
        phone={vendorPhone}
        icon="storefront-outline"
        onPress={onCallVendor}
      />
      {canFollowUp ? (
        <>
          <View style={s.contactDivider} />
          <View style={s.contactActionRow}>
            <TouchableOpacity style={[s.contactActionBtn, s.contactIssueBtn]} onPress={onReportProblem} activeOpacity={0.72}>
              <Ionicons name="alert-circle-outline" size={17} color={colors.error} />
              <Text style={[s.contactActionText, { color: colors.error }]}>Report Problem</Text>
            </TouchableOpacity>
            <TouchableOpacity style={s.contactActionBtn} onPress={onConfirmDelivery} activeOpacity={0.72}>
              <Ionicons name="checkmark-circle-outline" size={17} color={colors.primary} />
              <Text style={s.contactActionText}>Confirm Delivery</Text>
            </TouchableOpacity>
          </View>
        </>
      ) : null}
    </View>
  );
}

function ContactRow({ label, name, phone, detail, icon, onPress }: { label: string; name: string; phone?: string | null; detail?: string; icon: keyof typeof Ionicons.glyphMap; onPress: () => void }) {
  return (
    <View style={s.contactRow}>
      <View style={s.contactIcon}><Ionicons name={icon} size={20} color={colors.primary} /></View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.contactLabel}>{label}</Text>
        <Text style={s.contactName} numberOfLines={1}>{name}</Text>
        <Text style={s.contactPhone} numberOfLines={1}>{phone ? formatPhone(phone) : "No phone number"}{detail ? ` · ${detail}` : ""}</Text>
      </View>
      <View style={s.contactButtons}>
        <TouchableOpacity style={[s.iconActionBtn, !phone && s.disabledAction]} disabled={!phone} onPress={onPress}>
          <Ionicons name="call" size={18} color={phone ? colors.primary : colors.textMuted} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

function ProofRow({ icon, label, value, onPress }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string; onPress?: () => void }) {
  const Wrapper = onPress ? TouchableOpacity : View;
  return (
    <Wrapper style={s.proofRow} onPress={onPress as any} activeOpacity={0.75}>
      <View style={s.proofRowIcon}>
        <Ionicons name={icon} size={18} color={colors.primary} />
      </View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.proofRowLabel}>{label}</Text>
        <Text style={s.proofRowValue} numberOfLines={1}>{value}</Text>
      </View>
      {onPress ? <Ionicons name="call" size={17} color={colors.primary} /> : null}
    </Wrapper>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, backgroundColor: colors.background, alignItems: "center", justifyContent: "center", padding: 24 },
  emptyTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.dark, marginBottom: 14 },
  hero: { paddingHorizontal: 20, paddingBottom: 20, gap: 10, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  heroDecor2: { position: "absolute", bottom: -60, left: -40, width: width * 0.4, height: width * 0.4, borderWidth: 40, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.2 },
  heroTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", alignItems: "center", justifyContent: "center" },
  heroTitle: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white },
  heroSub: { marginTop: 2, fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)" },
  heroSummaryGrid: { flexDirection: "row", gap: 8, marginTop: 4 },
  heroSummaryCard: { flex: 1, minHeight: 92, backgroundColor: "rgba(255,255,255,0.07)", borderRadius: 12, borderWidth: 1, borderColor: "rgba(255,255,255,0.09)", paddingHorizontal: 6, paddingVertical: 9, alignItems: "center", justifyContent: "center", gap: 3 },
  heroSummaryIcon: { width: 28, height: 28, borderRadius: 9, justifyContent: "center", alignItems: "center" },
  heroSummaryAmount: { width: "100%", fontFamily: fontFamily.extrabold, fontSize: 18, color: colors.white, lineHeight: 22, textAlign: "center" },
  heroSummaryTitle: { fontFamily: fontFamily.bold, fontSize: 9, color: "rgba(255,255,255,0.82)", textAlign: "center" },
  content: { padding: 16, gap: 12 },
  sectionTitle: { marginTop: 4, fontFamily: fontFamily.bold, fontSize: 14, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.5 },
  guideCard: { backgroundColor: "#fff7ed", borderRadius: 14, borderWidth: 1, borderColor: "#fed7aa", padding: 13, gap: 12 },
  guideHeader: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  guideIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  guideTitle: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark },
  guideText: { marginTop: 3, fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, lineHeight: 17 },
  guideSteps: { flexDirection: "row", gap: 8 },
  guideStep: { flex: 1, minHeight: 42, borderRadius: 12, backgroundColor: colors.white, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  guideStepNumber: { width: 20, height: 20, borderRadius: 10, backgroundColor: colors.primary, overflow: "hidden", textAlign: "center", lineHeight: 20, fontFamily: fontFamily.bold, fontSize: 11, color: colors.white },
  guideStepLabel: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.dark },
  contactGroupCard: { backgroundColor: colors.white, borderRadius: 14, padding: 13, gap: 12, shadowColor: colors.dark, shadowOpacity: 0.04, shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: 1 },
  contactRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  contactDivider: { height: 1, backgroundColor: colors.neutral100, marginLeft: 54 },
  contactIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  contactLabel: { fontFamily: fontFamily.bold, fontSize: 10, color: colors.textMuted, textTransform: "uppercase" },
  contactName: { marginTop: 2, fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark },
  contactPhone: { marginTop: 2, fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted },
  contactButtons: { flexDirection: "row", alignItems: "center", gap: 8 },
  iconActionBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  contactActionRow: { flexDirection: "row", gap: 10 },
  contactActionBtn: { flex: 1, minHeight: 44, borderRadius: 13, backgroundColor: colors.warmSurface, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 },
  contactIssueBtn: { backgroundColor: "#fff1f2" },
  contactActionText: { fontFamily: fontFamily.bold, fontSize: 12, color: colors.primary },
  disabledAction: { opacity: 0.5 },
  proofCard: { backgroundColor: colors.white, borderRadius: 14, padding: 13, gap: 12, shadowColor: colors.dark, shadowOpacity: 0.04, shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: 1 },
  proofRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  proofRowIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  proofRowLabel: { fontFamily: fontFamily.bold, fontSize: 10, color: colors.textMuted, textTransform: "uppercase" },
  proofRowValue: { marginTop: 2, fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark },
  proofDivider: { height: 1, backgroundColor: colors.neutral100, marginLeft: 54 },
  proofPhotoBtn: { marginLeft: 54, minHeight: 44, borderRadius: 13, backgroundColor: colors.warmSurface, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 },
  proofPhotoBtnText: { fontFamily: fontFamily.bold, fontSize: 12, color: colors.primary },
  proofPhotoMissing: { marginLeft: 54, minHeight: 44, borderRadius: 13, backgroundColor: "#f8fafc", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 },
  proofPhotoMissingText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  resolvedCard: { flexDirection: "row", alignItems: "flex-start", gap: 10, borderRadius: 14, padding: 14, backgroundColor: colors.white, shadowColor: colors.dark, shadowOpacity: 0.04, shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: 1 },
  resolvedTitle: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark },
  resolvedText: { marginTop: 3, fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, lineHeight: 17 },
  resolvedMeta: { marginTop: 4, gap: 4 },
  resolvedMetaRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  notesInput: { minHeight: 86, paddingTop: 12, textAlignVertical: "top", fontFamily: fontFamily.medium, fontSize: 14 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "center", alignItems: "center", paddingHorizontal: 24 },
  modalCard: { width: "100%", maxWidth: 430, maxHeight: "86%", backgroundColor: colors.white, borderRadius: 20, padding: 20, gap: 14 },
  modalHeader: { alignItems: "center", gap: 6 },
  modalIconWrap: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.primary, justifyContent: "center", alignItems: "center", marginBottom: 4 },
  issueModalIconWrap: { backgroundColor: colors.error },
  modalTitle: { fontFamily: fontFamily.bold, fontSize: 17, color: colors.dark, textAlign: "center" },
  modalSub: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, textAlign: "center", lineHeight: 17 },
  modalInputLabel: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.dark, marginBottom: -8 },
  modalInput: { fontFamily: fontFamily.regular, fontSize: 16, color: colors.dark, paddingVertical: 14, paddingHorizontal: 12, backgroundColor: colors.warmSurface, borderTopLeftRadius: 4, borderTopRightRadius: 4, borderBottomWidth: 2, borderBottomColor: colors.primary },
  modalAvoider: { flex: 1 },
  modalSendRow: { flexDirection: "row", alignItems: "flex-end", gap: 10, marginTop: -6 },
  modalTargetSelect: { flex: 1, minWidth: 0 },
  modalSendCodeBtn: { width: 92, minHeight: 52, borderRadius: 16, backgroundColor: colors.primary, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  modalSendDisabled: { opacity: 0.55 },
  modalSendCodeText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.white },
  modalPhoneHint: { marginTop: -8, fontFamily: fontFamily.medium, fontSize: 11, color: colors.error },
  modalCountdownText: { marginTop: -6, fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, textAlign: "left" },
  modalCountdownExpired: { color: colors.error },
  modalBtnRow: { flexDirection: "row", gap: 10, marginTop: 6 },
  modalCancelBtn: { flex: 1, paddingVertical: 12, borderRadius: 24, alignItems: "center", justifyContent: "center", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  modalCancelText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.textMuted },
  modalApplyBtn: { flex: 1, minHeight: 45, paddingVertical: 12, borderRadius: 24, alignItems: "center", justifyContent: "center", backgroundColor: colors.primary },
  issueApplyBtn: { backgroundColor: colors.error },
  modalApplyDisabled: { opacity: 0.4 },
  modalApplyText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  lightbox: { flex: 1, backgroundColor: "rgba(0,0,0,0.94)", alignItems: "center", justifyContent: "center" },
  lightboxImage: { width: "100%", height: "82%" },
  lightboxClose: { position: "absolute", right: 20, zIndex: 2, width: 44, height: 44, borderRadius: 22, backgroundColor: "rgba(255,255,255,0.16)", alignItems: "center", justifyContent: "center" },
});
