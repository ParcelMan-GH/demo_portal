import { useCallback, useMemo, useState } from "react";
import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity, Dimensions, Linking } from "react-native";
import { router, useFocusEffect, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../../../src/components/common/EmptyState";
import ShimmerLoading from "../../../../src/components/common/ShimmerLoading";
import StatusBadge from "../../../../src/components/common/StatusBadge";
import { colors } from "../../../../src/constants/colors";
import { fontFamily } from "../../../../src/constants/typography";
import { getBusHandoffs, type BusHandoffFollowUp } from "../../../../src/api/v1/driver/bus-handoffs";
import { formatDateTimeAmPm, formatPhone } from "../../../../src/utils/format";
import { getErrorMessage, showError } from "../../../../src/utils/toast";

const { width } = Dimensions.get("window");

export default function BusHandoffStopScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const stopId = Number(id);
  const busHandoffsRoute = "/(driver)/bus-handoffs" as const;
  const leaveBusHandoffStop = () => {
    if (router.canGoBack()) router.back();
    else router.replace(busHandoffsRoute as any);
  };
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [items, setItems] = useState<BusHandoffFollowUp[]>([]);

  const fetchData = useCallback(async () => {
    try {
      const res = await getBusHandoffs({ limit: 100 });
      const data = (res as any)?.data || {};
      const rows = ((data.handoffs || []) as BusHandoffFollowUp[]).filter((item) => Number(item.delivery_run_stop_id) === stopId);
      setItems(rows);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [stopId]);

  useFocusEffect(useCallback(() => { setLoading(true); fetchData(); }, [fetchData]));

  const meta = useMemo(() => {
    const first = items[0];
    return {
      station: first?.handoff?.bus_station || "Bus station handoff",
      handedOffAt: first?.handoff?.handed_off_at || null,
      courierPhone: first?.handoff?.courier_phone || null,
      toFollow: items.filter((item) => ["pending", "code_sent"].includes(item.status)).length,
      issues: items.filter((item) => item.status === "issue_reported" || item.status === "failed").length,
      done: items.filter((item) => item.status === "confirmed" || item.status === "admin_confirmed").length,
    };
  }, [items]);

  const isInitialLoading = loading && items.length === 0;

  return (
    <View style={s.container}>
      <LinearGradient colors={["#1e293b", "#334155", "#1e293b"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
        <View style={s.heroDecor1} />
        <View style={s.headerRow}>
          <TouchableOpacity style={s.backBtn} onPress={leaveBusHandoffStop}>
            <Ionicons name="arrow-back" size={20} color={colors.white} />
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={s.headerTitle} numberOfLines={1}>{meta.station}</Text>
            <View style={s.headerMetaRow}>
              <View style={s.headerMetaItem}>
                <Ionicons name="cube-outline" size={12} color="rgba(255,255,255,0.55)" />
                <Text style={s.headerSub}>{items.length} package{items.length !== 1 ? "s" : ""}</Text>
              </View>
              {meta.handedOffAt ? (
                <View style={s.headerMetaItem}>
                  <Ionicons name="calendar-outline" size={12} color="rgba(255,255,255,0.55)" />
                  <Text style={s.headerSub}>{formatDateTimeAmPm(meta.handedOffAt)}</Text>
                </View>
              ) : null}
            </View>
          </View>
        </View>

        <View style={s.heroSummaryGrid}>
          <HeroSummaryCard icon="alert-circle" value={meta.toFollow} label="To follow" color="#93c5fd" bg="rgba(96,165,250,0.18)" />
          <HeroSummaryCard icon="warning" value={meta.issues} label="Issues" color="#fb7185" bg="rgba(251,113,133,0.18)" />
          <HeroSummaryCard icon="checkmark-circle" value={meta.done} label="Done" color="#34d399" bg="rgba(52,211,153,0.18)" />
        </View>

        {meta.courierPhone ? (
          <TouchableOpacity style={s.courierRow} activeOpacity={0.72} onPress={() => Linking.openURL(`tel:${meta.courierPhone}`)}>
            <Ionicons name="call-outline" size={15} color="rgba(255,255,255,0.65)" />
            <Text style={s.courierText}>Courier {formatPhone(meta.courierPhone)}</Text>
          </TouchableOpacity>
        ) : null}
      </LinearGradient>

      <View style={s.body}>
        {isInitialLoading ? (
          <PackageListSkeleton />
        ) : (
          <FlatList
            data={items}
            keyExtractor={(item) => String(item.delivery_run_item_id)}
            renderItem={({ item }) => <PackageCard item={item} />}
            contentContainerStyle={items.length ? s.list : s.emptyContent}
            ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} colors={[colors.primary]} />}
            ListEmptyComponent={<EmptyState icon="cube-outline" title="No packages found" subtitle="This handoff has no packages available for follow-up." illustration="packages" />}
          />
        )}
      </View>
    </View>
  );
}

function PackageCard({ item }: { item: BusHandoffFollowUp }) {
  const recipientPhone = item.recipient?.phone;
  const issue = item.status === "issue_reported" || item.status === "failed";
  const done = item.status === "confirmed" || item.status === "admin_confirmed";
  const accent = done ? colors.success : issue ? colors.error : colors.primary;

  return (
    <TouchableOpacity
      style={s.card}
      activeOpacity={0.72}
      onPress={() =>
        router.push({
          pathname: "/(driver)/bus-handoffs/[id]",
          params: { id: String(item.delivery_run_item_id) },
        } as any)
      }
    >
      <View style={[s.cardAccent, { backgroundColor: accent }]} />
      <View style={s.cardBody}>
        <View style={s.cardTop}>
          <View style={[s.cardIcon, { backgroundColor: done ? "#dcfce7" : issue ? "#fee2e2" : colors.warmSurface }]}>
            <Ionicons name={done ? "checkmark-circle" : issue ? "alert-circle" : "cube"} size={18} color={accent} />
          </View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={s.cardTitle} numberOfLines={1}>{item.package?.tracking_code || "Package"}</Text>
            <Text style={s.cardDescription} numberOfLines={1}>{item.package?.description || "Bus handoff package"}</Text>
            <View style={s.cardMeta}>
              <Ionicons name="person-outline" size={12} color={colors.textMuted} />
              <Text style={s.cardMetaText} numberOfLines={1}>{[item.recipient?.name, recipientPhone ? formatPhone(recipientPhone) : null].filter(Boolean).join(" · ") || "Recipient not set"}</Text>
            </View>
          </View>
        </View>
        <View style={s.cardBottom}>
          <StatusBadge status={item.status_label || item.status} />
          <View style={s.viewBtn}>
            <Text style={s.viewBtnText}>Follow Up</Text>
            <Ionicons name="arrow-forward" size={14} color={colors.primary} />
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

function HeroSummaryCard({ icon, value, label, color, bg }: { icon: keyof typeof Ionicons.glyphMap; value: number; label: string; color: string; bg: string }) {
  return (
    <View style={s.heroSummaryCard}>
      <View style={[s.heroSummaryIcon, { backgroundColor: bg }]}>
        <Ionicons name={icon} size={18} color={color} />
      </View>
      <Text style={s.heroSummaryValue}>{value}</Text>
      <Text style={s.heroSummaryTitle}>{label}</Text>
    </View>
  );
}

function PackageListSkeleton() {
  return (
    <View style={s.list}>
      {Array.from({ length: 4 }).map((_, index) => (
        <View key={index} style={s.card}>
          <View style={[s.cardAccent, { backgroundColor: colors.neutral200 }]} />
          <View style={s.cardBody}>
            <View style={s.cardTop}>
              <ShimmerLoading width={44} height={44} borderRadius={12} />
              <View style={{ flex: 1, gap: 7 }}>
                <ShimmerLoading width="54%" height={16} borderRadius={7} />
                <ShimmerLoading width="70%" height={12} borderRadius={6} />
                <ShimmerLoading width="62%" height={11} borderRadius={5} />
              </View>
            </View>
            <View style={s.cardBottom}>
              <ShimmerLoading width={92} height={28} borderRadius={14} />
              <ShimmerLoading width={102} height={32} borderRadius={8} />
            </View>
          </View>
        </View>
      ))}
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, gap: 10, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  headerMetaRow: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginTop: 4 },
  headerMetaItem: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 },
  heroSummaryGrid: { flexDirection: "row", gap: 8, marginTop: 4 },
  heroSummaryCard: { flex: 1, minHeight: 92, backgroundColor: "rgba(255,255,255,0.07)", borderRadius: 12, borderWidth: 1, borderColor: "rgba(255,255,255,0.09)", paddingHorizontal: 6, paddingVertical: 9, alignItems: "center", justifyContent: "center", gap: 3 },
  heroSummaryIcon: { width: 28, height: 28, borderRadius: 9, justifyContent: "center", alignItems: "center" },
  heroSummaryValue: { fontFamily: fontFamily.extrabold, fontSize: 24, color: colors.white, lineHeight: 28 },
  heroSummaryTitle: { fontFamily: fontFamily.bold, fontSize: 9, color: "rgba(255,255,255,0.82)", textAlign: "center" },
  courierRow: { flexDirection: "row", alignItems: "center", gap: 7, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.08)", paddingHorizontal: 12, paddingVertical: 9 },
  courierText: { fontFamily: fontFamily.medium, fontSize: 12, color: "rgba(255,255,255,0.72)" },
  body: { flex: 1, paddingTop: 14 },
  list: { flexGrow: 1, paddingHorizontal: 16, paddingBottom: 30 },
  emptyContent: { flexGrow: 1, justifyContent: "center", paddingHorizontal: 24 },
  card: { flexDirection: "row", backgroundColor: colors.white, borderRadius: 14, overflow: "hidden" },
  cardAccent: { width: 4 },
  cardBody: { flex: 1, padding: 14, gap: 10 },
  cardTop: { flexDirection: "row", gap: 12 },
  cardIcon: { width: 44, height: 44, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark },
  cardDescription: { marginTop: 2, fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted },
  cardMeta: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 3 },
  cardMetaText: { flex: 1, fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted },
  cardBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderTopWidth: 1, borderTopColor: colors.neutral100, paddingTop: 10 },
  viewBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  viewBtnText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.primary },
});
