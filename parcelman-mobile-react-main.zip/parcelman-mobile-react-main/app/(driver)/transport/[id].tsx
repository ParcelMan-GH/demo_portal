import { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  Dimensions,
  Modal,
  Pressable,
  TextInput,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { router, useLocalSearchParams, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../../src/components/common/EmptyState";
import StatusBadge from "../../../src/components/common/StatusBadge";
import Button from "../../../src/components/common/Button";
import ShimmerLoading from "../../../src/components/common/ShimmerLoading";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { getTransport, depart, arriveTransport, reportTransportScanIssue } from "../../../src/api/v1/driver/transports";
import { showSuccess, showError, getErrorMessage } from "../../../src/utils/toast";
import { formatDateTimeAmPm } from "../../../src/utils/format";
import ImagePickerButton from "../../../src/components/common/ImagePickerButton";

const { width } = Dimensions.get("window");

export default function TransportDetailScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const transportsRoute = "/(driver)/(tabs)/transports" as const;
  const scannerRoute = {
    pathname: "/(driver)/transport/[id]/scanner",
    params: { id: String(id) },
  } as const;
  const leaveTransportDetail = () => {
    if (router.canGoBack()) router.back();
    else router.replace(transportsRoute as any);
  };
  const [transport, setTransport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [issueTarget, setIssueTarget] = useState<any>(null);
  const [issueReason, setIssueReason] = useState("camera_cannot_read");
  const [issueNote, setIssueNote] = useState("");
  const [issuePhotos, setIssuePhotos] = useState<string[]>([]);

  const fetchTransport = async () => {
    try {
      const res = await getTransport(Number(id));
      setTransport((res.data as any)?.transport || res.data);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(useCallback(() => { fetchTransport(); }, [id]));

  const handleAction = async (action: () => Promise<any>, msg: string) => {
    setActionLoading(true);
    try {
      const res = await action();
      setTransport((res.data as any)?.transport || res.data);
      showSuccess(msg);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  const openScanIssue = (target: any) => {
    setIssueTarget(target);
    setIssueReason("camera_cannot_read");
    setIssueNote("");
    setIssuePhotos([]);
  };

  const closeScanIssue = () => {
    if (actionLoading) return;
    setIssueTarget(null);
    setIssueNote("");
    setIssuePhotos([]);
  };

  const submitScanIssue = async () => {
    if (!issueTarget) return;
    if (!issuePhotos[0]) {
      showError("Add a proof photo before submitting.");
      return;
    }

    setActionLoading(true);
    try {
      const res = await reportTransportScanIssue(Number(id), {
        target_type: issueTarget.type,
        container_id: issueTarget.type === "container" ? issueTarget.container?.id : undefined,
        manifest_item_id: issueTarget.type === "item" ? issueTarget.item?.manifest_item_id : undefined,
        reason: issueReason,
        note: issueNote.trim() || undefined,
        proof_photo: issuePhotos[0],
      });
      setTransport((res.data as any)?.transport || res.data);
      setIssueTarget(null);
      setIssueNote("");
      setIssuePhotos([]);
      const autoAccepted = Boolean((res.data as any)?.auto_accepted);
      showSuccess(autoAccepted ? "Scan issue accepted and loaded." : "Scan issue sent for admin review.");
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return <TransportDetailSkeleton topInset={insets.top} bottomInset={insets.bottom} />;
  }

  if (!transport) return null;

  const status = transport.status || "";
  const items = transport.items || [];
  const containers = (transport.containers || []).filter(hasContainerItems);
  const totalLoadUnits = containers.reduce((sum: number, container: any) => sum + containerLoadUnitCount(container), 0)
    || items.reduce((sum: number, item: any) => sum + loadUnitCount(item), 0);
  const loadedLoadUnits = containers.reduce((sum: number, container: any) => sum + loadedLoadUnitCount(container), 0);
  const remainingLoadUnits = Math.max(totalLoadUnits - loadedLoadUnits, 0);
  const loadedContainers = containers.filter((container: any) => isContainerLoaded(container)).length;
  const canDepart = containers.length > 0 && remainingLoadUnits === 0;

  return (
    <View style={s.container}>
      <ScrollView
        refreshControl={<RefreshControl refreshing={false} onRefresh={fetchTransport} colors={[colors.primary]} />}
        contentContainerStyle={{ paddingBottom: insets.bottom + 88 }}
      >
        <LinearGradient
          colors={["#0f172a", "#1e3a5f", "#0f172a"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[s.header, { paddingTop: insets.top + 12 }]}
        >
          <View style={s.heroDecor1} />
          <View style={s.headerTop}>
            <TouchableOpacity onPress={leaveTransportDetail} style={s.backBtn}>
              <Ionicons name="arrow-back" size={22} color={colors.white} />
            </TouchableOpacity>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={s.headerTitle}>Transport Details</Text>
              <Text style={s.headerSub} numberOfLines={1}>{transport.manifest_number || `#${transport.id}`}</Text>
            </View>
            <StatusBadge status={status} />
          </View>

          <View style={s.heroSummaryGrid}>
            <HeroSummaryCard icon="barcode-outline" value={String(totalLoadUnits)} label={totalLoadUnits === 1 ? "Label to scan" : "Labels to scan"} />
            <HeroSummaryCard icon="checkmark-done-outline" value={`${loadedLoadUnits}/${totalLoadUnits}`} label="Loaded" />
            <HeroSummaryCard icon="hourglass-outline" value={String(remainingLoadUnits)} label="Remaining" />
          </View>
        </LinearGradient>

        <View style={s.body}>
          <RouteDetailsCard transport={transport} />
          <TransportContainersCard
            containers={containers}
            onReportIssue={openScanIssue}
            actionLoading={actionLoading}
            canLoad={status === "assigned" || status === "loading"}
          />
          {transport.notes ? <NotesCard notes={transport.notes} /> : null}
        </View>
      </ScrollView>

      {(["assigned", "loading"].includes(status) && containers.length > 0) || status === "in_transit" ? (
        <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
          {(status === "assigned" || status === "loading") && (
            canDepart ? (
              <Button
                title="Depart"
                onPress={() => handleAction(() => depart(Number(id)), "Transport departed.")}
                loading={actionLoading}
                leftIcon={<Ionicons name="car" size={18} color={colors.white} />}
                gradientColors={["#1e293b", "#334155"] as [string, string]}
              />
            ) : (
              <Button
                title={`${transportScanActionLabel(containers)} (${loadedContainers}/${containers.length})`}
                onPress={() => router.push(scannerRoute as any)}
                leftIcon={<Ionicons name="scan" size={18} color={colors.white} />}
              />
            )
          )}
          {status === "in_transit" && (
            <Button
              title="Arrived"
              onPress={() => handleAction(() => arriveTransport(Number(id)), "Arrived at destination.")}
              loading={actionLoading}
              leftIcon={<Ionicons name="flag" size={18} color={colors.white} />}
              gradientColors={[colors.success, "#16a34a"] as [string, string]}
            />
          )}
        </View>
      ) : null}

      <ScanIssueModal
        visible={Boolean(issueTarget)}
        target={issueTarget}
        reason={issueReason}
        note={issueNote}
        photos={issuePhotos}
        loading={actionLoading}
        onReasonChange={setIssueReason}
        onNoteChange={setIssueNote}
        onPhotosChange={setIssuePhotos}
        onClose={closeScanIssue}
        onSubmit={submitScanIssue}
      />
    </View>
  );
}

function HeroSummaryCard({
  icon,
  value,
  label,
  compact = false,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  value: string;
  label: string;
  compact?: boolean;
}) {
  return (
    <View style={s.heroSummaryCard}>
      <View style={s.heroSummaryIcon}>
        <Ionicons name={icon} size={17} color={colors.white} />
      </View>
      <Text style={[s.heroSummaryValue, compact && s.heroSummaryValueCompact]} numberOfLines={1}>{value}</Text>
      <Text style={s.heroSummaryLabel} numberOfLines={1}>{label}</Text>
    </View>
  );
}

function RouteDetailsCard({ transport }: { transport: any }) {
  return (
    <View style={s.locationCard}>
      <View style={s.locationHeader}>
        <View style={s.routeHeaderIcon}>
          <Ionicons name="map-outline" size={14} color={colors.white} />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.locationTitle}>Route Details</Text>
        </View>
      </View>

      <View style={s.routeMarkerList}>
        <RouteInfoRow
          icon="radio-button-on-outline"
          label="Origin"
          value={transport.origin_warehouse?.name || "-"}
          sub={transport.origin_warehouse?.address}
          color={colors.primary}
          showLine
        />
        <RouteInfoRow
          icon="flag-outline"
          label="Destination"
          value={transport.destination_warehouse?.name || "-"}
          sub={transport.destination_warehouse?.address}
          color={colors.success}
        />
      </View>
    </View>
  );
}

function RouteInfoRow({
  icon,
  label,
  value,
  sub,
  color,
  showLine = false,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: string;
  sub?: string;
  color: string;
  showLine?: boolean;
}) {
  return (
    <View style={s.routeMarkerRow}>
      <View style={s.routeMarkerColumn}>
        <View style={[s.routeMarkerIcon, { backgroundColor: `${color}18` }]}>
          <Ionicons name={icon} size={15} color={color} />
        </View>
        {showLine ? <View style={s.routeMarkerLine} /> : null}
      </View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.locationDetailLabel}>{label}</Text>
        <Text style={s.locationDetailText} numberOfLines={2}>{value}</Text>
        {sub ? <Text style={s.locationDetailSub} numberOfLines={2}>{sub}</Text> : null}
      </View>
    </View>
  );
}

function TransportContainersCard({
  containers,
  onReportIssue,
  actionLoading,
  canLoad,
}: {
  containers: any[];
  onReportIssue: (target: any) => void;
  actionLoading: boolean;
  canLoad: boolean;
}) {
  return (
    <View style={s.packageListCard}>
      <View style={s.packageListHeader}>
        <Text style={s.packageListTitle}>ITEMS TO LOAD</Text>
        <View style={s.packageCount}>
          <Text style={s.packageCountText}>{containers.length}</Text>
        </View>
      </View>

      {containers.length === 0 ? (
        <View style={s.emptyItemsWrap}>
          <EmptyState
            icon="cube-outline"
            title="No containers found"
            subtitle="Transport containers will appear here once this manifest is prepared."
            illustration="logistics"
            compact
          />
        </View>
      ) : (
        containers.map((container: any, idx: number) => {
          const loaded = isContainerLoaded(container);
          const packageCount = Number(container.package_count || container.items?.length || 0);
          const itemQty = containerItemQuantity(container);
          const label = containerLabel(container, idx);
          const loose = isLooseContainer(container);
          const containerItems = container.items || [];

          return (
            <View
              key={container.id || container.container_code || idx}
              style={[s.containerListItem, idx === containers.length - 1 && s.packageListItemLast]}
            >
              <View style={s.containerMainRow}>
                <View style={s.packageNumberBadge}>
                  <Text style={s.packageNumberText}>{idx + 1}</Text>
                </View>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={s.packageNameText} numberOfLines={2}>{label}</Text>
                  <Text style={s.containerCodeText} numberOfLines={1}>{container.container_code}</Text>
                  <View style={s.itemQtyRow}>
                    <Text style={s.itemQtyText}>{packageCount} package{packageCount === 1 ? "" : "s"}</Text>
                    <Text style={s.itemQtyText}>{itemQty} item{itemQty === 1 ? "" : "s"}</Text>
                  </View>
                  {loose && !loaded ? (
                    <Text style={s.looseHintText}>Scan each package label. If scanning fails, report the issue with a proof photo.</Text>
                  ) : null}
                  {container.loaded_at ? <Text style={s.itemTime}>{formatDateTimeAmPm(container.loaded_at)}</Text> : null}
                </View>
                <View style={s.containerActionCol}>
                  <Text style={[s.itemStatusText, loaded ? s.itemStatusLoaded : s.itemStatusPending]}>
                    {containerStatusLabel(container, loaded)}
                  </Text>
                  {!loaded && canLoad ? (
                    <TouchableOpacity
                      style={s.markLoadedLink}
                      onPress={() => onReportIssue({ type: "container", container, label })}
                      disabled={actionLoading}
                      activeOpacity={0.75}
                    >
                      <Text style={s.markLoadedText}>Scan Issue</Text>
                    </TouchableOpacity>
                  ) : null}
                </View>
              </View>

              {loose && containerItems.length > 0 ? (
                <View style={s.looseItemsList}>
                  {containerItems.map((item: any, itemIdx: number) => (
                    <View
                      key={item.id || item.shipment_item_id || item.tracking_code || itemIdx}
                      style={[s.looseItemRow, itemIdx === containerItems.length - 1 && s.looseItemRowLast]}
                    >
                      <View style={s.looseItemIndex}>
                        <Text style={s.looseItemIndexText}>{itemIdx + 1}</Text>
                      </View>
                      <View style={{ flex: 1, minWidth: 0 }}>
                        <Text style={s.looseItemName} numberOfLines={2}>{item.description || "Package"}</Text>
                      </View>
                      <View style={s.looseItemActionCol}>
                        <Text style={s.looseItemQty}>{loadUnitCount(item)}</Text>
                        <Text style={s.looseItemQtyLabel}>label{loadUnitCount(item) === 1 ? "" : "s"}</Text>
                        {!isItemLoaded(item) && canLoad ? (
                          <TouchableOpacity
                            onPress={() => onReportIssue({ type: "item", item, label: item.description || "Package" })}
                            disabled={actionLoading}
                            activeOpacity={0.75}
                          >
                            <Text style={s.looseIssueText}>Issue</Text>
                          </TouchableOpacity>
                        ) : null}
                      </View>
                    </View>
                  ))}
                </View>
              ) : null}
            </View>
          );
        })
      )}
    </View>
  );
}

const SCAN_ISSUE_REASONS = [
  { value: "camera_cannot_read", label: "Camera cannot read" },
  { value: "label_damaged", label: "Label damaged" },
  { value: "label_missing", label: "Label missing" },
  { value: "item_present_no_label", label: "Item has no label" },
  { value: "other", label: "Other" },
];

function ScanIssueModal({
  visible,
  target,
  reason,
  note,
  photos,
  loading,
  onReasonChange,
  onNoteChange,
  onPhotosChange,
  onClose,
  onSubmit,
}: {
  visible: boolean;
  target: any;
  reason: string;
  note: string;
  photos: string[];
  loading: boolean;
  onReasonChange: (value: string) => void;
  onNoteChange: (value: string) => void;
  onPhotosChange: (photos: string[]) => void;
  onClose: () => void;
  onSubmit: () => void;
}) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 12 : 0}
        style={s.modalOverlay}
      >
        <Pressable style={s.modalBackdrop} onPress={onClose} />
        <View style={s.issueSheet}>
          <View style={s.issueSheetHandle} />
          <View style={s.issueHeader}>
            <View style={s.issueHeaderIcon}>
              <Ionicons name="alert-circle-outline" size={18} color={colors.white} />
            </View>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={s.issueTitle}>Scan Issue</Text>
              <Text style={s.issueSub} numberOfLines={1}>{targetLabel(target)}</Text>
            </View>
            <TouchableOpacity onPress={onClose} disabled={loading} style={s.issueCloseBtn}>
              <Ionicons name="close" size={20} color={colors.textMuted} />
            </TouchableOpacity>
          </View>

          <ScrollView
            style={s.issueBody}
            contentContainerStyle={s.issueBodyContent}
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
            showsVerticalScrollIndicator={false}
          >
            <Text style={s.issueFieldLabel}>Reason</Text>
            <View style={s.reasonGrid}>
              {SCAN_ISSUE_REASONS.map((item) => {
                const active = reason === item.value;
                return (
                  <TouchableOpacity
                    key={item.value}
                    style={[s.reasonChip, active && s.reasonChipActive]}
                    onPress={() => onReasonChange(item.value)}
                    activeOpacity={0.8}
                  >
                    <Text style={[s.reasonChipText, active && s.reasonChipTextActive]}>{item.label}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            <View style={s.issuePhotoBlock}>
              <ImagePickerButton label="Proof Photo (required)" images={photos} onImagesChange={onPhotosChange} maxImages={1} />
            </View>

            <Text style={s.issueFieldLabel}>Note (optional)</Text>
            <TextInput
              value={note}
              onChangeText={onNoteChange}
              placeholder="Add details for admin review"
              placeholderTextColor={colors.textLight}
              multiline
              style={s.issueTextInput}
            />
          </ScrollView>

          <View style={s.issueFooter}>
            <Button
              title="Submit Issue"
              onPress={onSubmit}
              loading={loading}
              disabled={!photos[0] || !reason}
              leftIcon={<Ionicons name="camera" size={18} color={colors.white} />}
              gradientColors={["#1e293b", "#334155"] as [string, string]}
            />
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function targetLabel(target: any): string {
  if (!target) return "Load group";
  if (target.type === "item") return target.item?.description || target.label || "Package";
  return target.label || target.container?.container_code || "Load group";
}

function NotesCard({ notes }: { notes: string }) {
  return (
    <View style={s.locationCard}>
      <View style={s.locationHeader}>
        <View style={s.locationHeaderIcon}>
          <Ionicons name="document-text-outline" size={18} color={colors.white} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={s.locationTitle}>Notes</Text>
          <Text style={s.locationMain}>Rider instructions</Text>
        </View>
      </View>
      <Text style={s.notesText}>{notes}</Text>
    </View>
  );
}

function TransportDetailSkeleton({ topInset, bottomInset }: { topInset: number; bottomInset: number }) {
  const darkSkeleton = { backgroundColor: "rgba(255,255,255,0.22)" };

  return (
    <View style={s.container}>
      <ScrollView contentContainerStyle={{ paddingBottom: bottomInset + 88 }}>
        <LinearGradient
          colors={["#0f172a", "#1e3a5f", "#0f172a"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[s.header, { paddingTop: topInset + 12 }]}
        >
          <View style={s.heroDecor1} />
          <View style={s.headerTop}>
            <View style={s.backBtn}>
              <ShimmerLoading width={18} height={18} borderRadius={9} style={darkSkeleton} />
            </View>
            <View style={{ flex: 1, gap: 7 }}>
              <ShimmerLoading width={142} height={20} borderRadius={8} style={darkSkeleton} />
              <ShimmerLoading width={132} height={12} borderRadius={6} style={darkSkeleton} />
            </View>
            <ShimmerLoading width={88} height={30} borderRadius={15} style={darkSkeleton} />
          </View>
          <View style={s.heroSummaryGrid}>
            {[0, 1, 2].map((item) => (
              <View key={item} style={s.heroSummaryCard}>
                <ShimmerLoading width={34} height={34} borderRadius={10} style={darkSkeleton} />
                <ShimmerLoading width="74%" height={20} borderRadius={8} style={darkSkeleton} />
                <ShimmerLoading width="54%" height={12} borderRadius={6} style={darkSkeleton} />
              </View>
            ))}
          </View>
        </LinearGradient>

        <View style={s.body}>
          <View style={s.locationCard}>
            <View style={s.locationHeader}>
              <ShimmerLoading width={42} height={42} borderRadius={13} />
              <View style={{ flex: 1, gap: 8 }}>
                <ShimmerLoading width={116} height={13} borderRadius={6} />
                <ShimmerLoading width="78%" height={17} borderRadius={8} />
              </View>
            </View>
            <View style={s.locationDetails}>
              <ShimmerLoading width="88%" height={14} borderRadius={7} />
              <ShimmerLoading width="76%" height={14} borderRadius={7} />
            </View>
          </View>

          <View style={s.packageListCard}>
            <View style={s.packageListHeader}>
              <ShimmerLoading width={72} height={17} borderRadius={8} />
              <ShimmerLoading width={26} height={26} borderRadius={13} />
            </View>
            {[0, 1, 2, 3].map((item) => (
              <View key={item} style={s.packageListItem}>
                <ShimmerLoading width={36} height={36} borderRadius={12} />
                <View style={{ flex: 1, gap: 8 }}>
                  <ShimmerLoading width="74%" height={15} borderRadius={7} />
                  <ShimmerLoading width="52%" height={12} borderRadius={6} />
                </View>
                <ShimmerLoading width={54} height={13} borderRadius={7} />
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function expectedQuantity(item: any): number {
  const value = Number(item.expected_quantity ?? item.quantity ?? 1);
  return Number.isFinite(value) && value > 0 ? value : 1;
}

function loadUnitCount(item: any): number {
  const labelCount = Number(item.label_count ?? (Array.isArray(item.labels) ? item.labels.length : 0));
  if (Number.isFinite(labelCount) && labelCount > 0) return labelCount;

  return expectedQuantity(item);
}

function loadedQuantity(item: any): number {
  const explicit = Number(item.loaded_quantity ?? item.scan_out_count ?? 0);
  if (Number.isFinite(explicit) && explicit > 0) return explicit;
  return item.loaded_at ? expectedQuantity(item) : 0;
}

function isItemLoaded(item: any): boolean {
  return Boolean(item.loaded_at) || loadedQuantity(item) >= expectedQuantity(item);
}

function isContainerLoaded(container: any): boolean {
  return ["loaded", "in_transit", "received", "reconciled"].includes(String(container.status || "").toLowerCase()) || Boolean(container.loaded_at);
}

function isLooseContainer(container: any): boolean {
  return String(container.container_type || "").toLowerCase() === "loose";
}

function hasContainerItems(container: any): boolean {
  const itemQty = containerItemQuantity(container);
  const packageCount = Number(container.package_count || container.items?.length || 0);

  return itemQty > 0 || packageCount > 0;
}

function containerItemQuantity(container: any): number {
  const value = Number(container.item_quantity || 0);
  if (Number.isFinite(value) && value > 0) return value;

  return (container.items || []).reduce((sum: number, item: any) => sum + expectedQuantity(item), 0);
}

function containerLoadUnitCount(container: any): number {
  if (!isLooseContainer(container)) {
    return 1;
  }

  return (container.items || []).reduce((sum: number, item: any) => sum + loadUnitCount(item), 0);
}

function loadedLoadUnitCount(container: any): number {
  if (!isLooseContainer(container)) {
    return isContainerLoaded(container) ? 1 : 0;
  }

  return (container.items || []).reduce((sum: number, item: any) => sum + Math.min(loadedQuantity(item), loadUnitCount(item)), 0);
}

function containerLabel(container: any, idx: number): string {
  const type = String(container.container_type || "container").replace(/_/g, " ");
  const normalized = type.charAt(0).toUpperCase() + type.slice(1);

  if (normalized.toLowerCase() === "loose") {
    return "Loose Items";
  }

  return `${normalized} ${container.sequence_number || idx + 1}`;
}

function containerStatusLabel(container: any, loaded: boolean): string {
  const status = String(container.status || "").toLowerCase();
  if (loaded) return "Loaded";
  if (["sealed", "open", "packed", ""].includes(status)) return "Ready";
  return formatStatus(status || "pending");
}

function transportScanActionLabel(containers: any[]): string {
  return "Scan Labels";
}

function formatStatus(status: string): string {
  return String(status || "pending").replace(/_/g, " ").replace(/\b\w/g, (c: string) => c.toUpperCase());
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 22, gap: 18, overflow: "hidden" },
  heroDecor1: {
    position: "absolute",
    top: -50,
    right: -30,
    width: width * 0.5,
    height: width * 0.5,
    borderWidth: 50,
    borderColor: "rgba(255,255,255,0.03)",
    borderRadius: width * 0.25,
    transform: [{ rotate: "20deg" }],
  },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
  },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 20, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.56)", marginTop: 2 },
  heroSummaryGrid: { flexDirection: "row", gap: 10 },
  heroSummaryCard: {
    flex: 1,
    minHeight: 118,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
    backgroundColor: "rgba(255,255,255,0.1)",
    padding: 12,
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
  },
  heroSummaryIcon: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: "rgba(255,255,255,0.16)",
    justifyContent: "center",
    alignItems: "center",
  },
  heroSummaryValue: { fontFamily: fontFamily.bold, fontSize: 26, color: colors.white, textAlign: "center" },
  heroSummaryValueCompact: { fontSize: 13, lineHeight: 18 },
  heroSummaryLabel: { fontFamily: fontFamily.semibold, fontSize: 12, color: "rgba(255,255,255,0.76)", textAlign: "center" },
  body: { padding: 16, gap: 14 },
  locationCard: {
    backgroundColor: colors.white,
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 14,
  },
  locationHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  locationHeaderIcon: {
    width: 42,
    height: 42,
    borderRadius: 13,
    backgroundColor: "#0f172a",
    justifyContent: "center",
    alignItems: "center",
  },
  routeHeaderIcon: {
    width: 30,
    height: 30,
    borderRadius: 9,
    backgroundColor: "#0f172a",
    justifyContent: "center",
    alignItems: "center",
  },
  locationTitle: { fontFamily: fontFamily.bold, fontSize: 12, color: colors.dark, textTransform: "uppercase", letterSpacing: 0.4 },
  locationMain: { fontFamily: fontFamily.semibold, fontSize: 16, color: colors.dark, marginTop: 2 },
  locationDetails: { gap: 12, paddingLeft: 2 },
  locationDetailRow: { flexDirection: "row", gap: 10, alignItems: "flex-start" },
  routeMarkerList: { paddingLeft: 2 },
  routeMarkerRow: { flexDirection: "row", gap: 12, minHeight: 70 },
  routeMarkerColumn: { width: 18, alignItems: "center" },
  routeMarkerIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  routeMarkerLine: { width: 2, flex: 1, backgroundColor: colors.neutral200, marginVertical: 4 },
  locationDetailLabel: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.4 },
  locationDetailText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.dark, marginTop: 1 },
  locationDetailSub: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: 2, lineHeight: 17 },
  packageListCard: {
    backgroundColor: colors.white,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
  },
  packageListHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral100,
  },
  packageListTitle: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark, letterSpacing: 0.2 },
  packageCount: {
    minWidth: 28,
    height: 28,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 8,
  },
  packageCountText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.primary },
  packageListItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral100,
  },
  containerListItem: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral100,
  },
  containerMainRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  packageListItemLast: { borderBottomWidth: 0, paddingBottom: 18 },
  packageNumberBadge: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: "#dbeafe",
    alignItems: "center",
    justifyContent: "center",
  },
  packageNumberText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.primary },
  packageNameText: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  containerCodeText: { fontFamily: "monospace", fontSize: 11, color: colors.textMuted, marginTop: 2 },
  itemQtyRow: { flexDirection: "row", alignItems: "center", gap: 12, marginTop: 4 },
  itemQtyText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  looseHintText: { fontFamily: fontFamily.regular, fontSize: 10, color: colors.textLight, marginTop: 4, lineHeight: 14 },
  itemTime: { fontFamily: fontFamily.regular, fontSize: 10, color: colors.textLight, marginTop: 3 },
  itemStatusText: { fontFamily: fontFamily.bold, fontSize: 10, textTransform: "uppercase", letterSpacing: 0.35 },
  itemStatusLoaded: { color: colors.success },
  itemStatusPending: { color: "#d97706" },
  containerActionCol: { alignItems: "flex-end", gap: 7, maxWidth: 94 },
  markLoadedLink: { paddingVertical: 2 },
  markLoadedText: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.primary, textDecorationLine: "underline", textAlign: "right" },
  looseItemsList: {
    marginTop: 12,
    marginLeft: 48,
    borderWidth: 1,
    borderColor: colors.neutral100,
    borderRadius: 12,
    overflow: "hidden",
  },
  looseItemRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 10,
    paddingVertical: 9,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral100,
    backgroundColor: "#f8fafc",
  },
  looseItemRowLast: { borderBottomWidth: 0 },
  looseItemIndex: {
    width: 24,
    height: 24,
    borderRadius: 8,
    backgroundColor: colors.white,
    alignItems: "center",
    justifyContent: "center",
  },
  looseItemIndexText: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.primary },
  looseItemName: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.dark },
  looseItemActionCol: { alignItems: "flex-end", gap: 2 },
  looseItemQty: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark },
  looseItemQtyLabel: { fontFamily: fontFamily.medium, fontSize: 9, color: colors.textMuted },
  looseIssueText: { fontFamily: fontFamily.semibold, fontSize: 10, color: colors.primary, textDecorationLine: "underline" },
  emptyItemsWrap: { padding: 14 },
  notesText: { fontFamily: fontFamily.regular, fontSize: 13, color: colors.text, lineHeight: 19 },
  footer: {
    paddingHorizontal: 16,
    paddingTop: 12,
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  modalOverlay: { flex: 1, justifyContent: "flex-end" },
  modalBackdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(15,23,42,0.54)" },
  issueSheet: {
    maxHeight: "88%",
    backgroundColor: colors.white,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: "hidden",
  },
  issueSheetHandle: {
    alignSelf: "center",
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.neutral300,
    marginTop: 10,
    marginBottom: 6,
  },
  issueHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral100,
  },
  issueHeaderIcon: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: "#0f172a",
    alignItems: "center",
    justifyContent: "center",
  },
  issueTitle: { fontFamily: fontFamily.bold, fontSize: 16, color: colors.dark },
  issueSub: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: 1 },
  issueCloseBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: colors.surface,
    alignItems: "center",
    justifyContent: "center",
  },
  issueBody: { maxHeight: 440 },
  issueBodyContent: { paddingHorizontal: 18, paddingTop: 16, paddingBottom: 32, gap: 12 },
  issueFieldLabel: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.dark },
  reasonGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  reasonChip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.white,
  },
  reasonChipActive: { backgroundColor: "#0f172a", borderColor: "#0f172a" },
  reasonChipText: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.text },
  reasonChipTextActive: { color: colors.white },
  issuePhotoBlock: { marginTop: 4 },
  issueTextInput: {
    minHeight: 86,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontFamily: fontFamily.regular,
    fontSize: 13,
    color: colors.dark,
    textAlignVertical: "top",
    backgroundColor: colors.surface,
  },
  issueFooter: {
    paddingHorizontal: 18,
    paddingTop: 12,
    paddingBottom: 18,
    borderTopWidth: 1,
    borderTopColor: colors.neutral100,
  },
});
