import { useEffect, useRef, useState } from "react";
import {
  Animated,
  Dimensions,
  Easing,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  Vibration,
  View,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CameraView, useCameraPermissions } from "expo-camera";
import { Ionicons } from "@expo/vector-icons";
import Button from "../../../../src/components/common/Button";
import { colors } from "../../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../../src/constants/typography";
import { borderRadius, spacing } from "../../../../src/constants/spacing";
import { scanContainerLoad } from "../../../../src/api/v1/driver/transports";
import { getErrorMessage } from "../../../../src/utils/toast";

const { width: SCREEN_WIDTH } = Dimensions.get("window");
const SCAN_WINDOW_SIZE = 260;
const DEBOUNCE_MS = 2200;

type ToastType = "success" | "warning" | "error";

interface ToastState {
  type: ToastType;
  title: string;
  subtitle?: string;
}

export default function TransportScannerScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const transportDetailRoute = {
    pathname: "/(driver)/transport/[id]",
    params: { id: String(id) },
  } as const;
  const leaveScanner = () => {
    if (router.canGoBack()) router.back();
    else router.replace(transportDetailRoute as any);
  };
  const [permission, requestPermission] = useCameraPermissions();
  const [toast, setToast] = useState<ToastState | null>(null);
  const [manualCode, setManualCode] = useState("");
  const [scanCount, setScanCount] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const scanLineAnim = useRef(new Animated.Value(0)).current;
  const lastScannedRef = useRef("");
  const lastScannedTimeRef = useRef(0);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(scanLineAnim, {
          toValue: 1,
          duration: 2000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(scanLineAnim, {
          toValue: 0,
          duration: 2000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [scanLineAnim]);

  const showToast = (nextToast: ToastState) => {
    setToast(nextToast);
    setTimeout(() => {
      setToast((current) => (current === nextToast ? null : current));
    }, 2600);
  };

  const submitCode = async (rawCode: string) => {
    const code = String(rawCode || "").trim();
    if (!code || submitting) return;

    const now = Date.now();
    if (code === lastScannedRef.current && now - lastScannedTimeRef.current < DEBOUNCE_MS) {
      return;
    }

    lastScannedRef.current = code;
    lastScannedTimeRef.current = now;
    setSubmitting(true);

    try {
      await scanContainerLoad(Number(id), code);
      Vibration.vibrate(100);
      setScanCount((prev) => prev + 1);
      showToast({
        type: "success",
        title: "Scan accepted",
        subtitle: code,
      });
    } catch (err: any) {
      Vibration.vibrate([0, 100, 50, 100]);
      showToast({
        type: "error",
        title: getErrorMessage(err) || "Scan failed",
        subtitle: code,
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleBarCodeScanned = ({ data }: { data: string }) => {
    submitCode(data);
  };

  const submitManualCode = () => {
    const code = manualCode.trim();
    if (!code) {
      showToast({
        type: "warning",
        title: "Enter a code",
        subtitle: "Type the label or load group code.",
      });
      return;
    }

    setManualCode("");
    submitCode(code);
  };

  const getToastColors = (type: ToastType) => {
    switch (type) {
      case "success":
        return { bg: colors.primary, icon: "checkmark-circle" as const };
      case "warning":
        return { bg: colors.primary, icon: "alert-circle" as const };
      case "error":
        return { bg: colors.primary, icon: "close-circle" as const };
    }
  };

  const scanLineTranslateY = scanLineAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [-SCAN_WINDOW_SIZE / 2 + 4, SCAN_WINDOW_SIZE / 2 - 4],
  });

  const hasCamera = Boolean(permission?.granted);

  return (
    <View style={styles.container}>
      {hasCamera ? (
        <CameraView
          style={StyleSheet.absoluteFill}
          barcodeScannerSettings={{
            barcodeTypes: ["qr", "code128", "code39", "ean13", "ean8", "codabar"],
          }}
          onBarcodeScanned={submitting ? undefined : handleBarCodeScanned}
        />
      ) : (
        <View style={styles.noCameraBackground} />
      )}

      {hasCamera ? (
        <ScannerOverlay scanLineTranslateY={scanLineTranslateY} />
      ) : (
        <View style={styles.permissionView}>
          <Ionicons name="camera-outline" size={56} color="rgba(255,255,255,0.74)" />
          <Text style={styles.permissionTitle}>Camera Access Required</Text>
          <Text style={styles.permissionText}>
            Grant camera access to scan labels. You can still enter a label code manually below.
          </Text>
          <Button title="Grant Permission" onPress={requestPermission} />
        </View>
      )}

      <View style={[styles.header, { paddingTop: insets.top + spacing.md }]} pointerEvents="box-none">
        <TouchableOpacity style={styles.backButton} onPress={leaveScanner} activeOpacity={0.8}>
          <Ionicons name="arrow-back" size={22} color={colors.white} />
        </TouchableOpacity>
        <View style={styles.headerCopy} pointerEvents="none">
          <Text style={styles.headerTitle}>Scan Labels</Text>
          <Text style={styles.headerSubtitle}>Point camera at a package label or load group code</Text>
        </View>
      </View>

      {toast && (
        <View style={[styles.toastContainer, { top: insets.top + 76 }]}>
          <View style={[styles.toast, { backgroundColor: getToastColors(toast.type).bg }]}>
            <Ionicons name={getToastColors(toast.type).icon} size={24} color={colors.white} />
            <View style={styles.toastTextContainer}>
              <Text style={styles.toastTitle}>{toast.title}</Text>
              {toast.subtitle ? <Text style={styles.toastSubtitle} numberOfLines={2}>{toast.subtitle}</Text> : null}
            </View>
          </View>
        </View>
      )}

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 8 : 0}
        style={styles.bottomKeyboardWrap}
        pointerEvents="box-none"
      >
        <View style={[styles.bottomContainer, { paddingBottom: insets.bottom + 18 }]}>
          <View style={styles.manualScanCard}>
            <View style={styles.manualScanHeader}>
              <Ionicons name="barcode-outline" size={16} color={colors.primary} />
              <Text style={styles.manualScanTitle}>Enter code manually</Text>
            </View>
            <Text style={styles.manualScanSub}>
              Use this when the camera cannot read the label or the barcode is damaged.
            </Text>
            <View style={styles.manualScanRow}>
              <TextInput
                value={manualCode}
                onChangeText={setManualCode}
                placeholder="e.g. TRKDKXGDLIE-001"
                placeholderTextColor="rgba(255,255,255,0.45)"
                autoCapitalize="characters"
                autoCorrect={false}
                returnKeyType="done"
                onSubmitEditing={submitManualCode}
                style={styles.manualScanInput}
              />
              <TouchableOpacity
                style={[styles.manualScanButton, submitting && styles.manualScanButtonDisabled]}
                onPress={submitManualCode}
                disabled={submitting}
                activeOpacity={0.85}
              >
                <Ionicons name="checkmark" size={18} color={colors.white} />
              </TouchableOpacity>
            </View>
          </View>

          {scanCount > 0 ? (
            <View style={styles.countBadge}>
              <Ionicons name="cube-outline" size={18} color={colors.white} />
              <Text style={styles.countText}>
                {scanCount} scan{scanCount !== 1 ? "s" : ""} accepted
              </Text>
            </View>
          ) : null}
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

function ScannerOverlay({ scanLineTranslateY }: { scanLineTranslateY: Animated.AnimatedInterpolation<string | number> }) {
  return (
    <View style={StyleSheet.absoluteFillObject} pointerEvents="none">
      <View style={styles.overlayEdge} />
      <View style={styles.overlayMiddleRow}>
        <View style={styles.overlayEdge} />
        <View style={styles.scanWindow}>
          <View style={[styles.corner, styles.cornerTL]} />
          <View style={[styles.corner, styles.cornerTR]} />
          <View style={[styles.corner, styles.cornerBL]} />
          <View style={[styles.corner, styles.cornerBR]} />
          <Animated.View style={[styles.scanLine, { transform: [{ translateY: scanLineTranslateY }] }]} />
        </View>
        <View style={styles.overlayEdge} />
      </View>
      <View style={styles.overlayEdge} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.black },
  noCameraBackground: { ...StyleSheet.absoluteFillObject, backgroundColor: "#0f172a" },
  header: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    minHeight: 94,
    alignItems: "center",
    justifyContent: "flex-start",
    backgroundColor: "rgba(0,0,0,0.5)",
  },
  backButton: {
    position: "absolute",
    left: 18,
    bottom: 18,
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: "rgba(15,23,42,0.62)",
    justifyContent: "center",
    alignItems: "center",
  },
  headerCopy: { alignItems: "center", paddingHorizontal: 72 },
  headerTitle: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.titleLg,
    color: colors.white,
  },
  headerSubtitle: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodySm,
    color: "rgba(255,255,255,0.7)",
    marginTop: spacing.sm,
    textAlign: "center",
  },
  permissionView: {
    position: "absolute",
    top: 150,
    left: spacing.xl,
    right: spacing.xl,
    alignItems: "center",
    gap: spacing.lg,
    padding: spacing.xl,
    borderRadius: borderRadius["2xl"],
    backgroundColor: "rgba(15,23,42,0.74)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.12)",
  },
  permissionTitle: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.titleMd,
    color: colors.white,
    textAlign: "center",
  },
  permissionText: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodySm,
    color: "rgba(255,255,255,0.72)",
    textAlign: "center",
    lineHeight: 20,
  },
  overlayEdge: { flex: 1, backgroundColor: "rgba(0,0,0,0.55)" },
  overlayMiddleRow: { flexDirection: "row", height: SCAN_WINDOW_SIZE },
  scanWindow: {
    width: SCAN_WINDOW_SIZE,
    height: SCAN_WINDOW_SIZE,
    position: "relative",
    overflow: "hidden",
  },
  corner: {
    position: "absolute",
    width: 30,
    height: 30,
    borderColor: colors.primary,
  },
  cornerTL: {
    top: 0,
    left: 0,
    borderTopWidth: 3,
    borderLeftWidth: 3,
    borderTopLeftRadius: 8,
  },
  cornerTR: {
    top: 0,
    right: 0,
    borderTopWidth: 3,
    borderRightWidth: 3,
    borderTopRightRadius: 8,
  },
  cornerBL: {
    bottom: 0,
    left: 0,
    borderBottomWidth: 3,
    borderLeftWidth: 3,
    borderBottomLeftRadius: 8,
  },
  cornerBR: {
    bottom: 0,
    right: 0,
    borderBottomWidth: 3,
    borderRightWidth: 3,
    borderBottomRightRadius: 8,
  },
  scanLine: {
    position: "absolute",
    left: 8,
    right: 8,
    height: 2,
    backgroundColor: colors.primary,
    top: "50%",
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 6,
    elevation: 4,
  },
  toastContainer: {
    position: "absolute",
    left: spacing.xl,
    right: spacing.xl,
    zIndex: 20,
  },
  toast: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.xl,
    borderRadius: borderRadius.lg,
    gap: spacing.lg,
    borderWidth: 1,
    borderColor: colors.primaryLight,
    boxShadow: "0 14px 28px rgba(124, 45, 18, 0.32)",
    elevation: 12,
  },
  toastTextContainer: { flex: 1 },
  toastTitle: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodyMd,
    color: colors.white,
  },
  toastSubtitle: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodySm,
    color: "rgba(255,255,255,0.85)",
    marginTop: 2,
  },
  bottomKeyboardWrap: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 15,
  },
  bottomContainer: {
    alignItems: "center",
    gap: spacing.lg,
    paddingHorizontal: spacing.xl,
  },
  manualScanCard: {
    width: SCREEN_WIDTH - spacing.xl * 2,
    backgroundColor: "rgba(15, 23, 42, 0.88)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
    borderRadius: borderRadius.xl,
    padding: spacing.lg,
    gap: spacing.sm,
  },
  manualScanHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
  },
  manualScanTitle: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodySm,
    color: colors.white,
  },
  manualScanSub: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyXs,
    color: "rgba(255,255,255,0.58)",
  },
  manualScanRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    marginTop: spacing.xs,
  },
  manualScanInput: {
    flex: 1,
    height: 44,
    borderRadius: borderRadius.lg,
    backgroundColor: "rgba(255,255,255,0.1)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
    paddingHorizontal: spacing.lg,
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodySm,
    color: colors.white,
  },
  manualScanButton: {
    width: 44,
    height: 44,
    borderRadius: borderRadius.lg,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.primary,
  },
  manualScanButtonDisabled: { opacity: 0.6 },
  countBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    backgroundColor: "rgba(0,0,0,0.6)",
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    borderRadius: borderRadius.full,
  },
  countText: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodyMd,
    color: colors.white,
  },
});
