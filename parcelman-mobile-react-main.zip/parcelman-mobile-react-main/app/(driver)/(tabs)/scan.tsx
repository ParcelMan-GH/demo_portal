import { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Easing,
  Dimensions,
  Vibration,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Modal,
  Pressable,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Ionicons } from '@expo/vector-icons';
import { scanClaim } from '../../../src/api/v1/driver/custody';
import { getRiderTeams, scanReceiveRiderTeam } from '../../../src/api/v1/driver/rider-teams';
import { colors } from '../../../src/constants/colors';
import { fontFamily, fontSize } from '../../../src/constants/typography';
import { spacing, borderRadius } from '../../../src/constants/spacing';
import Button from '../../../src/components/common/Button';
import type { RiderTeam } from '../../../src/types/driver';

const SCAN_WINDOW_SIZE = 260;
const DEBOUNCE_MS = 3000;

type ToastType = 'success' | 'warning' | 'error';
type ScanMode = 'team' | 'personal';

interface ToastState {
  type: ToastType;
  title: string;
  subtitle?: string;
}

interface PendingTeamConfirmation {
  barcode: string;
  team: RiderTeam;
}

export default function ScanScreen() {
  const insets = useSafeAreaInsets();
  const [permission, requestPermission] = useCameraPermissions();
  const [toast, setToast] = useState<ToastState | null>(null);
  const [teamScanCounts, setTeamScanCounts] = useState<Record<number, number>>({});
  const [personalScanCount, setPersonalScanCount] = useState(0);
  const [manualBarcode, setManualBarcode] = useState('');
  const [scanMode, setScanMode] = useState<ScanMode>('personal');
  const [teams, setTeams] = useState<RiderTeam[]>([]);
  const [selectedTeamId, setSelectedTeamId] = useState<number | null>(null);
  const [teamPickerOpen, setTeamPickerOpen] = useState(false);
  const [pendingTeamConfirmation, setPendingTeamConfirmation] = useState<PendingTeamConfirmation | null>(null);

  const lastScannedRef = useRef<string>('');
  const lastScannedTimeRef = useRef<number>(0);
  const scannedBarcodesRef = useRef<Set<string>>(new Set());
  const confirmedTeamIdsRef = useRef<Set<number>>(new Set());
  const teamConfirmationOpenRef = useRef(false);
  const scanLineAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    let mounted = true;
    getRiderTeams()
      .then((res) => {
        if (!mounted) return;
        const loadedTeams: RiderTeam[] = res?.data?.teams || [];
        setTeams(loadedTeams);
        if (loadedTeams.length > 0) {
          setSelectedTeamId(loadedTeams[0].id);
          setScanMode('team');
        }
      })
      .catch(() => {
        if (!mounted) return;
        setTeams([]);
        setSelectedTeamId(null);
        setScanMode('personal');
      });

    return () => {
      mounted = false;
    };
  }, []);

  // Animated scan line
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(scanLineAnim, {
          toValue: 1,
          duration: 2000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(scanLineAnim, {
          toValue: 0,
          duration: 2000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [scanLineAnim]);

  useEffect(() => {
    if (!toast || !permission?.granted) return undefined;

    const timeout = setTimeout(() => {
      setToast(null);
    }, toast.type === 'error' ? 6000 : 4000);

    return () => clearTimeout(timeout);
  }, [permission?.granted, toast]);

  const handleBarCodeScanned = async ({ data }: { data: string }) => {
    const barcode = String(data || '').trim();
    if (!barcode) return;
    const selectedTeam = teams.find((team) => team.id === selectedTeamId) || null;

    if (scanMode === 'team') {
      if (!selectedTeam) {
        setToast({
          type: 'warning',
          title: 'Select a rider team',
          subtitle: 'Choose the team receiving these packages before scanning.',
        });
        return;
      }

      if (!confirmedTeamIdsRef.current.has(selectedTeam.id)) {
        if (teamConfirmationOpenRef.current) return;

        teamConfirmationOpenRef.current = true;
        lastScannedRef.current = barcode;
        lastScannedTimeRef.current = Date.now();
        setPendingTeamConfirmation({ barcode, team: selectedTeam });
        return;
      }
    }

    const now = Date.now();

    // Debounce same barcode — ignore if scanned within last 3 seconds
    if (barcode === lastScannedRef.current && now - lastScannedTimeRef.current < DEBOUNCE_MS) {
      return;
    }

    lastScannedRef.current = barcode;
    lastScannedTimeRef.current = now;

    // Already accepted by this screen session. Failed scans are deliberately
    // not recorded here, so riders can retry after fixing the actual issue.
    const scanKey = `${scanMode}:${selectedTeamId || 'self'}:${barcode}`;
    if (scannedBarcodesRef.current.has(scanKey)) {
      Vibration.vibrate([0, 50, 30, 50]);
      setToast({
        type: 'warning',
        title: 'Already scanned',
        subtitle: barcode,
      });
      return;
    }

    try {
      const response = scanMode === 'team' && selectedTeam
        ? await scanReceiveRiderTeam(selectedTeam.id, { barcode })
        : await scanClaim({ barcode });
      const result = response?.data ?? response;
      const message = response?.message || result?.message || '';
      const action = response?.action || result?.action || result?.status;

      // API returns 200 for both new claims and "you already have this"
      const alreadyHave = message.toLowerCase().includes('already');

      Vibration.vibrate(100);

      if (alreadyHave) {
        setToast({
          type: 'warning',
          title: scanMode === 'team' ? 'Already in team custody' : 'You already have this package',
          subtitle: barcode,
        });
      } else {
        if (scanMode === 'team' && selectedTeam) {
          setTeamScanCounts((prev) => ({
            ...prev,
            [selectedTeam.id]: (prev[selectedTeam.id] || 0) + 1,
          }));
        } else {
          setPersonalScanCount((prev) => prev + 1);
        }

        const title =
          scanMode === 'team'
            ? 'Added to team custody'
            : action === 'leader_received'
              ? 'Handover received'
              : action === 'allocated_to_member' || action === 'member_claimed'
                ? 'Team package claimed'
                : 'Package claimed!';

        setToast({
          type: 'success',
          title,
          subtitle: result?.label?.description
            ? `${result.label.description}\n${barcode}`
            : (message ? `${message}\n${barcode}` : `${selectedTeam?.name || ''}\n${barcode}`.trim()),
        });
      }

      scannedBarcodesRef.current.add(scanKey);
    } catch (err: any) {
      const isNetworkError =
        !err?.response && (err?.message?.includes('Network') || err?.code === 'ERR_NETWORK');

      if (isNetworkError) {
        Vibration.vibrate([0, 100, 50, 100]);
        setToast({
          type: 'error',
          title: 'No internet connection',
          subtitle: `Connect to the internet and scan again.\n${barcode}`,
        });
        return;
      }

      Vibration.vibrate([0, 100, 50, 100]); // double buzz for error

      const status = err?.status || err?.response?.status;
      const serverMessage = err?.message || err?.response?.data?.message || '';

      if (serverMessage.toLowerCase().includes('already claimed')) {
        const claimedBy = err?.claimed_by || err?.response?.data?.claimed_by;
        if (claimedBy) {
          setToast({
            type: 'error',
            title: `Claimed by ${claimedBy}`,
            subtitle: barcode,
          });
        } else {
          setToast({
            type: 'warning',
            title: 'You already have this package',
            subtitle: barcode,
          });
        }
      } else if (status === 404) {
        setToast({
          type: 'error',
          title: 'Label not found',
          subtitle: barcode,
        });
      } else {
        setToast({
          type: 'error',
          title: serverMessage || 'Scan failed',
          subtitle: barcode,
        });
      }
    }
  };

  const submitManualBarcode = () => {
    const barcode = manualBarcode.trim();
    if (!barcode) {
      setToast({
        type: 'warning',
        title: 'Enter a barcode',
        subtitle: 'Type the package label barcode to claim it manually.',
      });
      return;
    }

    setManualBarcode('');
    handleBarCodeScanned({ data: barcode });
  };

  const openContextScreen = () => {
    if (scanMode === 'team') {
      if (selectedTeamId) {
        router.push({
          pathname: "/(driver)/teams/[id]",
          params: { id: String(selectedTeamId) },
        } as any);
        return;
      }

      router.push({ pathname: "/(driver)/teams" } as any);
      return;
    }

    router.push({ pathname: "/(driver)/packages" } as any);
  };

  const contextScanCount = scanMode === 'team' && selectedTeamId
    ? teamScanCounts[selectedTeamId] || 0
    : personalScanCount;

  const cancelTeamConfirmation = () => {
    teamConfirmationOpenRef.current = false;
    setPendingTeamConfirmation(null);
  };

  const confirmTeamScan = () => {
    const pending = pendingTeamConfirmation;
    if (!pending) return;

    confirmedTeamIdsRef.current.add(pending.team.id);
    teamConfirmationOpenRef.current = false;
    setPendingTeamConfirmation(null);
    lastScannedRef.current = '';
    lastScannedTimeRef.current = 0;

    setTimeout(() => {
      handleBarCodeScanned({ data: pending.barcode });
    }, 0);
  };

  const renderTeamConfirmationModal = () => {
    const pending = pendingTeamConfirmation;

    return (
      <Modal
        visible={!!pending}
        transparent
        animationType="fade"
        onRequestClose={cancelTeamConfirmation}
      >
        <Pressable style={styles.confirmOverlay} onPress={cancelTeamConfirmation}>
          <Pressable style={styles.confirmCard} onPress={(event) => event.stopPropagation()}>
            <View style={styles.confirmHeader}>
              <View style={styles.confirmIconWrap}>
                <Ionicons name="people" size={28} color={colors.white} />
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={styles.confirmTitle}>Scan Into This Team?</Text>
                <Text style={styles.confirmMessage}>
                  Packages will be received into {pending?.team.name || 'this team'} custody.
                </Text>
              </View>
            </View>
            <View style={styles.confirmTeamBox}>
              <View style={styles.confirmTeamAvatar}>
                <Ionicons name="people" size={18} color={colors.primary} />
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={styles.confirmTeamName} numberOfLines={1}>{pending?.team.name}</Text>
                <Text style={styles.confirmBarcode} numberOfLines={1}>{pending?.barcode}</Text>
              </View>
            </View>
            <View style={styles.confirmActions}>
              <TouchableOpacity style={styles.confirmCancelBtn} onPress={cancelTeamConfirmation} activeOpacity={0.85}>
                <Text style={styles.confirmCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.confirmSubmitBtn} onPress={confirmTeamScan} activeOpacity={0.85}>
                <Text style={styles.confirmSubmitText}>Yes, Scan</Text>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    );
  };

  const renderScanModeCard = () => {
    if (teams.length === 0) return null;
    const selectedTeam = teams.find((team) => team.id === selectedTeamId) || teams[0];

    return (
      <View style={styles.modeControls}>
        <View style={styles.modeSegment}>
          <TouchableOpacity
            style={[styles.modeOption, scanMode === 'team' && styles.modeOptionActive]}
            onPress={() => setScanMode('team')}
            activeOpacity={0.85}
          >
            <Ionicons name="people" size={15} color={scanMode === 'team' ? colors.white : 'rgba(255,255,255,0.72)'} />
            <Text style={[styles.modeOptionText, scanMode === 'team' && styles.modeOptionTextActive]}>Rider Team</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.modeOption, scanMode === 'personal' && styles.modeOptionActive]}
            onPress={() => {
              setScanMode('personal');
              setTeamPickerOpen(false);
            }}
            activeOpacity={0.85}
          >
            <Ionicons name="person" size={15} color={scanMode === 'personal' ? colors.white : 'rgba(255,255,255,0.72)'} />
            <Text style={[styles.modeOptionText, scanMode === 'personal' && styles.modeOptionTextActive]}>My Packages</Text>
          </TouchableOpacity>
        </View>

        {scanMode === 'team' ? (
          <>
            <TouchableOpacity
              style={styles.selectedTeamRow}
              onPress={() => teams.length > 1 && setTeamPickerOpen((open) => !open)}
              activeOpacity={teams.length > 1 ? 0.85 : 1}
            >
              <View style={styles.selectedTeamIcon}>
                <Ionicons name="people" size={16} color={colors.primary} />
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={styles.selectedTeamName} numberOfLines={1}>{selectedTeam?.name || 'Select team'}</Text>
                <Text style={styles.selectedTeamSub} numberOfLines={1}>Packages go into team custody</Text>
              </View>
              {teams.length > 1 ? (
                <Ionicons
                  name={teamPickerOpen ? 'chevron-up' : 'chevron-down'}
                  size={16}
                  color="rgba(255,255,255,0.68)"
                />
              ) : null}
            </TouchableOpacity>
            {teamPickerOpen && teams.length > 1 ? (
              <View style={styles.teamDropdown}>
                {teams.map((team, index) => {
                  const isSelected = selectedTeamId === team.id;

                  return (
                  <TouchableOpacity
                    key={team.id}
                    style={[
                      styles.teamDropdownRow,
                      index === teams.length - 1 && styles.teamDropdownRowLast,
                      isSelected && styles.teamDropdownRowActive,
                    ]}
                    onPress={() => {
                      setSelectedTeamId(team.id);
                      setTeamPickerOpen(false);
                    }}
                    activeOpacity={0.85}
                  >
                    <Text style={[styles.teamDropdownText, isSelected && styles.teamDropdownTextActive]} numberOfLines={1}>
                      {team.name}
                    </Text>
                    {isSelected ? <Ionicons name="checkmark" size={16} color={colors.primary} /> : null}
                  </TouchableOpacity>
                  );
                })}
              </View>
            ) : null}
          </>
        ) : (
          <Text style={styles.personalHint}>Scans will claim packages directly for your delivery work.</Text>
        )}
      </View>
    );
  };

  const renderManualScanCard = () => (
    <View style={styles.manualScanCard}>
      <View style={styles.manualScanHeader}>
        <Ionicons name="barcode-outline" size={16} color={colors.primary} />
        <Text style={styles.manualScanTitle}>Enter barcode manually</Text>
      </View>
      <View style={styles.manualScanRow}>
        <TextInput
          value={manualBarcode}
          onChangeText={setManualBarcode}
          placeholder="e.g. TRKDKXGDLIE-001"
          placeholderTextColor="rgba(255,255,255,0.45)"
          autoCapitalize="characters"
          autoCorrect={false}
          returnKeyType="done"
          onSubmitEditing={submitManualBarcode}
          style={styles.manualScanInput}
        />
        <TouchableOpacity
          style={styles.manualScanButton}
          onPress={submitManualBarcode}
          activeOpacity={0.85}
        >
          <Ionicons name="checkmark" size={18} color={colors.white} />
        </TouchableOpacity>
      </View>
    </View>
  );

  const getToastColors = (type: ToastType) => {
    switch (type) {
      case 'success':
        return { bg: colors.primary, softBg: 'rgba(234, 88, 12, 0.12)', border: 'rgba(234, 88, 12, 0.32)', icon: 'checkmark-circle' as const };
      case 'warning':
        return { bg: colors.primary, softBg: 'rgba(234, 88, 12, 0.12)', border: 'rgba(234, 88, 12, 0.32)', icon: 'alert-circle' as const };
      case 'error':
        return { bg: colors.primary, softBg: 'rgba(234, 88, 12, 0.12)', border: 'rgba(234, 88, 12, 0.32)', icon: 'close-circle' as const };
    }
  };

  const renderScanFeedbackCard = () => {
    if (!toast) return null;

    const feedback = getToastColors(toast.type);

    return (
      <View style={[styles.scanFeedbackCard, { backgroundColor: feedback.softBg, borderColor: feedback.border }]}>
        <View style={[styles.scanFeedbackIcon, { backgroundColor: feedback.bg }]}>
          <Ionicons name={feedback.icon} size={18} color={colors.white} />
        </View>
        <View style={styles.scanFeedbackTextWrap}>
          <Text style={styles.scanFeedbackTitle} numberOfLines={1}>{toast.title}</Text>
          {toast.subtitle ? (
            <Text style={styles.scanFeedbackSubtitle} numberOfLines={2}>{toast.subtitle}</Text>
          ) : null}
        </View>
        <TouchableOpacity style={styles.scanFeedbackClose} onPress={() => setToast(null)} activeOpacity={0.8}>
          <Ionicons name="close" size={18} color="rgba(255,255,255,0.72)" />
        </TouchableOpacity>
      </View>
    );
  };

  // Permission not yet determined
  if (!permission) {
    return (
      <View style={styles.container}>
        <View style={[styles.header, { paddingTop: insets.top + spacing.md }]}>
          <Text style={styles.headerTitle}>Scan Packages</Text>
        </View>
      </View>
    );
  }

  // Permission denied
  if (!permission.granted) {
    return (
      <View style={styles.container}>
        <View style={[styles.header, { paddingTop: insets.top + spacing.md }]}>
          <Text style={styles.headerTitle}>Scan Packages</Text>
        </View>
        {toast && (
          <View style={[styles.toastContainer, { top: insets.top + 70 }]}>
            <View style={[styles.toast, { backgroundColor: getToastColors(toast.type).bg }]}>
              <Ionicons
                name={getToastColors(toast.type).icon}
                size={24}
                color={colors.white}
              />
              <View style={styles.toastTextContainer}>
                <Text style={styles.toastTitle}>{toast.title}</Text>
                {toast.subtitle ? (
                  <Text style={styles.toastSubtitle} numberOfLines={2}>
                    {toast.subtitle}
                  </Text>
                ) : null}
              </View>
            </View>
          </View>
        )}
        <KeyboardAvoidingView
          style={styles.permissionView}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <Ionicons name="camera-outline" size={64} color={colors.textMuted} />
          <Text style={styles.permissionTitle}>Camera Access Required</Text>
          <Text style={styles.permissionText}>
            Camera permission is needed for camera scanning, but you can still enter a package label barcode manually.
          </Text>
          <Button title="Grant Permission" onPress={requestPermission} />
          {renderManualScanCard()}
        </KeyboardAvoidingView>
      </View>
    );
  }

  const scanLineTranslateY = scanLineAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [-SCAN_WINDOW_SIZE / 2 + 4, SCAN_WINDOW_SIZE / 2 - 4],
  });

  return (
    <View style={styles.container}>
      {/* Camera */}
      <CameraView
        style={StyleSheet.absoluteFill}
        barcodeScannerSettings={{
          barcodeTypes: ['qr', 'code128', 'code39', 'ean13', 'ean8', 'codabar'],
        }}
        onBarcodeScanned={handleBarCodeScanned}
      />

      {/* Dark overlay with clear scan window */}
      <View style={StyleSheet.absoluteFillObject} pointerEvents="none">
        {/* Top */}
        <View style={styles.overlayEdge} />
        {/* Middle row */}
        <View style={styles.overlayMiddleRow}>
          <View style={styles.overlayEdge} />
          {/* Scan window */}
          <View style={styles.scanWindow}>
            {/* Corner brackets */}
            <View style={[styles.corner, styles.cornerTL]} />
            <View style={[styles.corner, styles.cornerTR]} />
            <View style={[styles.corner, styles.cornerBL]} />
            <View style={[styles.corner, styles.cornerBR]} />
            {/* Animated scan line */}
            <Animated.View
              style={[
                styles.scanLine,
                { transform: [{ translateY: scanLineTranslateY }] },
              ]}
            />
          </View>
          <View style={styles.overlayEdge} />
        </View>
        {/* Bottom */}
        <View style={styles.overlayEdge} />
      </View>

      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + spacing.md }]}>
        <View style={styles.headerTopRow}>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={styles.headerTitle}>Scan Packages</Text>
            <Text style={styles.headerSubtitle} numberOfLines={1}>
              {scanMode === 'team' ? 'Team custody scan' : 'Personal package claim'}
            </Text>
          </View>
          <TouchableOpacity
            style={styles.headerIconButton}
            onPress={openContextScreen}
            activeOpacity={0.85}
          >
            <Ionicons name={scanMode === 'team' ? 'people' : 'list-outline'} size={22} color={colors.white} />
            {contextScanCount > 0 ? (
              <View style={styles.headerIconBadge}>
                <Text style={styles.headerIconBadgeText}>{contextScanCount > 99 ? '99+' : contextScanCount}</Text>
              </View>
            ) : null}
          </TouchableOpacity>
        </View>
        {renderScanModeCard()}
      </View>

      {renderTeamConfirmationModal()}

      {/* Bottom controls */}
      <KeyboardAvoidingView
        style={styles.bottomContainer}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={spacing.lg}
      >
        <View style={[styles.bottomContent, { paddingBottom: insets.bottom + spacing.md }]}>
          {renderScanFeedbackCard()}
          {renderManualScanCard()}
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.black,
  },

  // Header
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    paddingHorizontal: spacing.xl,
    paddingBottom: spacing.md,
    backgroundColor: 'rgba(0,0,0,0.56)',
    gap: spacing.md,
  },
  headerTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  headerTitle: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.titleMd,
    color: colors.white,
  },
  headerSubtitle: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyXs,
    color: 'rgba(255,255,255,0.7)',
    marginTop: 2,
  },
  headerIconBadge: {
    position: 'absolute',
    top: -9,
    right: -9,
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 5,
    borderWidth: 2,
    borderColor: colors.black,
  },
  headerIconBadgeText: {
    fontFamily: fontFamily.bold,
    fontSize: 11,
    color: colors.white,
  },
  headerIconButton: {
    position: 'relative',
    width: 42,
    height: 42,
    borderRadius: borderRadius.lg,
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    alignItems: 'center',
    justifyContent: 'center',
  },

  // Permission
  permissionView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing['4xl'],
    gap: spacing.xl,
    backgroundColor: colors.white,
  },
  permissionTitle: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.titleLg,
    color: colors.dark,
    textAlign: 'center',
  },
  permissionText: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.textMuted,
    textAlign: 'center',
    lineHeight: 22,
  },

  // Overlay
  overlayEdge: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
  },
  overlayMiddleRow: {
    flexDirection: 'row',
    height: SCAN_WINDOW_SIZE,
  },

  // Scan window
  scanWindow: {
    width: SCAN_WINDOW_SIZE,
    height: SCAN_WINDOW_SIZE,
    position: 'relative',
    overflow: 'hidden',
  },

  // Corner brackets
  corner: {
    position: 'absolute',
    width: 30,
    height: 30,
    borderColor: colors.primary,
  },
  cornerTL: {
    top: 0,
    left: 0,
    borderTopWidth: 3,
    borderLeftWidth: 3,
    borderTopLeftRadius: 8,
  },
  cornerTR: {
    top: 0,
    right: 0,
    borderTopWidth: 3,
    borderRightWidth: 3,
    borderTopRightRadius: 8,
  },
  cornerBL: {
    bottom: 0,
    left: 0,
    borderBottomWidth: 3,
    borderLeftWidth: 3,
    borderBottomLeftRadius: 8,
  },
  cornerBR: {
    bottom: 0,
    right: 0,
    borderBottomWidth: 3,
    borderRightWidth: 3,
    borderBottomRightRadius: 8,
  },

  // Scan line
  scanLine: {
    position: 'absolute',
    left: 8,
    right: 8,
    height: 2,
    backgroundColor: colors.primary,
    top: '50%',
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 6,
    elevation: 4,
  },

  // Toast
  toastContainer: {
    position: 'absolute',
    left: spacing.xl,
    right: spacing.xl,
    top: '62%',
    zIndex: 20,
  },
  toast: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.xl,
    borderRadius: borderRadius.lg,
    gap: spacing.lg,
    borderWidth: 1,
    borderColor: colors.primaryLight,
    boxShadow: '0 14px 28px rgba(124, 45, 18, 0.32)',
    elevation: 12,
  },
  toastTextContainer: {
    flex: 1,
  },
  toastTitle: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodyMd,
    color: colors.white,
  },
  toastSubtitle: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodySm,
    color: 'rgba(255,255,255,0.85)',
    marginTop: 2,
  },
  scanFeedbackCard: {
    width: SCREEN_WIDTH - spacing.xl * 2,
    minHeight: 64,
    borderRadius: borderRadius.xl,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    backgroundColor: 'rgba(15, 23, 42, 0.92)',
  },
  scanFeedbackIcon: {
    width: 36,
    height: 36,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scanFeedbackTextWrap: {
    flex: 1,
    minWidth: 0,
  },
  scanFeedbackTitle: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.bodySm,
    color: colors.white,
  },
  scanFeedbackSubtitle: {
    marginTop: 2,
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyXs,
    lineHeight: 17,
    color: 'rgba(255,255,255,0.78)',
  },
  scanFeedbackClose: {
    width: 34,
    height: 34,
    borderRadius: borderRadius.lg,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmOverlay: {
    flex: 1,
    backgroundColor: 'rgba(2, 6, 23, 0.76)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing['3xl'],
  },
  confirmCard: {
    width: '100%',
    maxWidth: 390,
    borderRadius: borderRadius['3xl'],
    backgroundColor: colors.white,
    padding: spacing['3xl'],
    alignItems: 'stretch',
    gap: spacing.lg,
  },
  confirmHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.lg,
  },
  confirmIconWrap: {
    width: 68,
    height: 68,
    borderRadius: borderRadius.xl,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.22,
    shadowRadius: 16,
    elevation: 8,
  },
  confirmTitle: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.titleSm,
    color: colors.dark,
  },
  confirmMessage: {
    marginTop: spacing.xs,
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodySm,
    lineHeight: 20,
    color: colors.textMuted,
  },
  confirmTeamBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    borderRadius: borderRadius.xl,
    backgroundColor: colors.warmSurface,
    borderWidth: 1,
    borderColor: colors.accentLighter,
    padding: spacing.md,
  },
  confirmTeamAvatar: {
    width: 42,
    height: 42,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmTeamName: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.bodyMd,
    color: colors.dark,
  },
  confirmBarcode: {
    marginTop: 2,
    fontFamily: fontFamily.medium,
    fontSize: fontSize.bodyXs,
    color: colors.textMuted,
  },
  confirmActions: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.sm,
  },
  confirmCancelBtn: {
    flex: 1,
    minHeight: 52,
    borderRadius: borderRadius.xl,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmCancelText: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.bodyMd,
    color: colors.dark,
  },
  confirmSubmitBtn: {
    flex: 1,
    minHeight: 52,
    borderRadius: borderRadius.xl,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.22,
    shadowRadius: 14,
    elevation: 7,
  },
  confirmSubmitText: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.bodyMd,
    color: colors.white,
  },

  // Bottom
  bottomContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: 'center',
    gap: spacing.lg,
    paddingHorizontal: spacing.xl,
  },
  bottomContent: {
    gap: spacing.lg,
    alignItems: 'center',
  },
  modeControls: {
    gap: spacing.sm,
  },
  modeSegment: {
    flexDirection: 'row',
    gap: spacing.sm,
    borderRadius: borderRadius.lg,
    backgroundColor: 'rgba(255,255,255,0.1)',
    padding: 4,
  },
  modeOption: {
    flex: 1,
    minHeight: 38,
    borderRadius: borderRadius.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
  },
  modeOptionActive: {
    backgroundColor: colors.primary,
  },
  modeOptionText: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.bodyXs,
    color: 'rgba(255,255,255,0.72)',
  },
  modeOptionTextActive: {
    color: colors.white,
  },
  selectedTeamRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    borderRadius: borderRadius.lg,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  selectedTeamIcon: {
    width: 32,
    height: 32,
    borderRadius: borderRadius.sm,
    backgroundColor: 'rgba(255,245,235,0.96)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedTeamName: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.bodySm,
    color: colors.white,
  },
  selectedTeamSub: {
    marginTop: 2,
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyXs,
    color: 'rgba(255,255,255,0.58)',
  },
  teamDropdown: {
    overflow: 'hidden',
    borderRadius: borderRadius.lg,
    backgroundColor: 'rgba(15, 23, 42, 0.96)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  teamDropdownRow: {
    minHeight: 44,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  teamDropdownRowLast: {
    borderBottomWidth: 0,
  },
  teamDropdownRowActive: {
    backgroundColor: 'rgba(249,115,22,0.12)',
  },
  teamDropdownText: {
    flex: 1,
    fontFamily: fontFamily.bold,
    fontSize: fontSize.bodyXs,
    color: 'rgba(255,255,255,0.76)',
  },
  teamDropdownTextActive: {
    color: colors.white,
  },
  personalHint: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyXs,
    color: 'rgba(255,255,255,0.62)',
    lineHeight: 18,
  },
  manualScanCard: {
    width: SCREEN_WIDTH - spacing.xl * 2,
    backgroundColor: 'rgba(15, 23, 42, 0.88)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    borderRadius: borderRadius.xl,
    padding: spacing.md,
    gap: spacing.md,
  },
  manualScanHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  manualScanTitle: {
    flex: 1,
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodySm,
    color: colors.white,
  },
  manualScanRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  manualScanInput: {
    flex: 1,
    height: 44,
    borderRadius: borderRadius.lg,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    paddingHorizontal: spacing.lg,
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodySm,
    color: colors.white,
  },
  manualScanButton: {
    width: 44,
    height: 44,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
  },
});
