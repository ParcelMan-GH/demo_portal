import { View, StyleSheet } from "react-native";
import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";

export default function DriverTabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarLabelStyle: { fontFamily: fontFamily.medium, fontSize: 11 },
        tabBarStyle: { backgroundColor: colors.white, borderTopColor: colors.border, paddingBottom: 4 },
      }}
    >
      <Tabs.Screen name="home" options={{ title: "Home", tabBarIcon: ({ color, size }) => <Ionicons name="home" size={size} color={color} /> }} />
      <Tabs.Screen name="pickups" options={{ title: "Pickups", tabBarIcon: ({ color, size }) => <Ionicons name="car" size={size} color={color} /> }} />
      <Tabs.Screen
        name="scan"
        options={{
          title: "",
          tabBarLabel: () => null,
          tabBarIcon: () => (
            <View style={s.scanBtn}>
              <Ionicons name="scan" size={26} color={colors.white} />
            </View>
          ),
        }}
      />
      <Tabs.Screen name="deliveries" options={{ title: "Deliveries", tabBarIcon: ({ color, size }) => <Ionicons name="bicycle" size={size} color={color} /> }} />
      <Tabs.Screen name="transports" options={{ title: "Transports", tabBarIcon: ({ color, size }) => <Ionicons name="bus" size={size} color={color} /> }} />
      <Tabs.Screen name="account" options={{ href: null }} />
    </Tabs>
  );
}

const s = StyleSheet.create({
  scanBtn: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: colors.primary,
    justifyContent: "center",
    alignItems: "center",
  },
});
