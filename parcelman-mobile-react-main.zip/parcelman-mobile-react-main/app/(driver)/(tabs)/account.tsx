import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Dimensions, RefreshControl, Image } from "react-native";
import { useState, useCallback } from "react";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import ConfirmDialog from "../../../src/components/common/ConfirmDialog";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { useAuthStore } from "../../../src/stores/auth.store";
import { formatPhone } from "../../../src/utils/format";
import { getDriverProfile } from "../../../src/api/v1/driver/profile";

const { width } = Dimensions.get("window");

export default function DriverAccountScreen() {
  const insets = useSafeAreaInsets();
  const user = useAuthStore((s) => s.user) as any;
  const setUser = useAuthStore((s) => s.setUser);
  const logout = useAuthStore((s) => s.logout);
  const [showLogout, setShowLogout] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const fetchProfile = async () => {
    try {
      const res = await getDriverProfile();
      setUser((res.data as any)?.user || (res.data as any)?.driver || res.data);
    } catch {}
    setRefreshing(false);
  };

  useFocusEffect(useCallback(() => { fetchProfile(); }, []));

  const handleLogout = async () => {
    await logout();
    router.replace("/(auth)/phone" as any);
  };

  const initials = (user?.name || "D").split(" ").map((w: string) => w[0]).join("").toUpperCase().slice(0, 2);
  const profilePhotoUrl = user?.photo_url || user?.profile_photo_url || null;

  return (
    <ScrollView style={s.container} contentContainerStyle={{ paddingBottom: insets.bottom + 30 }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchProfile(); }} colors={[colors.primary]} />}
    >
      <LinearGradient
        colors={["#1e293b", "#334155", "#1e293b"]}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={[s.hero, { paddingTop: insets.top + 24 }]}
      >
        <View style={s.heroDecor1} />
        <View style={s.heroDecor2} />

        <View style={s.avatarWrap}>
          {profilePhotoUrl ? (
            <Image source={{ uri: profilePhotoUrl }} style={s.avatarImage} resizeMode="cover" />
          ) : (
            <LinearGradient colors={[colors.primary, colors.primaryLight]} style={s.avatar}>
              <Text style={s.avatarText}>{initials}</Text>
            </LinearGradient>
          )}
        </View>

        <Text style={s.heroName}>{user?.name || "Rider"}</Text>
        <View style={s.infoChips}>
          {user?.email && (
            <View style={s.infoChip}>
              <Ionicons name="mail-outline" size={13} color={colors.accentLight} />
              <Text style={s.infoChipText}>{user.email}</Text>
            </View>
          )}
          {user?.phone && (
            <View style={s.infoChip}>
              <Ionicons name="call-outline" size={13} color={colors.accentLight} />
              <Text style={s.infoChipText}>{formatPhone(user.phone)}</Text>
            </View>
          )}
          {user?.vehicle_type && (
            <View style={s.infoChip}>
              <Ionicons name="car-outline" size={13} color={colors.accentLight} />
              <Text style={s.infoChipText}>{user.vehicle_type} {user.vehicle_number ? `(${user.vehicle_number})` : ""}</Text>
            </View>
          )}
        </View>

        {/* Capabilities */}
        {(user?.task_capabilities?.length > 0) && (
          <View style={s.capsRow}>
            {user.task_capabilities.map((cap: string) => {
              const capConfig: Record<string, { icon: keyof typeof Ionicons.glyphMap; color: string }> = {
                pickup: { icon: "car", color: "#3b82f6" },
                transport: { icon: "bus", color: colors.primary },
                delivery: { icon: "bicycle", color: colors.success },
              };
              const cfg = capConfig[cap] || { icon: "checkmark-circle" as const, color: colors.textMuted };
              return (
                <View key={cap} style={s.capChip}>
                  <Ionicons name={cfg.icon} size={13} color={cfg.color} />
                  <Text style={[s.capText, { color: cfg.color }]}>{cap}</Text>
                </View>
              );
            })}
          </View>
        )}
      </LinearGradient>

      <View style={s.body}>
        <Text style={s.sectionLabel}>ACCOUNT</Text>
        <View style={s.menuCard}>
          <MenuItem icon="person-outline" iconBg="#dbeafe" iconColor="#3b82f6" label="Edit Profile" sub="Update your personal details" onPress={() => router.push("/(driver)/profile/edit" as any)} />
          <MenuItem icon="lock-closed-outline" iconBg="#fef3c7" iconColor="#d97706" label="Change Password" sub="Update your login password" onPress={() => router.push("/(driver)/profile/change-password" as any)} />
          <MenuItem icon="notifications-outline" iconBg="#e0e7ff" iconColor="#6366f1" label="Notifications" sub="View your notifications" onPress={() => router.push("/(driver)/notifications" as any)} last />
        </View>

        <Text style={s.sectionLabel}>SUPPORT</Text>
        <View style={s.menuCard}>
          <MenuItem icon="help-circle-outline" iconBg="#dcfce7" iconColor={colors.success} label="Help & FAQ" sub="Get help with deliveries" onPress={() => {}} />
          <MenuItem icon="document-text-outline" iconBg="#e0e7ff" iconColor="#6366f1" label="Terms & Conditions" sub="Read our terms of service" onPress={() => router.push("/(driver)/legal/terms-of-service" as any)} />
          <MenuItem icon="shield-checkmark-outline" iconBg="#fce7f3" iconColor="#ec4899" label="Privacy Policy" sub="How we handle your data" onPress={() => router.push("/(driver)/legal/privacy-policy" as any)} last />
        </View>

        <Text style={s.sectionLabel}>APP</Text>
        <View style={s.menuCard}>
          <MenuItem icon="information-circle-outline" iconBg={colors.surface} iconColor={colors.textMuted} label="About Parcelman" sub="Version 1.0.0" onPress={() => {}} last />
        </View>

        <Text style={s.sectionLabel}>DANGER ZONE</Text>
        <View style={s.menuCard}>
          <TouchableOpacity style={s.logoutItem} onPress={() => setShowLogout(true)} activeOpacity={0.6}>
            <View style={[s.menuIconWrap, { backgroundColor: "#fee2e2" }]}>
              <Ionicons name="log-out-outline" size={20} color={colors.error} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[s.menuLabel, { color: colors.error }]}>Logout</Text>
              <Text style={s.menuSub}>Sign out of your account</Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color={colors.error} style={{ opacity: 0.4 }} />
          </TouchableOpacity>
        </View>
      </View>

      <ConfirmDialog visible={showLogout} type="warning" title="Logout" message="Are you sure you want to logout?" confirmText="Logout" onConfirm={handleLogout} onCancel={() => setShowLogout(false)} />
    </ScrollView>
  );
}

function MenuItem({ icon, iconBg, iconColor, label, sub, onPress, last }: {
  icon: keyof typeof Ionicons.glyphMap; iconBg: string; iconColor: string;
  label: string; sub: string; onPress: () => void; last?: boolean;
}) {
  return (
    <TouchableOpacity style={[s.menuItem, !last && s.menuItemBorder]} onPress={onPress} activeOpacity={0.6}>
      <View style={[s.menuIconWrap, { backgroundColor: iconBg }]}>
        <Ionicons name={icon} size={20} color={iconColor} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={s.menuLabel}>{label}</Text>
        <Text style={s.menuSub}>{sub}</Text>
      </View>
      <Ionicons name="chevron-forward" size={16} color={colors.neutral300} />
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  hero: { paddingHorizontal: 20, paddingTop: 24, paddingBottom: 28, alignItems: "center", gap: 8, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  heroDecor2: { position: "absolute", bottom: -60, left: -40, width: width * 0.4, height: width * 0.4, borderWidth: 40, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.2 },
  avatarWrap: { marginBottom: 4 },
  avatar: { width: 80, height: 80, borderRadius: 40, justifyContent: "center", alignItems: "center", borderWidth: 3, borderColor: "rgba(255,255,255,0.15)" },
  avatarImage: { width: 80, height: 80, borderRadius: 40, borderWidth: 3, borderColor: "rgba(255,255,255,0.2)", backgroundColor: "rgba(255,255,255,0.08)" },
  avatarText: { fontFamily: fontFamily.bold, fontSize: 28, color: colors.white },
  heroName: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white },
  infoChips: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 4, justifyContent: "center" },
  infoChip: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: "rgba(255,255,255,0.08)", paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: "rgba(255,255,255,0.06)" },
  infoChipText: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.7)" },
  capsRow: { flexDirection: "row", gap: 8, marginTop: 4, justifyContent: "center" },
  capChip: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: "rgba(255,255,255,0.08)", paddingHorizontal: 12, paddingVertical: 5, borderRadius: 16, borderWidth: 1, borderColor: "rgba(255,255,255,0.1)" },
  capText: { fontFamily: fontFamily.medium, fontSize: 11, textTransform: "capitalize" },
  body: { padding: 16, gap: 8 },
  sectionLabel: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.textMuted, letterSpacing: 0.8, marginTop: 12, marginBottom: 4, marginLeft: 4 },
  menuCard: { backgroundColor: colors.white, borderRadius: 16, overflow: "hidden" },
  menuItem: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14 },
  menuItemBorder: { borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  menuIconWrap: { width: 40, height: 40, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  menuLabel: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.dark },
  menuSub: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, marginTop: 1 },
  logoutItem: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14 },
});
