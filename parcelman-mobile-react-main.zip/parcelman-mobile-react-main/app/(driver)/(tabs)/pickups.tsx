import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity, Dimensions, TextInput } from "react-native";
import { useState, useCallback } from "react";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../../src/components/common/EmptyState";
import StatusBadge from "../../../src/components/common/StatusBadge";
import ShimmerLoading from "../../../src/components/common/ShimmerLoading";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { getPickups } from "../../../src/api/v1/driver/pickups";
import { showError, getErrorMessage } from "../../../src/utils/toast";
import { formatDateTimeAmPm } from "../../../src/utils/format";

const { width } = Dimensions.get("window");

const FILTERS = [
  { label: "All", value: "all" },
  { label: "Assigned", value: "assigned" },
  { label: "En Route", value: "en_route" },
  { label: "Arrived", value: "arrived_pickup" },
  { label: "Completed", value: "completed" },
];

export default function PickupsScreen() {
  const insets = useSafeAreaInsets();
  const [pickups, setPickups] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [counts, setCounts] = useState<Record<string, number>>({});

  const fetchPickups = useCallback(async () => {
    try {
      const params: any = { limit: 50 };
      if (filter !== "all") params["status[]"] = filter;
      if (search.trim()) params.search = search.trim();
      const res = await getPickups(params);
      const d = res.data as any;
      const items = d.pickups || d.items || [];
      setPickups(items);
      if (filter === "all") {
        const c: Record<string, number> = { all: d.pagination?.total ?? items.length };
        for (const p of items) c[p.status] = (c[p.status] || 0) + 1;
        setCounts(c);
      }
    } catch (err: any) { showError(getErrorMessage(err)); }
    finally { setLoading(false); setRefreshing(false); }
  }, [filter, search]);

  useFocusEffect(useCallback(() => { setLoading(true); fetchPickups(); }, [filter, search]));

  const openPickup = (pickupId: string | number) => {
    router.push({
      pathname: "/(driver)/pickup/[id]",
      params: { id: String(pickupId) },
    } as any);
  };

  const renderItem = ({ item }: { item: any }) => (
    <TouchableOpacity style={s.card} onPress={() => openPickup(item.id)} activeOpacity={0.7}>
      <View style={[s.cardAccent, { backgroundColor: item.status === "completed" ? colors.success : item.status === "assigned" ? "#3b82f6" : colors.primary }]} />
      <View style={s.cardBody}>
        <View style={s.cardTop}>
          <View style={[s.cardIcon, { backgroundColor: "#dbeafe" }]}>
            <Ionicons name="car" size={18} color="#3b82f6" />
          </View>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <Text style={s.cardTitle}>{item.shipment_number || item.shipment?.shipment_number || `Pickup #${item.id}`}</Text>
              {item.is_direct_delivery && (
                <View style={{ backgroundColor: "#fff7ed", paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 }}>
                  <Text style={{ fontFamily: fontFamily.semibold, fontSize: 9, color: colors.primary }}>Direct</Text>
                </View>
              )}
            </View>
            <View style={s.cardMeta}>
              <Ionicons name="person-outline" size={14} color={colors.textMuted} />
              <Text style={[s.cardMetaText, s.cardMetaStrong]} numberOfLines={2}>{item.shipment?.pickup?.contact_name || "—"}</Text>
            </View>
            <View style={s.cardMeta}>
              <Ionicons name="cube-outline" size={14} color={colors.textMuted} />
              <Text style={s.cardMetaText}>{item.shipment?.items?.length || 0} {(item.shipment?.items?.length || 0) === 1 ? 'package' : 'packages'}</Text>
            </View>
            <View style={s.cardMeta}>
              <Ionicons name="calendar-outline" size={14} color={colors.textMuted} />
              <Text style={s.cardMetaText}>{formatDateTimeAmPm(item.created_at)}</Text>
            </View>
          </View>
        </View>
        <View style={s.cardBottom}>
          <StatusBadge status={item.status} />
          <TouchableOpacity style={s.viewBtn} onPress={() => openPickup(item.id)}>
            <Text style={s.viewBtnText}>View Details</Text>
            <Ionicons name="arrow-forward" size={14} color={colors.primary} />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={s.container}>
      <LinearGradient colors={["#1e293b", "#334155", "#1e293b"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
        <View style={s.heroDecor1} />
        <View style={s.headerRow}>
          <View style={s.headerIconWrap}><Ionicons name="car" size={22} color={colors.white} /></View>
          <View style={{ flex: 1 }}>
            <Text style={s.headerTitle}>Pickups</Text>
            <Text style={s.headerSub}>Manage your pickup assignments</Text>
          </View>
        </View>
        <View style={s.filterWrap}>
          {FILTERS.map((f) => {
            const isActive = f.value === filter;
            const count = f.value === "all" ? (counts.all || pickups.length) : (counts[f.value] || 0);
            return (
              <TouchableOpacity key={f.value} style={[s.filterChip, isActive && s.filterChipActive]} onPress={() => setFilter(f.value)}>
                <Text style={[s.filterText, isActive && s.filterTextActive]}>{f.label}</Text>
                <View style={[s.filterCount, isActive && s.filterCountActive]}>
                  <Text style={[s.filterCountText, isActive && s.filterCountTextActive]}>{count}</Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
        <View style={s.searchRow}>
          <Ionicons name="search-outline" size={16} color="rgba(255,255,255,0.4)" />
          <TextInput style={s.searchInput} value={search} onChangeText={setSearch} placeholder="Search pickups..." placeholderTextColor="rgba(255,255,255,0.3)" returnKeyType="search" />
          {search.length > 0 && <TouchableOpacity onPress={() => setSearch("")}><Ionicons name="close-circle" size={16} color="rgba(255,255,255,0.4)" /></TouchableOpacity>}
        </View>
      </LinearGradient>

      <View style={s.body}>
        {loading && pickups.length === 0 ? (
          <PickupListSkeleton />
        ) : (
          <FlatList
            data={pickups}
            keyExtractor={(item) => String(item.id)}
            renderItem={renderItem}
            contentContainerStyle={s.list}
            ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchPickups(); }} colors={[colors.primary]} />}
            ListEmptyComponent={<EmptyState icon="car-outline" title="No pickups" subtitle="Pickup assignments will appear here" illustration="deliveryTruck" />}
          />
        )}
      </View>
    </View>
  );
}

function PickupListSkeleton() {
  return (
    <View style={s.list}>
      {Array.from({ length: 4 }).map((_, index) => (
        <View key={index} style={s.card}>
          <View style={[s.cardAccent, { backgroundColor: colors.neutral200 }]} />
          <View style={s.cardBody}>
            <View style={s.cardTop}>
              <ShimmerLoading width={44} height={44} borderRadius={12} />
              <View style={s.skeletonCardContent}>
                <View style={s.skeletonTitleRow}>
                  <ShimmerLoading width="54%" height={16} borderRadius={7} />
                  <ShimmerLoading width={46} height={18} borderRadius={6} />
                </View>
                <View style={s.cardMeta}>
                  <ShimmerLoading width={14} height={14} borderRadius={7} />
                  <ShimmerLoading width="50%" height={14} borderRadius={6} />
                </View>
                <View style={s.cardMeta}>
                  <ShimmerLoading width={14} height={14} borderRadius={7} />
                  <ShimmerLoading width={76} height={14} borderRadius={6} />
                </View>
                <View style={s.cardMeta}>
                  <ShimmerLoading width={14} height={14} borderRadius={7} />
                  <ShimmerLoading width="52%" height={14} borderRadius={6} />
                </View>
              </View>
            </View>
            <View style={s.cardBottom}>
              <ShimmerLoading width={92} height={28} borderRadius={14} />
              <ShimmerLoading width={112} height={32} borderRadius={8} />
            </View>
          </View>
        </View>
      ))}
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 16, gap: 12, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  headerIconWrap: { width: 44, height: 44, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  filterWrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  filterChip: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "rgba(255,255,255,0.06)", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 7, borderWidth: 1, borderColor: "rgba(255,255,255,0.08)" },
  filterChipActive: { backgroundColor: "rgba(255,255,255,0.15)", borderColor: "rgba(255,255,255,0.25)" },
  filterText: { fontFamily: fontFamily.medium, fontSize: 12, color: "rgba(255,255,255,0.5)" },
  filterTextActive: { color: colors.white },
  filterCount: { backgroundColor: "rgba(255,255,255,0.1)", borderRadius: 10, minWidth: 22, height: 20, justifyContent: "center", alignItems: "center", paddingHorizontal: 5 },
  filterCountActive: { backgroundColor: "rgba(255,255,255,0.2)" },
  filterCountText: { fontFamily: fontFamily.semibold, fontSize: 10, color: "rgba(255,255,255,0.5)" },
  filterCountTextActive: { color: colors.white },
  searchRow: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "rgba(255,255,255,0.1)", borderTopLeftRadius: 4, borderTopRightRadius: 4, borderBottomWidth: 2, borderBottomColor: colors.primary, paddingHorizontal: 12, height: 42 },
  searchInput: { flex: 1, fontFamily: fontFamily.regular, fontSize: fontSize.bodyMd, color: colors.white, paddingVertical: 0 },
  body: { flex: 1, paddingTop: 14 },
  list: { flexGrow: 1, paddingHorizontal: 16, paddingBottom: 30 },
  card: { flexDirection: "row", backgroundColor: colors.white, borderRadius: 14, overflow: "hidden" },
  cardAccent: { width: 4 },
  cardBody: { flex: 1, padding: 14, gap: 10 },
  cardTop: { flexDirection: "row", gap: 12 },
  cardIcon: { width: 44, height: 44, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark },
  cardMeta: { flexDirection: "row", alignItems: "flex-start", gap: 6, marginTop: 5 },
  cardMetaText: { flex: 1, minWidth: 0, fontFamily: fontFamily.medium, fontSize: 13, lineHeight: 18, color: colors.textMuted },
  cardMetaStrong: { fontFamily: fontFamily.semibold, color: colors.text },
  cardBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderTopWidth: 1, borderTopColor: colors.neutral100, paddingTop: 10 },
  viewBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  viewBtnText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.primary },
  skeletonCardContent: { flex: 1, gap: 6 },
  skeletonTitleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
});
