import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity, Dimensions, TextInput } from "react-native";
import { useState, useCallback } from "react";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../../src/components/common/EmptyState";
import StatusBadge from "../../../src/components/common/StatusBadge";
import ShimmerLoading from "../../../src/components/common/ShimmerLoading";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { getTransports } from "../../../src/api/v1/driver/transports";
import { showError, getErrorMessage } from "../../../src/utils/toast";
import { formatDateTimeAmPm } from "../../../src/utils/format";

const { width } = Dimensions.get("window");
const FILTERS = [
  { label: "All", value: "all" },
  { label: "Assigned", value: "assigned" },
  { label: "Loading", value: "loading" },
  { label: "In Transit", value: "in_transit" },
  { label: "Arrived", value: "arrived" },
];

export default function TransportsScreen() {
  const insets = useSafeAreaInsets();
  const [transports, setTransports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [counts, setCounts] = useState<Record<string, number>>({});

  const fetchTransports = useCallback(async () => {
    try {
      const params: any = { limit: 50 };
      if (filter !== "all") params["status[]"] = filter;
      if (search.trim()) params.search = search.trim();
      const res = await getTransports(params);
      const d = res.data as any;
      const items = d.transports || d.items || [];
      setTransports(items);
      if (filter === "all") {
        const c: Record<string, number> = { all: d.pagination?.total ?? items.length };
        for (const t of items) c[t.status] = (c[t.status] || 0) + 1;
        setCounts(c);
      }
    } catch (err: any) { showError(getErrorMessage(err)); }
    finally { setLoading(false); setRefreshing(false); }
  }, [filter, search]);

  useFocusEffect(useCallback(() => { setLoading(true); fetchTransports(); }, [filter, search]));
  const isInitialLoading = loading && transports.length === 0;

  const openTransport = (transportId: string | number) => {
    router.push({
      pathname: "/(driver)/transport/[id]",
      params: { id: String(transportId) },
    } as any);
  };

  const renderItem = ({ item }: { item: any }) => (
    <TouchableOpacity style={s.card} onPress={() => openTransport(item.id)} activeOpacity={0.7}>
      <View style={[s.cardAccent, { backgroundColor: item.status === "in_transit" ? colors.primary : item.status === "arrived" ? colors.success : "#3b82f6" }]} />
      <View style={s.cardBody}>
        <View style={s.cardTop}>
          <View style={[s.cardIcon, { backgroundColor: "#ffedd5" }]}>
            <Ionicons name="bus" size={18} color={colors.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.cardTitle}>{item.manifest_number || `Transport #${item.id}`}</Text>
            <View style={s.cardMeta}>
              <Ionicons name="arrow-forward-circle-outline" size={12} color={colors.textMuted} />
              <Text style={s.cardMetaText}>{item.origin_warehouse?.name || "Origin"} → {item.destination_warehouse?.name || "Destination"}</Text>
            </View>
            <View style={s.cardMeta}>
              <Ionicons name="cube-outline" size={12} color={colors.textMuted} />
              <Text style={s.cardMetaText}>{item.items?.length || 0} items</Text>
              <Ionicons name="calendar-outline" size={12} color={colors.textMuted} />
              <Text style={s.cardMetaText}>{formatDateTimeAmPm(item.created_at)}</Text>
            </View>
          </View>
        </View>
        <View style={s.cardBottom}>
          <StatusBadge status={item.status} />
          <TouchableOpacity style={s.viewBtn} onPress={() => openTransport(item.id)}>
            <Text style={s.viewBtnText}>View Details</Text>
            <Ionicons name="arrow-forward" size={14} color={colors.primary} />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={s.container}>
      <LinearGradient colors={["#1e293b", "#334155", "#1e293b"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
        <View style={s.heroDecor1} />
        {isInitialLoading ? (
          <HeaderSkeleton />
        ) : (
          <>
            <View style={s.headerRow}>
              <View style={s.headerIconWrap}><Ionicons name="bus" size={22} color={colors.white} /></View>
              <View style={{ flex: 1 }}>
                <Text style={s.headerTitle}>Transports</Text>
                <Text style={s.headerSub}>Manage transport manifests</Text>
              </View>
            </View>
            <View style={s.filterWrap}>
              {FILTERS.map((f) => {
                const isActive = f.value === filter;
                const count = f.value === "all" ? (counts.all || transports.length) : (counts[f.value] || 0);
                return (
                  <TouchableOpacity key={f.value} style={[s.filterChip, isActive && s.filterChipActive]} onPress={() => setFilter(f.value)}>
                    <Text style={[s.filterText, isActive && s.filterTextActive]}>{f.label}</Text>
                    <View style={[s.filterCount, isActive && s.filterCountActive]}>
                      <Text style={[s.filterCountText, isActive && s.filterCountTextActive]}>{count}</Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
            <View style={s.searchRow}>
              <Ionicons name="search-outline" size={16} color="rgba(255,255,255,0.4)" />
              <TextInput style={s.searchInput} value={search} onChangeText={setSearch} placeholder="Search transports..." placeholderTextColor="rgba(255,255,255,0.3)" returnKeyType="search" />
              {search.length > 0 && <TouchableOpacity onPress={() => setSearch("")}><Ionicons name="close-circle" size={16} color="rgba(255,255,255,0.4)" /></TouchableOpacity>}
            </View>
          </>
        )}
      </LinearGradient>

      <View style={s.body}>
        {isInitialLoading ? (
          <TransportListSkeleton />
        ) : (
          <FlatList data={transports} keyExtractor={(item) => String(item.id)} renderItem={renderItem} contentContainerStyle={s.list} ItemSeparatorComponent={() => <View style={{ height: 12 }} />} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchTransports(); }} colors={[colors.primary]} />} ListEmptyComponent={<EmptyState icon="bus-outline" title="No transports" subtitle="Transport manifests will appear here" illustration="logistics" />} />
        )}
      </View>
    </View>
  );
}

function HeaderSkeleton() {
  const darkSkeleton = { backgroundColor: "rgba(255,255,255,0.2)" };

  return (
    <>
      <View style={s.headerRow}>
        <ShimmerLoading width={44} height={44} borderRadius={14} style={darkSkeleton} />
        <View style={{ flex: 1, gap: 8 }}>
          <ShimmerLoading width="44%" height={22} borderRadius={8} style={darkSkeleton} />
          <ShimmerLoading width="62%" height={12} borderRadius={6} style={darkSkeleton} />
        </View>
      </View>
      <View style={s.filterWrap}>
        {[76, 96, 90, 104, 84].map((item, index) => (
          <ShimmerLoading key={index} width={item} height={34} borderRadius={17} style={darkSkeleton} />
        ))}
      </View>
      <View style={s.searchRow}>
        <ShimmerLoading width={16} height={16} borderRadius={8} style={darkSkeleton} />
        <ShimmerLoading width="52%" height={14} borderRadius={7} style={darkSkeleton} />
      </View>
    </>
  );
}

function TransportListSkeleton() {
  return (
    <View style={s.list}>
      {Array.from({ length: 4 }).map((_, index) => (
        <View key={index} style={s.card}>
          <View style={[s.cardAccent, { backgroundColor: colors.neutral200 }]} />
          <View style={s.cardBody}>
            <View style={s.cardTop}>
              <ShimmerLoading width={44} height={44} borderRadius={12} />
              <View style={s.skeletonCardContent}>
                <ShimmerLoading width="50%" height={15} borderRadius={7} />
                <View style={s.cardMeta}>
                  <ShimmerLoading width={12} height={12} borderRadius={6} />
                  <ShimmerLoading width="76%" height={11} borderRadius={5} />
                </View>
                <View style={s.cardMeta}>
                  <ShimmerLoading width={12} height={12} borderRadius={6} />
                  <ShimmerLoading width={52} height={11} borderRadius={5} />
                  <ShimmerLoading width={12} height={12} borderRadius={6} />
                  <ShimmerLoading width={94} height={11} borderRadius={5} />
                </View>
              </View>
            </View>
            <View style={s.cardBottom}>
              <ShimmerLoading width={92} height={28} borderRadius={14} />
              <ShimmerLoading width={112} height={32} borderRadius={8} />
            </View>
          </View>
        </View>
      ))}
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 16, gap: 12, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  headerIconWrap: { width: 44, height: 44, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  filterWrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  filterChip: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "rgba(255,255,255,0.06)", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 7, borderWidth: 1, borderColor: "rgba(255,255,255,0.08)" },
  filterChipActive: { backgroundColor: "rgba(255,255,255,0.15)", borderColor: "rgba(255,255,255,0.25)" },
  filterText: { fontFamily: fontFamily.medium, fontSize: 12, color: "rgba(255,255,255,0.5)" },
  filterTextActive: { color: colors.white },
  filterCount: { backgroundColor: "rgba(255,255,255,0.1)", borderRadius: 10, minWidth: 22, height: 20, justifyContent: "center", alignItems: "center", paddingHorizontal: 5 },
  filterCountActive: { backgroundColor: "rgba(255,255,255,0.2)" },
  filterCountText: { fontFamily: fontFamily.semibold, fontSize: 10, color: "rgba(255,255,255,0.5)" },
  filterCountTextActive: { color: colors.white },
  searchRow: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "rgba(255,255,255,0.1)", borderTopLeftRadius: 4, borderTopRightRadius: 4, borderBottomWidth: 2, borderBottomColor: colors.primary, paddingHorizontal: 12, height: 42 },
  searchInput: { flex: 1, fontFamily: fontFamily.regular, fontSize: fontSize.bodyMd, color: colors.white, paddingVertical: 0 },
  body: { flex: 1, paddingTop: 14 },
  list: { flexGrow: 1, paddingHorizontal: 16, paddingBottom: 30 },
  card: { flexDirection: "row", backgroundColor: colors.white, borderRadius: 14, overflow: "hidden" },
  cardAccent: { width: 4 },
  cardBody: { flex: 1, padding: 14, gap: 10 },
  cardTop: { flexDirection: "row", gap: 12 },
  cardIcon: { width: 44, height: 44, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark },
  cardMeta: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 3 },
  cardMetaText: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, marginRight: 8 },
  cardBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderTopWidth: 1, borderTopColor: colors.neutral100, paddingTop: 10 },
  viewBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  viewBtnText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.primary },
  skeletonCardContent: { flex: 1, gap: 6 },
});
