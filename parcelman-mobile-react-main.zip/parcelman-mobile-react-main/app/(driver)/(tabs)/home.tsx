import { useState, useCallback } from "react";
import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity, Dimensions, Image } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../../src/components/common/EmptyState";
import ShimmerLoading from "../../../src/components/common/ShimmerLoading";
import StatusBadge from "../../../src/components/common/StatusBadge";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { getPickups } from "../../../src/api/v1/driver/pickups";
import { getTransports } from "../../../src/api/v1/driver/transports";
import { getDeliveryRuns } from "../../../src/api/v1/driver/deliveries";
import { getMyPackages } from "../../../src/api/v1/driver/custody";
import { getDriverNotifications as getNotifications } from "../../../src/api/v1/driver/notifications";
import { getRiderTeamHandovers, getRiderTeams } from "../../../src/api/v1/driver/rider-teams";
import { showError, getErrorMessage } from "../../../src/utils/toast";
import { useAuthStore } from "../../../src/stores/auth.store";
import { formatDateTimeAmPm } from "../../../src/utils/format";

const { width, height } = Dimensions.get("window");
const summaryCardSize = (width - 56) / 3;

type RecentWorkItem = {
  key: string;
  title: string;
  meta: string;
  time?: string;
  status: string;
  route: { pathname: string; params?: Record<string, string> };
  icon: keyof typeof Ionicons.glyphMap;
  iconColor: string;
  iconBg: string;
  accentColor: string;
};

function responseItems(response: any, key: string): any[] {
  const data = (response?.data as any) || {};
  return data[key] || data.items || data.data || [];
}

function buildRecentWork({
  activeDeliveries,
  partialDeliveries,
  assignedDeliveries,
  pickups,
  transports,
}: {
  activeDeliveries: any[];
  partialDeliveries: any[];
  assignedDeliveries: any[];
  pickups: any[];
  transports: any[];
}): RecentWorkItem[] {
  const seen = new Set<string>();
  const items: RecentWorkItem[] = [];

  const add = (item: RecentWorkItem) => {
    if (seen.has(item.key)) return;
    seen.add(item.key);
    items.push(item);
  };

  [...activeDeliveries, ...partialDeliveries, ...assignedDeliveries].forEach((delivery) => {
    const stops = delivery.stops || [];
    const delivered = stops.filter((stop: any) => stop.status === "delivered").length;
    add({
      key: `delivery-${delivery.id}`,
      title: delivery.run_number || `Delivery Run #${delivery.id}`,
      meta: `${stops.length || 0} stops${delivered > 0 ? ` · ${delivered} delivered` : ""}`,
      time: delivery.created_at ? formatDateTimeAmPm(delivery.created_at) : undefined,
      status: delivery.status || "assigned",
      route: {
        pathname: "/(driver)/delivery/[id]",
        params: { id: String(delivery.id) },
      },
      icon: "bicycle",
      iconColor: colors.success,
      iconBg: "#dcfce7",
      accentColor: delivery.status === "partially_delivered" ? colors.primary : colors.success,
    });
  });

  pickups.forEach((pickup) => {
    const packageCount = pickup.shipment?.items?.length || 0;
    const contact = pickup.shipment?.pickup?.contact_name || pickup.vendor_name || "Pickup contact";
    add({
      key: `pickup-${pickup.id}`,
      title: pickup.shipment_number || pickup.shipment?.shipment_number || `Pickup #${pickup.id}`,
      meta: `${contact}${packageCount ? ` · ${packageCount} ${packageCount === 1 ? "package" : "packages"}` : ""}`,
      time: pickup.created_at ? formatDateTimeAmPm(pickup.created_at) : undefined,
      status: pickup.status || "assigned",
      route: {
        pathname: "/(driver)/pickup/[id]",
        params: { id: String(pickup.id) },
      },
      icon: "car",
      iconColor: "#b45309",
      iconBg: "#fef3c7",
      accentColor: "#d97706",
    });
  });

  transports.forEach((transport) => {
    add({
      key: `transport-${transport.id}`,
      title: transport.manifest_number || `Transport #${transport.id}`,
      meta: `${transport.origin_warehouse?.name || "Origin"} → ${transport.destination_warehouse?.name || "Destination"}`,
      time: transport.created_at ? formatDateTimeAmPm(transport.created_at) : undefined,
      status: transport.status || "assigned",
      route: {
        pathname: "/(driver)/transport/[id]",
        params: { id: String(transport.id) },
      },
      icon: "bus",
      iconColor: "#6d28d9",
      iconBg: "#f3e8ff",
      accentColor: "#8b5cf6",
    });
  });

  return items.slice(0, 5);
}

export default function DriverHomeScreen() {
  const insets = useSafeAreaInsets();
  const user = useAuthStore((state) => state.user);
  const emptyRecentHeight = Math.max(440, height * 0.52);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({
    pickupsTotal: 0, pickupsPending: 0,
    deliveriesTotal: 0, deliveriesNotCompleted: 0,
    riderTeamsTotal: 0, riderTeamHandoversPending: 0,
    packagesScanned: 0,
    unreadAlerts: 0,
  });
  const [recentWork, setRecentWork] = useState<RecentWorkItem[]>([]);

  const fetchData = async () => {
    try {
      const [allPickups, pendPickups, pendTransports, allDeliveries, assignedDeliveries, activeDeliveries, partialDeliveries, riderTeamsRes, riderTeamHandoversRes, packagesRes, notifsRes] = await Promise.all([
        getPickups({ limit: 1 } as any).catch(() => null),
        getPickups({ limit: 5, "status[]": "assigned" } as any).catch(() => null),
        getTransports({ limit: 5, "status[]": "assigned" } as any).catch(() => null),
        getDeliveryRuns({ limit: 1 } as any).catch(() => null),
        getDeliveryRuns({ limit: 5, "status[]": "assigned" } as any).catch(() => null),
        getDeliveryRuns({ limit: 5, "status[]": "out_for_delivery" } as any).catch(() => null),
        getDeliveryRuns({ limit: 5, "status[]": "partially_delivered" } as any).catch(() => null),
        getRiderTeams().catch(() => null),
        getRiderTeamHandovers({ limit: 30 }).catch(() => null),
        getMyPackages({ from_date: new Date().toISOString().split("T")[0], to_date: new Date().toISOString().split("T")[0], limit: 1 }).catch(() => null),
        getNotifications({ limit: 1, is_read: false } as any).catch(() => null),
      ]);

      const pickupsTotal = (allPickups?.data as any)?.pagination?.total ?? 0;
      const pickupsPending = (pendPickups?.data as any)?.pagination?.total ?? 0;
      const deliveriesTotal = (allDeliveries?.data as any)?.pagination?.total ?? 0;
      const deliveriesAssigned = (assignedDeliveries?.data as any)?.pagination?.total ?? 0;
      const deliveriesOutForDelivery = (activeDeliveries?.data as any)?.pagination?.total ?? 0;
      const deliveriesPartial = (partialDeliveries?.data as any)?.pagination?.total ?? 0;
      const deliveriesNotCompleted = deliveriesAssigned + deliveriesOutForDelivery + deliveriesPartial;
      const riderTeamsTotal = ((riderTeamsRes?.data as any)?.teams || []).length;
      const riderTeamHandoversPending = ((riderTeamHandoversRes?.data as any)?.handovers || []).filter((handover: any) => !["closed", "completed", "cancelled"].includes(String(handover.status || "").toLowerCase())).length;
      const packagesScanned = (packagesRes?.data as any)?.total ?? 0;
      const unread = (notifsRes?.data as any)?.unread_count ?? (notifsRes?.data as any)?.pagination?.total ?? 0;

      setStats({
        pickupsTotal, pickupsPending,
        deliveriesTotal, deliveriesNotCompleted,
        riderTeamsTotal, riderTeamHandoversPending,
        packagesScanned,
        unreadAlerts: unread,
      });
      setRecentWork(buildRecentWork({
        activeDeliveries: responseItems(activeDeliveries, "deliveries"),
        partialDeliveries: responseItems(partialDeliveries, "deliveries"),
        assignedDeliveries: responseItems(assignedDeliveries, "deliveries"),
        pickups: responseItems(pendPickups, "pickups"),
        transports: responseItems(pendTransports, "transports"),
      }));
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(useCallback(() => { fetchData(); }, []));
  const firstName = (user?.name || "").trim().split(/\s+/)[0] || "Rider";

  return (
    <View style={s.container}>
      <LinearGradient
        colors={["#1e293b", "#334155", "#1e293b"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[s.hero, { paddingTop: insets.top + 16 }]}
      >
        <View style={s.heroDecor1} />
        <View style={s.heroDecor2} />

        <View style={s.heroTop}>
          <View style={s.heroLogoWrap}>
            <Image source={require("../../../assets/images/logo.png")} style={s.heroLogo} resizeMode="contain" />
          </View>
          <View style={s.heroGreeting}>
            <Text style={s.heroWelcome}>
              Hi, <Text style={s.heroName}>{firstName}</Text>
            </Text>
            <Text style={s.heroBusiness} numberOfLines={1}>Ready for today's runs</Text>
          </View>
          <View style={{ flex: 1 }} />
          <TouchableOpacity style={s.headerIconBtn} onPress={() => router.push("/(driver)/notifications" as any)}>
            <Ionicons name="notifications-outline" size={20} color={colors.white} />
            {stats.unreadAlerts > 0 && (
              <View style={s.bellBadge}>
                <Text style={s.bellBadgeText}>{stats.unreadAlerts > 99 ? "99+" : stats.unreadAlerts}</Text>
              </View>
            )}
          </TouchableOpacity>
          <TouchableOpacity style={s.headerIconBtn} onPress={() => router.push("/(driver)/(tabs)/account" as any)}>
            <Ionicons name="person-outline" size={20} color={colors.white} />
          </TouchableOpacity>
        </View>

        <View style={s.summaryGrid}>
          <TouchableOpacity style={s.summaryCard} onPress={() => router.push("/(driver)/(tabs)/pickups" as any)} activeOpacity={0.78}>
            {loading ? (
              <SummaryCardSkeleton />
            ) : (
              <>
                <View style={[s.summaryIcon, { backgroundColor: "rgba(251,191,36,0.18)" }]}>
                  <Ionicons name="car" size={18} color="#fbbf24" />
                </View>
                <Text style={s.summaryHeadline}>
                  <Text style={s.summaryValue}>{stats.pickupsTotal}</Text> Pickups
                </Text>
                <Text style={s.summarySub} numberOfLines={1}>{stats.pickupsPending} pending</Text>
              </>
            )}
          </TouchableOpacity>

          <TouchableOpacity style={s.summaryCard} onPress={() => router.push({ pathname: "/(driver)/packages" } as any)} activeOpacity={0.78}>
            {loading ? (
              <SummaryCardSkeleton />
            ) : (
              <>
                <View style={[s.summaryIcon, { backgroundColor: "rgba(96,165,250,0.18)" }]}>
                  <Ionicons name="cube" size={18} color="#93c5fd" />
                </View>
                <Text style={s.summaryHeadline}>
                  <Text style={s.summaryValue}>{stats.packagesScanned}</Text> Packages
                </Text>
                <Text style={s.summarySub} numberOfLines={1}>in your custody</Text>
              </>
            )}
          </TouchableOpacity>

          <TouchableOpacity style={s.summaryCard} onPress={() => router.push("/(driver)/(tabs)/deliveries" as any)} activeOpacity={0.78}>
            {loading ? (
              <SummaryCardSkeleton />
            ) : (
              <>
                <View style={[s.summaryIcon, { backgroundColor: "rgba(34,197,94,0.18)" }]}>
                  <Ionicons name="navigate" size={18} color="#86efac" />
                </View>
                <Text style={s.summaryHeadline}>
                  <Text style={s.summaryValue}>{stats.deliveriesTotal}</Text> Deliveries
                </Text>
                <Text style={s.summarySub} numberOfLines={1}>{stats.deliveriesNotCompleted} not completed</Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <View style={s.body}>
        <ScrollView
          horizontal
          style={s.actionDockScroll}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={s.actionDock}
        >
          <HomeActionCard
            title="Scan"
            icon="scan"
            iconColor={colors.white}
            iconBg={colors.dark}
            primary
            onPress={() => router.push("/(driver)/(tabs)/scan" as any)}
          />
          <HomeActionCard
            title="Packages"
            icon="cube"
            iconColor="#1d4ed8"
            iconBg="#bfdbfe"
            onPress={() => router.push({ pathname: "/(driver)/packages" } as any)}
          />
          <HomeActionCard
            title="Transfers"
            icon="swap-horizontal"
            iconColor="#0f766e"
            iconBg="#ccfbf1"
            onPress={() => router.push("/(driver)/package-transfers" as any)}
          />
          {(stats.riderTeamsTotal > 0 || stats.riderTeamHandoversPending > 0) && (
            <HomeActionCard
              title="Teams"
              icon="people"
              iconColor="#be123c"
              iconBg="#ffe4e6"
              onPress={() => router.push("/(driver)/teams" as any)}
            />
          )}
          <HomeActionCard
            title="Deliveries"
            icon="navigate"
            iconColor="#047857"
            iconBg="#bbf7d0"
            onPress={() => router.push("/(driver)/(tabs)/deliveries" as any)}
          />
          <HomeActionCard
            title="Pickups"
            icon="car"
            iconColor="#b45309"
            iconBg="#fde68a"
            onPress={() => router.push("/(driver)/(tabs)/pickups" as any)}
          />
          <HomeActionCard
            title="Bus"
            icon="chatbubbles"
            iconColor="#7c3aed"
            iconBg="#ede9fe"
            onPress={() => router.push("/(driver)/bus-handoffs" as any)}
          />
          <HomeActionCard
            title="Transports"
            icon="bus"
            iconColor="#6d28d9"
            iconBg="#e9d5ff"
            onPress={() => router.push("/(driver)/(tabs)/transports" as any)}
          />
        </ScrollView>

        <ScrollView
          style={s.recentScroll}
          contentContainerStyle={s.recentScrollContent}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} colors={[colors.primary]} />}
          showsVerticalScrollIndicator={false}
        >
          {loading ? (
            <RecentWorkSkeleton />
          ) : (
            <View style={[s.recentSection, recentWork.length === 0 && s.recentSectionEmpty]}>
              <View style={s.recentHeaderRow}>
                <View style={s.recentHeaderIcon}>
                  <Ionicons name="time-outline" size={18} color={colors.dark} />
                </View>
                <Text style={s.recentHeaderTitle}>Recent Work</Text>
              </View>

              {recentWork.length > 0 ? (
                <View style={s.recentList}>
                  {recentWork.map((item) => (
                    <TouchableOpacity
                      key={item.key}
                      style={[s.recentCard, { borderLeftColor: item.accentColor }]}
                      onPress={() => router.push(item.route as any)}
                      activeOpacity={0.72}
                    >
                      <View style={s.recentCardTop}>
                        <View style={[s.recentIcon, { backgroundColor: item.iconBg }]}>
                          <Ionicons name={item.icon} size={17} color={item.iconColor} />
                        </View>
                        <View style={{ flex: 1, minWidth: 0 }}>
                          <Text style={s.recentTitle} numberOfLines={1}>{item.title}</Text>
                          <View style={s.recentMeta}>
                            <Ionicons name="information-circle-outline" size={12} color={colors.textMuted} />
                            <Text style={s.recentMetaText} numberOfLines={1}>{item.meta}</Text>
                          </View>
                          {item.time ? (
                            <View style={s.recentMeta}>
                              <Ionicons name="calendar-outline" size={12} color={colors.textMuted} />
                              <Text style={s.recentMetaText} numberOfLines={1}>{item.time}</Text>
                            </View>
                          ) : null}
                        </View>
                      </View>
                      <View style={s.recentCardBottom}>
                        <StatusBadge status={item.status} />
                        <TouchableOpacity style={s.recentViewBtn} onPress={() => router.push(item.route as any)}>
                          <Text style={s.recentViewText}>View</Text>
                          <Ionicons name="arrow-forward" size={14} color={colors.primary} />
                        </TouchableOpacity>
                      </View>
                    </TouchableOpacity>
                  ))}
                </View>
              ) : (
                <EmptyState
                  icon="checkmark-circle-outline"
                  title="No active work right now"
                  subtitle="New pickups, deliveries, transports, and team work will appear here."
                  illustration="onTheWay"
                  minHeight={emptyRecentHeight}
                />
              )}
            </View>
          )}
        </ScrollView>
      </View>
    </View>
  );
}

function HomeActionCard({
  title,
  icon,
  iconColor,
  iconBg,
  primary = false,
  onPress,
}: {
  title: string;
  icon: keyof typeof Ionicons.glyphMap;
  iconColor: string;
  iconBg: string;
  primary?: boolean;
  onPress: () => void;
}) {
  return (
    <TouchableOpacity style={s.dockAction} onPress={onPress} activeOpacity={0.72}>
      <View style={[s.dockIcon, primary && s.dockIconPrimary, { backgroundColor: iconBg }]}>
        <Ionicons name={icon} size={19} color={iconColor} />
      </View>
      <Text style={[s.dockTitle, primary && s.dockTitlePrimary]} numberOfLines={1}>{title}</Text>
    </TouchableOpacity>
  );
}

function SummaryCardSkeleton() {
  const darkSkeleton = { backgroundColor: "rgba(255,255,255,0.2)" };

  return (
    <>
      <ShimmerLoading width={30} height={30} borderRadius={10} style={darkSkeleton} />
      <ShimmerLoading width="70%" height={18} borderRadius={7} style={darkSkeleton} />
      <ShimmerLoading width="58%" height={9} borderRadius={5} style={darkSkeleton} />
    </>
  );
}

function RecentWorkSkeleton() {
  return (
    <View style={s.recentSection}>
      <View style={s.recentHeaderRow}>
        <ShimmerLoading width={38} height={38} borderRadius={12} />
        <ShimmerLoading width={124} height={18} borderRadius={8} />
      </View>

      <View style={s.recentList}>
        {Array.from({ length: 3 }).map((_, index) => (
          <View key={index} style={[s.recentCard, { borderLeftColor: colors.neutral200 }]}>
            <View style={s.recentCardTop}>
              <ShimmerLoading width={42} height={42} borderRadius={12} />
              <View style={{ flex: 1, gap: 7 }}>
                <ShimmerLoading width="58%" height={15} borderRadius={7} />
                <ShimmerLoading width="76%" height={11} borderRadius={5} />
                <ShimmerLoading width="48%" height={11} borderRadius={5} />
              </View>
            </View>
            <View style={s.recentCardBottom}>
              <ShimmerLoading width={96} height={28} borderRadius={14} />
              <ShimmerLoading width={70} height={30} borderRadius={8} />
            </View>
          </View>
        ))}
      </View>
    </View>
  );
}


const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  // Hero
  hero: { paddingHorizontal: 20, paddingBottom: 24, gap: 14, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.6, height: width * 0.6, borderWidth: 60, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.3, transform: [{ rotate: "20deg" }] },
  heroDecor2: { position: "absolute", bottom: -80, left: -40, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.25, transform: [{ rotate: "-15deg" }] },
  heroTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  heroLogoWrap: {
    width: 58,
    height: 58,
    borderRadius: 14,
    backgroundColor: colors.white,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: colors.black,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 14,
    elevation: 8,
  },
  heroLogo: { width: 48, height: 48 },
  heroGreeting: { minWidth: 0, gap: 2 },
  heroWelcome: { fontFamily: fontFamily.bold, fontSize: 20, color: colors.white },
  heroName: { color: colors.primaryLight },
  heroBusiness: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.6)" },
  headerIconBtn: { position: "relative", width: 42, height: 42, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  bellBadge: { position: "absolute", top: -3, right: -3, width: 22, height: 22, borderRadius: 11, backgroundColor: colors.error, justifyContent: "center", alignItems: "center" },
  bellBadgeText: { fontFamily: fontFamily.bold, fontSize: 9, lineHeight: 11, color: colors.white, textAlign: "center", includeFontPadding: false },
  summaryGrid: { flexDirection: "row", gap: 8 },
  summaryCard: { width: summaryCardSize, height: summaryCardSize, backgroundColor: "rgba(255,255,255,0.07)", borderRadius: 12, borderWidth: 1, borderColor: "rgba(255,255,255,0.09)", padding: 10, alignItems: "center", justifyContent: "center", gap: 4 },
  summaryIcon: { width: 30, height: 30, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  summaryHeadline: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.white, textAlign: "center" },
  summaryValue: { fontFamily: fontFamily.extrabold, fontSize: 22, color: colors.white },
  summarySub: { fontFamily: fontFamily.medium, fontSize: 9, color: "rgba(255,255,255,0.58)", textAlign: "center" },
  // Body
  body: { flex: 1, paddingHorizontal: 16, paddingTop: 16, gap: 18 },
  actionDockScroll: { flexGrow: 0, flexShrink: 0 },
  actionDock: { flexDirection: "row", alignItems: "stretch", gap: 12, paddingHorizontal: 4, paddingTop: 2 },
  dockAction: { width: 66, alignItems: "center", gap: 8, paddingHorizontal: 1, position: "relative" },
  dockIcon: { position: "relative", width: 46, height: 46, borderRadius: 14, justifyContent: "center", alignItems: "center" },
  dockIconPrimary: { shadowColor: colors.dark, shadowOpacity: 0.16, shadowRadius: 6, shadowOffset: { width: 0, height: 2 }, elevation: 2 },
  dockTitle: { fontFamily: fontFamily.bold, fontSize: 11, color: "#475569", textAlign: "center", letterSpacing: -0.2 },
  dockTitlePrimary: { color: colors.dark },
  recentScroll: { flex: 1 },
  recentScrollContent: { flexGrow: 1, paddingBottom: 100 },
  recentSection: { gap: 12 },
  recentSectionEmpty: { flexGrow: 1 },
  recentHeaderRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  recentHeaderIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, justifyContent: "center", alignItems: "center" },
  recentHeaderTitle: { flex: 1, fontFamily: fontFamily.bold, fontSize: 17, color: colors.dark },
  recentList: { gap: 12 },
  recentCard: { backgroundColor: colors.white, borderRadius: 14, borderLeftWidth: 4, overflow: "hidden", shadowColor: colors.dark, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 },
  recentCardTop: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14, paddingBottom: 10 },
  recentIcon: { width: 42, height: 42, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  recentTitle: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  recentMeta: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 },
  recentMetaText: { flex: 1, fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted },
  recentCardBottom: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 14, paddingVertical: 10, borderTopWidth: 1, borderTopColor: colors.neutral100 },
  recentViewBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  recentViewText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.primary },
});
