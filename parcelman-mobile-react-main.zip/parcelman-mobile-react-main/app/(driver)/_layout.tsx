import { Stack } from "expo-router";
import { colors } from "../../src/constants/colors";

export default function DriverLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        presentation: "card",
        animation: "none",
        gestureEnabled: false,
        contentStyle: { backgroundColor: colors.background },
      }}
    >
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="pickup/[id]" />
      <Stack.Screen name="pickup/[id]/confirm-items" />
      <Stack.Screen name="transport/[id]" />
      <Stack.Screen name="transport/[id]/scanner" />
      <Stack.Screen name="delivery/[id]" />
      <Stack.Screen name="delivery/[id]/stop/[stopId]" />
      <Stack.Screen name="packages/index" />
      <Stack.Screen name="packages/[barcode]" />
      <Stack.Screen name="profile/edit" />
      <Stack.Screen name="profile/change-password" />
      <Stack.Screen name="notifications" />
      <Stack.Screen name="package-transfers" />
      <Stack.Screen name="bus-handoffs/index" />
      <Stack.Screen name="bus-handoffs/[id]" />
      <Stack.Screen name="bus-handoffs/stop/[id]" />
      <Stack.Screen name="teams/index" />
      <Stack.Screen name="teams/[id]" />
      <Stack.Screen name="team-handover/[id]" />
      <Stack.Screen name="legal/[doc]" />
    </Stack>
  );
}
