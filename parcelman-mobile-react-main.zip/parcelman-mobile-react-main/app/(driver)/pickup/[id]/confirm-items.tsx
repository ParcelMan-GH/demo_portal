import { useState, useEffect, useRef } from "react";
import { View, Text, StyleSheet, ScrollView, Image, Alert, TouchableOpacity, Dimensions, Modal, Pressable, FlatList, KeyboardAvoidingView, Platform } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import Button from "../../../../src/components/common/Button";
import Input from "../../../../src/components/common/Input";
import ConfirmDialog from "../../../../src/components/common/ConfirmDialog";
import { ListSkeleton } from "../../../../src/components/common/ShimmerLoading";
import { colors } from "../../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../../src/constants/typography";
import { getPickup, confirmItem, confirmPickup } from "../../../../src/api/v1/driver/pickups";
import { showSuccess, showError, getErrorMessage } from "../../../../src/utils/toast";
import { compressToUnder2MB } from "../../../../src/utils/image";
import { captureSinglePhoto } from "../../../../src/utils/cameraCapture";

const { width } = Dimensions.get("window");

interface PhotoInfo {
  uri: string;
  id?: number; // API photo ID for existing photos
  isNew?: boolean;
}

interface ItemConfirmState {
  confirmed_quantity: string;
  notes: string;
  photos: PhotoInfo[];
  confirmed: boolean;
}

function lineQuantity(item: any, fallback?: string): number {
  const raw = item?.quantity ?? item?.expected_quantity ?? item?.packages_count ?? fallback;
  const value = Number(raw);
  return Number.isFinite(value) && value > 0 ? value : 1;
}

export default function ConfirmItemsScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const pickupDetailRoute = {
    pathname: "/(driver)/pickup/[id]",
    params: { id: String(id) },
  } as const;
  const leaveConfirmItems = () => {
    if (router.canGoBack()) router.back();
    else router.replace(pickupDetailRoute as any);
  };
  const [items, setItems] = useState<any[]>([]);
  const [shipmentNumber, setShipmentNumber] = useState("");
  const [driverPickedQuantity, setDriverPickedQuantity] = useState("");
  const [confirmStates, setConfirmStates] = useState<Record<number, ItemConfirmState>>({});
  const [originalStates, setOriginalStates] = useState<Record<number, ItemConfirmState>>({});
  const [editingItem, setEditingItem] = useState<number | null>(null);
  const [lightboxImages, setLightboxImages] = useState<string[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [showLightbox, setShowLightbox] = useState(false);
  const [showCompleteDialog, setShowCompleteDialog] = useState(false);

  const lightboxRef = useRef<FlatList>(null);

  const openLightbox = (images: string[], index: number) => {
    setLightboxImages(images);
    setLightboxIndex(index);
    setShowLightbox(true);
    setTimeout(() => lightboxRef.current?.scrollToIndex({ index, animated: false }), 50);
  };
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<number | null>(null);
  const [completing, setCompleting] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await getPickup(Number(id));
        const pickup = (res.data as any)?.pickup || (res.data as any)?.assignment || res.data;
        const shipment = pickup.shipment || {};
        const pickupItems = shipment.items || [];
        setItems(pickupItems);
        setShipmentNumber(pickup.shipment_number || shipment.shipment_number || `#${pickup.id}`);
        setDriverPickedQuantity(String(pickup.driver_picked_quantity ?? shipment.driver_picked_quantity ?? shipment.vendor_declared_quantity ?? ""));
        const states: Record<number, ItemConfirmState> = {};
        pickupItems.forEach((item: any) => {
          const alreadyConfirmed = !!item.pickup_confirmation;
          const rawPhotos: any[] = item.pickup_confirmation?.photos || item.pickup_confirmation?.confirmation_photos || item.confirmation_photos || [];
          const existingPhotos: PhotoInfo[] = Array.isArray(rawPhotos)
            ? rawPhotos.map((p: any) => {
                if (typeof p === 'string') return { uri: p };
                return { uri: p?.url || p?.path || p?.uri || '', id: p?.id };
              }).filter((p) => p.uri.length > 0)
            : [];
          states[item.id] = {
            confirmed_quantity: String(item.pickup_confirmation?.confirmed_quantity ?? item.quantity),
            notes: item.pickup_confirmation?.notes || item.pickup_confirmation?.confirmation_notes || "",
            photos: existingPhotos,
            confirmed: alreadyConfirmed,
          };
        });
        setConfirmStates(states);
        setOriginalStates(JSON.parse(JSON.stringify(states)));
      } catch (err: any) { showError(getErrorMessage(err)); }
      finally { setLoading(false); }
    })();
  }, [id]);

  const updateState = (itemId: number, updates: Partial<ItemConfirmState>) => {
    setConfirmStates((prev) => ({ ...prev, [itemId]: { ...prev[itemId], ...updates } }));
  };

  const takePhoto = async (itemId: number) => {
    const capturedUri = await captureSinglePhoto({ quality: 0.5, simulatorBehavior: 'choice' });
    if (!capturedUri) return;

    const uri = await compressToUnder2MB(capturedUri);
    const state = confirmStates[itemId];
    updateState(itemId, { photos: [...state.photos, { uri, isNew: true }] });
  };

  const handleConfirmItem = async (itemId: number) => {
    const state = confirmStates[itemId];
    if (state.photos.length === 0) {
      showError("Please take at least one photo before confirming");
      return;
    }
    setActionLoading(itemId);
    try {
      // Separate new photos from existing
      const newPhotos = state.photos.filter((p) => p.isNew).map((p) => p.uri);
      const keepPhotoIds = state.photos.filter((p) => !p.isNew && p.id).map((p) => p.id!);
      // Find original photos for this item to determine removed ones
      const item = items.find((i) => i.id === itemId);
      const originalPhotos: any[] = item?.pickup_confirmation?.photos || item?.pickup_confirmation?.confirmation_photos || [];
      const allOriginalIds = originalPhotos.map((p: any) => typeof p === 'object' ? p.id : null).filter(Boolean);
      const removePhotoIds = allOriginalIds.filter((pid: number) => !keepPhotoIds.includes(pid));

      await confirmItem(Number(id), itemId, {
        confirmed_quantity: lineQuantity(item, state.confirmed_quantity),
        notes: state.notes || undefined,
        photos: newPhotos.length > 0 ? newPhotos as any : undefined,
        remove_photo_ids: removePhotoIds.length > 0 ? removePhotoIds : undefined,
      } as any);
      updateState(itemId, { confirmed: true });
      showSuccess(editingItem === itemId ? "Package updated!" : "Package confirmed!");
      setEditingItem(null);

      // Check if all packages are now confirmed
      const othersConfirmed = items.every((i) => i.id === itemId || confirmStates[i.id]?.confirmed);
      if (othersConfirmed) {
        setTimeout(() => setShowCompleteDialog(true), 500);
      }
    } catch (err: any) { showError(getErrorMessage(err)); }
    finally { setActionLoading(null); }
  };

  const handleCompletePickup = async () => {
    const pickedQty = Number(driverPickedQuantity);
    if (!Number.isInteger(pickedQty) || pickedQty < 0) {
      showError("Enter the total packages picked");
      return;
    }
    setCompleting(true);
    try {
      const res = await confirmPickup(Number(id), pickedQty);
      const deliveryRunId = res.data?.delivery_run_id;

      if (deliveryRunId) {
        showSuccess("Pickup completed! Proceeding to delivery...");
        router.replace({
          pathname: "/(driver)/delivery/[id]",
          params: { id: String(deliveryRunId) },
        } as any);
      } else {
        showSuccess("Pickup completed!");
        router.replace(pickupDetailRoute as any);
      }
    } catch (err: any) { showError(getErrorMessage(err)); }
    finally { setCompleting(false); }
  };

  const allConfirmed = items.length > 0 && items.every((item) => confirmStates[item.id]?.confirmed);
  const confirmedCount = items.filter((item) => confirmStates[item.id]?.confirmed).length;

  if (loading) {
    return (
      <View style={s.container}>
        <View style={{ backgroundColor: "#0f172a", height: insets.top + 60 }} />
        <View style={{ padding: 16 }}><ListSkeleton count={3} /></View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={s.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={0}
    >
      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + 80 }}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
        automaticallyAdjustKeyboardInsets={Platform.OS === "ios"}
      >
        <LinearGradient colors={["#0f172a", "#1e3a5f", "#0f172a"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
          <View style={s.heroDecor1} />
          <View style={s.headerTop}>
            <TouchableOpacity onPress={leaveConfirmItems} style={s.backBtn}><Ionicons name="arrow-back" size={22} color={colors.white} /></TouchableOpacity>
            <View style={{ flex: 1 }}>
              <Text style={s.headerTitle}>Confirm Packages</Text>
              <Text style={s.headerSub}>{shipmentNumber}</Text>
            </View>
          </View>
          <View style={s.heroInfo}>
            <Ionicons name="checkmark-circle-outline" size={18} color="rgba(255,255,255,0.5)" />
            <Text style={s.heroInfoText}>Verify the number of packages and take at least one photo per package</Text>
          </View>
          <View style={s.heroProgress}>
            <View style={s.heroProgressBar}><View style={[s.heroProgressFill, { width: `${items.length > 0 ? (confirmedCount / items.length) * 100 : 0}%` }]} /></View>
            <Text style={s.heroProgressText}>{confirmedCount}/{items.length}</Text>
          </View>
        </LinearGradient>

        <View style={s.body}>
          <View style={s.card}>
            <View style={s.quantityHeader}>
              <Ionicons name="cube" size={20} color={colors.primary} />
              <View style={{ flex: 1 }}>
                <Text style={s.quantityTitle}>Pickup Quantity</Text>
                <Text style={s.quantitySub}>Total packages collected from the vendor.</Text>
              </View>
            </View>
            <Input
              label="Total packages picked"
              value={driverPickedQuantity}
              onChangeText={setDriverPickedQuantity}
              keyboardType="number-pad"
              leftIcon={<Ionicons name="calculator-outline" size={18} color={colors.textMuted} />}
            />
          </View>
          {items.map((item, itemIndex) => {
            const state = confirmStates[item.id];
            if (!state) return null;
            return (
              <View key={item.id} style={[s.card, state.confirmed && s.cardConfirmed]}>
                {state.confirmed ? (
                  <>
                    {/* Confirmed compact view */}
                    <View style={s.confirmedRow}>
                      <View style={s.confirmedCheck}>
                        <Ionicons name="checkmark-circle" size={20} color={colors.success} />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={s.itemDesc}>{item.description || `Package ${itemIndex + 1}`}</Text>
                        <View style={s.confirmedMeta}>
                          <Text style={s.confirmedMetaText}>{state.photos.length} photo{state.photos.length !== 1 ? "s" : ""}</Text>
                        </View>
                      </View>
                      <TouchableOpacity onPress={() => {
                        setOriginalStates((prev) => ({ ...prev, [item.id]: { ...state } }));
                        setEditingItem(item.id);
                        updateState(item.id, { confirmed: false });
                      }}>
                        <Text style={s.editLink}>Edit</Text>
                      </TouchableOpacity>
                    </View>
                    {/* Rider photo stacks */}
                    {(() => {
                      const driverImages = state.photos.map(p => p.uri);
                      if (driverImages.length === 0) return null;
                      const maxShow = 7;
                      const remaining = driverImages.length - maxShow;
                      return (
                        <View style={s.photoStacks}>
                          <View style={s.stackPhotos}>
                            {driverImages.slice(0, maxShow).map((uri, i) => (
                              <TouchableOpacity key={i} onPress={() => openLightbox(driverImages, i)}>
                                <Image source={{ uri }} style={[s.stackImg, s.stackImgDriver, { marginLeft: i > 0 ? -14 : 0, zIndex: 10 - i }]} />
                              </TouchableOpacity>
                            ))}
                            {remaining > 0 && (
                              <View style={[s.stackMore, { marginLeft: -14 }]}>
                                <Text style={s.stackMoreText}>+{remaining}</Text>
                              </View>
                            )}
                          </View>
                        </View>
                      );
                    })()}
                  </>
                ) : (
                  <>
                    {/* Unconfirmed header */}
                    <View style={s.itemHeader}>
                      <View style={[s.itemIcon, { backgroundColor: "#dbeafe" }]}>
                        <Ionicons name="cube" size={18} color="#3b82f6" />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={s.itemDesc}>{item.description || `Package ${itemIndex + 1}`}</Text>
                        <Text style={s.itemQty}>{item.tracking_code ? item.tracking_code : "Add proof photos"}</Text>
                      </View>
                    </View>

                  </>
                )}

                {!state.confirmed && (
                  <>
                    <View style={s.photoSection}>
                      <View style={s.photoSectionHeader}>
                        <Ionicons name="camera" size={14} color={colors.primary} />
                        <Text style={[s.photoSectionLabel, { color: colors.primary }]}>Your Photos *</Text>
                      </View>
                      <View style={s.photosRow}>
                        {state.photos.map((photo, i) => (
                          <View key={i} style={s.photoWrap}>
                            <TouchableOpacity onPress={() => openLightbox(state.photos.map(p => p.uri), i)}>
                              <Image source={{ uri: photo.uri }} style={s.photo} />
                            </TouchableOpacity>
                            <TouchableOpacity style={s.photoRemove} onPress={() => updateState(item.id, { photos: state.photos.filter((_, j) => j !== i) })}>
                              <Ionicons name="close-circle" size={18} color={colors.error} />
                            </TouchableOpacity>
                          </View>
                        ))}
                        <TouchableOpacity style={s.photoBtn} onPress={() => takePhoto(item.id)}>
                          <Ionicons name="camera-outline" size={22} color={colors.primary} />
                          <Text style={s.photoBtnText}>Photo</Text>
                        </TouchableOpacity>
                      </View>
                    </View>

                    <View style={{ flexDirection: "row", gap: 10 }}>
                      {editingItem === item.id && (
                        <TouchableOpacity
                          style={s.cancelEditBtn}
                          onPress={() => {
                            if (originalStates[item.id]) {
                              setConfirmStates((prev) => ({ ...prev, [item.id]: { ...originalStates[item.id] } }));
                            }
                            setEditingItem(null);
                          }}
                        >
                          <Ionicons name="close" size={16} color={colors.textMuted} />
                          <Text style={s.cancelEditText}>Cancel</Text>
                        </TouchableOpacity>
                      )}
                      <View style={{ flex: 1 }}>
                        <Button title={editingItem === item.id ? "Update Package" : "Confirm Package"} onPress={() => handleConfirmItem(item.id)} loading={actionLoading === item.id} disabled={state.photos.length === 0} height={44}
                          leftIcon={<Ionicons name="checkmark" size={18} color={colors.white} />} />
                      </View>
                    </View>
                  </>
                )}
              </View>
            );
          })}
        </View>
      </ScrollView>

      {allConfirmed && (
        <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
          <Button title="Complete Pickup" onPress={handleCompletePickup} loading={completing} height={50}
            disabled={!Number.isInteger(Number(driverPickedQuantity)) || Number(driverPickedQuantity) < 0}
            leftIcon={<Ionicons name="checkmark-done" size={18} color={colors.white} />}
            gradientColors={[colors.success, "#16a34a"] as [string, string]} />
        </View>
      )}
      {/* Lightbox */}
      <Modal visible={showLightbox} transparent animationType="fade" onRequestClose={() => setShowLightbox(false)}>
        <View style={s.lightbox}>
          <View style={s.lightboxHeader}>
            <Text style={s.lightboxCount}>{lightboxIndex + 1} / {lightboxImages.length}</Text>
            <TouchableOpacity onPress={() => setShowLightbox(false)} style={s.lightboxClose}>
              <Ionicons name="close" size={28} color={colors.white} />
            </TouchableOpacity>
          </View>
          <FlatList
            ref={lightboxRef}
            data={lightboxImages}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            keyExtractor={(_, i) => String(i)}
            getItemLayout={(_, index) => ({ length: width, offset: width * index, index })}
            initialScrollIndex={lightboxIndex}
            onMomentumScrollEnd={(e) => {
              const idx = Math.round(e.nativeEvent.contentOffset.x / width);
              setLightboxIndex(idx);
            }}
            renderItem={({ item: uri }) => (
              <View style={{ width, justifyContent: "center", alignItems: "center" }}>
                <Image source={{ uri }} style={s.lightboxImage} resizeMode="contain" />
              </View>
            )}
          />
        </View>
      </Modal>

      <ConfirmDialog
        visible={showCompleteDialog}
        type="success"
        title="All packages confirmed"
        message="Complete this pickup now?"
        confirmText="Complete Pickup"
        onConfirm={() => { setShowCompleteDialog(false); handleCompletePickup(); }}
        onCancel={() => setShowCompleteDialog(false)}
        loading={completing}
      />
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, gap: 10, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  heroInfo: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "rgba(255,255,255,0.08)", borderRadius: 10, padding: 12 },
  heroInfoText: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.6)", flex: 1 },
  heroProgress: { flexDirection: "row", alignItems: "center", gap: 8 },
  heroProgressBar: { flex: 1, height: 6, backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 3, overflow: "hidden" },
  heroProgressFill: { height: "100%", backgroundColor: "#4ade80", borderRadius: 3 },
  heroProgressText: { fontFamily: fontFamily.semibold, fontSize: 12, color: "#4ade80" },
  body: { padding: 16, gap: 14 },
  card: { backgroundColor: colors.white, borderRadius: 14, padding: 16, gap: 12 },
  quantityHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  quantityTitle: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  quantitySub: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: 2 },
  cardConfirmed: { borderWidth: 2, borderColor: colors.success },
  editConfirmBtn: { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 8, backgroundColor: colors.warmSurface },
  editConfirmText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.primary, textDecorationLine: "underline" },
  cancelEditBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, paddingHorizontal: 16, height: 44, borderRadius: 22, borderWidth: 1.5, borderColor: colors.border },
  cancelEditText: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.textMuted },
  // Confirmed compact view
  confirmedRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  confirmedCheck: { width: 32, height: 32, borderRadius: 16, backgroundColor: "#dcfce7", justifyContent: "center", alignItems: "center" },
  confirmedMeta: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 3, flexWrap: "wrap" },
  confirmedMetaText: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted },
  confirmedDot: { width: 3, height: 3, borderRadius: 1.5, backgroundColor: colors.neutral300 },
  editLink: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.primary, textDecorationLine: "underline" },
  // Photo stacks
  photoStacks: { gap: 6, marginTop: 6 },
  stackRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  stackPhotos: { flexDirection: "row", alignItems: "center" },
  stackImg: { width: 40, height: 40, borderRadius: 6, borderWidth: 2, borderColor: colors.white },
  stackImgDriver: { borderColor: colors.white },
  stackMore: { width: 40, height: 40, borderRadius: 6, backgroundColor: colors.neutral100, justifyContent: "center", alignItems: "center", borderWidth: 2, borderColor: colors.white },
  stackMoreText: { fontFamily: fontFamily.bold, fontSize: 10, color: colors.textMuted },
  confirmedPhotosRow: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  confirmedPhoto: { width: 44, height: 44, borderRadius: 8 },
  confirmedPhotoMore: { width: 44, height: 44, borderRadius: 8, backgroundColor: colors.neutral100, justifyContent: "center", alignItems: "center" },
  confirmedPhotoMoreText: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.textMuted },
  stackInfo: { flex: 1 },
  stackLabel: { fontFamily: fontFamily.medium, fontSize: 10, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.3 },
  stackCount: { display: "none" },
  // Photo sections
  photoSection: { gap: 8, marginTop: 4 },
  photoSectionHeader: { flexDirection: "row", alignItems: "center", gap: 6 },
  photoSectionLabel: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.3 },
  vendorPhoto: { width: 64, height: 64, borderRadius: 10 },
  // Lightbox
  lightbox: { flex: 1, backgroundColor: "rgba(0,0,0,0.95)", justifyContent: "center" },
  lightboxHeader: { position: "absolute", top: 50, left: 0, right: 0, flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 20, zIndex: 10 },
  lightboxCount: { fontFamily: fontFamily.medium, fontSize: 14, color: colors.white },
  lightboxClose: { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.15)", justifyContent: "center", alignItems: "center" },
  lightboxImage: { width: width - 20, height: "80%" },
  itemHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  itemIcon: { width: 40, height: 40, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  itemDesc: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark },
  itemQty: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: 2 },
  photosRow: { flexDirection: "row", gap: 10, flexWrap: "wrap" },
  photoWrap: { position: "relative" },
  photo: { width: 64, height: 64, borderRadius: 10 },
  photoRemove: { position: "absolute", top: -6, right: -6, backgroundColor: colors.white, borderRadius: 10 },
  photoBtn: { width: 64, height: 64, borderRadius: 10, borderWidth: 2, borderColor: colors.border, borderStyle: "dashed", justifyContent: "center", alignItems: "center", backgroundColor: colors.surface, gap: 2 },
  photoBtnText: { fontFamily: fontFamily.medium, fontSize: 10, color: colors.primary },
  footer: { paddingHorizontal: 16, paddingTop: 12, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.border },
});
