import { useCallback, useState } from "react";
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from "react-native";
import { router, useFocusEffect, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import * as Location from "expo-location";
import StatusBadge from "../../../src/components/common/StatusBadge";
import Button from "../../../src/components/common/Button";
import Input from "../../../src/components/common/Input";
import ShimmerLoading from "../../../src/components/common/ShimmerLoading";
import ConfirmDialog from "../../../src/components/common/ConfirmDialog";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { getPickup, markEnRoute, markArrived, confirmItem, confirmPickup } from "../../../src/api/v1/driver/pickups";
import { showSuccess, showError, showWarning, getErrorMessage } from "../../../src/utils/toast";
import { formatPhone } from "../../../src/utils/format";
import { captureSinglePhoto } from "../../../src/utils/cameraCapture";
import { compressToUnder2MB } from "../../../src/utils/image";

const { width } = Dimensions.get("window");

type PhotoInfo = {
  uri: string;
  id?: number;
  isNew?: boolean;
};

type ItemConfirmState = {
  confirmed_quantity: string;
  notes: string;
  photos: PhotoInfo[];
  confirmed: boolean;
};

type PickupCoordinates = {
  latitude: number;
  longitude: number;
};

function formatMoney(amount: number, currency = "GHS") {
  return `${currency} ${Number(amount || 0).toFixed(2)}`;
}

function pickupFeePresentation(pickupFee: any) {
  if (!pickupFee) {
    return {
      amount: "No fee",
      label: "No pickup fee",
      status: "none",
      icon: "remove-circle-outline" as keyof typeof Ionicons.glyphMap,
      color: colors.textMuted,
      bg: colors.neutral100,
    };
  }

  const status = String(pickupFee.status || "").toLowerCase();
  const amount = formatMoney(Number(pickupFee.amount || 0), pickupFee.currency || "GHS");

  if (status === "paid") {
    return {
      amount,
      label: "Paid",
      status: "paid",
      icon: "checkmark-circle-outline" as keyof typeof Ionicons.glyphMap,
      color: colors.success,
      bg: colors.successLight,
    };
  }

  if (status === "waived") {
    return {
      amount,
      label: "Waived",
      status: "waived",
      icon: "shield-checkmark-outline" as keyof typeof Ionicons.glyphMap,
      color: colors.info,
      bg: colors.infoLight,
    };
  }

  return {
    amount,
    label: "Unpaid",
    status: "unpaid",
    icon: "cash-outline" as keyof typeof Ionicons.glyphMap,
    color: colors.primary,
    bg: colors.warmSurface,
  };
}

function normalizePhotos(rawPhotos: any[]): PhotoInfo[] {
  if (!Array.isArray(rawPhotos)) return [];
  return rawPhotos
    .map((photo) => {
      if (typeof photo === "string") return { uri: photo };
      return { uri: photo?.url || photo?.path || photo?.uri || "", id: photo?.id };
    })
    .filter((photo) => photo.uri.length > 0);
}

function expectedQuantity(item: any): number | null {
  const raw = item?.quantity ?? item?.expected_quantity ?? item?.packages_count;
  const value = Number(raw);
  return Number.isFinite(value) && value > 0 ? value : null;
}

function packageQuantitySummary(items: any[]) {
  const quantities = items.map(expectedQuantity);
  const known = quantities.filter((qty): qty is number => qty !== null);
  if (known.length === 0) return { value: "Unknown", known: false };
  return { value: String(known.reduce((sum, qty) => sum + qty, 0)), known: known.length === items.length };
}

function pickupStatusLabel(status: string) {
  if (!status) return "—";
  return status.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

function locationParts(location: any) {
  return [location?.town, location?.district, location?.region].filter(Boolean).join(", ");
}

function normalizedPhotoSignature(photos: PhotoInfo[] = []) {
  return photos
    .map((photo) => `${photo.id || ""}:${photo.uri}:${photo.isNew ? "new" : "existing"}`)
    .sort()
    .join("|");
}

function confirmationStateChanged(current?: ItemConfirmState, original?: ItemConfirmState) {
  if (!current || !original) return false;
  return normalizedPhotoSignature(current.photos) !== normalizedPhotoSignature(original.photos);
}

async function getBestEffortPickupCoordinates(): Promise<PickupCoordinates | null> {
  try {
    const { status } = await Promise.race([
      Location.requestForegroundPermissionsAsync(),
      new Promise<{ status: Location.PermissionStatus }>((resolve) => {
        setTimeout(() => resolve({ status: Location.PermissionStatus.UNDETERMINED }), 3500);
      }),
    ]);

    if (status !== Location.PermissionStatus.GRANTED) {
      showWarning("Location permission unavailable. Pickup will continue without GPS proof.");
      return null;
    }

    const loc = await Promise.race([
      Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }),
      new Promise<null>((resolve) => {
        setTimeout(() => resolve(null), 6000);
      }),
    ]);

    if (!loc) {
      showWarning("Could not capture GPS right now. Pickup will continue without location proof.");
      return null;
    }

    return {
      latitude: loc.coords.latitude,
      longitude: loc.coords.longitude,
    };
  } catch {
    showWarning("Could not capture GPS right now. Pickup will continue without location proof.");
    return null;
  }
}

function readAssignmentFromResponse(res: any) {
  return (res?.data as any)?.assignment || (res?.data as any)?.pickup || res?.data || res;
}

function hasCoordinate(value: unknown) {
  return value !== null && value !== undefined && value !== "";
}

function formatCoordinate(value: unknown) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric.toFixed(6) : String(value || "");
}

export default function PickupDetailScreen() {
  const insets = useSafeAreaInsets();
  const { width: viewportWidth } = useWindowDimensions();
  const { id } = useLocalSearchParams<{ id: string }>();
  const pickupsRoute = "/(driver)/(tabs)/pickups" as const;
  const leavePickupDetail = () => {
    if (router.canGoBack()) router.back();
    else router.replace(pickupsRoute as any);
  };
  const [pickup, setPickup] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [arrivalLoading, setArrivalLoading] = useState(false);
  const [confirmStates, setConfirmStates] = useState<Record<number, ItemConfirmState>>({});
  const [originalStates, setOriginalStates] = useState<Record<number, ItemConfirmState>>({});
  const [driverPickedQuantity, setDriverPickedQuantity] = useState("");
  const [selectedItemId, setSelectedItemId] = useState<number | null>(null);
  const [itemSavingId, setItemSavingId] = useState<number | null>(null);
  const [autoDelivery, setAutoDelivery] = useState<any>(null);
  const [showDeliveryModal, setShowDeliveryModal] = useState(false);
  const [showCompleteDialog, setShowCompleteDialog] = useState(false);
  const [lightboxImages, setLightboxImages] = useState<string[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [lightboxLoadFailures, setLightboxLoadFailures] = useState<Record<string, boolean>>({});

  const hydratePickup = (assignment: any) => {
    setPickup(assignment);
    const shipment = assignment?.shipment || {};
    setDriverPickedQuantity(String(assignment?.driver_picked_quantity ?? shipment?.driver_picked_quantity ?? shipment?.vendor_declared_quantity ?? ""));
    const states: Record<number, ItemConfirmState> = {};
    (shipment.items || []).forEach((item: any) => {
      const confirmation = item.pickup_confirmation;
      const rawPhotos: any[] = confirmation?.photos || confirmation?.confirmation_photos || item.confirmation_photos || [];
      states[item.id] = {
        confirmed_quantity: String(confirmation?.confirmed_quantity ?? expectedQuantity(item) ?? 1),
        notes: confirmation?.notes || confirmation?.confirmation_notes || "",
        photos: normalizePhotos(rawPhotos),
        confirmed: Boolean(confirmation),
      };
    });
    setConfirmStates(states);
    setOriginalStates(JSON.parse(JSON.stringify(states)));
  };

  const fetchPickup = async () => {
    try {
      const res = await getPickup(Number(id));
      hydratePickup((res.data as any)?.pickup || (res.data as any)?.assignment || res.data);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(useCallback(() => { fetchPickup(); }, [id]));

  const updateState = (itemId: number, updates: Partial<ItemConfirmState>) => {
    setConfirmStates((prev) => ({ ...prev, [itemId]: { ...prev[itemId], ...updates } }));
  };

  const openLightbox = (images: string[], index: number) => {
    setLightboxImages(images);
    setLightboxIndex(index);
    setLightboxLoadFailures({});
  };

  const closeLightbox = () => {
    setLightboxImages([]);
    setLightboxIndex(0);
    setLightboxLoadFailures({});
  };

  const updateLightboxIndex = (offsetX: number) => {
    if (lightboxImages.length === 0 || viewportWidth <= 0) return;

    const nextIndex = Math.round(offsetX / viewportWidth);
    setLightboxIndex(Math.max(0, Math.min(nextIndex, lightboxImages.length - 1)));
  };

  const openConfirmModal = (item: any) => {
    setOriginalStates((prev) => ({ ...prev, [item.id]: JSON.parse(JSON.stringify(confirmStates[item.id])) }));
    setSelectedItemId(item.id);
  };

  const closeConfirmModal = () => {
    if (selectedItemId && originalStates[selectedItemId]) {
      setConfirmStates((prev) => ({ ...prev, [selectedItemId]: originalStates[selectedItemId] }));
    }
    closeLightbox();
    setSelectedItemId(null);
  };

  const takePhoto = async (itemId: number) => {
    const capturedUri = await captureSinglePhoto({ quality: 0.5, simulatorBehavior: "choice" });
    if (!capturedUri) return;

    const uri = await compressToUnder2MB(capturedUri);
    const state = confirmStates[itemId];
    updateState(itemId, { photos: [...state.photos, { uri, isNew: true }] });
  };

  const handleConfirmItem = async (itemId: number) => {
    const state = confirmStates[itemId];
    if (!state) return;

    if (state.photos.length === 0) {
      showError("Please take at least one photo before confirming");
      return;
    }

    setItemSavingId(itemId);
    try {
      await recordPickupArrivalWithGps();

      const item = (pickup?.shipment?.items || []).find((candidate: any) => Number(candidate.id) === Number(itemId));
      const newPhotos = state.photos.filter((photo) => photo.isNew).map((photo) => photo.uri);
      const keepPhotoIds = state.photos.filter((photo) => !photo.isNew && photo.id).map((photo) => photo.id!);
      const rawOriginalPhotos: any[] = item?.pickup_confirmation?.photos || item?.pickup_confirmation?.confirmation_photos || [];
      const originalIds = rawOriginalPhotos
        .map((photo: any) => (typeof photo === "object" ? photo.id : null))
        .filter(Boolean);
      const removePhotoIds = originalIds.filter((photoId: number) => !keepPhotoIds.includes(photoId));
      const lineQuantity = expectedQuantity(item) ?? (parseInt(state.confirmed_quantity, 10) || 1);

      await confirmItem(Number(id), itemId, {
        confirmed_quantity: lineQuantity,
        notes: state.notes || undefined,
        photos: newPhotos.length > 0 ? newPhotos as any : undefined,
        remove_photo_ids: removePhotoIds.length > 0 ? removePhotoIds : undefined,
      } as any);

      updateState(itemId, { confirmed: true });
      setOriginalStates((prev) => ({ ...prev, [itemId]: { ...state, confirmed: true } }));
      setSelectedItemId(null);
      showSuccess(state.confirmed ? "Package updated!" : "Package confirmed!");

      const allConfirmed = (pickup?.shipment?.items || []).every((item: any) => item.id === itemId || confirmStates[item.id]?.confirmed);
      if (allConfirmed) setTimeout(() => setShowCompleteDialog(true), 350);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setItemSavingId(null);
    }
  };

  const handleCompletePickup = async () => {
    const pickedQty = Number(driverPickedQuantity);
    if (!Number.isInteger(pickedQty) || pickedQty < 0) {
      showError("Enter the total packages picked");
      return;
    }
    setActionLoading(true);
    try {
      const coords = await getBestEffortPickupCoordinates();
      const res = await confirmPickup(Number(id), pickedQty, coords || undefined);
      const assignment = readAssignmentFromResponse(res);
      hydratePickup(assignment);

      if (assignment?.auto_delivery) {
        setAutoDelivery(assignment.auto_delivery);
        setShowDeliveryModal(true);
      } else {
        showSuccess("Pickup completed!");
      }
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  const handleStartEnRoute = async () => {
    setArrivalLoading(true);
    try {
      const res = await markEnRoute(Number(id));
      hydratePickup(readAssignmentFromResponse(res));
      showSuccess("Pickup trip started.");
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setArrivalLoading(false);
    }
  };

  const recordPickupArrivalWithGps = async (showSuccessToast = false) => {
    const currentStatus = String(pickup?.status || "");
    const hasArrivalGps = hasCoordinate(pickup?.pickup_latitude) && hasCoordinate(pickup?.pickup_longitude);

    if (hasArrivalGps || !["assigned", "en_route"].includes(currentStatus)) {
      return false;
    }

    const coords = await getBestEffortPickupCoordinates();
    if (!coords) return false;

    try {
      if (currentStatus === "assigned") {
        const enRouteRes = await markEnRoute(Number(id));
        hydratePickup(readAssignmentFromResponse(enRouteRes));
      }

      const arrivedRes = await markArrived(Number(id), coords.latitude, coords.longitude);
      hydratePickup(readAssignmentFromResponse(arrivedRes));
      if (showSuccessToast) showSuccess("Arrival GPS captured.");
      return true;
    } catch {
      showWarning("Could not record arrival GPS. Continue pickup and try again if needed.");
      return false;
    }
  };

  const handleArrivedAtPickup = async () => {
    setArrivalLoading(true);
    try {
      await recordPickupArrivalWithGps(true);
    } finally {
      setArrivalLoading(false);
    }
  };

  if (loading) {
    return <PickupDetailSkeleton topInset={insets.top} bottomInset={insets.bottom} />;
  }

  if (!pickup) return null;

  const status = pickup.status || "";
  const canConfirmItems = !["completed", "cancelled", "picked_up"].includes(status);
  const shipment = pickup.shipment || {};
  const pickupInfo = shipment.pickup || {};
  const location = pickupInfo.location || {};
  const items = shipment.items || [];
  const shipmentNumber = pickup.shipment_number || shipment.shipment_number || `#${pickup.id}`;
  const locationStr = locationParts(location);
  const pickupFeeUi = pickupFeePresentation(shipment.pickup_fee || null);
  const hasPickupFee = Boolean(shipment.pickup_fee);
  const quantitySummary = packageQuantitySummary(items);
  const confirmedCount = items.filter((item: any) => confirmStates[item.id]?.confirmed).length;
  const allConfirmed = items.length > 0 && confirmedCount === items.length;
  const selectedItem = selectedItemId ? items.find((item: any) => Number(item.id) === Number(selectedItemId)) : null;
  const selectedState = selectedItemId ? confirmStates[selectedItemId] : null;
  const selectedStateChanged = selectedItemId ? confirmationStateChanged(selectedState || undefined, originalStates[selectedItemId]) : false;
  const selectedModalReadOnly = !canConfirmItems;
  const capturedPickupLatitude = pickup.pickup_latitude ?? pickup.timeline?.arrived_pickup?.latitude;
  const capturedPickupLongitude = pickup.pickup_longitude ?? pickup.timeline?.arrived_pickup?.longitude;
  const hasCapturedPickupGps = hasCoordinate(capturedPickupLatitude) && hasCoordinate(capturedPickupLongitude);

  return (
    <View style={s.container}>
      <ScrollView
        refreshControl={<RefreshControl refreshing={false} onRefresh={fetchPickup} colors={[colors.primary]} />}
        contentContainerStyle={{ paddingBottom: insets.bottom + (allConfirmed && canConfirmItems ? 116 : 80) }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <LinearGradient colors={["#0f172a", "#1e3a5f", "#0f172a"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
          <View style={s.heroDecor1} />
          <View style={s.headerTop}>
            <TouchableOpacity onPress={leavePickupDetail} style={s.backBtn}>
              <Ionicons name="arrow-back" size={22} color={colors.white} />
            </TouchableOpacity>
            <View style={{ flex: 1 }}>
              <Text style={s.headerTitle}>Pickup Details</Text>
              <Text style={s.headerSub}>{shipmentNumber}</Text>
            </View>
            <StatusBadge status={status} />
          </View>

          <View style={s.heroSummaryGrid}>
            <SummaryCard icon="cube-outline" value={`${items.length}`} label={items.length === 1 ? "Package" : "Packages"} />
            <SummaryCard icon="layers-outline" value={quantitySummary.value} label={quantitySummary.known ? "Items" : "Item qty"} />
            {hasPickupFee ? (
              <SummaryCard icon={pickupFeeUi.icon} value={pickupFeeUi.amount} label={pickupFeeUi.label} />
            ) : (
              <SummaryCard icon="checkmark-circle-outline" value={pickupStatusLabel(status)} label="Status" />
            )}
          </View>
        </LinearGradient>

        <View style={s.body}>
          <PickupLocationCard pickupInfo={pickupInfo} location={location} locationStr={locationStr} pickupFeeUi={pickupFeeUi} showPickupFee={hasPickupFee} />
          <PickupProgressActionCard
            status={status}
            loading={arrivalLoading}
            hasGps={hasCapturedPickupGps}
            onStart={handleStartEnRoute}
            onArrived={handleArrivedAtPickup}
          />
          {hasCapturedPickupGps ? (
            <PickupGpsProofCard
              latitude={capturedPickupLatitude}
              longitude={capturedPickupLongitude}
              capturedAt={pickup.timeline?.arrived_pickup?.at || pickup.arrived_at}
            />
          ) : null}
          <DestinationCard pickup={pickup} />
          {canConfirmItems && (
            <View style={s.detailCard}>
              <View style={s.detailCardHeader}>
                <View style={[s.detailIconWrap, { backgroundColor: "#ffedd5" }]}>
                  <Ionicons name="cube" size={18} color={colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.detailTitle}>Pickup Quantity</Text>
                  <Text style={s.detailSub}>Enter the total packages collected.</Text>
                </View>
              </View>
              <Input
                label="Total packages picked"
                value={driverPickedQuantity}
                onChangeText={setDriverPickedQuantity}
                keyboardType="number-pad"
                leftIcon={<Ionicons name="calculator-outline" size={18} color={colors.textMuted} />}
              />
            </View>
          )}
          <PackagesCard items={items} states={confirmStates} canConfirm={canConfirmItems} onOpen={openConfirmModal} />
        </View>
      </ScrollView>

      {allConfirmed && canConfirmItems && (
        <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
          <Button
            title="Complete Pickup"
            onPress={handleCompletePickup}
            loading={actionLoading}
            disabled={!Number.isInteger(Number(driverPickedQuantity)) || Number(driverPickedQuantity) < 0}
            height={52}
            leftIcon={<Ionicons name="checkmark-done" size={18} color={colors.white} />}
            gradientColors={[colors.success, "#16a34a"] as [string, string]}
          />
        </View>
      )}

      {status === "picked_up" && (
        <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
          <View style={s.successBanner}>
            <Ionicons name="checkmark-circle" size={24} color={colors.success} />
            <Text style={s.successText}>Pickup completed</Text>
          </View>
        </View>
      )}

      <Modal
        visible={Boolean(selectedItem && selectedState)}
        transparent
        animationType="fade"
        onRequestClose={lightboxImages.length > 0 ? closeLightbox : closeConfirmModal}
        presentationStyle="overFullScreen"
      >
        {lightboxImages.length > 0 ? (
          <View style={s.lightbox}>
            <View style={[s.lightboxHeader, { top: insets.top + 12 }]}>
              <Text style={s.lightboxCount}>{lightboxIndex + 1} / {lightboxImages.length}</Text>
              <TouchableOpacity onPress={closeLightbox} style={s.lightboxClose} accessibilityRole="button" accessibilityLabel="Close photo viewer">
                <Ionicons name="close" size={28} color={colors.white} />
              </TouchableOpacity>
            </View>
            <FlatList
              key={`lightbox-${viewportWidth}`}
              data={lightboxImages}
              horizontal
              pagingEnabled
              showsHorizontalScrollIndicator={false}
              keyExtractor={(_, index) => String(index)}
              getItemLayout={(_, index) => ({ length: viewportWidth, offset: viewportWidth * index, index })}
              initialScrollIndex={lightboxIndex}
              onScrollEndDrag={(event) => updateLightboxIndex(event.nativeEvent.contentOffset.x)}
              onMomentumScrollEnd={(event) => updateLightboxIndex(event.nativeEvent.contentOffset.x)}
              renderItem={({ item: uri, index }) => (
                <View style={{ width: viewportWidth, justifyContent: "center", alignItems: "center" }}>
                  {lightboxLoadFailures[uri] ? (
                    <View style={[s.lightboxError, { width: viewportWidth - 40 }]}>
                      <Ionicons name="image-outline" size={42} color="rgba(255,255,255,0.72)" />
                      <Text style={s.lightboxErrorTitle}>Photo unavailable</Text>
                      <Text style={s.lightboxErrorText}>This photo could not be loaded.</Text>
                    </View>
                  ) : (
                    <Image
                      source={{ uri }}
                      style={[s.lightboxImage, { width: viewportWidth - 20 }]}
                      resizeMode="contain"
                      onError={() => setLightboxLoadFailures((current) => ({ ...current, [uri]: true }))}
                    />
                  )}
                </View>
              )}
            />
          </View>
        ) : (
          <View style={s.modalOverlay}>
            <Pressable style={StyleSheet.absoluteFill} onPress={closeConfirmModal} />
            {selectedItem && selectedState && (
              <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "position" : undefined}
                keyboardVerticalOffset={0}
                style={s.keyboardAvoider}
                contentContainerStyle={s.keyboardAvoiderContent}
              >
                <View style={[s.actionSheet, { paddingBottom: insets.bottom + 18 }]}>
                  <View style={s.sheetHandle} />
                  <View style={s.actionSheetHeader}>
                    <View style={[s.cardIconWrap, { backgroundColor: "#dbeafe" }]}>
                      <Ionicons name="cube" size={18} color="#3b82f6" />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={s.actionSheetTitle} numberOfLines={1}>{selectedItem.description || "Package"}</Text>
                      <Text style={s.actionSheetSub}>Add proof photos for this package.</Text>
                    </View>
                    <TouchableOpacity style={s.actionSheetClose} onPress={closeConfirmModal}>
                      <Ionicons name="close" size={20} color={colors.textMuted} />
                    </TouchableOpacity>
                  </View>

                  <ScrollView
                    style={s.actionSheetScroll}
                    contentContainerStyle={s.actionSheetContent}
                    keyboardShouldPersistTaps="handled"
                    keyboardDismissMode="interactive"
                    automaticallyAdjustKeyboardInsets
                    showsVerticalScrollIndicator={false}
                  >
                    {selectedModalReadOnly ? (
                      <View style={s.readOnlyPanel}>
                        <DetailRow icon="camera-outline" label="Proof photos" value={`${selectedState.photos.length} photo${selectedState.photos.length === 1 ? "" : "s"}`} />
                      </View>
                    ) : (
                      null
                    )}

                    <View style={s.photoSection}>
                      <Text style={s.photoSectionTitle}>Proof Photos</Text>
                      <View style={s.photosRow}>
                        {selectedState.photos.map((photo, index) => (
                          <View key={`${photo.id || photo.uri}-${index}`} style={s.photoWrap}>
                            <TouchableOpacity onPress={() => openLightbox(selectedState.photos.map((item) => item.uri), index)}>
                              <Image source={{ uri: photo.uri }} style={s.photo} />
                            </TouchableOpacity>
                            {!selectedModalReadOnly && (
                              <TouchableOpacity
                                style={s.photoRemove}
                                onPress={() => updateState(selectedItem.id, { photos: selectedState.photos.filter((_, photoIndex) => photoIndex !== index) })}
                              >
                                <Ionicons name="close-circle" size={18} color={colors.error} />
                              </TouchableOpacity>
                            )}
                          </View>
                        ))}
                        {!selectedModalReadOnly && (
                          <TouchableOpacity style={s.photoBtn} onPress={() => takePhoto(selectedItem.id)}>
                            <Ionicons name="camera-outline" size={22} color={colors.primary} />
                            <Text style={s.photoBtnText}>Photo</Text>
                          </TouchableOpacity>
                        )}
                      </View>
                    </View>
                  </ScrollView>

                  {!selectedModalReadOnly && (
                    <Button
                      title={selectedState.confirmed ? "Update Package" : "Confirm Package"}
                      onPress={() => handleConfirmItem(selectedItem.id)}
                      loading={itemSavingId === selectedItem.id}
                      disabled={selectedState.photos.length === 0 || !selectedStateChanged}
                      height={52}
                      leftIcon={<Ionicons name="checkmark-circle" size={18} color={colors.white} />}
                    />
                  )}
                </View>
              </KeyboardAvoidingView>
            )}
          </View>
        )}
      </Modal>

      <ConfirmDialog
        visible={showCompleteDialog}
        type="success"
        title="Complete pickup"
        message="Complete this pickup now?"
        confirmText="Complete Pickup"
        onConfirm={() => { setShowCompleteDialog(false); handleCompletePickup(); }}
        onCancel={() => setShowCompleteDialog(false)}
        loading={actionLoading}
      />

      <Modal visible={showDeliveryModal} transparent animationType="fade">
        <View style={s.deliveryModalOverlay}>
          <View style={s.deliveryModalSheet}>
            <Ionicons name="checkmark-circle" size={48} color={colors.success} />
            <Text style={s.deliveryModalTitle}>Pickup Complete</Text>
            <Text style={s.deliveryModalSub}>This is a direct delivery. Proceed to deliver the packages to the recipient.</Text>
            {autoDelivery && (
              <View style={s.deliveryModalInfoCard}>
                <Ionicons name="location" size={16} color={colors.primary} />
                <View style={{ flex: 1 }}>
                  <Text style={s.deliveryModalInfoName}>{autoDelivery.recipient_name}</Text>
                  <Text style={s.deliveryModalInfoLoc}>{autoDelivery.location?.town}, {autoDelivery.location?.district}</Text>
                </View>
              </View>
            )}
            <TouchableOpacity
              style={s.deliveryModalPrimaryBtn}
              onPress={() => {
                setShowDeliveryModal(false);
                if (autoDelivery) {
                  router.replace({
                    pathname: "/(driver)/delivery/[id]/stop/[stopId]",
                    params: {
                      id: String(autoDelivery.delivery_run_id),
                      stopId: String(autoDelivery.stop_id),
                    },
                  } as any);
                }
              }}
            >
              <Ionicons name="car" size={18} color={colors.white} />
              <Text style={s.deliveryModalPrimaryText}>Proceed to Delivery</Text>
            </TouchableOpacity>
            <TouchableOpacity style={s.deliveryModalSecondaryBtn} onPress={() => { setShowDeliveryModal(false); router.replace(pickupsRoute as any); }}>
              <Text style={s.deliveryModalSecondaryText}>Back to Pickups</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function SummaryCard({ icon, value, label }: { icon: keyof typeof Ionicons.glyphMap; value: string; label: string }) {
  return (
    <View style={s.heroSummaryCard}>
      <View style={s.heroSummaryIcon}>
        <Ionicons name={icon} size={18} color={colors.white} />
      </View>
      <Text style={s.heroSummaryValue} numberOfLines={1} adjustsFontSizeToFit>{value}</Text>
      <Text style={s.heroSummaryLabel} numberOfLines={1}>{label}</Text>
    </View>
  );
}

function DetailRow({ icon, label, value }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string }) {
  return (
    <View style={s.detailRow}>
      <Ionicons name={icon} size={15} color={colors.textMuted} />
      <View style={{ flex: 1 }}>
        <Text style={s.detailLabel}>{label}</Text>
        <Text style={s.detailValue}>{value}</Text>
      </View>
    </View>
  );
}

function PickupLocationCard({ pickupInfo, location, locationStr, pickupFeeUi, showPickupFee }: { pickupInfo: any; location: any; locationStr: string; pickupFeeUi: ReturnType<typeof pickupFeePresentation>; showPickupFee: boolean }) {
  const hasCoordinates = location?.latitude && location?.longitude;
  const contactName = pickupInfo.contact_name || "—";

  return (
    <View style={s.locationCard}>
      <View style={s.locationHeader}>
        <View style={s.locationHeaderIcon}>
          <Ionicons name="location-outline" size={18} color={colors.success} />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.locationTitle}>Pickup Location</Text>
          <Text style={s.locationMain} numberOfLines={3}>{locationStr || pickupInfo.town || "—"}</Text>
        </View>
      </View>

      <View style={s.locationDetails}>
        <View style={s.locationDetailRow}>
          <Ionicons name="person-outline" size={16} color={colors.textMuted} />
          <Text style={s.locationDetailText} numberOfLines={2}>{contactName}</Text>
        </View>
        {pickupInfo.contact_phone ? (
          <TouchableOpacity style={s.locationDetailRow} onPress={() => Linking.openURL(`tel:${pickupInfo.contact_phone}`)} activeOpacity={0.75}>
            <Ionicons name="call-outline" size={16} color={colors.textMuted} />
            <Text style={[s.locationDetailText, s.locationPhoneText]}>{formatPhone(pickupInfo.contact_phone)}</Text>
          </TouchableOpacity>
        ) : null}
        {showPickupFee ? (
          <View style={s.locationDetailRow}>
            <Ionicons name={pickupFeeUi.icon} size={16} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={2}>
              Pickup fee: {pickupFeeUi.amount} · {pickupFeeUi.label}
            </Text>
          </View>
        ) : null}
        {location?.landmark ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="flag-outline" size={16} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={2}>{location.landmark}</Text>
          </View>
        ) : null}
        {pickupInfo.instructions ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="document-text-outline" size={16} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={3}>{pickupInfo.instructions}</Text>
          </View>
        ) : null}
        {hasCoordinates ? (
          <TouchableOpacity
            style={s.locationDetailRow}
            onPress={() => Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${location.latitude},${location.longitude}`)}
            activeOpacity={0.75}
          >
            <Ionicons name="navigate-outline" size={16} color={colors.textMuted} />
            <Text style={[s.locationDetailText, s.locationActionText]}>Navigate to pickup</Text>
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}

function PickupProgressActionCard({
  status,
  loading,
  hasGps,
  onStart,
  onArrived,
}: {
  status: string;
  loading: boolean;
  hasGps: boolean;
  onStart: () => void;
  onArrived: () => void;
}) {
  if (hasGps || !["assigned", "en_route"].includes(status)) return null;

  const isAssigned = status === "assigned";
  const title = isAssigned ? "Start pickup trip" : "Arrived at pickup";
  const subtitle = isAssigned
    ? "Begin the trip before collecting packages."
    : "Capture phone GPS before package confirmation.";
  const icon = isAssigned ? "navigate-outline" : "location-outline";

  return (
    <View style={s.progressActionCard}>
      <View style={s.detailCardHeader}>
        <View style={[s.detailIconWrap, { backgroundColor: "#ffedd5" }]}>
          <Ionicons name={icon} size={18} color={colors.primary} />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.detailTitle}>{title}</Text>
          <Text style={s.detailSub}>{subtitle}</Text>
        </View>
      </View>
      <TouchableOpacity
        style={[s.progressActionButton, loading && s.progressActionButtonDisabled]}
        onPress={isAssigned ? onStart : onArrived}
        disabled={loading}
        activeOpacity={0.82}
      >
        <Ionicons name={loading ? "hourglass-outline" : icon} size={17} color={colors.white} />
        <Text style={s.progressActionButtonText}>{loading ? "Saving..." : title}</Text>
      </TouchableOpacity>
    </View>
  );
}

function PickupGpsProofCard({ latitude, longitude, capturedAt }: { latitude: unknown; longitude: unknown; capturedAt?: string }) {
  const lat = formatCoordinate(latitude);
  const lng = formatCoordinate(longitude);

  return (
    <View style={s.gpsProofCard}>
      <View style={s.detailCardHeader}>
        <View style={[s.detailIconWrap, { backgroundColor: "#dcfce7" }]}>
          <Ionicons name="shield-checkmark-outline" size={18} color={colors.success} />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.detailTitle}>Pickup GPS Captured</Text>
          <Text style={s.detailSub} numberOfLines={1}>{lat}, {lng}</Text>
          {capturedAt ? <Text style={s.gpsProofTime}>{new Date(capturedAt).toLocaleString()}</Text> : null}
        </View>
      </View>
      <TouchableOpacity
        style={s.gpsMapLink}
        onPress={() => Linking.openURL(`https://www.google.com/maps?q=${lat},${lng}`)}
        activeOpacity={0.75}
      >
        <Ionicons name="map-outline" size={15} color={colors.primary} />
        <Text style={s.gpsMapLinkText}>View on map</Text>
      </TouchableOpacity>
    </View>
  );
}

function DestinationCard({ pickup }: { pickup: any }) {
  const direct = pickup.is_direct_delivery && pickup.direct_delivery ? pickup.direct_delivery : null;
  const warehouse = pickup.target_warehouse || null;
  const title = direct ? "Direct Delivery" : "Target Warehouse";
  const main = direct
    ? direct.recipient_name || "Recipient"
    : warehouse?.name || "Warehouse not set";
  const destinationLocation = direct ? locationParts(direct.location || {}) : [warehouse?.town, warehouse?.district, warehouse?.region].filter(Boolean).join(", ");

  return (
    <View style={s.locationCard}>
      <View style={s.locationHeader}>
        <View style={[s.locationHeaderIcon, { backgroundColor: direct ? "#ffedd5" : "#dbeafe" }]}>
          <Ionicons name={direct ? "flash-outline" : "business-outline"} size={18} color={direct ? colors.primary : colors.info} />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.locationTitle}>{title}</Text>
          <Text style={s.locationMain} numberOfLines={2}>{main}</Text>
        </View>
      </View>
      <View style={s.locationDetails}>
        {direct?.recipient_phone ? (
          <TouchableOpacity style={s.locationDetailRow} onPress={() => Linking.openURL(`tel:${direct.recipient_phone}`)} activeOpacity={0.75}>
            <Ionicons name="call-outline" size={16} color={colors.textMuted} />
            <Text style={[s.locationDetailText, s.locationPhoneText]}>{formatPhone(direct.recipient_phone)}</Text>
          </TouchableOpacity>
        ) : null}
        {destinationLocation ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="location-outline" size={16} color={colors.textMuted} />
            <Text style={s.locationDetailText}>{destinationLocation}</Text>
          </View>
        ) : null}
        {warehouse?.contact_phone ? (
          <TouchableOpacity style={s.locationDetailRow} onPress={() => Linking.openURL(`tel:${warehouse.contact_phone}`)} activeOpacity={0.75}>
            <Ionicons name="call-outline" size={16} color={colors.textMuted} />
            <Text style={[s.locationDetailText, s.locationPhoneText]}>{formatPhone(warehouse.contact_phone)}</Text>
          </TouchableOpacity>
        ) : null}
        <View style={s.locationDetailRow}>
          <Ionicons name="navigate-circle-outline" size={16} color={colors.textMuted} />
          <Text style={s.locationDetailText}>
            {direct ? "Deliver directly after pickup." : "Deliver collected packages to this warehouse."}
          </Text>
        </View>
      </View>
    </View>
  );
}

function PackagesCard({ items, states, canConfirm, onOpen }: { items: any[]; states: Record<number, ItemConfirmState>; canConfirm: boolean; onOpen: (item: any) => void }) {
  return (
    <View style={s.packageListCard}>
      <View style={s.packageListHeader}>
        <Text style={s.packageListTitle}>Packages</Text>
      </View>

      {items.map((item: any, index: number) => {
        const state = states[item.id];
        const isConfirmed = Boolean(state?.confirmed);
        const photosCount = state?.photos?.length || 0;

        return (
          <TouchableOpacity
            key={item.id || index}
            style={[s.packageListItem, index === items.length - 1 && { borderBottomWidth: 0, paddingBottom: 0 }]}
            activeOpacity={0.78}
            onPress={() => onOpen(item)}
          >
            <View style={s.packageNumberBadge}>
              <Text style={s.packageNumberText}>{index + 1}</Text>
            </View>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={s.packageNameText} numberOfLines={2}>{item.description?.trim() || `Package ${index + 1}`}</Text>
              <View style={s.packageMetaRow}>
                {item.tracking_code ? <Text style={s.packageMetaText}>{item.tracking_code}</Text> : null}
                <Text style={[s.packageStatusText, isConfirmed ? s.packageStatusConfirmed : s.packageStatusPending]}>
                  {isConfirmed ? "Confirmed" : "Pending"}
                </Text>
                {photosCount > 0 ? <Text style={s.packageMetaText}>{photosCount} photo{photosCount === 1 ? "" : "s"}</Text> : null}
              </View>
            </View>
            {canConfirm ? (
              <Text style={s.packageActionText}>{isConfirmed ? "Edit" : "Confirm"}</Text>
            ) : (
              <Text style={s.packageActionText}>View</Text>
            )}
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

function PickupDetailSkeleton({ topInset, bottomInset }: { topInset: number; bottomInset: number }) {
  const darkSkeleton = { backgroundColor: "rgba(255,255,255,0.22)" };

  return (
    <View style={s.container}>
      <ScrollView contentContainerStyle={{ paddingBottom: bottomInset + 120 }}>
        <LinearGradient colors={["#0f172a", "#1e3a5f", "#0f172a"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: topInset + 12 }]}>
          <View style={s.heroDecor1} />
          <View style={s.headerTop}>
            <View style={s.skeletonBackBtn}>
              <ShimmerLoading width={18} height={18} borderRadius={9} style={darkSkeleton} />
            </View>
            <View style={{ flex: 1, gap: 7 }}>
              <ShimmerLoading width={120} height={20} borderRadius={8} style={darkSkeleton} />
              <ShimmerLoading width={148} height={12} borderRadius={6} style={darkSkeleton} />
            </View>
            <ShimmerLoading width={88} height={34} borderRadius={17} style={darkSkeleton} />
          </View>

          <View style={s.heroSummaryGrid}>
            {[0, 1, 2].map((item) => (
              <View key={item} style={s.heroSummaryCard}>
                <ShimmerLoading width={34} height={34} borderRadius={11} style={darkSkeleton} />
                <ShimmerLoading width="74%" height={20} borderRadius={8} style={darkSkeleton} />
                <ShimmerLoading width="56%" height={11} borderRadius={6} style={darkSkeleton} />
              </View>
            ))}
          </View>
        </LinearGradient>

        <View style={s.body}>
          {[0, 1].map((card) => (
            <View key={card} style={s.locationCard}>
              <View style={s.locationHeader}>
                <ShimmerLoading width={36} height={36} borderRadius={12} />
                <View style={{ flex: 1, gap: 8 }}>
                  <ShimmerLoading width={card === 0 ? "44%" : "38%"} height={13} borderRadius={6} />
                  <ShimmerLoading width={card === 0 ? "82%" : "58%"} height={16} borderRadius={7} />
                </View>
              </View>
              <View style={s.locationDetails}>
                {[0, 1, 2].map((row) => (
                  <View key={row} style={s.locationDetailRow}>
                    <ShimmerLoading width={14} height={14} borderRadius={7} />
                    <ShimmerLoading width={row === 2 ? "64%" : "48%"} height={13} borderRadius={6} />
                  </View>
                ))}
              </View>
            </View>
          ))}

          <View style={s.packageListCard}>
            <View style={s.packageListHeader}>
              <ShimmerLoading width={92} height={14} borderRadius={7} />
            </View>
            {[0, 1, 2].map((item) => (
              <View key={item} style={[s.packageListItem, item === 2 && { borderBottomWidth: 0, paddingBottom: 0 }]}>
                <ShimmerLoading width={36} height={36} borderRadius={10} />
                <View style={{ flex: 1, gap: 8 }}>
                  <ShimmerLoading width="70%" height={16} borderRadius={7} />
                  <ShimmerLoading width="58%" height={11} borderRadius={6} />
                </View>
                <ShimmerLoading width={54} height={14} borderRadius={7} />
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, gap: 12, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  skeletonBackBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  heroSummaryGrid: { flexDirection: "row", gap: 8, marginTop: 2 },
  heroSummaryCard: { flex: 1, minHeight: 96, alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: "rgba(255,255,255,0.1)", borderRadius: 15, paddingHorizontal: 8, paddingVertical: 12, borderWidth: 1, borderColor: "rgba(255,255,255,0.18)" },
  heroSummaryIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: "rgba(255,255,255,0.16)", justifyContent: "center", alignItems: "center" },
  heroSummaryValue: { width: "100%", fontFamily: fontFamily.bold, fontSize: 20, color: colors.white, textAlign: "center", letterSpacing: -0.3 },
  heroSummaryLabel: { fontFamily: fontFamily.semibold, fontSize: 10, color: "rgba(255,255,255,0.72)", textAlign: "center", lineHeight: 14 },
  body: { padding: 16, gap: 14 },
  locationCard: { borderWidth: 1, borderColor: colors.neutral200, borderRadius: 16, padding: 14, backgroundColor: colors.white, shadowColor: colors.black, shadowOpacity: 0.04, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1, gap: 10 },
  locationHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  locationHeaderIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: "#dcfce7", justifyContent: "center", alignItems: "center" },
  locationTitle: { fontFamily: fontFamily.bold, fontSize: 14, lineHeight: 18, color: colors.dark, textTransform: "uppercase", letterSpacing: 0.4 },
  locationMain: { fontFamily: fontFamily.bold, fontSize: 17, color: colors.dark, marginTop: 4, lineHeight: 23 },
  locationDetails: { borderLeftWidth: 2, borderLeftColor: colors.neutral200, marginLeft: 17, paddingLeft: 18, gap: 10 },
  locationDetailRow: { flexDirection: "row", alignItems: "flex-start", gap: 9 },
  locationDetailText: { flex: 1, minWidth: 0, fontFamily: fontFamily.medium, fontSize: 14, color: colors.text, lineHeight: 20 },
  locationPhoneText: { fontFamily: fontFamily.semibold, fontSize: 16, lineHeight: 22, color: colors.primary },
  locationActionText: { color: colors.primary, textDecorationLine: "underline" },
  progressActionCard: { borderWidth: 1, borderColor: colors.accentLighter, borderRadius: 16, padding: 14, backgroundColor: colors.warmSurface, shadowColor: colors.black, shadowOpacity: 0.04, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1, gap: 12 },
  progressActionButton: { height: 46, borderRadius: 23, backgroundColor: colors.primary, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  progressActionButtonDisabled: { opacity: 0.72 },
  progressActionButtonText: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.white },
  gpsProofCard: { borderWidth: 1, borderColor: "#bbf7d0", borderRadius: 16, padding: 14, backgroundColor: "#f0fdf4", shadowColor: colors.black, shadowOpacity: 0.04, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1, gap: 12 },
  gpsProofTime: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, marginTop: 2 },
  gpsMapLink: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 6, borderRadius: 16, backgroundColor: colors.white, paddingHorizontal: 12, paddingVertical: 8, borderWidth: 1, borderColor: colors.neutral200 },
  gpsMapLinkText: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.primary },
  detailCard: { borderWidth: 1, borderColor: colors.neutral200, borderRadius: 16, padding: 14, backgroundColor: colors.white, shadowColor: colors.black, shadowOpacity: 0.04, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1, gap: 12 },
  detailCardHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  detailIconWrap: { width: 36, height: 36, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  detailTitle: { fontFamily: fontFamily.bold, fontSize: 14, lineHeight: 18, color: colors.dark, textTransform: "uppercase", letterSpacing: 0.4 },
  detailSub: { fontFamily: fontFamily.regular, fontSize: 13, lineHeight: 19, color: colors.textMuted, marginTop: 2 },
  packageListCard: { backgroundColor: colors.white, borderRadius: 18, paddingTop: 16, paddingBottom: 14, borderWidth: 1, borderColor: colors.border, overflow: "hidden" },
  packageListHeader: { paddingHorizontal: 16, paddingBottom: 12 },
  packageListTitle: { fontFamily: fontFamily.bold, fontSize: 14, lineHeight: 18, color: colors.dark, letterSpacing: 0.5, textTransform: "uppercase" },
  packageListItem: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  packageNumberBadge: { width: 36, height: 36, borderRadius: 10, backgroundColor: "#dbeafe", justifyContent: "center", alignItems: "center" },
  packageNumberText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.primary },
  packageNameText: { fontFamily: fontFamily.bold, fontSize: 16, color: colors.dark, lineHeight: 22 },
  packageMetaRow: { flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap", marginTop: 4 },
  packageMetaText: { fontFamily: fontFamily.medium, fontSize: 13, lineHeight: 18, color: colors.textMuted },
  packageStatusText: { fontFamily: fontFamily.semibold, fontSize: 11, lineHeight: 16, textTransform: "uppercase", letterSpacing: 0.4 },
  packageStatusConfirmed: { color: colors.success },
  packageStatusPending: { color: colors.primary },
  packageActionText: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.primary, textDecorationLine: "underline" },
  footer: { position: "absolute", left: 0, right: 0, bottom: 0, paddingHorizontal: 16, paddingTop: 12, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.border },
  successBanner: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#dcfce7", paddingVertical: 14, borderRadius: 24, width: "100%" },
  successText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.success },
  modalOverlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(15,23,42,0.45)" },
  keyboardAvoider: { flex: 1, justifyContent: "flex-end" },
  keyboardAvoiderContent: { flex: 1, justifyContent: "flex-end" },
  actionSheet: { maxHeight: "88%", backgroundColor: colors.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 16, paddingTop: 10, gap: 12 },
  sheetHandle: { alignSelf: "center", width: 42, height: 4, borderRadius: 2, backgroundColor: colors.neutral300 },
  actionSheetHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  cardIconWrap: { width: 34, height: 34, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  actionSheetTitle: { fontFamily: fontFamily.bold, fontSize: 16, color: colors.dark },
  actionSheetSub: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: 2 },
  actionSheetClose: { width: 34, height: 34, borderRadius: 17, justifyContent: "center", alignItems: "center", backgroundColor: colors.surface },
  actionSheetScroll: { maxHeight: 460 },
  actionSheetContent: { gap: 14, paddingBottom: 120 },
  readOnlyPanel: { borderWidth: 1, borderColor: colors.neutral100, borderRadius: 14, paddingHorizontal: 12, backgroundColor: colors.surface },
  detailRow: { flexDirection: "row", alignItems: "flex-start", gap: 10, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.neutral200 },
  detailLabel: { fontFamily: fontFamily.semibold, fontSize: 10, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.4 },
  detailValue: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.dark, marginTop: 2, lineHeight: 18 },
  photoSection: { gap: 8 },
  photoSectionTitle: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.dark, textTransform: "uppercase", letterSpacing: 0.4 },
  photosRow: { flexDirection: "row", gap: 10, flexWrap: "wrap" },
  photoWrap: { position: "relative" },
  photo: { width: 64, height: 64, borderRadius: 10 },
  photoRemove: { position: "absolute", top: -6, right: -6, backgroundColor: colors.white, borderRadius: 10 },
  photoBtn: { width: 64, height: 64, borderRadius: 10, borderWidth: 2, borderColor: colors.border, borderStyle: "dashed", justifyContent: "center", alignItems: "center", backgroundColor: colors.surface, gap: 2 },
  photoBtnText: { fontFamily: fontFamily.medium, fontSize: 10, color: colors.primary },
  lightbox: { flex: 1, backgroundColor: "rgba(0,0,0,0.95)", justifyContent: "center" },
  lightboxHeader: { position: "absolute", left: 0, right: 0, flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 20, zIndex: 10 },
  lightboxCount: { fontFamily: fontFamily.medium, fontSize: 14, color: colors.white },
  lightboxClose: { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.15)", justifyContent: "center", alignItems: "center" },
  lightboxImage: { height: "80%" },
  lightboxError: { alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 24 },
  lightboxErrorTitle: { fontFamily: fontFamily.bold, fontSize: 16, color: colors.white },
  lightboxErrorText: { fontFamily: fontFamily.regular, fontSize: 13, color: "rgba(255,255,255,0.68)", textAlign: "center" },
  deliveryModalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center", padding: 24 },
  deliveryModalSheet: { backgroundColor: colors.white, borderRadius: 24, padding: 24, alignItems: "center", width: "100%", gap: 12 },
  deliveryModalTitle: { fontFamily: fontFamily.bold, fontSize: 20, color: colors.dark },
  deliveryModalSub: { fontFamily: fontFamily.regular, fontSize: 13, color: colors.textMuted, textAlign: "center", lineHeight: 20 },
  deliveryModalInfoCard: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.warmSurface, borderRadius: 12, padding: 14, width: "100%", borderWidth: 1, borderColor: colors.accentLighter },
  deliveryModalInfoName: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.dark },
  deliveryModalInfoLoc: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: 2 },
  deliveryModalPrimaryBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: colors.primary, borderRadius: 24, paddingVertical: 14, width: "100%", marginTop: 4 },
  deliveryModalPrimaryText: { fontFamily: fontFamily.semibold, fontSize: 15, color: colors.white },
  deliveryModalSecondaryBtn: { paddingVertical: 10 },
  deliveryModalSecondaryText: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.textMuted },
});
