import { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Dimensions,
  Image,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import DateTimePicker from "@react-native-community/datetimepicker";
import * as Location from "expo-location";
import Input from "../../../../../src/components/common/Input";
import Button from "../../../../../src/components/common/Button";
import Dropdown from "../../../../../src/components/common/Dropdown";
import ImagePickerButton from "../../../../../src/components/common/ImagePickerButton";
import ShimmerLoading from "../../../../../src/components/common/ShimmerLoading";
import { colors } from "../../../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../../../src/constants/typography";
import { getDeliveryRun, arriveAtStop, confirmPackages, confirmHandoff, failStop, getBusStations, getDeliveryFailureReasons, updateDeliveryItemEta, type BusStation, type ConfirmPackagesData } from "../../../../../src/api/v1/driver/deliveries";
import { showSuccess, showError, getErrorMessage } from "../../../../../src/utils/toast";
import { formatCurrency, formatPhone, formatDateTimeAmPm as formatDateTime, isValidGhanaPhone, sanitizeLocalPhoneInput } from "../../../../../src/utils/format";

const { width } = Dimensions.get("window");

const SKIP_REASONS = [
  { label: "SMS not received by recipient", value: "SMS not received" },
  { label: "Recipient's phone is off", value: "Recipient phone off" },
  { label: "Recipient has no phone", value: "Recipient has no phone" },
  { label: "Network issues with SMS", value: "Network issues" },
  { label: "Recipient forgot the code", value: "Recipient forgot code" },
  { label: "Code expired before entry", value: "Code expired" },
];

const MAX_STATION_SUGGESTIONS = 6;

function etaQuickDate(choice: string) {
  const now = new Date();
  if (choice === "1h") return new Date(now.getTime() + 60 * 60 * 1000);
  if (choice === "2h") return new Date(now.getTime() + 2 * 60 * 60 * 1000);
  if (choice === "evening") {
    const date = new Date(now);
    date.setHours(18, 0, 0, 0);
    if (date <= now) date.setDate(date.getDate() + 1);
    return date;
  }
  if (choice === "tomorrow") {
    const date = new Date(now);
    date.setDate(date.getDate() + 1);
    date.setHours(9, 0, 0, 0);
    return date;
  }
  return now;
}

function etaToneColor(tone?: string) {
  if (tone === "rose") return colors.error;
  if (tone === "amber") return "#d97706";
  if (tone === "blue") return colors.primary;
  if (tone === "emerald") return colors.success;
  return colors.textMuted;
}

function editableDeliveryFeeAmount(deliveryFee: any) {
  const amounts = [
    deliveryFee?.outstanding_amount,
    deliveryFee?.total_amount,
    deliveryFee?.paid_amount,
  ];

  for (const amount of amounts) {
    const value = Number(amount || 0);
    if (Number.isFinite(value) && value > 0) return value.toFixed(2);
  }

  return "";
}

function stopStatusDisplay(status: string) {
  const config: Record<string, { label: string; icon: keyof typeof Ionicons.glyphMap; color: string; bgColor: string }> = {
    pending: { label: "Pending", icon: "time-outline", color: colors.textMuted, bgColor: colors.neutral100 },
    arrived: { label: "Arrived", icon: "location-outline", color: colors.primary, bgColor: colors.warmSurface },
    delivered: { label: "Delivered", icon: "checkmark-done-outline", color: colors.success, bgColor: colors.successLight },
    handed_off: { label: "Handed Off", icon: "bus-outline", color: "#7c3aed", bgColor: "#ede9fe" },
    failed: { label: "Failed", icon: "close-circle-outline", color: colors.error, bgColor: colors.errorLight },
  };

  return config[status] || {
    label: status ? status.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()) : "—",
    icon: "ellipse-outline" as keyof typeof Ionicons.glyphMap,
    color: colors.textMuted,
    bgColor: colors.neutral100,
  };
}

function uniqueVendorsFromItems(items: any[]) {
  const vendors = new Map<string, any>();

  for (const item of items) {
    if (item.vendor?.name) {
      const key = item.vendor.phone || item.vendor.name;
      if (!vendors.has(key)) vendors.set(key, item.vendor);
    }
  }

  return Array.from(vendors.values());
}

async function getBestEffortCoordinates(): Promise<{ latitude?: number; longitude?: number }> {
  try {
    const { status } = await Promise.race([
      Location.requestForegroundPermissionsAsync(),
      new Promise<{ status: Location.PermissionStatus }>((resolve) => {
        setTimeout(() => resolve({ status: Location.PermissionStatus.UNDETERMINED }), 3500);
      }),
    ]);

    if (status !== Location.PermissionStatus.GRANTED) {
      return {};
    }

    const loc = await Promise.race([
      Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }),
      new Promise<null>((resolve) => {
        setTimeout(() => resolve(null), 5000);
      }),
    ]);

    if (!loc) {
      return {};
    }

    return {
      latitude: loc.coords.latitude,
      longitude: loc.coords.longitude,
    };
  } catch {
    return {};
  }
}

export default function StopDetailScreen() {
  const insets = useSafeAreaInsets();
  const { id, stopId } = useLocalSearchParams<{ id: string; stopId: string }>();
  const deliveryRunRoute = {
    pathname: "/(driver)/delivery/[id]",
    params: { id: String(id) },
  } as const;
  const leaveStopDetail = () => {
    if (router.canGoBack()) router.back();
    else router.replace(deliveryRunRoute as any);
  };
  const [stop, setStop] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [etaModalOpen, setEtaModalOpen] = useState(false);
  const [etaLoading, setEtaLoading] = useState(false);
  const [etaTargetItems, setEtaTargetItems] = useState<any[]>([]);
  const [etaDate, setEtaDate] = useState<Date>(etaQuickDate("1h"));
  const [showEtaPicker, setShowEtaPicker] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showFailModal, setShowFailModal] = useState(false);

  const [verificationCode, setVerificationCode] = useState("");
  const [proofPhotos, setProofPhotos] = useState<string[]>([]);
  const [packagesDelivered, setPackagesDelivered] = useState(0);
  const [skipVerification, setSkipVerification] = useState(false);
  const [skipReason, setSkipReason] = useState("");
  const [deliveryNotes, setDeliveryNotes] = useState("");
  const [lightboxImages, setLightboxImages] = useState<string[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const scrollRef = useRef<ScrollView>(null);

  const [busStationName, setBusStationName] = useState("");
  const [busStations, setBusStations] = useState<BusStation[]>([]);
  const [stationSuggestionsOpen, setStationSuggestionsOpen] = useState(false);
  const [stationListLoading, setStationListLoading] = useState(false);
  const [failureReasonOptions, setFailureReasonOptions] = useState<Array<{ label: string; value: string }>>([]);
  const [failureReasonsLoading, setFailureReasonsLoading] = useState(false);
  const [courierName, setCourierName] = useState("");
  const [courierPhone, setCourierPhone] = useState("");
  const [courierPhoneError, setCourierPhoneError] = useState("");
  const [vehicleNumber, setVehicleNumber] = useState("");
  const [stationFee, setStationFee] = useState("");
  const [handoffPhotos, setHandoffPhotos] = useState<string[]>([]);
  const [deliveryFeeAmount, setDeliveryFeeAmount] = useState("");

  const [failReason, setFailReason] = useState<string | null>(null);
  const [failNotes, setFailNotes] = useState("");
  const [failReasonDropdownOpen, setFailReasonDropdownOpen] = useState(false);

  const [warehousePhone, setWarehousePhone] = useState<string | null>(null);
  const [allowSkipVerification, setAllowSkipVerification] = useState(false);

  useEffect(() => {
    setStationListLoading(true);
    getBusStations()
      .then((res) => setBusStations(Array.isArray(res.data?.bus_stations) ? res.data.bus_stations : []))
      .catch(() => {
        // Riders can still type the station manually if the list cannot load.
      })
      .finally(() => setStationListLoading(false));

    setFailureReasonsLoading(true);
    getDeliveryFailureReasons()
      .then((res) => {
        const reasons = Array.isArray(res.data?.reasons) ? res.data.reasons : [];
        setFailureReasonOptions(
          reasons
            .filter((reason) => reason.type === "failed")
            .map((reason) => ({ label: reason.label, value: reason.label })),
        );
      })
      .catch(() => {
        setFailureReasonOptions([]);
      })
      .finally(() => setFailureReasonsLoading(false));
  }, []);

  useEffect(() => {
    getDeliveryRun(Number(id))
      .then((res) => {
        const run = (res.data as any)?.delivery || (res.data as any)?.delivery_run || res.data;
        const s = (run.stops || []).find((st: any) => String(st.id) === String(stopId));
        setStop(s);
        if (s?.handoff?.bus_station) setBusStationName(String(s.handoff.bus_station));
        if (run.warehouse?.contact_phone) setWarehousePhone(run.warehouse.contact_phone);
        if (run.allow_skip_verification) setAllowSkipVerification(true);

        const stopItems = s?.items || [];
        const itemQuantityTotal = stopItems.reduce((sum: number, item: any) => sum + Number(item?.expected_quantity || 0), 0);
        const stopQuantity = Number(s?.total_packages || 0) || itemQuantityTotal || stopItems.length;
        if (stopQuantity) setPackagesDelivered(stopQuantity);
      })
      .catch((err) => showError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [id, stopId]);

  useEffect(() => {
    setDeliveryFeeAmount(editableDeliveryFeeAmount(stop?.delivery_fee));
  }, [stop?.id, stop?.delivery_fee?.outstanding_amount, stop?.delivery_fee?.total_amount, stop?.delivery_fee?.paid_amount]);

  const openEtaModal = (targetItems: any[]) => {
    const validItems = targetItems.filter(Boolean);
    if (!validItems.length) return;
    const firstEta = validItems[0]?.eta?.expected_delivery_at_iso;
    setEtaTargetItems(validItems);
    setEtaDate(firstEta ? new Date(firstEta) : etaQuickDate("1h"));
    setEtaModalOpen(true);
  };

  const saveEta = async () => {
    if (!etaTargetItems.length) return;
    if (etaDate <= new Date()) {
      showError("Choose a future ETA");
      return;
    }

    setEtaLoading(true);
    try {
      const expectedDeliveryAt = etaDate.toISOString();
      const results = await Promise.all(
        etaTargetItems.map((item) => updateDeliveryItemEta(Number(item.delivery_run_item_id || item.id), {
          expected_delivery_at: expectedDeliveryAt,
        })),
      );

      const etaById = new Map<number, any>();
      results.forEach((res, index) => {
        const itemId = Number(etaTargetItems[index]?.delivery_run_item_id || etaTargetItems[index]?.id);
        etaById.set(itemId, res?.data?.item?.eta);
      });

      setStop((prev: any) => ({
        ...prev,
        items: (prev?.items || []).map((item: any) => {
          const itemId = Number(item.delivery_run_item_id || item.id);
          return etaById.has(itemId) ? { ...item, eta: etaById.get(itemId) } : item;
        }),
      }));
      setEtaModalOpen(false);
      showSuccess(etaTargetItems.length > 1 ? "ETAs updated" : "ETA updated");
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setEtaLoading(false);
    }
  };

  const handleArrive = async () => {
    setActionLoading(true);
    try {
      await arriveAtStop(Number(id), Number(stopId));
      setStop((prev: any) => ({ ...prev, status: "arrived", arrived_at: new Date().toISOString() }));
      showSuccess("Arrival marked!");
      setShowConfirmModal(true);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  const handleConfirm = async () => {
    if (!skipVerification && (!verificationCode.trim() || verificationCode.length !== 4)) {
      showError("Please enter the 4-digit verification code");
      return;
    }
    if (skipVerification && !skipReason.trim()) {
      showError("Please provide a reason for skipping verification");
      return;
    }
    if (proofPhotos.length === 0) {
      showError("Please take a proof photo");
      return;
    }

    let inFieldDeliveryFee: number | undefined;

    if (packagesDelivered > 0 && stop?.delivery_method !== "bus_handoff") {
      const feeText = deliveryFeeAmount.trim();
      if (feeText) {
        const parsed = Number(feeText.replace(/,/g, ""));
        if (Number.isNaN(parsed) || parsed < 0) {
          showError("Delivery fee collected must be a valid amount");
          return;
        }
        if (parsed > 0) inFieldDeliveryFee = parsed;
      }
    }

    setActionLoading(true);
    try {
      const { latitude, longitude } = await getBestEffortCoordinates();

      const payload: ConfirmPackagesData = {
        verification_code: skipVerification ? undefined : verificationCode.trim(),
        skip_verification: skipVerification || undefined,
        skip_reason: skipVerification ? skipReason.trim() : undefined,
        packages_delivered: packagesDelivered,
        proof_photo: proofPhotos[0],
        delivery_notes: deliveryNotes.trim() || undefined,
        in_field_delivery_fee: inFieldDeliveryFee,
      };

      if (Number.isFinite(latitude) && Number.isFinite(longitude)) {
        payload.latitude = latitude;
        payload.longitude = longitude;
      }

      await confirmPackages(Number(id), Number(stopId), payload);

      showSuccess(skipVerification ? "Delivery confirmed (flagged for review)" : "Delivery confirmed!");
      router.replace(deliveryRunRoute as any);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  const handleHandoff = async () => {
    if (handoffPhotos.length === 0) {
      showError("Please take a proof photo");
      return;
    }

    const courierPhoneDigits = sanitizeLocalPhoneInput(courierPhone);
    if (courierPhoneDigits.length > 0 && !isValidGhanaPhone(courierPhoneDigits)) {
      setCourierPhoneError("Enter a valid 10-digit Ghana phone number");
      showError("Enter a valid bus rider phone number");
      return;
    }

    const feeText = stationFee.trim();
    let feeValue: number | undefined;
    if (feeText) {
      const parsed = Number(feeText);
      if (Number.isNaN(parsed) || parsed < 0) {
        showError("Amount paid must be a valid number");
        return;
      }
      feeValue = parsed;
    }

    setActionLoading(true);
    try {
      const { latitude, longitude } = await getBestEffortCoordinates();

      await confirmHandoff(Number(id), Number(stopId), {
        proof_photo: handoffPhotos[0],
        bus_station_name: busStationName.trim() || undefined,
        courier_name: courierName.trim() || undefined,
        courier_phone: courierPhoneDigits || undefined,
        vehicle_number: vehicleNumber.trim() || undefined,
        station_fee: feeValue,
        latitude,
        longitude,
      });

      showSuccess("Handoff confirmed! Packages handed over.");
      router.replace(deliveryRunRoute as any);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  const handleFail = async () => {
    if (!failReason) {
      showError("Please select a reason");
      return;
    }

    setActionLoading(true);
    try {
      await failStop(Number(id), Number(stopId), { reason: failReason, notes: failNotes || undefined });
      showSuccess("Stop marked as failed");
      router.replace(deliveryRunRoute as any);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return <StopDetailSkeleton topInset={insets.top} bottomInset={insets.bottom} />;
  }

  if (!stop) return null;

  const stationSearch = busStationName.trim().toLowerCase();
  const stationSuggestions = busStations
    .filter((station) => {
      if (!stationSearch) return true;
      return `${station.name} ${station.location_hint || ""}`.toLowerCase().includes(stationSearch);
    })
    .slice(0, MAX_STATION_SUGGESTIONS);
  const courierPhoneDigits = sanitizeLocalPhoneInput(courierPhone);
  const courierPhoneHelper = courierPhoneDigits.length === 0
    ? ""
    : courierPhoneDigits.length < 10
      ? `${courierPhoneDigits.length}/10 digits entered`
      : !isValidGhanaPhone(courierPhoneDigits)
        ? "Enter a valid Ghana phone number, e.g. 0551234567"
        : "";

  const loc = stop.location || {};
  const locationStr = [loc.town, loc.district, loc.region].filter(Boolean).join(", ");
  const items = stop.items || [];
  const activeEtaItems = items.filter((item: any) => item?.eta?.can_update !== false && !["delivered", "failed"].includes(String(item?.status || "")));
  const itemQuantityTotal = items.reduce((sum: number, item: any) => sum + Number(item?.expected_quantity || 0), 0);
  const packageLineCount = Math.max(items.length, 1);
  const stopPackageQuantity = Number(stop.total_packages || 0) || itemQuantityTotal || items.length;
  const isFailed = stop.status === "failed";
  const isPending = stop.status === "pending";
  const isArrived = stop.status === "arrived";
  const deliveryFee = stop.delivery_fee || null;
  const heroDeliveryFeeAmount = deliveryFeeAmount.trim() || editableDeliveryFeeAmount(deliveryFee);
  const savedHandoffAmount = Number(stop.handoff?.amount_paid || 0);
  const deliveryFeeStatus = String(deliveryFee?.status || "").toLowerCase();
  const heroFeeAmount = stop.delivery_method === "bus_handoff"
    ? (stationFee.trim()
      ? `GHS ${stationFee.trim()}`
      : (Number.isFinite(savedHandoffAmount) && savedHandoffAmount > 0
        ? formatCurrency(savedHandoffAmount, stop.handoff?.currency || "GHS")
        : "Not set"))
    : (heroDeliveryFeeAmount ? `GHS ${heroDeliveryFeeAmount}` : "Not set");
  const heroFeeLabel = stop.delivery_method === "bus_handoff"
    ? "Station Fee"
    : `Delivery Fee${deliveryFeeStatus === "paid" ? " · Paid" : ""}`;
  const vendors = uniqueVendorsFromItems(items);
  const isBusHandoffStop = stop.delivery_method === "bus_handoff";

  return (
    <View style={s.container}>
      <ScrollView
        ref={scrollRef}
        contentContainerStyle={{ paddingBottom: insets.bottom + 300 }}
        keyboardShouldPersistTaps="handled"
        automaticallyAdjustKeyboardInsets
      >
        <LinearGradient colors={["#0f172a", "#1e3a5f", "#0f172a"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
          <View style={s.heroDecor1} />
          <View style={s.headerTop}>
            <TouchableOpacity onPress={leaveStopDetail} style={s.backBtn}>
              <Ionicons name="arrow-back" size={22} color={colors.white} />
            </TouchableOpacity>
            <View style={{ flex: 1 }}>
              <Text style={s.headerTitle}>{stop.recipient_name}</Text>
              <Text style={s.headerSub}>{isBusHandoffStop ? "Station Handoff" : "Delivery Stop"}</Text>
            </View>
            <StopStatusPill status={stop.status} />
          </View>

          <View style={s.heroSummaryGrid}>
            <View style={s.heroSummaryCard}>
              <View style={s.heroSummaryIcon}>
                <Ionicons name="cube-outline" size={18} color={colors.white} />
              </View>
              <View>
                <Text style={s.heroSummaryValue}>
                  {packageLineCount} {packageLineCount === 1 ? "package" : "packages"}
                </Text>
                <Text style={s.heroSummaryLabel}>
                  {stopPackageQuantity} {stopPackageQuantity === 1 ? "item" : "items"}
                </Text>
              </View>
            </View>
            <View style={s.heroSummaryCard}>
              <View style={s.heroSummaryIcon}>
                <Ionicons name={stop.delivery_method === "bus_handoff" ? "cash-outline" : "wallet-outline"} size={18} color={colors.white} />
              </View>
              <View>
                <Text style={s.heroSummaryValue}>{heroFeeAmount}</Text>
                <Text style={s.heroSummaryLabel}>{heroFeeLabel}</Text>
              </View>
            </View>
          </View>
        </LinearGradient>

        <View style={s.body}>
          {isBusHandoffStop ? (
            <StationHandoffCard
              stop={stop}
              locationStr={locationStr}
              loc={loc}
              onOpenProof={(url) => {
                setLightboxImages([url]);
                setLightboxIndex(0);
              }}
            />
          ) : (
            <RecipientLocationCard stop={stop} locationStr={locationStr} loc={loc} />
          )}

          {!isBusHandoffStop && vendors.map((vendor, i) => (
            <SenderCard key={vendor.phone || vendor.name || i} vendor={vendor} />
          ))}

          {items.length > 0 && (
            <PackageListCard
              items={items}
              showSender={isBusHandoffStop}
              onSetEta={(item) => openEtaModal([item])}
              onSetAllEta={activeEtaItems.length > 1 ? () => openEtaModal(activeEtaItems) : undefined}
            />
          )}

          {isFailed && (
            <View style={s.failCard}>
              <Ionicons name="close-circle" size={32} color={colors.error} />
              <Text style={s.failTitle}>Delivery Failed</Text>
              <Text style={s.failSub}>Reason: {stop.failure_reason || "Unknown"}</Text>
              {stop.failure_notes && <Text style={s.failSub}>Notes: {stop.failure_notes}</Text>}
            </View>
          )}
        </View>
      </ScrollView>

      {(isPending || isArrived) && (
        <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
          {isPending && (
            <Button title="I've Arrived" onPress={handleArrive} loading={actionLoading} leftIcon={<Ionicons name="location" size={18} color={colors.white} />} gradientColors={[colors.success, "#16a34a"] as [string, string]} />
          )}
          {isArrived && (
            <Button title={stop?.delivery_method === "bus_handoff" ? "Confirm Handoff" : "Confirm Delivery"} onPress={() => setShowConfirmModal(true)} loading={actionLoading} leftIcon={<Ionicons name="checkmark-circle" size={18} color={colors.white} />} gradientColors={[colors.success, "#16a34a"] as [string, string]} />
          )}
        </View>
      )}

      <Modal visible={etaModalOpen} transparent animationType="fade" onRequestClose={() => setEtaModalOpen(false)} presentationStyle="overFullScreen">
        <View style={s.centerModalOverlay}>
          <View style={s.etaModalCard}>
            <View style={s.etaModalHeader}>
              <View style={[s.cardIconWrap, { backgroundColor: colors.warmSurface }]}>
                <Ionicons name="time-outline" size={19} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={s.actionSheetTitle}>{etaTargetItems.length > 1 ? "Set ETA for stop" : "Set package ETA"}</Text>
                <Text style={s.actionSheetSub}>{etaTargetItems.length} package{etaTargetItems.length === 1 ? "" : "s"}</Text>
              </View>
              <TouchableOpacity style={s.actionSheetClose} onPress={() => setEtaModalOpen(false)} disabled={etaLoading}>
                <Ionicons name="close" size={20} color={colors.textMuted} />
              </TouchableOpacity>
            </View>

            <View style={s.etaQuickGrid}>
              {[
                ["1h", "+1 hour"],
                ["2h", "+2 hours"],
                ["evening", "Today evening"],
                ["tomorrow", "Tomorrow morning"],
              ].map(([value, label]) => (
                <TouchableOpacity key={value} style={s.etaQuickBtn} onPress={() => setEtaDate(etaQuickDate(value))} activeOpacity={0.75}>
                  <Text style={s.etaQuickText}>{label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity style={s.etaDateBox} onPress={() => setShowEtaPicker(true)} activeOpacity={0.8}>
              <View>
                <Text style={s.etaDateLabel}>Expected delivery</Text>
                <Text style={s.etaDateText}>{formatDateTime(etaDate.toISOString())}</Text>
              </View>
              <Ionicons name="calendar-outline" size={20} color={colors.primary} />
            </TouchableOpacity>

            {showEtaPicker && (
              <DateTimePicker
                value={etaDate}
                mode={Platform.OS === "ios" ? "datetime" : "date"}
                minimumDate={new Date()}
                onChange={(_, selectedDate) => {
                  setShowEtaPicker(Platform.OS === "ios");
                  if (selectedDate) setEtaDate(selectedDate);
                }}
              />
            )}

            <View style={s.etaModalActions}>
              <TouchableOpacity style={s.etaCancelBtn} onPress={() => setEtaModalOpen(false)} disabled={etaLoading} activeOpacity={0.8}>
                <Text style={s.etaCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.etaSaveBtn, etaLoading && { opacity: 0.6 }]} onPress={saveEta} disabled={etaLoading} activeOpacity={0.85}>
                {etaLoading ? <ActivityIndicator color={colors.white} /> : <Text style={s.etaSaveText}>Save ETA</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {lightboxImages.length > 0 && (
        <Modal visible transparent animationType="fade" onRequestClose={() => setLightboxImages([])}>
          <Pressable style={s.lightboxOverlay} onPress={() => setLightboxImages([])}>
            <TouchableOpacity
              style={[s.lightboxClose, { top: insets.top + 12 }]}
              onPress={() => setLightboxImages([])}
              activeOpacity={0.85}
            >
              <Ionicons name="close" size={24} color={colors.white} />
            </TouchableOpacity>
            <Pressable onPress={(event) => event.stopPropagation()} style={s.lightboxImageWrap}>
              <Image source={{ uri: lightboxImages[lightboxIndex] }} style={s.lightboxImg} resizeMode="contain" />
            </Pressable>
          </Pressable>
        </Modal>
      )}

      <Modal visible={showConfirmModal} transparent animationType="fade" onRequestClose={() => setShowConfirmModal(false)} presentationStyle="overFullScreen">
        <View style={s.actionModalOverlay}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} keyboardVerticalOffset={0} style={s.keyboardAvoider}>
            <View style={[s.actionSheet, { paddingBottom: insets.bottom + 18 }]}>
              <View style={s.stepsHandle} />
              <View style={s.actionSheetHeader}>
                <View style={[s.cardIconWrap, { backgroundColor: stop.delivery_method === "bus_handoff" ? "#ede9fe" : "#dcfce7" }]}>
                  <Ionicons name={stop.delivery_method === "bus_handoff" ? "bus" : "checkmark-circle"} size={18} color={stop.delivery_method === "bus_handoff" ? "#7c3aed" : colors.success} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.actionSheetTitle}>{stop.delivery_method === "bus_handoff" ? "Confirm Handoff" : "Confirm Delivery"}</Text>
                  <Text style={s.actionSheetSub}>{stop.recipient_name || "Delivery stop"}</Text>
                </View>
                <TouchableOpacity
                  style={s.headerFailLink}
                  onPress={() => {
                    setShowConfirmModal(false);
                    setShowFailModal(true);
                  }}
                  activeOpacity={0.75}
                >
                  <Text style={s.headerFailLinkText}>Mark Failed</Text>
                </TouchableOpacity>
                <TouchableOpacity style={s.actionSheetClose} onPress={() => setShowConfirmModal(false)}>
                  <Ionicons name="close" size={20} color={colors.textMuted} />
                </TouchableOpacity>
              </View>

              <ScrollView
                style={s.actionSheetScroll}
                contentContainerStyle={s.actionSheetContent}
                keyboardShouldPersistTaps="handled"
                keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
                showsVerticalScrollIndicator={false}
              >
                {stop.delivery_method === "bus_handoff" ? (
                  <>
                    <View style={s.stationCombo}>
                      <Text style={s.stationLabel}>Bus Station Name</Text>
                      <View style={[s.stationInputWrap, stationSuggestionsOpen && s.stationInputWrapOpen]}>
                        <Ionicons name="bus-outline" size={18} color={colors.textMuted} style={s.stationInputIcon} />
                        <TextInput
                          style={s.stationInputText}
                          placeholder="Select or type station name"
                          placeholderTextColor={colors.textLight}
                          value={busStationName}
                          onFocus={() => setStationSuggestionsOpen(true)}
                          onBlur={() => setTimeout(() => setStationSuggestionsOpen(false), 140)}
                          onChangeText={(value) => {
                            setBusStationName(value);
                            setStationSuggestionsOpen(true);
                          }}
                        />
                        {stationListLoading ? (
                          <ActivityIndicator size="small" color={colors.primary} style={s.stationInputAction} />
                        ) : (
                          <TouchableOpacity
                            style={s.stationInputAction}
                            activeOpacity={0.75}
                            onPress={() => setStationSuggestionsOpen((open) => !open)}
                          >
                            <Ionicons name={stationSuggestionsOpen ? "chevron-up" : "chevron-down"} size={20} color={colors.textMuted} />
                          </TouchableOpacity>
                        )}
                      </View>
                      {stationSuggestionsOpen && (
                        <View style={s.stationSuggestions}>
                          {stationSuggestions.length > 0 ? (
                            stationSuggestions.map((station) => (
                              <TouchableOpacity
                                key={station.id}
                                style={s.stationSuggestionRow}
                                activeOpacity={0.78}
                                onPress={() => {
                                  setBusStationName(station.name);
                                  setStationSuggestionsOpen(false);
                                }}
                              >
                                <Text style={s.stationSuggestionName} numberOfLines={2}>
                                  {[station.name, station.location_hint].filter(Boolean).join(", ")}
                                </Text>
                              </TouchableOpacity>
                            ))
                          ) : (
                            <View style={s.stationManualHint}>
                              <Text style={s.stationManualHintText}>No saved station found. Keep typing to use this station name.</Text>
                            </View>
                          )}
                        </View>
                      )}
                    </View>
                    <Input
                      label="Bus Rider Phone"
                      placeholder="e.g. 0551234567"
                      value={courierPhone}
                      onChangeText={(text) => {
                        const next = sanitizeLocalPhoneInput(text);
                        setCourierPhone(next);
                        setCourierPhoneError(next.length === 10 && !isValidGhanaPhone(next) ? "Enter a valid 10-digit Ghana phone number" : "");
                      }}
                      keyboardType="phone-pad"
                      maxLength={10}
                      error={courierPhoneError}
                      leftIcon={<Ionicons name="call-outline" size={18} color={colors.textMuted} />}
                    />
                    {!!courierPhoneHelper && !courierPhoneError && (
                      <View style={s.phoneHelperRow}>
                        <Ionicons name="information-circle-outline" size={14} color={colors.textMuted} />
                        <Text style={s.phoneHelperText}>{courierPhoneHelper}</Text>
                      </View>
                    )}
                    <Input
                      label="Vehicle Number"
                      placeholder="Optional"
                      value={vehicleNumber}
                      onChangeText={setVehicleNumber}
                      autoCapitalize="characters"
                      leftIcon={<Ionicons name="car-outline" size={18} color={colors.textMuted} />}
                    />
                    <Input
                      label="Amount Paid to Courier (GHS)"
                      placeholder="e.g. 20"
                      value={stationFee}
                      onChangeText={setStationFee}
                      keyboardType="decimal-pad"
                      leftIcon={<Ionicons name="cash-outline" size={18} color={colors.textMuted} />}
                    />
                    <ImagePickerButton label="Proof Photo (required)" images={handoffPhotos} onImagesChange={setHandoffPhotos} maxImages={1} />
                  </>
                ) : (
                  <>
                    <View style={s.modalSection}>
                      {!skipVerification ? (
                        <Input
                          label="Verification Code"
                          required
                          placeholder="Enter 4-digit code"
                          value={verificationCode}
                          onChangeText={setVerificationCode}
                          keyboardType="number-pad"
                          maxLength={4}
                          leftIcon={<Ionicons name="key-outline" size={18} color={colors.textMuted} />}
                        />
                      ) : (
                        <Dropdown label="Reason for skipping" required placeholder="Select a reason" options={SKIP_REASONS} value={skipReason} onSelect={(v) => setSkipReason(v as string)} />
                      )}

                      {allowSkipVerification ? (
                        <TouchableOpacity
                          style={s.skipToggle}
                          onPress={() => { setSkipVerification(!skipVerification); setVerificationCode(""); setSkipReason(""); }}
                          activeOpacity={0.7}
                        >
                          <View style={[s.skipToggleIcon, skipVerification && s.skipToggleIconActive]}>
                            <Ionicons name={skipVerification ? "shield-outline" : "alert-circle-outline"} size={16} color={skipVerification ? colors.primary : colors.textMuted} />
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={[s.skipToggleText, skipVerification && { color: colors.primary }]}>
                              {skipVerification ? "Skipping verification" : "Recipient can't verify?"}
                            </Text>
                            <Text style={s.skipToggleSub}>
                              {skipVerification ? "A reason is required. This delivery will be flagged for review." : "Tap here if the SMS code wasn't received"}
                            </Text>
                          </View>
                          <View style={[s.skipToggleSwitch, skipVerification && s.skipToggleSwitchActive]}>
                            <View style={[s.skipToggleDot, skipVerification && s.skipToggleDotActive]} />
                          </View>
                        </TouchableOpacity>
                      ) : (
                        <TouchableOpacity onPress={() => warehousePhone && Linking.openURL(`tel:${warehousePhone}`)} disabled={!warehousePhone} activeOpacity={0.7}>
                          <Text style={s.callAdminInline}>
                            Can't get the code? <Text style={s.callAdminInlineLink}>{warehousePhone ? "Call office" : "Call admin"}</Text>
                          </Text>
                        </TouchableOpacity>
                      )}

                      <View style={[s.pkgSection, s.confirmSectionGap]}>
                        <View style={s.pkgStepperCompact}>
                          <View style={{ flex: 1 }}>
                            <Text style={s.subLabel}>Packages Delivered</Text>
                            <Text style={s.pkgHelper}>{stopPackageQuantity} package(s) expected</Text>
                          </View>
                          <View style={s.stepperRowCompact}>
                            <TouchableOpacity style={s.stepperBtnCompact} onPress={() => setPackagesDelivered(Math.max(0, packagesDelivered - 1))}>
                              <Ionicons name="remove" size={16} color={colors.dark} />
                            </TouchableOpacity>
                            <Text style={s.stepperNumCompact}>{packagesDelivered}</Text>
                            <TouchableOpacity style={s.stepperBtnCompact} onPress={() => setPackagesDelivered(packagesDelivered + 1)}>
                              <Ionicons name="add" size={16} color={colors.dark} />
                            </TouchableOpacity>
                          </View>
                        </View>
                        {packagesDelivered === 0 && (
                          <View style={s.pkgWarning}>
                            <Ionicons name="warning" size={14} color={colors.error} />
                            <Text style={s.pkgWarningText}>No packages delivered — stop will be marked as failed</Text>
                          </View>
                        )}
                        {packagesDelivered > 0 && packagesDelivered < stopPackageQuantity && (
                          <View style={[s.pkgWarning, { backgroundColor: "#fef3c7", borderColor: "#fde68a" }]}>
                            <Ionicons name="alert-circle" size={14} color="#d97706" />
                            <Text style={[s.pkgWarningText, { color: "#92400e" }]}>Partial delivery — will be flagged for review</Text>
                          </View>
                        )}
                      </View>

                      <View style={s.confirmSectionGap}>
                        <ImagePickerButton label="Proof Photo (required)" images={proofPhotos} onImagesChange={setProofPhotos} maxImages={1} />
                      </View>
                    </View>

                    <View style={s.modalSection}>
                      <Text style={s.modalSectionTitle}>Delivery Fee</Text>
                      <Input
                        label="Amount Collected (optional)"
                        placeholder="Enter amount"
                        value={deliveryFeeAmount}
                        onChangeText={setDeliveryFeeAmount}
                        keyboardType="decimal-pad"
                        leftIcon={<Ionicons name="cash-outline" size={18} color={colors.textMuted} />}
                      />
                      <Text style={s.feeNoteCompact}>If the recipient did not pay, clear this field before confirming.</Text>
                      {deliveryFee?.notes ? <Text style={s.feeNoteCompact}>Note: {deliveryFee.notes}</Text> : null}
                      {packagesDelivered === 0 && deliveryFeeAmount.trim() !== "" && (
                        <Text style={s.deliveryFeeHelperMuted}>Delivery fee capture is skipped when no packages were delivered.</Text>
                      )}
                    </View>

                    <View style={s.modalSection}>
                      <Text style={s.modalSectionTitle}>Delivery Notes</Text>
                      <Input
                        label={packagesDelivered < stopPackageQuantity ? "Please explain" : "Optional"}
                        placeholder="Add notes about this delivery"
                        value={deliveryNotes}
                        onChangeText={setDeliveryNotes}
                        multiline
                        numberOfLines={3}
                        maxLength={1000}
                        leftIcon={<Ionicons name="document-text-outline" size={18} color={colors.textMuted} />}
                      />
                    </View>
                  </>
                )}
              </ScrollView>

              <View style={s.actionSheetFooter}>
                <Button
                  title={stop.delivery_method === "bus_handoff" ? "Confirm Handoff" : "Confirm Delivery"}
                  onPress={stop.delivery_method === "bus_handoff" ? handleHandoff : handleConfirm}
                  loading={actionLoading}
                  disabled={stop.delivery_method === "bus_handoff" ? handoffPhotos.length === 0 : proofPhotos.length === 0}
                  leftIcon={<Ionicons name="checkmark-circle" size={18} color={colors.white} />}
                  gradientColors={[colors.success, "#16a34a"] as [string, string]}
                />
              </View>
            </View>
          </KeyboardAvoidingView>
        </View>
      </Modal>

      <Modal visible={showFailModal} transparent animationType="fade" onRequestClose={() => { setFailReasonDropdownOpen(false); setShowFailModal(false); }} presentationStyle="overFullScreen">
        <View style={s.actionModalOverlay}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} keyboardVerticalOffset={0} style={s.keyboardAvoider}>
            <View style={[s.actionSheet, { paddingBottom: insets.bottom + 18 }]}>
              <View style={s.stepsHandle} />
              <View style={s.actionSheetHeader}>
                <View style={[s.cardIconWrap, { backgroundColor: "#fee2e2" }]}>
                  <Ionicons name="close-circle" size={18} color={colors.error} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.actionSheetTitle}>Mark as Failed</Text>
                  <Text style={s.actionSheetSub}>{stop.recipient_name || "Delivery stop"}</Text>
                </View>
                <TouchableOpacity style={s.actionSheetClose} onPress={() => { setFailReasonDropdownOpen(false); setShowFailModal(false); }}>
                  <Ionicons name="close" size={20} color={colors.textMuted} />
                </TouchableOpacity>
              </View>

              <ScrollView
                style={s.actionSheetScroll}
                contentContainerStyle={s.actionSheetContent}
                keyboardShouldPersistTaps="handled"
                keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
                showsVerticalScrollIndicator={false}
              >
                <FailureReasonPicker
                  options={failureReasonOptions}
                  value={failReason}
                  loading={failureReasonsLoading}
                  open={failReasonDropdownOpen}
                  onToggle={() => setFailReasonDropdownOpen((current) => !current)}
                  onSelect={(value) => {
                    setFailReason(value);
                    setFailReasonDropdownOpen(false);
                  }}
                />
                {!failureReasonsLoading && failureReasonOptions.length === 0 ? (
                  <Text style={s.formHelperError}>No active failed-delivery reasons configured.</Text>
                ) : null}
                <Input
                  label="Additional Notes"
                  placeholder="Optional details..."
                  value={failNotes}
                  onChangeText={setFailNotes}
                  multiline
                  numberOfLines={3}
                  leftIcon={<Ionicons name="document-text-outline" size={18} color={colors.textMuted} />}
                />
              </ScrollView>

              <View style={s.actionSheetFooter}>
                <Button
                  title="Submit Failure"
                  onPress={handleFail}
                  loading={actionLoading}
                  leftIcon={<Ionicons name="close-circle" size={18} color={colors.white} />}
                  gradientColors={[colors.error, colors.errorDark] as [string, string]}
                />
              </View>
            </View>
          </KeyboardAvoidingView>
        </View>
      </Modal>
    </View>
  );
}

function FailureReasonPicker({
  options,
  value,
  loading,
  open,
  onToggle,
  onSelect,
}: {
  options: Array<{ label: string; value: string }>;
  value: string | null;
  loading: boolean;
  open: boolean;
  onToggle: () => void;
  onSelect: (value: string) => void;
}) {
  const selected = options.find((option) => option.value === value);
  const disabled = loading || options.length === 0;

  return (
    <View style={s.stationCombo}>
      <Text style={s.stationLabel}>
        Reason <Text style={s.requiredText}>*</Text>
      </Text>
      <TouchableOpacity
        style={[s.stationInputWrap, open && s.stationInputWrapOpen, disabled && s.disabled]}
        onPress={disabled ? undefined : onToggle}
        disabled={disabled}
        activeOpacity={0.82}
      >
        <Ionicons name="alert-circle-outline" size={18} color={colors.textMuted} style={s.stationInputIcon} />
        <Text style={[s.reasonSelectText, !selected && s.reasonSelectPlaceholder]} numberOfLines={1}>
          {loading ? "Loading reasons..." : selected?.label || "Select a reason"}
        </Text>
        {loading ? (
          <ActivityIndicator size="small" color={colors.primary} style={s.stationInputAction} />
        ) : (
          <Ionicons name={open ? "chevron-up" : "chevron-down"} size={20} color={colors.textMuted} style={s.stationInputAction} />
        )}
      </TouchableOpacity>

      {open ? (
        <View style={s.stationSuggestions}>
          {options.map((option, index) => {
            const isSelected = option.value === value;
            const isLast = index === options.length - 1;

            return (
              <TouchableOpacity
                key={option.value}
                style={[s.reasonSelectRow, isSelected && s.reasonSelectRowSelected, isLast && s.reasonSelectRowLast]}
                onPress={() => onSelect(option.value)}
                activeOpacity={0.82}
              >
                <Text style={[s.reasonSelectOptionText, isSelected && s.reasonSelectOptionTextSelected]}>{option.label}</Text>
                {isSelected ? <Ionicons name="checkmark-circle" size={20} color={colors.primary} /> : null}
              </TouchableOpacity>
            );
          })}
        </View>
      ) : null}
    </View>
  );
}

function StopStatusPill({ status }: { status: string }) {
  const statusInfo = stopStatusDisplay(status);

  return (
    <View style={[s.heroStatusBadge, { backgroundColor: statusInfo.bgColor }]}>
      <Ionicons name={statusInfo.icon} size={13} color={statusInfo.color} />
      <Text style={[s.heroStatusText, { color: statusInfo.color }]} numberOfLines={1}>
        {statusInfo.label}
      </Text>
    </View>
  );
}

function RecipientLocationCard({ stop, locationStr, loc }: { stop: any; locationStr: string; loc: any }) {
  const hasCoordinates = loc?.latitude && loc?.longitude;
  const arrivedAt = stop.timeline?.arrived?.at || stop.arrived_at;
  const confirmedAt = stop.status === "delivered"
    ? (stop.timeline?.delivered?.at || stop.delivered_at)
    : null;
  const handedOffAt = stop.status === "handed_off"
    ? (stop.handoff?.handed_off_at || stop.timeline?.handed_off?.at || stop.handed_off_at)
    : null;
  const failedAt = stop.status === "failed"
    ? (stop.timeline?.failed?.at || stop.failed_at || stop.updated_at)
    : null;

  return (
    <View style={s.locationCard}>
      <View style={s.locationHeader}>
        <View style={s.locationHeaderIcon}>
          <Ionicons name="location-outline" size={18} color={colors.success} />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.locationTitle}>Delivery Location</Text>
          <Text style={s.locationMain} numberOfLines={2}>{locationStr || "—"}</Text>
        </View>
      </View>

      <View style={s.locationDetails}>
        <View style={s.locationDetailRow}>
          <Ionicons name="person-outline" size={14} color={colors.textMuted} />
          <Text style={s.locationDetailText} numberOfLines={1}>{stop.recipient_name || "Recipient"}</Text>
        </View>
        {stop.recipient_phone ? (
          <TouchableOpacity style={s.locationDetailRow} onPress={() => Linking.openURL(`tel:${stop.recipient_phone}`)} activeOpacity={0.75}>
            <Ionicons name="call-outline" size={14} color={colors.textMuted} />
            <Text style={[s.locationDetailText, s.locationPhoneText]} numberOfLines={1}>{formatPhone(stop.recipient_phone)}</Text>
          </TouchableOpacity>
        ) : null}
        {loc?.landmark ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="flag-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={2}>{loc.landmark}</Text>
          </View>
        ) : null}
        {arrivedAt ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="time-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={1}>Arrived: {formatDateTime(arrivedAt)}</Text>
          </View>
        ) : null}
        {confirmedAt ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="checkmark-done-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={1}>Confirmed: {formatDateTime(confirmedAt)}</Text>
          </View>
        ) : null}
        {handedOffAt ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="bus-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={1}>Handed off: {formatDateTime(handedOffAt)}</Text>
          </View>
        ) : null}
        {failedAt ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="close-circle-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={1}>Failed: {formatDateTime(failedAt)}</Text>
          </View>
        ) : null}
        {hasCoordinates ? (
          <TouchableOpacity
            style={s.locationDetailRow}
            onPress={() => Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${loc.latitude},${loc.longitude}`)}
            activeOpacity={0.75}
          >
            <Ionicons name="navigate-outline" size={14} color={colors.textMuted} />
            <Text style={[s.locationDetailText, s.locationActionText]}>Navigate to location</Text>
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}

function StationHandoffCard({
  stop,
  locationStr,
  loc,
  onOpenProof,
}: {
  stop: any;
  locationStr: string;
  loc: any;
  onOpenProof: (url: string) => void;
}) {
  const hasCoordinates = loc?.latitude && loc?.longitude;
  const arrivedAt = stop.timeline?.arrived?.at || stop.arrived_at;
  const handedOffAt = stop.status === "handed_off"
    ? (stop.handoff?.handed_off_at || stop.timeline?.handed_off?.at || stop.handed_off_at)
    : null;
  const failedAt = stop.status === "failed"
    ? (stop.timeline?.failed?.at || stop.failed_at || stop.updated_at)
    : null;
  const stationName = stop.handoff?.bus_station || stop.recipient_name || "Bus Station Handoff";

  return (
    <View style={s.locationCard}>
      <View style={s.locationHeader}>
        <View style={[s.locationHeaderIcon, { backgroundColor: "#ede9fe" }]}>
          <Ionicons name="bus-outline" size={18} color="#7c3aed" />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.locationTitle}>Station / Handoff Details</Text>
          <Text style={s.locationMain} numberOfLines={2}>{stationName}</Text>
        </View>
      </View>

      <View style={s.locationDetails}>
        {locationStr ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="location-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={2}>{locationStr}</Text>
          </View>
        ) : null}
        {loc?.landmark ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="flag-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={2}>{loc.landmark}</Text>
          </View>
        ) : null}
        {stop.handoff?.courier_phone ? (
          <TouchableOpacity
            style={s.locationDetailRow}
            onPress={() => Linking.openURL(`tel:${stop.handoff.courier_phone}`)}
            activeOpacity={0.75}
          >
            <Ionicons name="call-outline" size={14} color={colors.textMuted} />
            <Text style={[s.locationDetailText, s.locationPhoneText]} numberOfLines={1}>
              Bus rider: {formatPhone(stop.handoff.courier_phone)}
            </Text>
          </TouchableOpacity>
        ) : null}
        {typeof stop.handoff?.amount_paid === "number" ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="cash-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={1}>
              Amount paid: {formatCurrency(stop.handoff.amount_paid, stop.handoff.currency || "GHS")}
            </Text>
          </View>
        ) : null}
        {arrivedAt ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="time-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={1}>Arrived: {formatDateTime(arrivedAt)}</Text>
          </View>
        ) : null}
        {handedOffAt ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="bus-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={1}>Handed off: {formatDateTime(handedOffAt)}</Text>
          </View>
        ) : null}
        {failedAt ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="close-circle-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={1}>Failed: {formatDateTime(failedAt)}</Text>
          </View>
        ) : null}
        {hasCoordinates ? (
          <TouchableOpacity
            style={s.locationDetailRow}
            onPress={() => Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${loc.latitude},${loc.longitude}`)}
            activeOpacity={0.75}
          >
            <Ionicons name="navigate-outline" size={14} color={colors.textMuted} />
            <Text style={[s.locationDetailText, s.locationActionText]}>Navigate to station</Text>
          </TouchableOpacity>
        ) : null}
        {stop.handoff?.proof_photo_url ? (
          <TouchableOpacity
            activeOpacity={0.85}
            style={s.proofSection}
            onPress={() => onOpenProof(stop.handoff.proof_photo_url)}
          >
            <Text style={s.proofLabel}>Proof Photo</Text>
            <Image source={{ uri: stop.handoff.proof_photo_url }} style={s.proofImage} resizeMode="cover" />
            <Text style={s.proofHint}>Tap to view full photo</Text>
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}

function SenderCard({ vendor }: { vendor: any }) {
  return (
    <View style={s.locationCard}>
      <View style={s.locationHeader}>
        <View style={[s.locationHeaderIcon, { backgroundColor: "#ffedd5" }]}>
          <Ionicons name="storefront-outline" size={18} color={colors.primary} />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={s.locationTitle}>Sender</Text>
          <Text style={s.locationMain} numberOfLines={2}>{vendor.business_name || vendor.name || "—"}</Text>
        </View>
      </View>

      <View style={s.locationDetails}>
        <View style={s.locationDetailRow}>
          <Ionicons name="person-outline" size={14} color={colors.textMuted} />
          <Text style={s.locationDetailText} numberOfLines={1}>{vendor.name || "Sender"}</Text>
        </View>
        {vendor.business_name ? (
          <View style={s.locationDetailRow}>
            <Ionicons name="briefcase-outline" size={14} color={colors.textMuted} />
            <Text style={s.locationDetailText} numberOfLines={1}>{vendor.business_name}</Text>
          </View>
        ) : null}
        {vendor.phone ? (
          <TouchableOpacity style={s.locationDetailRow} onPress={() => Linking.openURL(`tel:${vendor.phone}`)} activeOpacity={0.75}>
            <Ionicons name="call-outline" size={14} color={colors.textMuted} />
            <Text style={[s.locationDetailText, s.locationPhoneText]} numberOfLines={1}>{formatPhone(vendor.phone)}</Text>
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}

function PackageListCard({
  items,
  showSender = false,
  onSetEta,
  onSetAllEta,
}: {
  items: any[];
  showSender?: boolean;
  onSetEta?: (item: any) => void;
  onSetAllEta?: () => void;
}) {
  return (
    <View style={s.packageListCard}>
      <View style={s.packageListHeader}>
        <Text style={s.packageListTitle}>PACKAGES</Text>
        {onSetAllEta ? (
          <TouchableOpacity style={s.packageHeaderAction} onPress={onSetAllEta} activeOpacity={0.75}>
            <Ionicons name="time-outline" size={14} color={colors.primary} />
            <Text style={s.packageHeaderActionText}>Set ETA for all</Text>
          </TouchableOpacity>
        ) : null}
      </View>

      {items.map((item: any, idx: number) => {
        const recipientName = item.recipient_name || item.delivery?.recipient_name || item.delivery_recipient_name;
        const recipientPhone = item.recipient_phone || item.delivery?.recipient_phone || item.delivery_recipient_phone;
        const deliveryLocation = item.delivery_location || item.delivery?.location || item.delivery_town || item.location;
        const deliveryLocationText = typeof deliveryLocation === "string"
          ? deliveryLocation
          : [deliveryLocation?.town, deliveryLocation?.district, deliveryLocation?.region].filter(Boolean).join(", ");
        const etaStatus = String(item.eta?.status || "");
        const canSetEta = Boolean(onSetEta && item.eta?.can_update !== false && !["delivered", "failed"].includes(String(item.status || "")));
        const showEtaLine = Boolean(item.eta?.expected_delivery_at || item.eta?.last_notice_at || ["overdue", "no_eta_overdue"].includes(etaStatus));

        return (
          <View
            key={item.shipment_item_id || idx}
            style={[s.packageListItem, idx === items.length - 1 && { borderBottomWidth: 0, paddingBottom: 0 }]}
          >
            <View style={s.packageNumberBadge}>
              <Text style={s.packageNumberText}>{idx + 1}</Text>
            </View>
            <View style={s.packageMain}>
              <Text style={s.packageNameText} numberOfLines={2}>{item.description?.trim() || `Package ${idx + 1}`}</Text>
              {showSender ? (
                <>
                  <View style={s.packageMetaRow}>
                    <Ionicons name="storefront-outline" size={12} color={colors.textMuted} />
                    <Text style={s.packageMetaText} numberOfLines={1}>
                      {item.vendor?.business_name || item.vendor?.name || item.sender_name || "Sender not shown"}
                    </Text>
                  </View>
                  {recipientName ? (
                    <View style={s.packageMetaRow}>
                      <Ionicons name="person-outline" size={12} color={colors.textMuted} />
                      <Text style={s.packageMetaText} numberOfLines={1}>
                        {recipientName}{recipientPhone ? ` · ${formatPhone(recipientPhone)}` : ""}
                      </Text>
                    </View>
                  ) : recipientPhone ? (
                    <View style={s.packageMetaRow}>
                      <Ionicons name="call-outline" size={12} color={colors.textMuted} />
                      <Text style={s.packageMetaText} numberOfLines={1}>{formatPhone(recipientPhone)}</Text>
                    </View>
                  ) : null}
                  {deliveryLocationText ? (
                    <View style={s.packageMetaRow}>
                      <Ionicons name="location-outline" size={12} color={colors.textMuted} />
                      <Text style={s.packageMetaText} numberOfLines={2}>{deliveryLocationText}</Text>
                    </View>
                  ) : null}
                </>
              ) : null}
              {showEtaLine ? (
                <View style={[s.packageMetaRow, s.packageEtaRow]}>
                  <Ionicons name="time-outline" size={12} color={etaToneColor(item.eta?.tone)} />
                  <Text style={[s.packageMetaText, { color: etaToneColor(item.eta?.tone), fontFamily: fontFamily.semibold }]} numberOfLines={1}>
                    {item.eta?.expected_delivery_at ? `${item.eta.label} · ${item.eta.expected_delivery_at}` : item.eta?.label}
                  </Text>
                </View>
              ) : null}
            </View>
            <View style={s.packageRightCol}>
              <Text style={s.packageQtyText}>{item.expected_quantity ?? 1}</Text>
              {canSetEta ? (
                <TouchableOpacity style={s.packageEtaButton} onPress={() => onSetEta?.(item)} activeOpacity={0.75}>
                  <Text style={s.packageEtaButtonText}>{item.eta?.expected_delivery_at ? "Edit ETA" : "Set ETA"}</Text>
                </TouchableOpacity>
              ) : null}
            </View>
          </View>
        );
      })}
    </View>
  );
}

function StopDetailSkeleton({ topInset, bottomInset }: { topInset: number; bottomInset: number }) {
  const darkSkeleton = { backgroundColor: "rgba(255,255,255,0.22)" };

  return (
    <View style={s.container}>
      <ScrollView contentContainerStyle={{ paddingBottom: bottomInset + 120 }}>
        <LinearGradient colors={["#0f172a", "#1e3a5f", "#0f172a"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: topInset + 12 }]}>
          <View style={s.heroDecor1} />
          <View style={s.headerTop}>
            <View style={s.skeletonBackBtn}>
              <ShimmerLoading width={18} height={18} borderRadius={9} style={darkSkeleton} />
            </View>
            <View style={{ flex: 1, gap: 7 }}>
              <ShimmerLoading width="44%" height={20} borderRadius={8} style={darkSkeleton} />
              <ShimmerLoading width="30%" height={12} borderRadius={6} style={darkSkeleton} />
            </View>
            <ShimmerLoading width={88} height={34} borderRadius={17} style={darkSkeleton} />
          </View>

          <View style={s.heroSummaryGrid}>
            {[0, 1].map((item) => (
              <View key={item} style={s.heroSummaryCard}>
                <ShimmerLoading width={38} height={38} borderRadius={11} style={darkSkeleton} />
                <ShimmerLoading width="78%" height={24} borderRadius={8} style={darkSkeleton} />
                <ShimmerLoading width="58%" height={12} borderRadius={6} style={darkSkeleton} />
              </View>
            ))}
          </View>
        </LinearGradient>

        <View style={s.body}>
          <View style={s.locationCard}>
            <View style={s.locationHeader}>
              <ShimmerLoading width={36} height={36} borderRadius={12} />
              <View style={{ flex: 1, gap: 8 }}>
                <ShimmerLoading width="44%" height={13} borderRadius={6} />
                <ShimmerLoading width="82%" height={16} borderRadius={7} />
              </View>
            </View>
            <View style={s.locationDetails}>
              {[0, 1, 2].map((item) => (
                <View key={item} style={s.locationDetailRow}>
                  <ShimmerLoading width={14} height={14} borderRadius={7} />
                  <ShimmerLoading width={item === 2 ? "62%" : "48%"} height={13} borderRadius={6} />
                </View>
              ))}
            </View>
          </View>

          <View style={s.locationCard}>
            <View style={s.locationHeader}>
              <ShimmerLoading width={36} height={36} borderRadius={12} />
              <View style={{ flex: 1, gap: 8 }}>
                <ShimmerLoading width="34%" height={13} borderRadius={6} />
                <ShimmerLoading width="54%" height={16} borderRadius={7} />
              </View>
            </View>
            <View style={s.locationDetails}>
              {[0, 1, 2].map((item) => (
                <View key={item} style={s.locationDetailRow}>
                  <ShimmerLoading width={14} height={14} borderRadius={7} />
                  <ShimmerLoading width={item === 1 ? "64%" : "46%"} height={13} borderRadius={6} />
                </View>
              ))}
            </View>
          </View>

          <View style={s.packageListCard}>
            <View style={s.packageListHeader}>
              <ShimmerLoading width={92} height={14} borderRadius={7} />
            </View>
            {[0, 1].map((item) => (
              <View key={item} style={[s.packageListItem, item === 1 && { borderBottomWidth: 0, paddingBottom: 0 }]}>
                <ShimmerLoading width={36} height={36} borderRadius={10} />
                <ShimmerLoading width="58%" height={16} borderRadius={7} style={{ flex: 1 }} />
                <ShimmerLoading width={22} height={16} borderRadius={7} />
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, gap: 10, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  skeletonBackBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  heroStatusBadge: { flexDirection: "row", alignItems: "center", gap: 5, maxWidth: 144, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 999, borderWidth: 1, borderColor: "rgba(255,255,255,0.38)", shadowColor: colors.black, shadowOpacity: 0.12, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 2 },
  heroStatusText: { flexShrink: 1, fontFamily: fontFamily.semibold, fontSize: 11 },
  heroSummaryGrid: { flexDirection: "row", gap: 10, marginTop: 6 },
  heroSummaryCard: { flex: 1, minHeight: 116, alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "rgba(255,255,255,0.1)", borderRadius: 15, paddingHorizontal: 10, paddingVertical: 14, borderWidth: 1, borderColor: "rgba(255,255,255,0.18)" },
  heroSummaryIcon: { width: 38, height: 38, borderRadius: 11, backgroundColor: "rgba(255,255,255,0.16)", justifyContent: "center", alignItems: "center" },
  heroSummaryValue: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white, textAlign: "center", letterSpacing: -0.3 },
  heroSummaryLabel: { fontFamily: fontFamily.semibold, fontSize: 11, color: "rgba(255,255,255,0.72)", marginTop: 2, textAlign: "center", lineHeight: 15 },
  body: { padding: 16, gap: 14 },
  locationCard: { borderWidth: 1, borderColor: colors.neutral200, borderRadius: 16, padding: 14, backgroundColor: colors.white, shadowColor: colors.black, shadowOpacity: 0.04, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1, gap: 10 },
  locationHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  locationHeaderIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: "#dcfce7", justifyContent: "center", alignItems: "center" },
  locationTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, textTransform: "uppercase", letterSpacing: 0.4 },
  locationMain: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.dark, marginTop: 3, lineHeight: 18 },
  locationDetails: { borderLeftWidth: 2, borderLeftColor: colors.neutral200, marginLeft: 17, paddingLeft: 18, gap: 8 },
  locationDetailRow: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  locationDetailText: { flex: 1, fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, lineHeight: 17 },
  locationPhoneText: { color: colors.primary },
  locationActionText: { color: colors.primary, textDecorationLine: "underline" },
  packageListCard: { backgroundColor: colors.white, borderRadius: 18, paddingTop: 16, paddingBottom: 14, borderWidth: 1, borderColor: colors.border, overflow: "hidden" },
  packageListHeader: { paddingHorizontal: 16, paddingBottom: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 },
  packageListTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, letterSpacing: 0.5 },
  packageHeaderAction: { flexDirection: "row", alignItems: "center", gap: 5, borderRadius: 999, backgroundColor: colors.warmSurface, paddingHorizontal: 10, paddingVertical: 6 },
  packageHeaderActionText: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.primary },
  packageListItem: { flexDirection: "row", alignItems: "flex-start", gap: 12, paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  packageNumberBadge: { width: 36, height: 36, borderRadius: 10, backgroundColor: "#dbeafe", justifyContent: "center", alignItems: "center" },
  packageNumberText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.primary },
  packageMain: { flex: 1, minWidth: 0 },
  packageNameText: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark, lineHeight: 19 },
  packageMetaRow: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 },
  packageEtaRow: { marginTop: 2 },
  packageMetaText: { flex: 1, fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted },
  packageRightCol: { minWidth: 76, alignItems: "flex-end", gap: 8 },
  packageEtaButton: { borderRadius: 999, borderWidth: 1, borderColor: colors.primary, backgroundColor: colors.white, paddingHorizontal: 12, paddingVertical: 6 },
  packageEtaButtonText: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.primary },
  packageQtyText: { minWidth: 24, textAlign: "right", fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  card: { backgroundColor: colors.white, borderRadius: 14, padding: 16, gap: 10 },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 4 },
  cardIconWrap: { width: 34, height: 34, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, letterSpacing: 0.5 },
  infoRow: { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  infoLabel: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, width: 75 },
  infoValue: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.dark, flex: 1, textAlign: "right" },
  failCard: { backgroundColor: "#fee2e2", borderRadius: 14, padding: 24, alignItems: "center", gap: 8 },
  failTitle: { fontFamily: fontFamily.bold, fontSize: 16, color: colors.error },
  failSub: { fontFamily: fontFamily.regular, fontSize: 13, color: colors.text, textAlign: "center" },
  formHelperError: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.error, marginTop: -6, lineHeight: 17 },
  disabled: { opacity: 0.6 },
  requiredText: { color: colors.error },
  reasonSelectText: { flex: 1, fontFamily: fontFamily.regular, fontSize: fontSize.bodyMd, color: colors.dark, paddingVertical: 14, paddingLeft: 14, paddingRight: 8 },
  reasonSelectPlaceholder: { color: colors.textLight },
  reasonSelectRow: { minHeight: 50, paddingHorizontal: 14, paddingVertical: 13, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  reasonSelectRowSelected: { backgroundColor: colors.warmSurface },
  reasonSelectRowLast: { borderBottomWidth: 0 },
  reasonSelectOptionText: { flex: 1, fontFamily: fontFamily.semibold, fontSize: 13, color: colors.text, lineHeight: 18 },
  reasonSelectOptionTextSelected: { color: colors.primary },
  subLabel: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.dark },
  skipToggle: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.surface, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: colors.border },
  skipToggleIcon: { width: 32, height: 32, borderRadius: 8, backgroundColor: colors.neutral100, justifyContent: "center", alignItems: "center" },
  skipToggleIconActive: { backgroundColor: colors.warmSurface },
  skipToggleText: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.textMuted },
  skipToggleSub: { fontFamily: fontFamily.regular, fontSize: 10, color: colors.textLight, marginTop: 1 },
  skipToggleSwitch: { width: 44, height: 24, borderRadius: 12, backgroundColor: colors.neutral200, padding: 2, justifyContent: "center" },
  skipToggleSwitchActive: { backgroundColor: colors.primary },
  skipToggleDot: { width: 20, height: 20, borderRadius: 10, backgroundColor: colors.white },
  skipToggleDotActive: { alignSelf: "flex-end" },
  callAdminInline: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, paddingHorizontal: 2 },
  callAdminInlineLink: { fontFamily: fontFamily.semibold, color: colors.primary },
  pkgSection: { gap: 8 },
  confirmSectionGap: { marginTop: 14 },
  pkgHelper: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted },
  pkgStepperCompact: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  stepperRowCompact: { flexDirection: "row", alignItems: "center", gap: 10 },
  stepperBtnCompact: { width: 32, height: 32, borderRadius: 16, backgroundColor: colors.surface, borderWidth: 1.2, borderColor: colors.border, justifyContent: "center", alignItems: "center" },
  stepperNumCompact: { minWidth: 26, textAlign: "center", fontFamily: fontFamily.bold, fontSize: 20, color: colors.dark },
  pkgWarning: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#fee2e2", borderRadius: 10, padding: 10, borderWidth: 1, borderColor: "#fca5a5" },
  pkgWarningText: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.error, flex: 1 },
  feeNoteCompact: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, lineHeight: 15 },
  deliveryFeeHelperMuted: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: -2 },
  footer: { paddingHorizontal: 16, paddingTop: 12, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.border },
  actionModalOverlay: { flex: 1, backgroundColor: "rgba(15,23,42,0.45)", justifyContent: "flex-end" },
  centerModalOverlay: { flex: 1, backgroundColor: "rgba(15,23,42,0.55)", justifyContent: "center", padding: 18 },
  etaModalCard: { backgroundColor: colors.white, borderRadius: 24, padding: 18, gap: 16, shadowColor: colors.black, shadowOpacity: 0.16, shadowRadius: 24, shadowOffset: { width: 0, height: 12 }, elevation: 8 },
  etaModalHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  etaQuickGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  etaQuickBtn: { borderRadius: 999, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 12, paddingVertical: 9 },
  etaQuickText: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.dark },
  etaDateBox: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12, borderRadius: 16, borderWidth: 1.5, borderColor: colors.border, backgroundColor: colors.white, paddingHorizontal: 14, paddingVertical: 12 },
  etaDateLabel: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.4 },
  etaDateText: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark, marginTop: 3 },
  etaModalActions: { flexDirection: "row", justifyContent: "flex-end", gap: 10 },
  etaCancelBtn: { borderRadius: 14, borderWidth: 1.5, borderColor: colors.border, paddingHorizontal: 18, paddingVertical: 12 },
  etaCancelText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark },
  etaSaveBtn: { minWidth: 108, alignItems: "center", borderRadius: 14, backgroundColor: colors.primary, paddingHorizontal: 18, paddingVertical: 12 },
  etaSaveText: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.white },
  keyboardAvoider: { flex: 1, justifyContent: "flex-end" },
  actionSheet: { maxHeight: "88%", backgroundColor: colors.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 18, paddingTop: 12, overflow: "hidden" },
  actionSheetHeader: { flexDirection: "row", alignItems: "center", gap: 10, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  actionSheetTitle: { fontFamily: fontFamily.bold, fontSize: 17, color: colors.dark },
  actionSheetSub: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: 2 },
  headerFailLink: { paddingHorizontal: 6, paddingVertical: 8 },
  headerFailLinkText: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.error, textDecorationLine: "underline" },
  actionSheetClose: { width: 34, height: 34, borderRadius: 17, backgroundColor: colors.surface, justifyContent: "center", alignItems: "center" },
  actionSheetScroll: { marginHorizontal: -2, flexGrow: 0 },
  actionSheetContent: { gap: 14, paddingTop: 14, paddingBottom: 18, paddingHorizontal: 2 },
  actionSheetFooter: { borderTopWidth: 1, borderTopColor: colors.neutral100, backgroundColor: colors.white, paddingTop: 12 },
  stationCombo: {},
  stationLabel: { fontFamily: fontFamily.medium, fontSize: fontSize.bodySm, color: colors.dark, marginBottom: 8 },
  stationInputWrap: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.warmSurface,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
    borderBottomWidth: 2,
    borderBottomColor: colors.primary,
  },
  stationInputWrapOpen: { borderBottomWidth: 0 },
  stationInputIcon: { marginLeft: 12 },
  stationInputText: {
    flex: 1,
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.dark,
    paddingVertical: 14,
    paddingLeft: 14,
    paddingRight: 8,
  },
  stationInputAction: { marginRight: 12 },
  stationSuggestions: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderTopWidth: 0,
    borderBottomLeftRadius: 14,
    borderBottomRightRadius: 14,
    shadowColor: colors.dark,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 6,
    overflow: "hidden",
  },
  stationSuggestionRow: { paddingHorizontal: 14, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  stationSuggestionName: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.text, lineHeight: 18 },
  stationManualHint: { paddingHorizontal: 14, paddingVertical: 13, backgroundColor: colors.white },
  stationManualHintText: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.textMuted, lineHeight: 18 },
  phoneHelperRow: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: -8 },
  phoneHelperText: { flex: 1, fontFamily: fontFamily.medium, fontSize: 11, color: colors.textMuted },
  modalSection: { gap: 10, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  modalSectionTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, letterSpacing: 0.4, textTransform: "uppercase" },
  stepsHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: colors.neutral300, alignSelf: "center", marginBottom: 16 },
  proofSection: { paddingTop: 8 },
  proofLabel: { fontFamily: fontFamily.semibold, fontSize: 12, color: "#7c3aed", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 },
  proofImage: { width: "100%", height: 200, borderRadius: 12, backgroundColor: colors.neutral100 },
  proofHint: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: 8 },
  lightboxOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.9)", justifyContent: "center", alignItems: "center" },
  lightboxClose: {
    position: "absolute",
    right: 18,
    zIndex: 3,
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: "rgba(255,255,255,0.16)",
    alignItems: "center",
    justifyContent: "center",
  },
  lightboxImageWrap: { width: "100%", height: "80%", justifyContent: "center", alignItems: "center" },
  lightboxImg: { width: "100%", height: "80%" },
});
