import { useState, useCallback } from "react";
import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity, Dimensions, Linking } from "react-native";
import { router, useLocalSearchParams, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import StatusBadge from "../../../src/components/common/StatusBadge";
import ShimmerLoading from "../../../src/components/common/ShimmerLoading";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { getDeliveryRun } from "../../../src/api/v1/driver/deliveries";
import { showError, getErrorMessage } from "../../../src/utils/toast";
import { formatPhone } from "../../../src/utils/format";

const { width } = Dimensions.get("window");

export default function DeliveryRunDetailScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const deliveriesRoute = "/(driver)/(tabs)/deliveries" as const;
  const leaveDeliveryRun = () => {
    if (router.canGoBack()) router.back();
    else router.replace(deliveriesRoute as any);
  };
  const openStop = (stopId: string | number) => {
    router.push({
      pathname: "/(driver)/delivery/[id]/stop/[stopId]",
      params: { id: String(id), stopId: String(stopId) },
    } as any);
  };
  const [run, setRun] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchRun = async () => {
    try {
      const res = await getDeliveryRun(Number(id));
      setRun((res.data as any)?.delivery || (res.data as any)?.delivery_run || res.data);
    } catch (err: any) { showError(getErrorMessage(err)); }
    finally { setLoading(false); }
  };

  useFocusEffect(useCallback(() => { fetchRun(); }, [id]));

  if (loading) {
    return <DeliveryRunSkeleton topInset={insets.top} bottomInset={insets.bottom} />;
  }

  if (!run) return null;

  const status = run.status || "";
  const stops = run.stops || [];
  const completedCount = stops.filter((st: any) => ["delivered", "handed_off"].includes(st.status)).length;
  const failedCount = stops.filter((st: any) => st.status === "failed").length;
  const progress = stops.length > 0 ? completedCount / stops.length : 0;

  const getStopColor = (st: string) => {
    if (st === "delivered") return colors.success;
    if (st === "handed_off") return colors.success;
    if (st === "failed") return colors.error;
    if (st === "arrived") return colors.primary;
    return colors.neutral300;
  };

  return (
    <View style={s.container}>
      <ScrollView refreshControl={<RefreshControl refreshing={false} onRefresh={fetchRun} colors={[colors.primary]} />} contentContainerStyle={{ paddingBottom: insets.bottom + 30 }}>
        <LinearGradient colors={["#0f172a", "#1e3a5f", "#0f172a"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 12 }]}>
          <View style={s.heroDecor1} />
          <View style={s.headerTop}>
            <TouchableOpacity onPress={leaveDeliveryRun} style={s.backBtn}><Ionicons name="arrow-back" size={22} color={colors.white} /></TouchableOpacity>
            <View style={{ flex: 1 }}>
              <Text style={s.headerTitle}>Delivery Run</Text>
              <Text style={s.headerSub}>{run.run_number || `#${run.id}`}</Text>
            </View>
            <StatusBadge status={status} />
          </View>
          {stops.length > 0 && (
            <View style={s.deliveryProgress}>
              <View style={s.deliveryProgressTop}>
                <Ionicons name="checkmark-circle-outline" size={14} color="rgba(255,255,255,0.5)" />
                <Text style={s.deliveryProgressLabel}>{completedCount} of {stops.length} complete{failedCount > 0 ? ` · ${failedCount} failed` : ""}</Text>
                <Text style={s.deliveryProgressPct}>{Math.round(progress * 100)}%</Text>
              </View>
              <View style={s.deliveryProgressBar}><View style={[s.deliveryProgressFill, { width: `${progress * 100}%` }]} /></View>
            </View>
          )}
        </LinearGradient>

        <View style={s.body}>
          <Text style={s.stopsTitle}>Delivery Stops ({stops.length})</Text>
          {stops.map((stop: any, i: number) => {
            const loc = stop.location || {};
            const locationStr = [loc.town, loc.district, loc.region].filter(Boolean).join(", ");
            const pkgCount = stop.total_packages || stop.items?.length || 0;
            const recipientPhone = String(stop.recipient_phone || "").trim();
            const isBusHandoff = stop.delivery_method === "bus_handoff";
            const stationName = String(stop.handoff?.bus_station || "").trim();
            const stopName = isBusHandoff
              ? (stationName || stop.recipient_name || "Bus Station Handoff")
              : stop.recipient_name;
            return (
              <TouchableOpacity key={stop.id} style={s.stopCard} onPress={() => openStop(stop.id)} activeOpacity={0.7}>
                <View style={[s.stopAccent, { backgroundColor: getStopColor(stop.status) }]} />
                <View style={s.stopBody}>
                  <View style={s.stopTop}>
                    <View style={[s.stopNum, { backgroundColor: getStopColor(stop.status) + "20", borderColor: getStopColor(stop.status) }]}>
                      <Text style={[s.stopNumText, { color: getStopColor(stop.status) }]}>{i + 1}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <View style={s.stopTitleRow}>
                        <Text style={s.stopName} numberOfLines={1}>{stopName}</Text>
                        <StatusBadge status={stop.status} />
                      </View>
                      {isBusHandoff && stationName ? (
                        <View style={s.stopMeta}>
                          <Ionicons name="business-outline" size={11} color={colors.textMuted} />
                          <Text style={s.stopMetaText}>Bus station handoff</Text>
                        </View>
                      ) : null}
                      {recipientPhone ? (
                        <View style={s.stopMeta}>
                          <Ionicons name="call-outline" size={11} color={colors.textMuted} />
                          <Text style={s.stopMetaText}>{formatPhone(recipientPhone)}</Text>
                        </View>
                      ) : null}
                      {locationStr && (
                        <View style={s.stopMeta}>
                          <Ionicons name="location-outline" size={11} color={colors.textMuted} />
                          <Text style={s.stopMetaText}>{locationStr}</Text>
                        </View>
                      )}
                      {loc.landmark && (
                        <View style={s.stopMeta}>
                          <Ionicons name="flag-outline" size={11} color={colors.textMuted} />
                          <Text style={s.stopMetaText}>{loc.landmark}</Text>
                        </View>
                      )}
                    </View>
                  </View>
                  <View style={s.stopBottom}>
                    <Text style={s.stopItems}>{pkgCount} package{pkgCount !== 1 ? "s" : ""}</Text>
                    <View style={{ flex: 1 }} />
                    {stop.status === "pending" && loc.latitude && loc.longitude && (
                      <TouchableOpacity style={s.navBtn} onPress={() => Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${loc.latitude},${loc.longitude}`)}>
                        <Ionicons name="navigate" size={14} color={colors.primary} />
                        <Text style={s.navBtnText}>Navigate</Text>
                      </TouchableOpacity>
                    )}
                    <TouchableOpacity style={s.viewStopBtn} onPress={() => openStop(stop.id)}>
                      <Text style={s.viewStopText}>Details</Text>
                      <Ionicons name="arrow-forward" size={14} color={colors.primary} />
                    </TouchableOpacity>
                  </View>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

function DeliveryRunSkeleton({ topInset, bottomInset }: { topInset: number; bottomInset: number }) {
  const darkSkeleton = { backgroundColor: "rgba(255,255,255,0.22)" };

  return (
    <View style={s.container}>
      <ScrollView contentContainerStyle={{ paddingBottom: bottomInset + 30 }}>
        <LinearGradient colors={["#0f172a", "#1e3a5f", "#0f172a"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: topInset + 12 }]}>
          <View style={s.heroDecor1} />
          <View style={s.headerTop}>
            <View style={s.skeletonBackBtn}>
              <ShimmerLoading width={18} height={18} borderRadius={9} style={darkSkeleton} />
            </View>
            <View style={{ flex: 1, gap: 7 }}>
              <ShimmerLoading width={112} height={19} borderRadius={8} style={darkSkeleton} />
              <ShimmerLoading width={136} height={12} borderRadius={6} style={darkSkeleton} />
            </View>
            <ShimmerLoading width={92} height={30} borderRadius={15} style={darkSkeleton} />
          </View>

          <View style={s.deliveryProgress}>
            <View style={s.deliveryProgressTop}>
              <ShimmerLoading width={14} height={14} borderRadius={7} style={darkSkeleton} />
              <ShimmerLoading width="58%" height={12} borderRadius={6} style={darkSkeleton} />
              <View style={{ flex: 1 }} />
              <ShimmerLoading width={34} height={13} borderRadius={7} style={darkSkeleton} />
            </View>
            <ShimmerLoading width="100%" height={6} borderRadius={3} style={darkSkeleton} />
          </View>
        </LinearGradient>

        <View style={s.body}>
          <ShimmerLoading width={156} height={18} borderRadius={8} />
          {[0, 1, 2, 3].map((item) => (
            <View key={item} style={s.stopCard}>
              <View style={s.stopAccent} />
              <View style={s.stopBody}>
                <View style={s.stopTop}>
                  <ShimmerLoading width={36} height={36} borderRadius={18} />
                  <View style={{ flex: 1, gap: 8 }}>
                    <View style={s.stopTitleRow}>
                      <ShimmerLoading width="52%" height={16} borderRadius={7} />
                      <ShimmerLoading width={74} height={28} borderRadius={14} />
                    </View>
                    <ShimmerLoading width="44%" height={11} borderRadius={6} />
                    <ShimmerLoading width="82%" height={11} borderRadius={6} />
                  </View>
                </View>
                <View style={s.stopBottom}>
                  <ShimmerLoading width={76} height={11} borderRadius={6} />
                  <View style={{ flex: 1 }} />
                  <ShimmerLoading width={86} height={30} borderRadius={15} />
                </View>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, gap: 10, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  skeletonBackBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  deliveryProgress: { backgroundColor: "rgba(255,255,255,0.08)", borderRadius: 10, padding: 12, gap: 8, borderWidth: 1, borderColor: "rgba(255,255,255,0.06)" },
  deliveryProgressTop: { flexDirection: "row", alignItems: "center", gap: 6 },
  deliveryProgressLabel: { fontFamily: fontFamily.medium, fontSize: 12, color: "rgba(255,255,255,0.7)", flex: 1 },
  deliveryProgressPct: { fontFamily: fontFamily.bold, fontSize: 13, color: "#4ade80" },
  deliveryProgressBar: { height: 6, backgroundColor: "rgba(255,255,255,0.12)", borderRadius: 3, overflow: "hidden" },
  deliveryProgressFill: { height: "100%", backgroundColor: "#4ade80", borderRadius: 3 },
  body: { padding: 16, gap: 12 },
  stopsTitle: { fontFamily: fontFamily.bold, fontSize: 16, color: colors.dark, marginBottom: 4 },
  stopCard: { flexDirection: "row", backgroundColor: colors.white, borderRadius: 14, overflow: "hidden" },
  stopAccent: { width: 4 },
  stopBody: { flex: 1, padding: 14, gap: 10 },
  stopTop: { flexDirection: "row", gap: 12 },
  stopNum: { width: 36, height: 36, borderRadius: 18, justifyContent: "center", alignItems: "center", borderWidth: 2 },
  stopNumText: { fontFamily: fontFamily.bold, fontSize: 14 },
  stopName: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.dark },
  stopTitleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  stopMeta: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 3 },
  stopMetaText: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted },
  stopBottom: { flexDirection: "row", alignItems: "center", gap: 8, borderTopWidth: 1, borderTopColor: colors.neutral100, paddingTop: 10 },
  stopItems: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted },
  navBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: "#dbeafe", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  navBtnText: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.primary },
  viewStopBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  viewStopText: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.primary },
});
