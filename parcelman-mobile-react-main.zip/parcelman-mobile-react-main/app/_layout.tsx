import "../global.css";
import { useEffect } from "react";
import { StatusBar } from "react-native";
import { Stack } from "expo-router";
import {
  useFonts,
  PlusJakartaSans_400Regular,
  PlusJakartaSans_500Medium,
  PlusJakartaSans_600SemiBold,
  PlusJakartaSans_700Bold,
  PlusJakartaSans_800ExtraBold,
} from "@expo-google-fonts/plus-jakarta-sans";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { useAuthStore } from "../src/stores/auth.store";
import { useNotifications } from "../src/hooks/useNotifications";
import ToastProvider from "../src/components/common/Toast";
import NetworkStatus from "../src/components/common/NetworkStatus";
import ErrorBoundary from "../src/components/common/ErrorBoundary";
import { colors } from "../src/constants/colors";

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    PlusJakartaSans_400Regular,
    PlusJakartaSans_500Medium,
    PlusJakartaSans_600SemiBold,
    PlusJakartaSans_700Bold,
    PlusJakartaSans_800ExtraBold,
  });

  const hydrate = useAuthStore((s) => s.hydrate);

  useEffect(() => {
    hydrate();
  }, []);

  useNotifications();

  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <ErrorBoundary>
        <Stack
          screenOptions={{
            headerShown: false,
            presentation: "card",
            animation: "none",
            gestureEnabled: false,
            contentStyle: { backgroundColor: colors.background },
          }}
        />
        <NetworkStatus />
        <ToastProvider />
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
