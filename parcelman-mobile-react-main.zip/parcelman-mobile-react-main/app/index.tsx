import { useEffect, useState, useRef } from "react";
import {
  View,
  Image,
  StyleSheet,
  Animated,
  Linking,
  Text,
  TouchableOpacity,
} from "react-native";
import { useRouter } from "expo-router";
import { useAuthStore } from "../src/stores/auth.store";
import { colors } from "../src/constants/colors";

export default function SplashScreen() {
  const router = useRouter();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const isLoading = useAuthStore((s) => s.isLoading);
  const userType = useAuthStore((s) => s.userType);
  const [ready, setReady] = useState(false);

  const logoOpacity = useRef(new Animated.Value(0)).current;
  const logoScale = useRef(new Animated.Value(0.8)).current;
  const barWidth = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Logo fade + scale
    Animated.parallel([
      Animated.timing(logoOpacity, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(logoScale, { toValue: 1, tension: 80, friction: 12, useNativeDriver: true }),
    ]).start();

    // Progress bar
    setTimeout(() => {
      Animated.timing(barWidth, { toValue: 1, duration: 1200, useNativeDriver: false }).start();
    }, 500);

    const t = setTimeout(() => setReady(true), 500);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (isLoading || !ready) return;

    const timer = setTimeout(() => {
      try {
        if (isAuthenticated && userType === "vendor") {
          router.replace("/(vendor)/(tabs)/home" as any);
        } else if (isAuthenticated && userType === "driver") {
          router.replace("/(driver)/(tabs)/home" as any);
        } else {
          router.replace("/(auth)/phone" as any);
        }
      } catch {
        setTimeout(() => {
          router.replace("/(auth)/phone" as any);
        }, 1000);
      }
    }, 1500);

    return () => clearTimeout(timer);
  }, [isLoading, isAuthenticated, userType, ready]);

  return (
    <View style={s.container}>
      <View style={s.content}>
        <Animated.View style={{ opacity: logoOpacity, transform: [{ scale: logoScale }] }}>
          <Image
            source={require("../assets/images/logo.png")}
            style={s.logo}
            resizeMode="contain"
          />
        </Animated.View>
      </View>

      {/* Progress bar */}
      <View style={s.progressWrap}>
        <Animated.View
          style={[
            s.progressBar,
            {
              width: barWidth.interpolate({
                inputRange: [0, 1],
                outputRange: ["0%", "100%"],
              }),
            },
          ]}
        />
      </View>

      <View style={s.poweredWrap}>
        <Text style={s.poweredText}>Powered by </Text>
        <TouchableOpacity onPress={() => Linking.openURL("https://smartqix.com")} activeOpacity={0.7}>
          <Text style={s.poweredLink}>SmartQix</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    alignItems: "center",
    gap: 20,
  },
  logo: {
    width: 132,
    height: 132,
  },
  progressWrap: {
    position: "absolute",
    bottom: 76,
    width: 120,
    height: 3,
    backgroundColor: colors.neutral100,
    borderRadius: 2,
    overflow: "hidden",
  },
  progressBar: {
    height: 3,
    backgroundColor: colors.primary,
    borderRadius: 2,
  },
  poweredWrap: {
    position: "absolute",
    bottom: 36,
    flexDirection: "row",
    alignItems: "center",
  },
  poweredText: {
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: "500",
  },
  poweredLink: {
    fontSize: 12,
    color: colors.primary,
    fontWeight: "700",
  },
});
