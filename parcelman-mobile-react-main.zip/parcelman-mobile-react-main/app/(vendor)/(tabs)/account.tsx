import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Dimensions, Image, RefreshControl } from "react-native";
import { useState, useCallback } from "react";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import ConfirmDialog from "../../../src/components/common/ConfirmDialog";
import WhatsAppSupportButton from "../../../src/components/vendor/WhatsAppSupportButton";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { useAuthStore } from "../../../src/stores/auth.store";
import { formatPhone } from "../../../src/utils/format";
import { getProfile, deleteAccount } from "../../../src/api/v1/vendor/profile";
import { showSuccess, showError, getErrorMessage } from "../../../src/utils/toast";
import { useAppConfigStore } from "../../../src/stores/app-config.store";

const { width } = Dimensions.get("window");

export default function VendorAccountScreen() {
  const insets = useSafeAreaInsets();
  const user = useAuthStore((s) => s.user) as any;
  const setUser = useAuthStore((s) => s.setUser);
  const logout = useAuthStore((s) => s.logout);
  const setAppConfigFromProfile = useAppConfigStore((s) => s.setFromProfile);
  const [showLogout, setShowLogout] = useState(false);
  const [showDeleteAccount, setShowDeleteAccount] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const fetchProfile = async () => {
    try {
      const res = await getProfile();
      setUser((res.data as any)?.user || (res.data as any)?.vendor || res.data);
      setAppConfigFromProfile(res.data).catch(() => {});
    } catch {}
    setRefreshing(false);
  };

  // Refresh profile every time screen is focused
  useFocusEffect(useCallback(() => { fetchProfile(); }, [setAppConfigFromProfile, setUser]));

  const handleLogout = async () => {
    await logout();
    router.replace("/(auth)/phone" as any);
  };

  const handleDeleteAccount = async () => {
    setDeleteLoading(true);
    try {
      await deleteAccount();
      showSuccess("Your account has been deleted successfully.");
      await logout();
      router.replace("/(auth)/phone" as any);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setDeleteLoading(false);
    }
  };

  const initials = (user?.name || "U").split(" ").map((w: string) => w[0]).join("").toUpperCase().slice(0, 2);

  return (
    <View style={s.container}>
      <ScrollView style={s.container} contentContainerStyle={{ paddingBottom: insets.bottom + 30 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchProfile(); }} colors={[colors.primary]} />}
      >
        {/* Hero Profile — extends behind the translucent status bar */}
        <LinearGradient
          colors={["#1e293b", "#334155", "#1e293b"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[s.hero, { paddingTop: insets.top + 24 }]}
        >
          <View style={s.heroDecor1} />
          <View style={s.heroDecor2} />

          <View style={s.avatarWrap}>
            <LinearGradient colors={[colors.primary, colors.primaryLight]} style={s.avatar}>
              <Text style={s.avatarText}>{initials}</Text>
            </LinearGradient>
            <TouchableOpacity style={s.editAvatarBtn} onPress={() => router.push("/(vendor)/profile/edit" as any)}>
              <Ionicons name="pencil" size={12} color={colors.white} />
            </TouchableOpacity>
          </View>

          <Text style={s.heroName}>{user?.name || "User"}</Text>
          {user?.business_name && (
            <View style={s.businessRow}>
              <Ionicons name="business-outline" size={14} color="rgba(255,255,255,0.5)" />
              <Text style={s.heroBusiness}>{user.business_name}</Text>
            </View>
          )}

          <View style={s.infoChips}>
            {user?.phone && (
              <View style={s.infoChip}>
                <Ionicons name="call-outline" size={13} color={colors.accentLight} />
                <Text style={s.infoChipText}>{formatPhone(user.phone)}</Text>
              </View>
            )}
            {user?.email && (
              <View style={s.infoChip}>
                <Ionicons name="mail-outline" size={13} color={colors.accentLight} />
                <Text style={s.infoChipText}>{user.email}</Text>
              </View>
            )}
          </View>
        </LinearGradient>

        <View style={s.body}>
        {/* Account Section */}
        <Text style={s.sectionLabel}>ACCOUNT</Text>
        <View style={s.menuCard}>
          <MenuItem icon="person-outline" iconBg="#dbeafe" iconColor="#3b82f6" label="Edit Profile" sub="Update your name, business, and email" onPress={() => router.push("/(vendor)/profile/edit" as any)} />
          <MenuItem icon="wallet-outline" iconBg="#dcfce7" iconColor={colors.success} label="Earnings" sub="View balance, earnings, and payouts" onPress={() => router.push("/(vendor)/earnings" as any)} />
          <MenuItem
            icon="card-outline"
            iconBg="#ffedd5"
            iconColor={colors.primary}
            label="Payout Account"
            sub="Set where we should send commission"
            onPress={() =>
              router.push({
                pathname: "/(vendor)/profile/payout-account",
                params: { returnTo: "account" },
              } as any)
            }
          />
          <MenuItem icon="notifications-outline" iconBg="#fef3c7" iconColor="#d97706" label="Notifications" sub="Manage notification preferences" onPress={() => router.push("/(vendor)/(tabs)/notifications" as any)} />
        </View>

        {/* Support Section */}
        <Text style={s.sectionLabel}>SUPPORT</Text>
        <View style={s.menuCard}>
          <MenuItem icon="help-circle-outline" iconBg="#dcfce7" iconColor={colors.success} label="Help & FAQ" sub="Get help with using Parcelman" onPress={() => {}} />
          <MenuItem icon="document-text-outline" iconBg="#e0e7ff" iconColor="#6366f1" label="Terms & Conditions" sub="Read our terms of service" onPress={() => router.push("/(vendor)/legal/terms-of-service" as any)} />
          <MenuItem icon="shield-checkmark-outline" iconBg="#fce7f3" iconColor="#ec4899" label="Privacy Policy" sub="How we handle your data" onPress={() => router.push("/(vendor)/legal/privacy-policy" as any)} last />
        </View>

        {/* App Info */}
        <Text style={s.sectionLabel}>APP</Text>
        <View style={s.menuCard}>
          <MenuItem icon="information-circle-outline" iconBg={colors.surface} iconColor={colors.textMuted} label="About Parcelman" sub="Version 1.0.0" onPress={() => {}} last />
        </View>

        {/* Danger Zone */}
        <Text style={s.sectionLabel}>DANGER ZONE</Text>
        <View style={s.menuCard}>
          <TouchableOpacity style={s.logoutItem} onPress={() => setShowLogout(true)} activeOpacity={0.6}>
            <View style={[s.menuIconWrap, { backgroundColor: "#fef3c7" }]}>
              <Ionicons name="log-out-outline" size={20} color="#d97706" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.menuLabel}>Logout</Text>
              <Text style={s.menuSub}>Sign out of your account</Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color={colors.neutral300} />
          </TouchableOpacity>
          <TouchableOpacity style={s.deleteItem} onPress={() => setShowDeleteAccount(true)} activeOpacity={0.6}>
            <View style={[s.menuIconWrap, { backgroundColor: "#fee2e2" }]}>
              <Ionicons name="trash-outline" size={20} color={colors.error} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[s.menuLabel, { color: colors.error }]}>Delete Account</Text>
              <Text style={s.menuSub}>Permanently delete your account and all data</Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color={colors.error} style={{ opacity: 0.4 }} />
          </TouchableOpacity>
        </View>
        </View>

        <ConfirmDialog visible={showLogout} type="warning" title="Logout" message="Are you sure you want to logout?" confirmText="Logout" onConfirm={handleLogout} onCancel={() => setShowLogout(false)} />
        <ConfirmDialog visible={showDeleteAccount} type="error" title="Delete Account" message="This action is permanent and cannot be undone. All your data and parcels will be permanently deleted." confirmText="Delete My Account" onConfirm={handleDeleteAccount} onCancel={() => setShowDeleteAccount(false)} loading={deleteLoading} />
      </ScrollView>
      <WhatsAppSupportButton />
    </View>
  );
}

function MenuItem({ icon, iconBg, iconColor, label, sub, onPress, last }: {
  icon: keyof typeof Ionicons.glyphMap; iconBg: string; iconColor: string;
  label: string; sub: string; onPress: () => void; last?: boolean;
}) {
  return (
    <TouchableOpacity style={[s.menuItem, !last && s.menuItemBorder]} onPress={onPress} activeOpacity={0.6}>
      <View style={[s.menuIconWrap, { backgroundColor: iconBg }]}>
        <Ionicons name={icon} size={20} color={iconColor} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={s.menuLabel}>{label}</Text>
        <Text style={s.menuSub}>{sub}</Text>
      </View>
      <Ionicons name="chevron-forward" size={16} color={colors.neutral300} />
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  // Hero
  hero: { paddingHorizontal: 20, paddingTop: 24, paddingBottom: 28, alignItems: "center", gap: 8, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  heroDecor2: { position: "absolute", bottom: -60, left: -40, width: width * 0.4, height: width * 0.4, borderWidth: 40, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.2 },
  avatarWrap: { position: "relative", marginBottom: 4 },
  avatar: { width: 80, height: 80, borderRadius: 40, justifyContent: "center", alignItems: "center", borderWidth: 3, borderColor: "rgba(255,255,255,0.15)" },
  avatarText: { fontFamily: fontFamily.bold, fontSize: 28, color: colors.white },
  editAvatarBtn: { position: "absolute", bottom: 0, right: -2, width: 28, height: 28, borderRadius: 14, backgroundColor: colors.dark, justifyContent: "center", alignItems: "center", borderWidth: 2, borderColor: "#334155" },
  heroName: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white },
  businessRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  heroBusiness: { fontFamily: fontFamily.regular, fontSize: 14, color: "rgba(255,255,255,0.6)" },
  infoChips: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 4, justifyContent: "center" },
  infoChip: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: "rgba(255,255,255,0.08)", paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: "rgba(255,255,255,0.06)" },
  infoChipText: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.7)" },
  // Body
  body: { padding: 16, gap: 8 },
  sectionLabel: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.textMuted, letterSpacing: 0.8, marginTop: 12, marginBottom: 4, marginLeft: 4 },
  menuCard: { backgroundColor: colors.white, borderRadius: 16, overflow: "hidden" },
  menuItem: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14 },
  menuItemBorder: { borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  menuIconWrap: { width: 40, height: 40, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  menuLabel: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.dark },
  menuSub: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, marginTop: 1 },
  // Danger zone
  logoutItem: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  deleteItem: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14 },
});
