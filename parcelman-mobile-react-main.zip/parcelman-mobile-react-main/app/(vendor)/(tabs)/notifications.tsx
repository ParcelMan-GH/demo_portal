import { useState, useEffect, useCallback } from "react";
import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl, Dimensions, Image } from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import ShimmerLoading from "../../../src/components/common/ShimmerLoading";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { getNotifications, markAsRead, markAllAsRead } from "../../../src/api/v1/vendor/notifications";
import { showError, showSuccess, getErrorMessage } from "../../../src/utils/toast";
import { formatVendorNotificationCopy } from "../../../src/utils/notificationCopy";

const { width, height } = Dimensions.get("window");

const NOTIFICATION_ICONS: Record<string, { icon: string; bg: string; color: string }> = {
  shipment_status: { icon: "cube-outline", bg: "#dbeafe", color: "#3b82f6" },
  shipment_status_changed: { icon: "cube-outline", bg: "#dbeafe", color: "#3b82f6" },
  shipment_rejected: { icon: "alert-circle-outline", bg: "#fee2e2", color: "#ef4444" },
  shipment_submitted: { icon: "paper-plane-outline", bg: "#dbeafe", color: "#3b82f6" },
  shipment_ready_for_collection: { icon: "cube-outline", bg: "#dbeafe", color: "#3b82f6" },
  shipment_collected: { icon: "checkmark-done-outline", bg: "#dcfce7", color: "#16a34a" },
  walkin_shipment_received: { icon: "cube-outline", bg: "#dbeafe", color: "#3b82f6" },
  pickup_assigned: { icon: "car-outline", bg: "#e0e7ff", color: "#6366f1" },
  pickup_completed: { icon: "checkmark-done-outline", bg: "#dcfce7", color: "#16a34a" },
  delivery_completed: { icon: "checkmark-done-outline", bg: "#dcfce7", color: "#16a34a" },
  default: { icon: "notifications-outline", bg: colors.neutral100, color: colors.textMuted },
};

function getTimeAgo(dateStr: string): string {
  const now = new Date();
  const date = new Date(dateStr);
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return "Just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDay = Math.floor(diffHr / 24);
  if (diffDay < 7) return `${diffDay}d ago`;
  return date.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}

export default function NotificationsScreen() {
  const insets = useSafeAreaInsets();
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState("all");

  const fetchNotifications = useCallback(async () => {
    try {
      const res = await getNotifications({ limit: 50 });
      const d = res.data;
      const items = (d as any)?.notifications || (d as any)?.items || (d as any)?.data || (Array.isArray(d) ? d : []);
      setNotifications(items);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { fetchNotifications(); }, []);

  const onRefresh = () => { setRefreshing(true); fetchNotifications(); };

  const unreadCount = notifications.filter((n) => !n.read_at).length;
  const readCount = notifications.filter((n) => !!n.read_at).length;
  const filteredNotifications = filter === "all" ? notifications
    : filter === "unread" ? notifications.filter((n) => !n.read_at)
    : notifications.filter((n) => !!n.read_at);
  const headerHeight = insets.top + 12 + 44 + 12 + 36 + 16;
  const emptyListHeight = Math.max(360, height - headerHeight - 100);

  const handleTap = async (n: any) => {
    // Mark as read via API
    if (!n.read_at) {
      try {
        await markAsRead(n.id);
        setNotifications((prev) =>
          prev.map((item) => item.id === n.id ? { ...item, read_at: new Date().toISOString() } : item)
        );
      } catch {}
    }
    // Navigate based on type/data
    const data = n.data || {};
    if (data.shipment_id) {
      router.push({
        pathname: "/(vendor)/shipment/[id]",
        params: { id: String(data.shipment_id) },
      } as any);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await markAllAsRead();
      setNotifications((prev) =>
        prev.map((item) => ({ ...item, read_at: item.read_at || new Date().toISOString() }))
      );
      showSuccess("All notifications marked as read");
    } catch (err: any) {
      showError(getErrorMessage(err));
    }
  };

  return (
    <View style={s.container}>
      <LinearGradient
        colors={["#1e293b", "#334155", "#1e293b"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[s.header, { paddingTop: insets.top + 12 }]}
      >
        <View style={s.heroDecor1} />
        <View style={s.heroDecor2} />

        <View style={s.headerRow}>
          <View style={s.headerIconWrap}>
            <Ionicons name="notifications" size={22} color={colors.white} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.headerTitle}>Notifications</Text>
            <Text style={s.headerSub}>
              {unreadCount > 0 ? `${unreadCount} unread notification${unreadCount > 1 ? "s" : ""}` : "You're all caught up!"}
            </Text>
          </View>
          {unreadCount > 0 && (
            <TouchableOpacity style={s.markAllBtn} onPress={handleMarkAllRead}>
              <Ionicons name="checkmark-done-outline" size={14} color={colors.white} />
              <Text style={s.markAllText}>Read all</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Filters */}
        <View style={s.filterWrap}>
          {[
            { label: "All", value: "all", count: notifications.length },
            { label: "Unread", value: "unread", count: unreadCount },
            { label: "Read", value: "read", count: readCount },
          ].map((f) => {
            const isActive = f.value === filter;
            return (
              <TouchableOpacity key={f.value} style={[s.filterChip, isActive && s.filterChipActive]} onPress={() => setFilter(f.value)}>
                <Text style={[s.filterText, isActive && s.filterTextActive]}>{f.label}</Text>
                <View style={[s.filterCount, isActive && s.filterCountActive]}>
                  <Text style={[s.filterCountText, isActive && s.filterCountTextActive]}>{f.count}</Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      </LinearGradient>

      {loading ? (
        <NotificationListSkeleton />
      ) : (
        <FlatList
          data={filteredNotifications}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={s.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} />}
          ItemSeparatorComponent={null}
          renderItem={({ item, index }) => {
            const iconConfig = NOTIFICATION_ICONS[item.type] || NOTIFICATION_ICONS.default;
            const isUnread = !item.read_at;
            const title = formatVendorNotificationCopy(item.title);
            const body = formatVendorNotificationCopy(item.body);

            const prevDate = index > 0 ? new Date(filteredNotifications[index - 1].created_at).toDateString() : null;
            const thisDate = new Date(item.created_at).toDateString();
            const showDateHeader = index === 0 || thisDate !== prevDate;
            const today = new Date().toDateString();
            const yesterday = new Date(Date.now() - 86400000).toDateString();
            const dateLabel = thisDate === today ? "Today" : thisDate === yesterday ? "Yesterday" : new Date(item.created_at).toLocaleDateString("en-GB", { day: "numeric", month: "long" });

            return (
              <>
                {showDateHeader && (
                  <View style={s.dateHeader}>
                    <Text style={s.dateLabel}>{dateLabel}</Text>
                  </View>
                )}
                <TouchableOpacity
                  style={[s.notifRow, isUnread && s.notifRowUnread]}
                  onPress={() => handleTap(item)}
                  activeOpacity={0.7}
                >
                  {isUnread && <View style={s.unreadDot} />}
                    <View style={s.notifIcon}>
                      <Ionicons name={iconConfig.icon as any} size={18} color={iconConfig.color} />
                    </View>
                  <View style={s.notifContent}>
                    <View style={s.notifTitleRow}>
                      <Text style={[s.notifTitle, isUnread && s.notifTitleUnread]} numberOfLines={2}>{title}</Text>
                      <Text style={s.notifTime}>{getTimeAgo(item.created_at)}</Text>
                    </View>
                    <Text style={s.notifBody} numberOfLines={2}>{body}</Text>
                  </View>
                </TouchableOpacity>
              </>
            );
          }}
          ListEmptyComponent={
            <View style={[s.emptyCard, { minHeight: emptyListHeight }]}>
              <View style={s.emptyIllustration}>
                <Image
                  source={require("../../../assets/images/empty-states/vendor-empty-notifications.png")}
                  style={s.emptyIllustrationImage}
                  resizeMode="contain"
                />
              </View>

              <View style={s.emptyCopy}>
                <Text style={s.emptyTitle}>No notifications</Text>
                <Text style={s.emptyText}>
                  You're all caught up. We'll notify you when something happens.
                </Text>
              </View>
            </View>
          }
        />
      )}
    </View>
  );
}

function NotificationListSkeleton() {
  return (
    <View style={s.skeletonList}>
      <View style={s.skeletonDateHeader}>
        <ShimmerLoading width={54} height={10} borderRadius={5} />
      </View>
      {[0, 1, 2, 3, 4].map((item) => (
        <View key={item} style={s.skeletonNotifRow}>
          <ShimmerLoading width={24} height={24} borderRadius={12} style={s.skeletonIcon} />
          <View style={s.skeletonNotifContent}>
            <View style={s.skeletonTitleRow}>
              <ShimmerLoading width={item % 2 === 0 ? "66%" : "52%"} height={14} borderRadius={7} />
              <ShimmerLoading width={38} height={10} borderRadius={5} />
            </View>
            <ShimmerLoading width={item % 2 === 0 ? "88%" : "74%"} height={11} borderRadius={6} />
            <ShimmerLoading width={item % 3 === 0 ? "58%" : "46%"} height={11} borderRadius={6} />
          </View>
          {item < 2 ? <View style={s.skeletonUnreadDot} /> : null}
        </View>
      ))}
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 16, paddingBottom: 16, paddingTop: 12, gap: 12, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  heroDecor2: { position: "absolute", bottom: -60, left: -40, width: width * 0.4, height: width * 0.4, borderWidth: 40, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.2 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  headerIconWrap: { width: 44, height: 44, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 22, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  markAllBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: "rgba(255,255,255,0.12)", paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  markAllText: { fontFamily: fontFamily.medium, fontSize: 11, color: "rgba(255,255,255,0.8)" },
  // Filters
  filterWrap: { flexDirection: "row", gap: 8 },
  filterChip: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "rgba(255,255,255,0.06)", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 7, borderWidth: 1, borderColor: "rgba(255,255,255,0.08)" },
  filterChipActive: { backgroundColor: "rgba(255,255,255,0.15)", borderColor: "rgba(255,255,255,0.25)" },
  filterText: { fontFamily: fontFamily.medium, fontSize: 12, color: "rgba(255,255,255,0.5)" },
  filterTextActive: { color: colors.white },
  filterCount: { backgroundColor: "rgba(255,255,255,0.1)", borderRadius: 10, minWidth: 22, height: 20, justifyContent: "center", alignItems: "center", paddingHorizontal: 5 },
  filterCountActive: { backgroundColor: "rgba(255,255,255,0.2)" },
  filterCountText: { fontFamily: fontFamily.semibold, fontSize: 10, color: "rgba(255,255,255,0.5)" },
  filterCountTextActive: { color: colors.white },
  // List
  list: { flexGrow: 1, paddingHorizontal: 16, paddingTop: 8, paddingBottom: 30 },
  // Date headers
  dateHeader: { marginTop: 14, marginBottom: 4, alignSelf: "flex-start" },
  dateLabel: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.primary, textTransform: "uppercase", letterSpacing: 0.5 },
  // Notification list
  notifRow: { flexDirection: "row", alignItems: "flex-start", gap: 12, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.neutral200 },
  notifRowUnread: { backgroundColor: "transparent" },
  unreadDot: {
    position: "absolute",
    top: 18,
    right: 0,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.primary,
  },
  notifIcon: {
    width: 24,
    height: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  notifContent: { flex: 1, gap: 4, paddingRight: 14 },
  notifTitleRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  notifTitle: { flex: 1, fontFamily: fontFamily.medium, fontSize: 14, color: colors.dark, lineHeight: 19 },
  notifTitleUnread: { fontFamily: fontFamily.bold },
  notifBody: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, lineHeight: 17 },
  notifTime: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textLight, marginTop: 2 },
  skeletonList: { flexGrow: 1, paddingHorizontal: 16, paddingTop: 8, paddingBottom: 30 },
  skeletonDateHeader: { marginTop: 14, marginBottom: 4, alignSelf: "flex-start" },
  skeletonNotifRow: { flexDirection: "row", alignItems: "flex-start", gap: 12, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.neutral200 },
  skeletonIcon: { backgroundColor: colors.neutral200 },
  skeletonNotifContent: { flex: 1, gap: 7, paddingRight: 14 },
  skeletonTitleRow: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 10 },
  skeletonUnreadDot: { position: "absolute", top: 18, right: 0, width: 8, height: 8, borderRadius: 4, backgroundColor: colors.neutral200 },
  emptyCard: {
    backgroundColor: "transparent",
    borderRadius: 0,
    paddingHorizontal: 22,
    paddingVertical: 26,
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
  },
  emptyIllustration: {
    width: "100%",
    height: 158,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyIllustrationImage: { width: "100%", height: "100%" },
  emptyCopy: { alignItems: "center", gap: 7 },
  emptyTitle: { fontFamily: fontFamily.bold, fontSize: 20, color: colors.dark, textAlign: "center" },
  emptyText: { fontFamily: fontFamily.medium, fontSize: 14, lineHeight: 21, color: colors.textMuted, textAlign: "center" },
});
