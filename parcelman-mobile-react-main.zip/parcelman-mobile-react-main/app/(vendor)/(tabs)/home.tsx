import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity, Dimensions, Image } from "react-native";
import { useState, useCallback, useMemo } from "react";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import ShimmerLoading from "../../../src/components/common/ShimmerLoading";
import DateGroupHeader from "../../../src/components/common/DateGroupHeader";
import ShipmentCard from "../../../src/components/vendor/ShipmentCard";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { useAuthStore } from "../../../src/stores/auth.store";
import { getShipments } from "../../../src/api/v1/vendor/shipments";
import { showError, getErrorMessage } from "../../../src/utils/toast";
import { getNotifications } from "../../../src/api/v1/vendor/notifications";
import { getProfile } from "../../../src/api/v1/vendor/profile";
import { getEarningsSummary } from "../../../src/api/v1/vendor/earnings";
import { formatCurrency } from "../../../src/utils/format";
import { buildDateGroupedRows } from "../../../src/utils/dateGrouping";
import { useAppConfigStore } from "../../../src/stores/app-config.store";

const { width, height } = Dimensions.get("window");
const summaryCardSize = (width - 56) / 3;

export default function VendorHomeScreen() {
  const insets = useSafeAreaInsets();
  const user = useAuthStore((s) => s.user);
  const setUser = useAuthStore((s) => s.setUser);
  const setAppConfigFromProfile = useAppConfigStore((s) => s.setFromProfile);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [unreadAlerts, setUnreadAlerts] = useState(0);
  const [recentShipments, setRecentShipments] = useState<any[]>([]);
  const [earningsSummary, setEarningsSummary] = useState<any>(null);

  const fetchDashboard = useCallback(async () => {
    try {
      const [shipmentsRes, notificationsRes, profileRes, earningsRes] = await Promise.all([
        getShipments({ limit: 5 }).catch(() => null),
        getNotifications({ limit: 50, is_read: false } as any).catch(() => null),
        getProfile().catch(() => null),
        getEarningsSummary().catch(() => null),
      ]);

      // Update user profile
      if (profileRes?.data) {
        const u = (profileRes.data as any)?.user || (profileRes.data as any)?.vendor || profileRes.data;
        if (u?.name) setUser(u);
        setAppConfigFromProfile(profileRes.data).catch(() => {});
      }

      if (shipmentsRes?.data) {
        const d = shipmentsRes.data;
        const items: any[] = d.shipments || d.items || d.data || [];
        setRecentShipments(items.slice(0, 5));
      }

      if (notificationsRes?.data) {
        const nd = notificationsRes.data as any;
        const notifications: any[] = nd.notifications || nd.items || nd.data || [];
        const unread = notifications.filter((n) => !n.read_at).length;
        setUnreadAlerts(unread);
      }

      if (earningsRes?.data) {
        const summary = (earningsRes.data as any)?.summary || earningsRes.data;
        setEarningsSummary(summary);
      }
    } catch (err: any) {
      if (__DEV__) console.log("[Dashboard] Error:", err);
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [setAppConfigFromProfile, setUser]);

  useFocusEffect(
    useCallback(() => {
      fetchDashboard();
    }, [fetchDashboard])
  );

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchDashboard();
  }, [fetchDashboard]);

  const firstName = (user?.name || "").trim().split(/\s+/)[0] || "there";
  const earningsCurrency = earningsSummary?.currency || "GHS";
  const heroHeight = insets.top + 16 + 58 + 14 + summaryCardSize + 24;
  const emptyRecentHeight = Math.max(340, height - heroHeight - 16 - 40 - 100);
  const recentRows = useMemo(() => buildDateGroupedRows(recentShipments), [recentShipments]);

  return (
    <View style={styles.container}>
      {/* Hero Card — extends behind the translucent status bar */}
      <LinearGradient
        colors={["#1e293b", "#334155", "#1e293b"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.hero, { paddingTop: insets.top + 16 }]}
      >
        {/* Decorative V shapes */}
        <View style={styles.heroDecor1} />
        <View style={styles.heroDecor2} />

        <View style={styles.heroTop}>
          <View style={styles.heroLogoWrap}>
            <Image source={require("../../../assets/images/logo.png")} style={styles.heroLogo} resizeMode="contain" />
          </View>
          <View style={styles.heroGreeting}>
            <Text style={styles.heroWelcome}>
              Hi, <Text style={styles.heroName}>{firstName}</Text>
            </Text>
            {(user as any)?.business_name && (
              <Text style={styles.heroBusiness} numberOfLines={1}>{(user as any).business_name}</Text>
            )}
          </View>
          <View style={{ flex: 1 }} />
          <TouchableOpacity style={styles.bellBtn} onPress={() => router.push("/(vendor)/(tabs)/notifications" as any)}>
            <Ionicons name="notifications-outline" size={22} color={colors.white} />
            {unreadAlerts > 0 && (
              <View style={styles.bellBadge}>
                <Text style={styles.bellBadgeText}>{unreadAlerts > 99 ? "99+" : unreadAlerts}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.summaryGrid}>
          <TouchableOpacity style={styles.summaryCard} onPress={() => router.push("/(vendor)/(tabs)/shipments" as any)} activeOpacity={0.78}>
            <View style={[styles.summaryIcon, { backgroundColor: "rgba(96,165,250,0.18)" }]}>
              <Ionicons name="cube" size={18} color="#93c5fd" />
            </View>
            <Text style={styles.parcelsTitle}>All Parcels</Text>
            <Text style={styles.summarySub} numberOfLines={1}>
              View your parcel requests
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.summaryCard, styles.sendSummaryCard]} onPress={() => router.push({ pathname: "/(vendor)/shipment/create" } as any)} activeOpacity={0.8}>
            <View style={styles.sendIcon}>
              <Ionicons name="add" size={22} color={colors.white} />
            </View>
            <Text style={styles.sendTitle}>Send</Text>
            <Text style={styles.sendSub}>Package</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.summaryCard} onPress={() => router.push("/(vendor)/earnings" as any)} activeOpacity={0.78}>
            <View style={[styles.summaryIcon, { backgroundColor: "rgba(34,197,94,0.18)" }]}>
              <Ionicons name="wallet" size={18} color="#86efac" />
            </View>
            <Text style={styles.earningsValue} numberOfLines={1} adjustsFontSizeToFit>
              {formatCurrency(earningsSummary?.available_balance || 0, earningsCurrency)}
            </Text>
            <Text style={styles.summaryTitle}>Earnings</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <ScrollView
        style={styles.contentScroll}
        contentContainerStyle={styles.contentContainer}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} />}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.body}>
        {loading ? (
          <VendorHomeSkeleton />
        ) : (
          <>
            <View style={styles.sectionHeaderRow}>
              <View style={styles.sectionIconWrap}>
                <Ionicons name="cube" size={20} color={colors.white} />
              </View>
              <Text style={styles.sectionTitleLg}>Recent Parcels</Text>
              <TouchableOpacity
                style={styles.viewAllBtn}
                onPress={() => router.push("/(vendor)/(tabs)/shipments" as any)}
              >
                <Text style={styles.viewAllText}>View All</Text>
                <Ionicons name="chevron-forward" size={16} color={colors.primary} />
              </TouchableOpacity>
            </View>

            {/* Recent Parcels */}
            <View style={styles.section}>
              {recentShipments.length > 0 ? (
                <View style={styles.recentList}>
                  {recentRows.map((row) => {
                    if (row.type === "date") {
                      return <DateGroupHeader key={row.key} label={row.label} />;
                    }

                    const shipment = row.item;
                    return (
                      <ShipmentCard
                        key={row.key}
                        shipment={shipment}
                        onPress={() =>
                          router.push({
                            pathname: "/(vendor)/shipment/[id]",
                            params: { id: String(shipment.id) },
                          } as any)
                        }
                      />
                    );
                  })}
                </View>
              ) : (
                <View style={[styles.emptyCard, { minHeight: emptyRecentHeight }]}>
                  <View style={styles.emptyIllustration}>
                    <Image
                      source={require("../../../assets/images/empty-states/vendor-empty-logistics.png")}
                      style={styles.emptyIllustrationImage}
                      resizeMode="contain"
                    />
                  </View>

                  <View style={styles.emptyCopy}>
                    <Text style={styles.emptyTitle}>No parcels yet</Text>
                    <Text style={styles.emptyText}>
                      Send your package and track every update here.
                    </Text>
                  </View>

                  <TouchableOpacity
                    style={styles.emptyActionBtn}
                    onPress={() => router.push({ pathname: "/(vendor)/shipment/create" } as any)}
                    activeOpacity={0.82}
                  >
                    <Ionicons name="camera" size={20} color={colors.white} />
                    <Text style={styles.emptyActionText}>Send Package</Text>
                    <Ionicons name="arrow-forward" size={19} color={colors.white} />
                  </TouchableOpacity>
                </View>
              )}
            </View>
          </>
        )}
        </View>
      </ScrollView>
    </View>
  );
}

function VendorHomeSkeleton() {
  return (
    <>
      <View style={styles.skeletonSectionHeader}>
        <ShimmerLoading width={40} height={40} borderRadius={12} />
        <ShimmerLoading width={140} height={18} borderRadius={6} style={{ flex: 1 }} />
        <ShimmerLoading width={82} height={34} borderRadius={17} />
      </View>

      <View style={styles.recentList}>
        {Array.from({ length: 4 }).map((_, index) => (
          <View key={index} style={[styles.skeletonParcelCard, { borderLeftColor: index === 0 ? colors.primary : colors.neutral200 }]}>
            <View style={styles.skeletonParcelTop}>
              <ShimmerLoading width={44} height={44} borderRadius={8} />
              <View style={styles.skeletonRecentMain}>
                <ShimmerLoading width="58%" height={16} borderRadius={6} />
                <View style={styles.skeletonMetaRow}>
                  <ShimmerLoading width={12} height={12} borderRadius={6} />
                  <ShimmerLoading width="28%" height={12} borderRadius={5} />
                  <ShimmerLoading width={12} height={12} borderRadius={6} />
                  <ShimmerLoading width="18%" height={12} borderRadius={5} />
                  <ShimmerLoading width={12} height={12} borderRadius={6} />
                  <ShimmerLoading width="24%" height={12} borderRadius={5} />
                </View>
              </View>
            </View>
            <View style={styles.skeletonDivider} />
            <View style={styles.skeletonParcelBottom}>
              <ShimmerLoading width={92} height={26} borderRadius={13} />
              <ShimmerLoading width={118} height={34} borderRadius={6} />
            </View>
          </View>
        ))}
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f1f5f9" },
  // Hero
  hero: {
    paddingHorizontal: 20,
    paddingBottom: 24,
    gap: 14,
    overflow: "hidden",
  },
  heroDecor1: {
    position: "absolute", top: -50, right: -30, width: width * 0.6, height: width * 0.6,
    borderWidth: 60, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.3,
    transform: [{ rotate: "20deg" }],
  },
  heroDecor2: {
    position: "absolute", bottom: -80, left: -40, width: width * 0.5, height: width * 0.5,
    borderWidth: 50, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.25,
    transform: [{ rotate: "-15deg" }],
  },
  heroTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 12 },
  heroLogoWrap: {
    width: 58,
    height: 58,
    borderRadius: 14,
    backgroundColor: colors.white,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: colors.black,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 14,
    elevation: 8,
  },
  heroLogo: { width: 48, height: 48 },
  bellBtn: { position: "relative", width: 42, height: 42, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  bellBadge: { position: "absolute", top: -2, right: -2, minWidth: 18, height: 18, borderRadius: 9, backgroundColor: colors.error, justifyContent: "center", alignItems: "center", paddingHorizontal: 4 },
  bellBadgeText: { fontFamily: fontFamily.bold, fontSize: 9, color: colors.white },
  heroGreeting: { minWidth: 0, gap: 2 },
  heroWelcome: { fontFamily: fontFamily.bold, fontSize: 20, color: colors.white },
  heroName: { color: colors.primaryLight },
  heroBusiness: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.6)" },
  contentScroll: { flex: 1, backgroundColor: colors.background },
  contentContainer: { paddingBottom: 100 },
  // Body
  body: { padding: 16, gap: 20, backgroundColor: colors.background },
  summaryGrid: { flexDirection: "row", gap: 8 },
  summaryCard: {
    width: summaryCardSize,
    height: summaryCardSize,
    backgroundColor: "rgba(255,255,255,0.07)",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.09)",
    padding: 10,
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
  },
  summaryIcon: { width: 30, height: 30, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  summaryTitle: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.white, textAlign: "center" },
  parcelsTitle: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.white, textAlign: "center" },
  summarySub: { fontFamily: fontFamily.medium, fontSize: 9, color: "rgba(255,255,255,0.58)", textAlign: "center" },
  sendSummaryCard: { backgroundColor: "rgba(249,115,22,0.2)", borderColor: "rgba(249,115,22,0.3)" },
  sendIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.16)", justifyContent: "center", alignItems: "center", marginBottom: 2 },
  sendTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.white, textAlign: "center" },
  sendSub: { fontFamily: fontFamily.medium, fontSize: 11, color: "rgba(255,255,255,0.72)", textAlign: "center" },
  earningsValue: { alignSelf: "stretch", fontFamily: fontFamily.extrabold, fontSize: 16, color: colors.white, textAlign: "center", lineHeight: 20 },
  earningsSub: { fontFamily: fontFamily.medium, fontSize: 9, color: "rgba(255,255,255,0.58)", textAlign: "center" },
  // Sections
  section: { gap: 12 },
  sectionHeaderRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  sectionIconWrap: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: colors.primary, justifyContent: "center", alignItems: "center",
  },
  sectionTitleLg: { fontFamily: fontFamily.bold, fontSize: 17, color: colors.dark, flex: 1 },
  viewAllBtn: {
    flexDirection: "row", alignItems: "center", gap: 2,
    backgroundColor: colors.warmSurface, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20,
  },
  viewAllText: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.primary },
  // Lists
  recentList: { gap: 12 },
  skeletonSectionHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  skeletonParcelCard: { backgroundColor: colors.white, borderRadius: 8, padding: 16, gap: 12, borderLeftWidth: 4, shadowColor: colors.dark, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 },
  skeletonParcelTop: { flexDirection: "row", gap: 12 },
  skeletonRecentMain: { flex: 1, gap: 7 },
  skeletonMetaRow: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 4, columnGap: 12, marginTop: 4 },
  skeletonDivider: { height: 1, backgroundColor: colors.neutral100 },
  skeletonParcelBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  // Empty
  emptyCard: {
    backgroundColor: "transparent",
    borderRadius: 0,
    paddingHorizontal: 22,
    paddingVertical: 26,
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
  },
  emptyIllustration: {
    width: "100%",
    height: 108,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyIllustrationImage: { width: "100%", height: "100%" },
  emptyCopy: { alignItems: "center", gap: 7 },
  emptyTitle: { fontFamily: fontFamily.bold, fontSize: 20, color: colors.dark, textAlign: "center" },
  emptyText: { fontFamily: fontFamily.medium, fontSize: 14, lineHeight: 21, color: colors.textMuted, textAlign: "center" },
  emptyActionBtn: {
    minWidth: 212,
    height: 54,
    borderRadius: 27,
    backgroundColor: colors.primary,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.28,
    shadowRadius: 16,
    elevation: 6,
  },
  emptyActionText: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.white },
});
