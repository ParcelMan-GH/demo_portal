import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { useEffect, useState } from "react";
import { getShipments } from "../../../src/api/v1/vendor/shipments";
import { getNotifications } from "../../../src/api/v1/vendor/notifications";

export default function VendorTabsLayout() {
  const [parcelsBadge, setParcelsBadge] = useState<number | undefined>(undefined);
  const [alertsBadge, setAlertsBadge] = useState<number | undefined>(undefined);

  useEffect(() => {
    // Fetch badge counts
    getShipments({ limit: 100 }).then((res) => {
      const d = res.data as any;
      const items: any[] = d.shipments || d.items || d.data || [];
      const total = d.pagination?.total ?? items.length;
      const drafts = items.filter((s: any) => s.status === "draft").length;
      const delivered = items.filter((s: any) => s.status === "delivered").length;
      const cancelled = items.filter((s: any) => s.status === "cancelled").length;
      const rejected = items.filter((s: any) => s.status === "rejected").length;
      const active = total - drafts - delivered - cancelled - rejected;
      setParcelsBadge(active > 0 ? active : undefined);
    }).catch(() => {});

    getNotifications({ limit: 50, is_read: false } as any).then((res) => {
      const d = res.data as any;
      const items: any[] = d.notifications || d.items || d.data || [];
      const unread = items.filter((n) => !n.read_at).length;
      setAlertsBadge(unread > 0 ? unread : undefined);
    }).catch(() => {});
  }, []);

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarLabelStyle: {
          fontFamily: fontFamily.medium,
          fontSize: 11,
        },
        tabBarStyle: {
          backgroundColor: colors.white,
          borderTopColor: colors.border,
        },
      }}
    >
      <Tabs.Screen
        name="home"
        options={{
          title: "Home",
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="home-outline" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="shipments"
        options={{
          title: "Parcels",
          tabBarBadge: parcelsBadge,
          tabBarBadgeStyle: { backgroundColor: colors.primary, fontSize: 10, fontFamily: fontFamily.bold },
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="cube-outline" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="notifications"
        options={{
          title: "Alerts",
          tabBarBadge: alertsBadge,
          tabBarBadgeStyle: { backgroundColor: colors.error, fontSize: 10, fontFamily: fontFamily.bold },
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="notifications-outline" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="account"
        options={{
          title: "Account",
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="person-outline" size={size} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}
