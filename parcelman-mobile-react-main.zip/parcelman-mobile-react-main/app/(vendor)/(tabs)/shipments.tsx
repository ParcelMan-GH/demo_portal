import { View, Text, TextInput, StyleSheet, FlatList, RefreshControl, TouchableOpacity, Dimensions, Modal, Pressable, Platform, Image } from "react-native";
import { useState, useEffect, useCallback, useMemo } from "react";
import DateTimePicker from "@react-native-community/datetimepicker";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import DateGroupHeader from "../../../src/components/common/DateGroupHeader";
import ShipmentCard from "../../../src/components/vendor/ShipmentCard";
import { ListSkeleton } from "../../../src/components/common/ShimmerLoading";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { spacing } from "../../../src/constants/spacing";
import { getShipments } from "../../../src/api/v1/vendor/shipments";
import { showError, getErrorMessage } from "../../../src/utils/toast";
import { buildDateGroupedRows } from "../../../src/utils/dateGrouping";

const { width, height } = Dimensions.get("window");

const FILTERS = [
  { label: "All", value: "all" },
  { label: "In Progress", value: "in_progress" },
  { label: "Delivered", value: "delivered" },
  { label: "Rejected", value: "rejected" },
  { label: "Cancelled", value: "cancelled" },
];

const IN_PROGRESS_STATUSES = [
  "submitted", "processing", "pickup_assigned",
  "picked_up", "at_warehouse", "sorted", "in_transit", "out_for_delivery",
];

const SORT_FIELDS = [
  { label: "Date Created", value: "created_at", icon: "time-outline" as const },
  { label: "Parcel Number", value: "shipment_number", icon: "barcode-outline" as const },
  { label: "Destination Mode", value: "destination_mode", icon: "navigate-outline" as const },
  { label: "Recipient Name", value: "delivery_recipient_name", icon: "person-outline" as const },
  { label: "Pickup Contact Name", value: "pickup_contact_name", icon: "call-outline" as const },
];

export default function ShipmentsScreen() {
  const insets = useSafeAreaInsets();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [shipments, setShipments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [offset, setOffset] = useState(0);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [sortField, setSortField] = useState("created_at");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [showSort, setShowSort] = useState(false);
  const [dateFrom, setDateFrom] = useState<Date | null>(null);
  const [dateTo, setDateTo] = useState<Date | null>(null);
  const [pendingDateFrom, setPendingDateFrom] = useState<Date | null>(null);
  const [pendingDateTo, setPendingDateTo] = useState<Date | null>(null);
  const [showDatePicker, setShowDatePicker] = useState<"from" | "to" | null>(null);
  const [showDateModal, setShowDateModal] = useState(false);

  const fetchShipments = useCallback(async (reset = false) => {
    try {
      const newOffset = reset ? 0 : offset;
      const params: any = { offset: newOffset, limit: 20 };
      if (filter === "in_progress") {
        params.status = IN_PROGRESS_STATUSES.join(",");
      } else if (filter !== "all") {
        params.status = filter;
      }
      if (search.trim()) params.search = search.trim();
      params.sort_by = sortField;
      params.sort_order = sortOrder;
      if (dateFrom) params.date_from = dateFrom.toISOString().split("T")[0];
      if (dateTo) params.date_to = dateTo.toISOString().split("T")[0];

      const res = await getShipments(params);
      const d = res.data;
      const items: any[] = d.shipments || d.items || d.data || [];
      if (reset) {
        setShipments(items);
      } else {
        setShipments((prev) => [...prev, ...items]);
      }
      setHasMore(d.pagination?.has_more ?? false);
      setOffset(newOffset + items.length);

      // Set counts from pagination or compute from items
      if (d.counts) {
        setCounts(d.counts);
      } else if (reset && filter === "all") {
        const c: Record<string, number> = { all: d.pagination?.total ?? items.length };
        let inProgress = 0;
        for (const item of items) {
          c[item.status] = (c[item.status] || 0) + 1;
          if (IN_PROGRESS_STATUSES.includes(item.status)) inProgress++;
        }
        c.in_progress = inProgress;
        setCounts(c);
      }
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [filter, search, offset, sortField, sortOrder, dateFrom, dateTo]);

  useEffect(() => {
    setLoading(true);
    setOffset(0);
    fetchShipments(true);
  }, [filter, search, sortField, sortOrder, dateFrom, dateTo]);

  useFocusEffect(
    useCallback(() => {
      setOffset(0);
      fetchShipments(true);
    }, [filter, search, sortField, sortOrder, dateFrom, dateTo])
  );

  const onRefresh = () => {
    setRefreshing(true);
    setOffset(0);
    fetchShipments(true);
  };

  const onEndReached = () => {
    if (hasMore && !loading) fetchShipments(false);
  };

  const totalCount = counts.all || shipments.length;
  const headerHeight = insets.top + 12 + 46 + 14 + 42 + 20;
  const activeFilterHeight = dateFrom || dateTo ? 36 : 0;
  const emptyListHeight = Math.max(340, height - headerHeight - activeFilterHeight - 14 - 100);
  const shipmentRows = useMemo(() => buildDateGroupedRows(shipments), [shipments]);

  return (
    <View style={s.container}>
      {/* Dark Header — extends behind the translucent status bar */}
      <LinearGradient
        colors={["#1e293b", "#334155", "#1e293b"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[s.header, { paddingTop: insets.top + 12 }]}
      >
        <View style={s.heroDecor1} />
        <View style={s.heroDecor2} />

        <View style={s.headerRow}>
          <View style={s.headerIconWrap}>
            <Ionicons name="cube" size={22} color={colors.white} />
          </View>
          <View style={s.headerCopy}>
            <View>
              <Text style={s.headerTitle}>Parcels</Text>
              <Text style={s.headerSub}>Manage and track all your parcels</Text>
            </View>
          </View>
          <TouchableOpacity
            style={s.newBtn}
            onPress={() => router.push({ pathname: "/(vendor)/shipment/create" } as any)}
            activeOpacity={0.8}
          >
            <Ionicons name="add" size={16} color={colors.white} />
            <Text style={s.newBtnText}>Send Package</Text>
          </TouchableOpacity>
        </View>

        {/* Search + filter icons in hero */}
        <View style={s.heroSearchRow}>
          <View style={s.heroSearchInput}>
            <Ionicons name="search-outline" size={16} color="rgba(255,255,255,0.4)" />
            <TextInput
              style={s.heroSearchText}
              value={search}
              onChangeText={setSearch}
              placeholder="Search parcels..."
              placeholderTextColor="rgba(255,255,255,0.3)"
              returnKeyType="search"
            />
            {search.length > 0 && (
              <TouchableOpacity onPress={() => setSearch("")}>
                <Ionicons name="close-circle" size={16} color="rgba(255,255,255,0.4)" />
              </TouchableOpacity>
            )}
          </View>
          <TouchableOpacity
            style={[s.heroIconBtn, (dateFrom || dateTo) && s.heroIconBtnActive]}
            onPress={() => { setPendingDateFrom(dateFrom); setPendingDateTo(dateTo); setShowDateModal(true); }}
          >
            <Ionicons name="calendar-outline" size={18} color={(dateFrom || dateTo) ? colors.primary : "rgba(255,255,255,0.6)"} />
          </TouchableOpacity>
          <TouchableOpacity style={s.heroIconBtn} onPress={() => setShowSort(true)}>
            <Ionicons name="filter-outline" size={18} color="rgba(255,255,255,0.6)" />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      {/* Active date filter indicator */}
      {(dateFrom || dateTo) && (
        <TouchableOpacity style={s.activeFilter} onPress={() => { setDateFrom(null); setDateTo(null); }}>
          <Ionicons name="calendar" size={12} color={colors.primary} />
          <Text style={s.activeFilterText}>
            {dateFrom ? dateFrom.toLocaleDateString("en-GB", { day: "numeric", month: "short" }) : "Start"}
            {" → "}
            {dateTo ? dateTo.toLocaleDateString("en-GB", { day: "numeric", month: "short" }) : "Now"}
          </Text>
          <Ionicons name="close-circle" size={14} color={colors.textMuted} />
        </TouchableOpacity>
      )}

      {/* Filter Sheet */}
      <Modal visible={showSort} transparent animationType="slide" onRequestClose={() => setShowSort(false)}>
        <Pressable style={s.modalOverlay} onPress={() => setShowSort(false)}>
          <Pressable style={s.sheet} onPress={() => {}}>
            <View style={s.sheetHandle} />
            <Text style={s.sheetTitle}>Filter Parcels</Text>

            <Text style={s.sortSectionLabel}>Status</Text>
            <View style={s.filterSheetGrid}>
              {FILTERS.map((f) => {
                const isActive = f.value === filter;
                const count = f.value === "all" ? totalCount : (counts[f.value] || 0);
                return (
                  <TouchableOpacity
                    key={f.value}
                    style={[s.filterSheetChip, isActive && s.filterSheetChipActive]}
                    onPress={() => setFilter(f.value)}
                  >
                    <Text style={[s.filterSheetText, isActive && s.filterSheetTextActive]}>{f.label}</Text>
                    <View style={[s.filterSheetCount, isActive && s.filterSheetCountActive]}>
                      <Text style={[s.filterSheetCountText, isActive && s.filterSheetCountTextActive]}>{count}</Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>

            {/* Order toggle */}
            <View style={s.orderToggle}>
              <TouchableOpacity
                style={[s.orderBtn, sortOrder === "desc" && s.orderBtnActive]}
                onPress={() => setSortOrder("desc")}
              >
                <Ionicons name="arrow-down" size={14} color={sortOrder === "desc" ? colors.white : colors.textMuted} />
                <Text style={[s.orderBtnText, sortOrder === "desc" && s.orderBtnTextActive]}>Newest</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[s.orderBtn, sortOrder === "asc" && s.orderBtnActive]}
                onPress={() => setSortOrder("asc")}
              >
                <Ionicons name="arrow-up" size={14} color={sortOrder === "asc" ? colors.white : colors.textMuted} />
                <Text style={[s.orderBtnText, sortOrder === "asc" && s.orderBtnTextActive]}>Oldest</Text>
              </TouchableOpacity>
            </View>

            {/* Sort field options */}
            <Text style={s.sortSectionLabel}>Sort by</Text>
            <View style={s.sortGrid}>
              {SORT_FIELDS.map((f) => (
                <TouchableOpacity
                  key={f.value}
                  style={[s.sortTile, sortField === f.value && s.sortTileActive]}
                  onPress={() => { setSortField(f.value); setShowSort(false); }}
                >
                  <Ionicons name={f.icon} size={16} color={sortField === f.value ? colors.primary : colors.textMuted} />
                  <Text style={[s.sortTileText, sortField === f.value && s.sortTileTextActive]} numberOfLines={1}>{f.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Date Range Sheet */}
      <Modal visible={showDateModal} transparent animationType="slide" onRequestClose={() => setShowDateModal(false)}>
        <Pressable style={s.modalOverlay} onPress={() => setShowDateModal(false)}>
          <Pressable style={s.sheet} onPress={() => {}}>
            <View style={s.sheetHandle} />
            <Text style={s.sheetTitle}>Filter by Date</Text>
            <Text style={s.sheetSub}>Select a date range to filter parcels</Text>

            <View style={s.dateRow}>
              <TouchableOpacity style={s.dateTile} onPress={() => setShowDatePicker("from")}>
                <View style={s.dateTileIcon}>
                  <Ionicons name="calendar-outline" size={20} color={colors.primary} />
                </View>
                <Text style={s.dateTileLabel}>From</Text>
                <Text style={s.dateTileValue}>
                  {pendingDateFrom ? pendingDateFrom.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "Start date"}
                </Text>
              </TouchableOpacity>

              <Ionicons name="arrow-forward" size={16} color={colors.textMuted} />

              <TouchableOpacity style={s.dateTile} onPress={() => setShowDatePicker("to")}>
                <View style={s.dateTileIcon}>
                  <Ionicons name="calendar-outline" size={20} color={colors.primary} />
                </View>
                <Text style={s.dateTileLabel}>To</Text>
                <Text style={s.dateTileValue}>
                  {pendingDateTo ? pendingDateTo.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "End date"}
                </Text>
              </TouchableOpacity>
            </View>

            <View style={s.dateActions}>
              <TouchableOpacity style={s.dateClearBtn} onPress={() => { setPendingDateFrom(null); setPendingDateTo(null); setDateFrom(null); setDateTo(null); setShowDateModal(false); }}>
                <Text style={s.dateClearText}>Clear</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.dateApplyBtn} onPress={() => { setDateFrom(pendingDateFrom); setDateTo(pendingDateTo); setShowDateModal(false); }}>
                <Text style={s.dateApplyText}>Apply Filter</Text>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Native Date Picker */}
      {showDatePicker && (
        <DateTimePicker
          value={showDatePicker === "from" ? (pendingDateFrom || new Date()) : (pendingDateTo || new Date())}
          mode="date"
          display="default"
          maximumDate={new Date()}
          accentColor={colors.primary}
          onChange={(event, date) => {
            if (event.type === "dismissed") {
              setShowDatePicker(null);
              return;
            }
            setShowDatePicker(null);
            if (date) {
              if (showDatePicker === "from") setPendingDateFrom(date);
              else setPendingDateTo(date);
            }
          }}
        />
      )}

      {/* Body */}
      <View style={s.body}>

        {loading && shipments.length === 0 ? (
          <View style={{ padding: 16 }}><ListSkeleton count={4} /></View>
        ) : (
          <FlatList
            data={shipmentRows}
            keyExtractor={(item) => item.key}
            renderItem={({ item }) => {
              if (item.type === "date") {
                return <DateGroupHeader label={item.label} />;
              }

              const shipment = item.item;
              return (
                <ShipmentCard
                  shipment={shipment}
                  onPress={() =>
                    router.push({
                      pathname: "/(vendor)/shipment/[id]",
                      params: { id: String(shipment.id) },
                    } as any)
                  }
                />
              );
            }}
            contentContainerStyle={s.list}
            ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} />
            }
            onEndReached={onEndReached}
            onEndReachedThreshold={0.5}
            ListEmptyComponent={
              <View style={[s.emptyCard, { minHeight: emptyListHeight }]}>
                <View style={s.emptyIllustration}>
                  <Image
                    source={require("../../../assets/images/empty-states/vendor-empty-logistics.png")}
                    style={s.emptyIllustrationImage}
                    resizeMode="contain"
                  />
                </View>

                <View style={s.emptyCopy}>
                  <Text style={s.emptyTitle}>No parcels yet</Text>
                  <Text style={s.emptyText}>
                    Send your package and track every update here.
                  </Text>
                </View>

                <TouchableOpacity
                  style={s.emptyActionBtn}
                  onPress={() => router.push({ pathname: "/(vendor)/shipment/create" } as any)}
                  activeOpacity={0.82}
                >
                  <Ionicons name="camera" size={20} color={colors.white} />
                  <Text style={s.emptyActionText}>Send Package</Text>
                  <Ionicons name="arrow-forward" size={19} color={colors.white} />
                </TouchableOpacity>
              </View>
            }
          />
        )}
      </View>

    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f1f5f9" },
  // Header
  header: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    gap: 14,
    overflow: "hidden",
  },
  heroDecor1: {
    position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5,
    borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25,
    transform: [{ rotate: "20deg" }],
  },
  heroDecor2: {
    position: "absolute", bottom: -60, left: -40, width: width * 0.4, height: width * 0.4,
    borderWidth: 40, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.2,
  },
  headerRow: {
    flexDirection: "row", alignItems: "center", gap: 12,
  },
  headerCopy: {
    flex: 1, minWidth: 0, paddingRight: 4,
  },
  headerIconWrap: {
    width: 46, height: 46, borderRadius: 14,
    backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center",
  },
  headerTitle: {
    fontFamily: fontFamily.bold, fontSize: 22, color: colors.white,
  },
  headerSub: {
    fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2,
  },
  newBtn: {
    flexDirection: "row", alignItems: "center", gap: 4,
    flexShrink: 0, backgroundColor: colors.primary, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 12,
  },
  newBtnText: {
    fontFamily: fontFamily.semibold, fontSize: 12, color: colors.white,
  },
  // Body
  body: {
    flex: 1, backgroundColor: colors.background,
    paddingTop: 14,
  },
  // Hero search
  heroSearchRow: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 6 },
  heroSearchInput: { flex: 1, flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "rgba(255,255,255,0.1)", borderTopLeftRadius: 4, borderTopRightRadius: 4, borderBottomWidth: 2, borderBottomColor: colors.primary, paddingHorizontal: 12, height: 42 },
  heroSearchText: { flex: 1, fontFamily: fontFamily.regular, fontSize: fontSize.bodyMd, color: colors.white, paddingVertical: 0 },
  heroIconBtn: { width: 42, height: 42, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.12)", justifyContent: "center", alignItems: "center" },
  heroIconBtnActive: { backgroundColor: colors.warmSurface },
  activeFilter: { flexDirection: "row", alignItems: "center", gap: 6, marginHorizontal: 16, marginTop: 10, marginBottom: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, borderWidth: 1, borderColor: colors.accentLighter, alignSelf: "flex-start" },
  activeFilterText: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.primary },
  // Loading bar
  // Modals
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  sheet: { backgroundColor: colors.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingBottom: 34, paddingTop: 12 },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: colors.neutral300, alignSelf: "center", marginBottom: 16 },
  sheetTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.dark },
  sheetSub: { fontFamily: fontFamily.regular, fontSize: 13, color: colors.textMuted, marginTop: 4, marginBottom: 16 },
  // Sort
  filterSheetGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 16 },
  filterSheetChip: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: colors.surface, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 9, borderWidth: 1, borderColor: colors.border },
  filterSheetChipActive: { backgroundColor: colors.warmSurface, borderColor: colors.primary },
  filterSheetText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  filterSheetTextActive: { color: colors.primary },
  filterSheetCount: { minWidth: 22, height: 20, borderRadius: 10, backgroundColor: colors.neutral200, justifyContent: "center", alignItems: "center", paddingHorizontal: 5 },
  filterSheetCountActive: { backgroundColor: colors.primary },
  filterSheetCountText: { fontFamily: fontFamily.semibold, fontSize: 10, color: colors.textMuted },
  filterSheetCountTextActive: { color: colors.white },
  orderToggle: { flexDirection: "row", backgroundColor: colors.surface, borderRadius: 12, padding: 4, marginTop: 12, marginBottom: 16 },
  orderBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 10, borderRadius: 10 },
  orderBtnActive: { backgroundColor: colors.primary },
  orderBtnText: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.textMuted },
  orderBtnTextActive: { color: colors.white },
  sortSectionLabel: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 10 },
  sortGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  sortTile: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 10, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  sortTileActive: { backgroundColor: colors.warmSurface, borderColor: colors.primary },
  sortTileText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  sortTileTextActive: { color: colors.primary },
  // Date
  dateRow: { flexDirection: "row", alignItems: "center", gap: 12, marginTop: 8, marginBottom: 20 },
  dateTile: { flex: 1, backgroundColor: colors.surface, borderRadius: 14, padding: 14, alignItems: "center", gap: 6, borderWidth: 1, borderColor: colors.border },
  dateTileIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: colors.warmSurface, justifyContent: "center", alignItems: "center" },
  dateTileLabel: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.5 },
  dateTileValue: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.dark, textAlign: "center" },
  dateActions: { flexDirection: "row", gap: 12 },
  dateClearBtn: { flex: 1, paddingVertical: 14, borderRadius: 14, borderWidth: 1.5, borderColor: colors.border, alignItems: "center" },
  dateClearText: { fontFamily: fontFamily.medium, fontSize: 14, color: colors.textMuted },
  dateApplyBtn: { flex: 1.5, paddingVertical: 14, borderRadius: 14, backgroundColor: colors.primary, alignItems: "center" },
  dateApplyText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  list: { flexGrow: 1, paddingHorizontal: 16, paddingBottom: 120 },
  emptyCard: {
    backgroundColor: "transparent",
    borderRadius: 0,
    paddingHorizontal: 22,
    paddingVertical: 26,
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
  },
  emptyIllustration: {
    width: "100%",
    height: 108,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyIllustrationImage: { width: "100%", height: "100%" },
  emptyCopy: { alignItems: "center", gap: 7 },
  emptyTitle: { fontFamily: fontFamily.bold, fontSize: 20, color: colors.dark, textAlign: "center" },
  emptyText: { fontFamily: fontFamily.medium, fontSize: 14, lineHeight: 21, color: colors.textMuted, textAlign: "center" },
  emptyActionBtn: {
    minWidth: 212,
    height: 54,
    borderRadius: 27,
    backgroundColor: colors.primary,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.28,
    shadowRadius: 16,
    elevation: 6,
  },
  emptyActionText: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.white },
});
