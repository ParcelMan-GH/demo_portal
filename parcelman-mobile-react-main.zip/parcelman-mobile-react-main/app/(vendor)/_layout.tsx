import { Stack } from "expo-router";
import { useEffect } from "react";
import { AppState } from "react-native";
import { colors } from "../../src/constants/colors";
import { useAppConfigStore } from "../../src/stores/app-config.store";

export default function VendorLayout() {
  const hydrateAppConfig = useAppConfigStore((s) => s.hydrate);
  const refreshAppConfig = useAppConfigStore((s) => s.refresh);

  useEffect(() => {
    hydrateAppConfig().then(() => refreshAppConfig(true));

    const subscription = AppState.addEventListener("change", (state) => {
      if (state === "active") refreshAppConfig(true);
    });

    return () => subscription.remove();
  }, [hydrateAppConfig, refreshAppConfig]);

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        presentation: "card",
        animation: "none",
        gestureEnabled: false,
        contentStyle: { backgroundColor: colors.background },
      }}
    >
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="shipment/create" />
      <Stack.Screen name="shipment/[id]" />
      <Stack.Screen name="shipment/[id]/edit" />
      <Stack.Screen name="shipment/[id]/item/[itemId]" />
      <Stack.Screen name="profile/edit" />
      <Stack.Screen name="profile/payout-account" />
      <Stack.Screen name="earnings" />
      <Stack.Screen name="legal/[doc]" />
    </Stack>
  );
}
