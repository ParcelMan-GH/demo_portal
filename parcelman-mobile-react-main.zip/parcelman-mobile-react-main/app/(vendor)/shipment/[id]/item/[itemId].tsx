import { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Image,
  Modal,
  RefreshControl,
  Animated,
  Linking,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { ListSkeleton } from "../../../../../src/components/common/ShimmerLoading";
import { colors } from "../../../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../../../src/constants/typography";
import { spacing } from "../../../../../src/constants/spacing";
import { getShipment } from "../../../../../src/api/v1/vendor/shipments";
import { showError, getErrorMessage } from "../../../../../src/utils/toast";
import { formatLocation, formatPhone, formatDateTimeAmPm } from "../../../../../src/utils/format";
import { itemStatusConfig, type ItemStatus } from "../../../../../src/constants/statuses";

const { width } = Dimensions.get("window");

export default function PackageDetailScreen() {
  const insets = useSafeAreaInsets();
  const { id, itemId } = useLocalSearchParams<{ id: string; itemId: string }>();
  const shipmentDetailRoute = {
    pathname: "/(vendor)/shipment/[id]",
    params: { id: String(id) },
  } as const;
  const leavePackageDetail = () => {
    if (router.canGoBack()) router.back();
    else router.replace(shipmentDetailRoute as any);
  };
  const [loading, setLoading] = useState(true);
  const [isPerItem, setIsPerItem] = useState(false);
  const [shipmentNumber, setShipmentNumber] = useState("");
  const [previewIndex, setPreviewIndex] = useState(-1);
  const [proofPreviewUri, setProofPreviewUri] = useState<string | null>(null);

  const [description, setDescription] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [images, setImages] = useState<{ uri: string; recipient_phone: string | null }[]>([]);

  const [trackingCode, setTrackingCode] = useState<string | null>(null);
  const [itemStatus, setItemStatus] = useState<string | null>(null);
  const [itemDeliveryPref, setItemDeliveryPref] = useState<"deliver" | "self_pickup">("deliver");
  const [itemHandoff, setItemHandoff] = useState<any>(null);
  const [deliveryName, setDeliveryName] = useState("");
  const [deliveryPhoneRaw, setDeliveryPhoneRaw] = useState(""); // full +233 format for display
  const [deliveryLocation, setDeliveryLocation] = useState({ region_id: null as number | null, district_id: null as number | null, town: "", gh_post_address: "", landmark: "", display: "" });
  const [deliveryInstructions, setDeliveryInstructions] = useState("");

  const fetchData = async () => {
    try {
      const res = await getShipment(Number(id));
      const s = res.data?.shipment || res.data;
      setIsPerItem(s.destination_mode === "per_item");
      setShipmentNumber(s.shipment_number || "");
      const item = (s.items || []).find((i: any) => i.id === Number(itemId));
      if (item) {
        setDescription(item.description);
        setQuantity(String(item.quantity));
        setTrackingCode(item.tracking_code || null);
        setItemStatus(item.status || null);
        setItemHandoff(item.handoff || null);
        setItemDeliveryPref(item.delivery_preference || "deliver");
        setImages(
          (item.images || []).map((img: any) =>
            typeof img === "string"
              ? { uri: img, recipient_phone: null }
              : { uri: img.url, recipient_phone: img.recipient_phone ?? null },
          ),
        );
        const d = item.delivery;
        setDeliveryName(d?.recipient_name || item.delivery_recipient_name || "");
        const phone = d?.recipient_phone || item.delivery_recipient_phone || "";
        setDeliveryPhoneRaw(phone);
        setDeliveryInstructions(d?.instructions || item.delivery_instructions || "");
        const loc = d?.location;
        setDeliveryLocation({
          region_id: loc?.region_id || item.delivery_region_id || null,
          district_id: loc?.district_id || item.delivery_district_id || null,
          town: loc?.town || item.delivery_town || "",
          gh_post_address: loc?.gh_post_address || item.delivery_gh_post_address || "",
          landmark: loc?.landmark || item.delivery_landmark || "",
          display: loc ? formatLocation({...loc, landmark: undefined}) : item.delivery_town || "",
        });
      }
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [id, itemId]);

  if (loading) {
    return (
      <View style={s.container}>
        <View style={[s.headerPlaceholder, { paddingTop: insets.top + 16 }]}>
          <TouchableOpacity onPress={leavePackageDetail} style={s.backBtn}>
            <Ionicons name="arrow-back" size={24} color={colors.white} />
          </TouchableOpacity>
          <Text style={s.headerTitle}>Package Details</Text>
        </View>
        <View style={{ padding: 20 }}><ListSkeleton count={3} /></View>
      </View>
    );
  }

  return (
    <View style={s.container}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: 100, backgroundColor: colors.background }}
        automaticallyAdjustKeyboardInsets
        keyboardShouldPersistTaps="handled"
        refreshControl={<RefreshControl refreshing={false} onRefresh={() => { setLoading(true); fetchData(); }} colors={[colors.primary]} />}
      >
        {/* Header — extends behind the translucent status bar */}
        <LinearGradient
          colors={["#1e293b", "#334155", "#1e293b"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[s.header, { paddingTop: insets.top + 8 }]}
        >
          <View style={s.heroDecor1} />
          <View style={s.headerTop}>
            <TouchableOpacity onPress={leavePackageDetail} style={s.backBtn}>
              <Ionicons name="arrow-back" size={22} color={colors.white} />
            </TouchableOpacity>
            <View style={{ flex: 1 }}>
              <Text style={s.headerTitle}>Package</Text>
              {shipmentNumber ? <Text style={s.headerSubtitle}>{shipmentNumber}</Text> : null}
            </View>
            {trackingCode && (
              <View style={s.trackingBadge}>
                <Ionicons name="barcode-outline" size={12} color={colors.primary} />
                <Text style={s.trackingText}>{trackingCode}</Text>
              </View>
            )}
          </View>

          {itemStatus && itemStatusConfig[itemStatus as ItemStatus] && (() => {
            const cfg = itemStatusConfig[itemStatus as ItemStatus];
            return (
              <View style={[s.heroStatusChip, { backgroundColor: cfg.bgColor }]}>
                {cfg.icon && <Ionicons name={cfg.icon as any} size={14} color={cfg.color} />}
                <Text style={[s.heroStatusChipText, { color: cfg.color }]}>{cfg.label}</Text>
              </View>
            );
          })()}

          <View style={{ height: 10 }} />

          {/* Item name + description */}
          <View style={s.heroItemCard}>
            <View style={{ flex: 1 }}>
              <Text style={s.heroItemName} numberOfLines={2}>{description || "Item"}</Text>
              <Text style={s.heroItemSub}>
                {isPerItem && deliveryLocation.display
                  ? deliveryLocation.display
                  : "View package details, photos and delivery info"}
              </Text>
              {isPerItem && itemDeliveryPref && (
                <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 }}>
                  <Ionicons name={itemDeliveryPref === "deliver" ? "car-outline" : "business-outline"} size={12} color={colors.accentLight} />
                  <Text style={{ fontFamily: fontFamily.medium, fontSize: 10, color: colors.accentLight }}>
                    {itemDeliveryPref === "deliver" ? "Deliver to Recipient" : "Recipient Collects"}
                  </Text>
                </View>
              )}
            </View>
            {/* Summary badges */}
            <View style={s.heroSummaryCol}>
              <View style={s.heroSummaryCard}>
                <Ionicons name="layers-outline" size={16} color={colors.primary} />
                <Text style={s.heroSummaryValue}>{quantity}</Text>
                <Text style={s.heroSummaryLabel}>Qty</Text>
              </View>
              <View style={s.heroSummaryCard}>
                <Ionicons name="camera-outline" size={16} color="#8b5cf6" />
                <Text style={s.heroSummaryValue}>{images.length}</Text>
                <Text style={s.heroSummaryLabel}>Photos</Text>
              </View>
            </View>
          </View>
        </LinearGradient>

        <View style={s.body}>
          {/* Package Information Card */}
          <View style={s.card}>
            <View style={s.cardHeader}>
              <View style={[s.cardIconWrap, { backgroundColor: "#3b82f6" }]}>
                <Ionicons name="cube" size={18} color={colors.white} />
              </View>
              <Text style={s.cardTitle}>Package Information</Text>
            </View>
            <ViewRow icon="document-text-outline" label="Description" value={description} />
            <ViewRow icon="layers-outline" label="Quantity" value={quantity} last />
          </View>

          {/* Photos Card */}
          {images.length > 0 && (
            <View style={s.card}>
              <View style={s.cardHeader}>
                <View style={[s.cardIconWrap, { backgroundColor: "#8b5cf6" }]}>
                  <Ionicons name="camera" size={18} color={colors.white} />
                </View>
                <Text style={s.cardTitle}>Photos ({images.length})</Text>
              </View>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {images.map((img, i) => (
                  <PhotoThumb
                    key={i}
                    uri={img.uri}
                    recipientPhone={img.recipient_phone}
                    onPress={() => setPreviewIndex(i)}
                  />
                ))}
              </ScrollView>
            </View>
          )}

          {/* Bus Courier Handoff — per-item handoff data (item.handoff) */}
          {itemHandoff && (
            <View style={[s.card, { borderWidth: 1.5, borderColor: "#7c3aed" }]}>
              <View style={s.cardHeader}>
                <View style={[s.cardIconWrap, { backgroundColor: "#ede9fe" }]}>
                  <Ionicons name="bus" size={18} color="#7c3aed" />
                </View>
                <Text style={s.cardTitle}>Sent via Bus Courier</Text>
              </View>
              {itemHandoff.bus_station && (
                <View style={s.handoffRow}>
                  <Text style={s.handoffLabel}>Station</Text>
                  <Text style={s.handoffValue}>{itemHandoff.bus_station}</Text>
                </View>
              )}
              {itemHandoff.courier_phone && (
                <TouchableOpacity
                  style={s.handoffRow}
                  onPress={() => Linking.openURL(`tel:${itemHandoff.courier_phone}`)}
                  activeOpacity={0.7}
                >
                  <Text style={s.handoffLabel}>Bus Rider Number</Text>
                  <Text style={[s.handoffValue, { color: colors.primary }]}>{formatPhone(itemHandoff.courier_phone)}</Text>
                </TouchableOpacity>
              )}
              {itemHandoff.vehicle_number && (
                <View style={s.handoffRow}>
                  <Text style={s.handoffLabel}>Vehicle</Text>
                  <Text style={s.handoffValue}>{itemHandoff.vehicle_number}</Text>
                </View>
              )}
              {itemHandoff.handed_off_at && (
                <View style={s.handoffRow}>
                  <Text style={s.handoffLabel}>Handed off</Text>
                  <Text style={s.handoffValue}>{formatDateTimeAmPm(itemHandoff.handed_off_at)}</Text>
                </View>
              )}
              {itemHandoff.proof_photo_url && (
                <TouchableOpacity
                  activeOpacity={0.85}
                  style={s.handoffProofBlock}
                  onPress={() => setProofPreviewUri(itemHandoff.proof_photo_url)}
                >
                  <Text style={s.handoffProofLabel}>Rider Proof Photo</Text>
                  <Image
                    source={{ uri: itemHandoff.proof_photo_url }}
                    style={s.handoffProofImage}
                    resizeMode="cover"
                  />
                  <Text style={s.handoffProofHint}>Tap to view full photo</Text>
                </TouchableOpacity>
              )}
            </View>
          )}

          {/* Delivery Details Card (per-item, separate) */}
          {isPerItem && deliveryName && (
            <View style={s.card}>
              <View style={s.cardHeader}>
                <View style={[s.cardIconWrap, { backgroundColor: colors.primary }]}>
                  <Ionicons name="home" size={18} color={colors.white} />
                </View>
                <Text style={s.cardTitle}>Delivery Details</Text>
              </View>
              {(() => {
                const rows = [
                  { icon: "person-outline" as const, label: "Recipient", value: deliveryName },
                  deliveryPhoneRaw ? { icon: "call-outline" as const, label: "Phone", value: formatPhone(deliveryPhoneRaw) } : null,
                  deliveryLocation.display ? { icon: "navigate-outline" as const, label: "Location", value: deliveryLocation.display } : null,
                  deliveryLocation.landmark ? { icon: "flag-outline" as const, label: "Landmark", value: deliveryLocation.landmark } : null,
                  deliveryInstructions ? { icon: "chatbubble-outline" as const, label: "Instructions", value: deliveryInstructions } : null,
                ].filter(Boolean) as { icon: keyof typeof Ionicons.glyphMap; label: string; value: string }[];
                return rows.map((row, i) => (
                  <ViewRow key={row.label} icon={row.icon} label={row.label} value={row.value} last={i === rows.length - 1} />
                ));
              })()}
            </View>
          )}
        </View>
      </ScrollView>

      {/* Lightbox */}
      <Modal visible={previewIndex >= 0} transparent animationType="fade" onRequestClose={() => setPreviewIndex(-1)}>
        <View style={s.lightbox}>
          <View style={s.lightboxHeader}>
            <Text style={s.lightboxCounter}>{previewIndex + 1} / {images.length}</Text>
            <TouchableOpacity onPress={() => setPreviewIndex(-1)} style={s.lightboxClose}>
              <Ionicons name="close" size={24} color={colors.white} />
            </TouchableOpacity>
          </View>
          {previewIndex >= 0 && images[previewIndex] && (
            <Image source={{ uri: images[previewIndex].uri }} style={s.lightboxImage} resizeMode="contain" />
          )}
          <View style={s.lightboxNav}>
            <TouchableOpacity
              onPress={() => setPreviewIndex(Math.max(0, previewIndex - 1))}
              style={[s.lightboxNavBtn, previewIndex === 0 && { opacity: 0.3 }]}
              disabled={previewIndex === 0}
            >
              <Ionicons name="chevron-back" size={28} color={colors.white} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setPreviewIndex(Math.min(images.length - 1, previewIndex + 1))}
              style={[s.lightboxNavBtn, previewIndex === images.length - 1 && { opacity: 0.3 }]}
              disabled={previewIndex === images.length - 1}
            >
              <Ionicons name="chevron-forward" size={28} color={colors.white} />
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={!!proofPreviewUri} transparent animationType="fade" onRequestClose={() => setProofPreviewUri(null)}>
        <View style={s.lightbox}>
          <View style={s.lightboxHeader}>
            <Text style={s.lightboxCounter}>Bus courier proof</Text>
            <TouchableOpacity onPress={() => setProofPreviewUri(null)} style={s.lightboxClose}>
              <Ionicons name="close" size={24} color={colors.white} />
            </TouchableOpacity>
          </View>
          {proofPreviewUri && (
            <Image source={{ uri: proofPreviewUri }} style={s.lightboxImage} resizeMode="contain" />
          )}
        </View>
      </Modal>
    </View>
  );
}

function PhotoThumb({ uri, recipientPhone, onPress }: { uri: string; recipientPhone: string | null; onPress: () => void }) {
  const [loaded, setLoaded] = useState(false);
  const shimmerAnim = useRef(new Animated.Value(0.3)).current;

  useEffect(() => {
    if (!loaded) {
      const anim = Animated.loop(
        Animated.sequence([
          Animated.timing(shimmerAnim, { toValue: 0.7, duration: 800, useNativeDriver: true }),
          Animated.timing(shimmerAnim, { toValue: 0.3, duration: 800, useNativeDriver: true }),
        ])
      );
      anim.start();
      return () => anim.stop();
    }
  }, [loaded]);

  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.8} style={{ marginRight: 10 }}>
      {!loaded && (
        <Animated.View style={[s.viewThumb, { backgroundColor: colors.neutral200, position: 'absolute', opacity: shimmerAnim }]}>
          <Ionicons name="image-outline" size={24} color={colors.neutral400} />
        </Animated.View>
      )}
      <Image source={{ uri }} style={s.viewThumb} onLoad={() => setLoaded(true)} />
      {recipientPhone ? (
        <View style={s.recipientRow}>
          <Text style={s.recipientRowText}>{recipientPhone}</Text>
        </View>
      ) : (
        <View style={s.recipientRow}>
          <Text style={s.recipientRowMuted} numberOfLines={1}>No recipient</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

function ViewRow({ icon, label, value, last }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string; last?: boolean }) {
  return (
    <View style={[s.viewRow, last && { borderBottomWidth: 0 }]}>
      <Ionicons name={icon} size={16} color={colors.textMuted} style={{ marginTop: 2 }} />
      <View style={{ flex: 1 }}>
        <Text style={s.viewLabel}>{label}</Text>
        <Text style={s.viewValue}>{value}</Text>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f1f5f9" },
  headerPlaceholder: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 20, paddingBottom: 16, backgroundColor: "#1e293b" },
  header: { paddingHorizontal: 20, paddingBottom: 20, gap: 8, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.semibold, fontSize: 18, color: colors.white, flex: 1 },
  body: { padding: 16, gap: 16, backgroundColor: colors.background, flexGrow: 1 },
  card: { backgroundColor: colors.white, borderRadius: 16, padding: 16, gap: 14 },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 4 },
  cardIconWrap: { width: 34, height: 34, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, letterSpacing: 0.5, textTransform: "uppercase", flex: 1 },
  // View mode
  viewRow: { flexDirection: "row", gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  viewLabel: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.5 },
  viewValue: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.dark, marginTop: 1 },
  viewThumb: { width: 90, height: 90, borderRadius: 12, justifyContent: "center", alignItems: "center" },
  recipientRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, paddingTop: 2, paddingBottom: 2, width: 90 },
  recipientRowText: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.primary, flexShrink: 1 },
  recipientRowMuted: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, flexShrink: 1 },
  // Header
  headerSubtitle: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  trackingBadge: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: "rgba(255,255,255,0.9)", paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  heroStatusChip: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, marginTop: 10 },
  heroStatusChipText: { fontFamily: fontFamily.semibold, fontSize: 12, letterSpacing: 0.3 },
  handoffRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  handoffLabel: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted },
  handoffValue: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.dark, flexShrink: 1, textAlign: "right" },
  handoffProofBlock: { marginTop: 6, borderTopWidth: 1, borderTopColor: "#ede9fe", paddingTop: 12, gap: 8 },
  handoffProofLabel: { fontFamily: fontFamily.semibold, fontSize: 12, color: "#7c3aed", textTransform: "uppercase", letterSpacing: 0.5 },
  handoffProofImage: { width: "100%", height: 180, borderRadius: 12, backgroundColor: colors.neutral200 },
  handoffProofHint: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted },
  trackingText: { fontFamily: fontFamily.medium, fontSize: 10, color: colors.primary, letterSpacing: 0.3 },
  // Hero view mode
  heroItemCard: { flexDirection: "row", alignItems: "center", backgroundColor: "rgba(255,255,255,0.08)", borderRadius: 14, padding: 14, gap: 12 },
  heroItemName: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.white, lineHeight: 24 },
  heroItemSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", lineHeight: 17, flex: 1 },
  heroSummaryCol: { flexDirection: "row", gap: 6 },
  heroSummaryCard: { alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.1)", borderRadius: 10, width: 52, height: 64 },
  heroSummaryValue: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.white },
  heroSummaryLabel: { fontFamily: fontFamily.regular, fontSize: 8, color: "rgba(255,255,255,0.5)", textTransform: "uppercase", letterSpacing: 0.3 },
  // Lightbox
  lightbox: { flex: 1, backgroundColor: "rgba(0,0,0,0.95)", justifyContent: "center" },
  lightboxHeader: { position: "absolute", top: 50, left: 0, right: 0, flexDirection: "row", justifyContent: "center", alignItems: "center", zIndex: 10 },
  lightboxCounter: { fontFamily: fontFamily.medium, fontSize: 14, color: "rgba(255,255,255,0.7)" },
  lightboxClose: { position: "absolute", right: 20, width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.15)", justifyContent: "center", alignItems: "center" },
  lightboxImage: { width: "100%", height: "65%" },
  lightboxNav: { position: "absolute", bottom: 60, left: 0, right: 0, flexDirection: "row", justifyContent: "center", gap: 40 },
  lightboxNavBtn: { width: 50, height: 50, borderRadius: 25, backgroundColor: "rgba(255,255,255,0.15)", justifyContent: "center", alignItems: "center" },
});
