import { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  Dimensions,
  Modal,
  Pressable,
  FlatList,
  KeyboardAvoidingView,
  Keyboard,
  Platform,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import Input from "../../../../src/components/common/Input";
import Button from "../../../../src/components/common/Button";
import PickupVehicleRequestCard, { type PickupVehicleSelection } from "../../../../src/components/vendor/PickupVehicleRequestCard";
import { colors } from "../../../../src/constants/colors";
import { fontFamily } from "../../../../src/constants/typography";
import { getShipment } from "../../../../src/api/v1/vendor/shipments";
import { showSuccess, showError, getErrorMessage } from "../../../../src/utils/toast";
import { compressToUnder2MB, compressMany } from "../../../../src/utils/image";
import { captureSinglePhoto } from "../../../../src/utils/cameraCapture";
import { isValidGhanaPhone, sanitizeLocalPhoneInput, toApiPhone, toLocalPhone } from "../../../../src/utils/format";
import api from "../../../../src/api/client";

type EditPhoto =
  | {
      kind: "existing";
      id: number;
      uri: string;
      recipientPhone: string | null;
      originalPhone: string | null;
    }
  | { kind: "new"; uri: string; recipientPhone: string | null };

const MAX_PHOTOS = 100;
const SCREEN_WIDTH = Dimensions.get("window").width;
const PHOTO_GAP = 4;

export default function EditShipmentScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const detailRoute = {
    pathname: "/(vendor)/shipment/[id]",
    params: { id: String(id) },
  } as const;
  const [pageLoading, setPageLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const scrollRef = useRef<ScrollView>(null);
  const [fieldPositions, setFieldPositions] = useState({ pickupTown: 0, senderNotes: 0 });

  const [pickupTown, setPickupTown] = useState("");
  const [totalPackageQty, setTotalPackageQty] = useState("");
  const [senderNotes, setSenderNotes] = useState("");
  const [pickupVehicles, setPickupVehicles] = useState<PickupVehicleSelection[]>([]);
  const [pickupVehiclesTouched, setPickupVehiclesTouched] = useState(false);
  const [pickupVehiclesDefaultExpanded, setPickupVehiclesDefaultExpanded] = useState(false);
  const [photos, setPhotos] = useState<EditPhoto[]>([]);
  const [removedExistingIds, setRemovedExistingIds] = useState<number[]>([]);

  const [gridWidth, setGridWidth] = useState(0);
  const photoSize = gridWidth > 0 ? (gridWidth - PHOTO_GAP * 2) / 3 : 90;
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const openLightbox = (i: number) => { setLightboxIndex(i); setLightboxOpen(true); };
  const closeLightbox = () => setLightboxOpen(false);
  const lightboxRef = useRef<FlatList>(null);

  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState<Set<number>>(new Set());

  const [tagModalOpen, setTagModalOpen] = useState(false);
  const [tagPhoneInput, setTagPhoneInput] = useState("");
  const [tagPhoneError, setTagPhoneError] = useState("");
  const [tagTargetIndices, setTagTargetIndices] = useState<number[] | null>(null);

  const leaveEditScreen = () => {
    if (router.canGoBack()) router.back();
    else router.replace(detailRoute as any);
  };

  useEffect(() => {
    const showSub = Keyboard.addListener("keyboardDidShow", () => setKeyboardVisible(true));
    const hideSub = Keyboard.addListener("keyboardDidHide", () => setKeyboardVisible(false));
    return () => {
      showSub.remove();
      hideSub.remove();
    };
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const res = await getShipment(Number(id));
        const sh = res.data?.shipment || res.data;
        setPickupTown(sh.pickup_town || sh.pickup?.location?.town || "");
        setSenderNotes(sh.sender_notes || "");
        setTotalPackageQty(String(sh.vendor_declared_quantity || ""));
        const initialVehicles = (sh.pickup_vehicles || []).map((vehicle: any) => ({
          vehicle_type_id: Number(vehicle.vehicle_type_id),
          quantity: Number(vehicle.quantity || 1),
        })).filter((vehicle: PickupVehicleSelection) => vehicle.vehicle_type_id > 0);
        setPickupVehicles(initialVehicles);
        setPickupVehiclesDefaultExpanded(initialVehicles.length > 0);
        setPickupVehiclesTouched(false);

        const initial: EditPhoto[] = [];
        (sh.items || []).forEach((item: any) => {
          (item.images || []).forEach((img: any) => {
            const localPhone = sanitizeLocalPhoneInput(toLocalPhone(img.recipient_phone));
            initial.push({
              kind: "existing",
              id: img.id,
              uri: img.thumbnail_url || img.url || img,
              recipientPhone: localPhone || null,
              originalPhone: localPhone || null,
            });
          });
        });
        setPhotos(initial);
      } catch (err: any) {
        showError(getErrorMessage(err));
      } finally {
        setPageLoading(false);
      }
    })();
  }, [id]);

  const takePhoto = async () => {
    if (photos.length >= MAX_PHOTOS) {
      Alert.alert("Limit reached", `Maximum ${MAX_PHOTOS} photos allowed.`);
      return;
    }
    const capturedUri = await captureSinglePhoto({ quality: 0.7, simulatorBehavior: 'choice' });
    if (!capturedUri) return;

    const newIndex = photos.length;
    const compressedUri = await compressToUnder2MB(capturedUri);
    const newPhoto: EditPhoto = { kind: "new", uri: compressedUri, recipientPhone: null };
    setPhotos((prev) => [...prev, newPhoto].slice(0, MAX_PHOTOS));
    setTimeout(() => openTagModal([newIndex]), 80);
  };

  const pickFromGallery = async () => {
    const remaining = MAX_PHOTOS - photos.length;
    if (remaining <= 0) {
      Alert.alert("Limit reached", `Maximum ${MAX_PHOTOS} photos allowed.`);
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsMultipleSelection: true,
      quality: 0.7,
      selectionLimit: remaining,
    });
    if (!result.canceled && result.assets.length > 0) {
      const startIdx = photos.length;
      const count = Math.min(result.assets.length, remaining);
      const originalUris = result.assets.slice(0, count).map((a) => a.uri);
      const compressedUris = await compressMany(originalUris);
      const newEntries: EditPhoto[] = compressedUris.map((uri) => ({
        kind: "new" as const,
        uri,
        recipientPhone: null,
      }));
      const newIndices = Array.from({ length: count }, (_, i) => startIdx + i);
      setPhotos((prev) => [...prev, ...newEntries].slice(0, MAX_PHOTOS));
      setTimeout(() => openTagModal(newIndices), 80);
    }
  };

  const removePhoto = (index: number) => {
    const ph = photos[index];
    if (!ph) return;
    if (ph.kind === "existing") {
      setRemovedExistingIds((prev) => [...prev, ph.id]);
    }
    setPhotos((prev) => prev.filter((_, i) => i !== index));
    if (lightboxOpen) {
      if (lightboxIndex >= photos.length - 1) setLightboxIndex(Math.max(0, photos.length - 2));
      if (photos.length <= 1) setLightboxOpen(false);
    }
  };

  const toggleSelect = (index: number) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  };

  const removeSelected = () => {
    const removedIds = photos
      .filter((p, i) => selected.has(i) && p.kind === "existing")
      .map((p) => (p as { id: number }).id);
    if (removedIds.length > 0) {
      setRemovedExistingIds((prev) => [...prev, ...removedIds]);
    }
    setPhotos((prev) => prev.filter((_, i) => !selected.has(i)));
    setSelected(new Set());
    setSelectMode(false);
  };

  const openTagModal = (arg?: number | number[]) => {
    let indices: number[] | null = null;
    if (typeof arg === "number") indices = [arg];
    else if (Array.isArray(arg)) indices = arg;

    setTagTargetIndices(indices);

    const sourceIndices = indices ?? Array.from(selected);
    const phones = sourceIndices.map((i) => sanitizeLocalPhoneInput(photos[i]?.recipientPhone || ""));
    const unique = new Set(phones);
    setTagPhoneInput(unique.size === 1 ? Array.from(unique)[0] : "");
    setTagPhoneError("");

    setTagModalOpen(true);
  };

  const applyTag = (overridePhone?: string) => {
    const phoneRaw = sanitizeLocalPhoneInput(overridePhone ?? tagPhoneInput);
    if (phoneRaw.length > 0 && !isValidGhanaPhone(phoneRaw)) {
      setTagPhoneError("Enter a valid 10-digit Ghana phone number");
      return;
    }
    const phone = phoneRaw.length > 0 ? phoneRaw : null;
    const wasSelectModeBulk = tagTargetIndices === null;
    // Applies to both new and existing. Existing photos with changed phones
    // will be transparently re-uploaded on save (backend supports only
    // new_photos_phones[], so we automate "remove + re-add" for the user).
    setPhotos((prev) => {
      if (tagTargetIndices !== null) {
        const set = new Set(tagTargetIndices);
        return prev.map((p, i) => (set.has(i) ? { ...p, recipientPhone: phone } : p));
      }
      return prev.map((p, i) => (selected.has(i) ? { ...p, recipientPhone: phone } : p));
    });
    setTagModalOpen(false);
    setTagPhoneInput("");
    setTagPhoneError("");
    setTagTargetIndices(null);
    if (wasSelectModeBulk) {
      setSelected(new Set());
      setSelectMode(false);
    }
  };

  const cancelTag = () => {
    setTagModalOpen(false);
    setTagPhoneInput("");
    setTagPhoneError("");
    setTagTargetIndices(null);
  };

  const scrollToField = (key: "pickupTown" | "senderNotes") => {
    const y = fieldPositions[key];
    requestAnimationFrame(() => {
      scrollRef.current?.scrollTo({ y: Math.max(0, y - 24), animated: true });
    });
  };

  const untaggedNewCount = photos.filter((p) => p.kind === "new" && !p.recipientPhone).length;
  const canSave = untaggedNewCount === 0;

  const handleSave = async () => {
    if (!canSave) {
      showError(`${untaggedNewCount} new photo${untaggedNewCount !== 1 ? "s" : ""} still need a recipient phone`);
      return;
    }
    const declaredQty = Number(totalPackageQty);
    if (!Number.isInteger(declaredQty) || declaredQty < 1) {
      showError("Enter the total package quantity");
      return;
    }
    setSaving(true);
    try {
      const formData = new FormData();
      if (pickupTown.trim()) formData.append("pickup_town", pickupTown.trim());
      if (senderNotes.trim()) formData.append("sender_notes", senderNotes.trim());
      formData.append("vendor_declared_quantity", String(declaredQty));
      if (pickupVehiclesTouched) {
        formData.append("pickup_vehicles", JSON.stringify(pickupVehicles));
      }

      // Backend only supports new_photos_phones[] for new photos, not updating
      // existing photo phones directly (AGENTS.md Appendix G & I). To give the
      // user a seamless edit experience, we automate the spec's "remove + re-add"
      // flow client-side: download the original image and re-upload it with the
      // new phone, queuing the original ID for removal.
      const existingToReupload: Array<{ oldId: number; uri: string; phone: string | null }> = [];
      photos.forEach((ph) => {
        if (ph.kind === "existing") {
          const changed = (ph.recipientPhone || "") !== (ph.originalPhone || "");
          if (changed) {
            existingToReupload.push({ oldId: ph.id, uri: ph.uri, phone: ph.recipientPhone });
          }
        }
      });

      const reuploaded: Array<{ localUri: string; phone: string | null; oldId: number }> = [];
      if (existingToReupload.length > 0) {
        const FileSystem = await import("expo-file-system");
        const cacheDir = (FileSystem as any).cacheDirectory || "";
        for (const item of existingToReupload) {
          const target = `${cacheDir}edit_${item.oldId}_${Date.now()}.jpg`;
          const res = await (FileSystem as any).downloadAsync(item.uri, target);
          reuploaded.push({ localUri: res.uri, phone: item.phone, oldId: item.oldId });
        }
      }

      // Original IDs that need removing: user-deleted + phone-edited existing.
      const allRemoveIds = [
        ...removedExistingIds,
        ...reuploaded.map((r) => r.oldId),
      ];
      allRemoveIds.forEach((pid) => {
        formData.append("remove_photo_ids[]", String(pid));
      });

      // New photos + re-uploaded existing photos both go into new_photos[].
      let newIdx = 0;
      photos.forEach((ph) => {
        if (ph.kind === "new") {
          formData.append(`new_photos[${newIdx}]`, {
            uri: ph.uri,
            name: `photo_${newIdx}.jpg`,
            type: "image/jpeg",
          } as any);
          if (ph.recipientPhone) {
            formData.append(`new_photos_phones[${newIdx}]`, toApiPhone(ph.recipientPhone));
          }
          newIdx++;
        }
      });
      reuploaded.forEach((r) => {
        formData.append(`new_photos[${newIdx}]`, {
          uri: r.localUri,
          name: `photo_${newIdx}.jpg`,
          type: "image/jpeg",
        } as any);
        if (r.phone) {
          formData.append(`new_photos_phones[${newIdx}]`, toApiPhone(r.phone));
        }
        newIdx++;
      });

      await api.put(`/vendor/shipments/${Number(id)}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
        timeout: 180000,
      });

      showSuccess("Package updated!");
      router.replace(detailRoute as any);
    } catch (err: any) {
      if (__DEV__) console.log("[EditShipment] Error:", JSON.stringify(err, null, 2));
      showError(getErrorMessage(err, "Failed to update. Please try again."));
    } finally {
      setSaving(false);
    }
  };

  if (pageLoading) {
    return (
      <View style={s.container}>
        <LinearGradient
          colors={["#1e293b", "#334155", "#1e293b"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[s.header, { paddingTop: insets.top + 12 }]}
        >
          <View style={s.headerRow}>
            <TouchableOpacity onPress={leaveEditScreen} style={s.backBtn}>
              <Ionicons name="arrow-back" size={20} color={colors.white} />
            </TouchableOpacity>
            <View style={{ flex: 1 }}>
              <View style={[s.loadingBlock, s.loadingTitle]} />
              <View style={[s.loadingBlock, s.loadingSubtitle]} />
            </View>
          </View>
        </LinearGradient>

        <ScrollView
          style={s.scroll}
          contentContainerStyle={{ paddingBottom: 100, flexGrow: 1, backgroundColor: colors.background }}
          showsVerticalScrollIndicator={false}
        >
          <View style={s.body}>
            <View style={s.loadingCard}>
              <View style={s.loadingCardHeader}>
                <View style={s.loadingIcon} />
                <View style={[s.loadingBlock, { width: 132, height: 14 }]} />
              </View>
              <View style={[s.loadingBlock, s.loadingInputLabel]} />
              <View style={s.loadingInput} />
            </View>

            <View style={s.loadingCard}>
              <View style={s.loadingCardHeader}>
                <View style={s.loadingIcon} />
                <View style={[s.loadingBlock, { width: 112, height: 14 }]} />
                <View style={s.loadingOptionalPill} />
              </View>
              <View style={[s.loadingBlock, s.loadingInputLabel]} />
              <View style={[s.loadingInput, { height: 92 }]} />
            </View>

            <View style={s.loadingCard}>
              <View style={s.loadingCardHeader}>
                <View style={s.loadingIcon} />
                <View style={[s.loadingBlock, { width: 64, height: 14 }]} />
                <View style={{ flex: 1 }} />
                <View style={s.loadingActionText} />
                <View style={s.loadingPhotoCount} />
              </View>
              <View style={s.loadingPhotoGrid}>
                {[0, 1, 2, 3, 4, 5].map((idx) => (
                  <View key={idx} style={s.loadingPhotoTile}>
                    <View style={s.loadingPhotoThumb} />
                    <View style={s.loadingPhotoCaption} />
                  </View>
                ))}
              </View>
              <View style={s.loadingGalleryLink}>
                <View style={s.loadingTinyIcon} />
                <View style={[s.loadingBlock, { width: 128, height: 11 }]} />
              </View>
            </View>
          </View>
        </ScrollView>

        <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
          <View style={s.loadingSaveButton} />
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={s.container} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <LinearGradient
        colors={["#1e293b", "#334155", "#1e293b"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[s.header, { paddingTop: insets.top + 12 }]}
      >
        <View style={s.headerRow}>
          <TouchableOpacity onPress={leaveEditScreen} style={s.backBtn}>
            <Ionicons name="arrow-back" size={20} color={colors.white} />
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={s.headerTitle}>Edit Parcel</Text>
            <Text style={s.headerSub}>Update photos, pickup, and notes</Text>
          </View>
        </View>
      </LinearGradient>

      <ScrollView
        ref={scrollRef}
        style={s.scroll}
        contentContainerStyle={{
          paddingBottom: keyboardVisible ? 360 : 24,
          flexGrow: 1,
          backgroundColor: colors.background,
        }}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="interactive"
        automaticallyAdjustKeyboardInsets={Platform.OS === "ios"}
        showsVerticalScrollIndicator={false}
      >
        <View style={s.body}>
          {/* Pickup Location — FIRST */}
          <View
            style={s.card}
            onLayout={(e) => {
              const y = e.nativeEvent.layout.y;
              setFieldPositions((prev) => ({ ...prev, pickupTown: y }));
            }}
          >
            <View style={s.cardHeader}>
              <View style={[s.cardIconWrap, { backgroundColor: "#dcfce7" }]}>
                <Ionicons name="location" size={18} color={colors.success} />
              </View>
              <Text style={s.cardTitle}>Pickup Location</Text>
            </View>
            <Input
              label="Pickup Location"
              placeholder="Where should we pick up? e.g. Lapaz"
              value={pickupTown}
              onChangeText={setPickupTown}
              onFocus={() => scrollToField("pickupTown")}
              leftIcon={<Ionicons name="navigate-outline" size={18} color={colors.textMuted} />}
            />
          </View>

          <View style={s.card}>
            <View style={s.cardHeader}>
              <View style={[s.cardIconWrap, { backgroundColor: "#ffedd5" }]}>
                <Ionicons name="cube" size={18} color={colors.primary} />
              </View>
              <Text style={s.cardTitle}>Total Quantity</Text>
            </View>
            <Input
              label="Total package quantity"
              placeholder="How many packages in total?"
              value={totalPackageQty}
              onChangeText={setTotalPackageQty}
              keyboardType="number-pad"
              leftIcon={<Ionicons name="calculator-outline" size={18} color={colors.textMuted} />}
            />
          </View>

          <PickupVehicleRequestCard
            selections={pickupVehicles}
            onChange={setPickupVehicles}
            defaultExpanded={pickupVehiclesDefaultExpanded}
            onTouched={() => setPickupVehiclesTouched(true)}
          />

          {/* Photos — LAST */}
          <View style={s.card}>
            <View style={s.cardHeader}>
              <View style={[s.cardIconWrap, { backgroundColor: "#dbeafe" }]}>
                <Ionicons name="camera" size={18} color="#3b82f6" />
              </View>
              <Text style={[s.cardTitle, { flex: 1 }]}>Photos</Text>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                {selectMode ? (
                  <TouchableOpacity
                    onPress={() => {
                      setSelectMode(false);
                      setSelected(new Set());
                    }}
                  >
                    <Text style={s.headerAction}>Cancel</Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity onPress={() => setSelectMode(true)}>
                    <Text style={s.headerAction}>Select</Text>
                  </TouchableOpacity>
                )}
                <View style={s.photoCountBadge}>
                  <Text style={s.photoCountText}>{photos.length}</Text>
                </View>
              </View>
            </View>

            <View style={s.photoGrid} onLayout={(e) => setGridWidth(e.nativeEvent.layout.width)}>
              {photos.map((photo, i) => (
                <View
                  key={photo.kind === "existing" ? `ex-${photo.id}` : `new-${i}`}
                  style={{ width: photoSize }}
                >
                  <TouchableOpacity
                    style={[
                      s.photoItem,
                      { width: photoSize, height: photoSize },
                      selectMode && selected.has(i) && s.photoSelected,
                    ]}
                    onPress={() => (selectMode ? toggleSelect(i) : openLightbox(i))}
                    onLongPress={async () => {
                      const Haptics = await import("expo-haptics");
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                      if (!selectMode) {
                        setSelectMode(true);
                        setSelected(new Set([i]));
                      } else {
                        toggleSelect(i);
                      }
                    }}
                    delayLongPress={300}
                    activeOpacity={0.8}
                  >
                    <Image source={{ uri: photo.uri }} style={[s.photoImg, { width: photoSize, height: photoSize }]} />
                    {photo.kind === "new" && !selectMode && (
                      <View style={s.newBadge}>
                        <Text style={s.newBadgeText}>NEW</Text>
                      </View>
                    )}
                    {selectMode && (
                      <View style={[s.selectCircle, selected.has(i) && s.selectCircleActive]}>
                        {selected.has(i) && <Ionicons name="checkmark" size={14} color={colors.white} />}
                      </View>
                    )}
                    {!selectMode && (
                      <TouchableOpacity style={s.photoRemove} onPress={() => removePhoto(i)}>
                        <View style={s.photoRemoveBg}>
                          <Ionicons name="close" size={14} color={colors.white} />
                        </View>
                      </TouchableOpacity>
                    )}
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={s.recipientRow}
                    onPress={() => !selectMode && openTagModal(i)}
                    disabled={selectMode}
                    activeOpacity={0.7}
                  >
                    {photo.recipientPhone ? (
                      <Text style={s.recipientRowText}>{photo.recipientPhone}</Text>
                    ) : photo.kind === "new" ? (
                      <>
                        <Ionicons name="alert-circle" size={12} color={colors.error} />
                        <Text style={s.recipientRowRequired}>Required</Text>
                      </>
                    ) : (
                      <>
                        <Ionicons name="add-circle-outline" size={11} color={colors.textMuted} />
                        <Text style={s.recipientRowMuted}>Add Recipient</Text>
                      </>
                    )}
                  </TouchableOpacity>
                </View>
              ))}

              {/* Add more tile */}
              <TouchableOpacity
                style={[s.addMoreBtn, { width: photoSize, height: photoSize }]}
                onPress={takePhoto}
                activeOpacity={0.7}
              >
                <Ionicons name="camera-outline" size={24} color={colors.primary} />
                <Text style={s.addMoreText}>Add</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={s.galleryLink} onPress={pickFromGallery}>
              <Ionicons name="images-outline" size={16} color={colors.primary} />
              <Text style={s.galleryLinkText}>Choose from gallery</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      {/* Footer */}
      {!keyboardVisible && (
        <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
          {selectMode && selected.size > 0 ? (
            <View style={s.selectActionRow}>
              <TouchableOpacity onPress={() => openTagModal()} style={s.tagRecipientBar}>
                <Ionicons name="call" size={16} color={colors.white} />
                <Text style={s.tagRecipientText}>Tag Recipient</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={removeSelected} style={s.removeSelectedBar}>
                <Ionicons name="trash-outline" size={16} color={colors.white} />
                <Text style={s.removeSelectedText}>Remove</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={{ gap: 8 }}>
              {!canSave && (
                <View style={s.saveHelper}>
                  <Ionicons name="alert-circle" size={14} color={colors.error} />
                  <Text style={s.saveHelperText}>
                    Tag {untaggedNewCount} new photo{untaggedNewCount !== 1 ? "s" : ""} with a recipient to save
                  </Text>
                </View>
              )}
              <Button
                title={saving ? "Saving..." : "Save Changes"}
                onPress={handleSave}
                loading={saving}
                disabled={saving || !canSave || selectMode || !Number.isInteger(Number(totalPackageQty)) || Number(totalPackageQty) < 1}
                height={52}
                leftIcon={!saving ? <Ionicons name="checkmark" size={18} color={colors.white} /> : undefined}
              />
            </View>
          )}
        </View>
      )}

      {/* Lightbox */}
      <Modal visible={lightboxOpen} transparent animationType="fade" onRequestClose={closeLightbox}>
        <View style={s.lightbox}>
          <View style={s.lightboxTop}>
            <Text style={s.lightboxCounter}>
              {lightboxIndex + 1} / {photos.length}
            </Text>
            <View style={{ flexDirection: "row", gap: 16 }}>
              <TouchableOpacity onPress={() => removePhoto(lightboxIndex)} style={s.lightboxAction}>
                <Ionicons name="trash-outline" size={20} color="#fca5a5" />
              </TouchableOpacity>
              <TouchableOpacity onPress={closeLightbox} style={s.lightboxAction}>
                <Ionicons name="close" size={24} color={colors.white} />
              </TouchableOpacity>
            </View>
          </View>
          <FlatList
            ref={lightboxRef}
            data={photos}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            initialScrollIndex={lightboxIndex}
            getItemLayout={(_, index) => ({ length: SCREEN_WIDTH, offset: SCREEN_WIDTH * index, index })}
            onMomentumScrollEnd={(e) => {
              if (!lightboxOpen) return;
              const idx = Math.round(e.nativeEvent.contentOffset.x / SCREEN_WIDTH);
              setLightboxIndex(idx);
            }}
            keyExtractor={(ph, i) => (ph.kind === "existing" ? `ex-${ph.id}` : `new-${i}`)}
            renderItem={({ item: ph }) => (
              <View style={{ width: SCREEN_WIDTH, justifyContent: "center", alignItems: "center" }}>
                <Image source={{ uri: ph.uri }} style={s.lightboxImage} resizeMode="contain" />
              </View>
            )}
          />
          {photos[lightboxIndex]?.recipientPhone ? (
            <View style={s.lightboxPhonePill}>
              <Ionicons name="call" size={12} color={colors.white} />
              <Text style={s.lightboxPhonePillText}>{photos[lightboxIndex].recipientPhone}</Text>
            </View>
          ) : null}
        </View>
      </Modal>

      {/* Tag recipient phone modal */}
      <Modal visible={tagModalOpen} transparent animationType="fade" onRequestClose={cancelTag}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 12 : 0}
          style={s.tagModalAvoider}
        >
        <Pressable style={s.tagModalOverlay} onPress={cancelTag}>
          <Pressable style={s.tagModalCard} onPress={(e) => e.stopPropagation()}>
            {(() => {
              const activeIndices = tagTargetIndices ?? Array.from(selected);
              const isSingle = activeIndices.length === 1;
              const existingPhone = isSingle ? photos[activeIndices[0]]?.recipientPhone : null;
              const isEditingExisting = isSingle && !!existingPhone;

              const title = isEditingExisting
                ? "Edit Recipient Phone"
                : isSingle
                ? "Add Recipient Phone"
                : `Same recipient for ${activeIndices.length} photos?`;

              const subtitle = isSingle
                ? "Every package needs a recipient phone so we know who it's going to."
                : "Every photo needs a recipient. The same phone will apply to all selected — you can change any one later.";

              const cancelLabel = "Cancel";
              const phoneDigits = sanitizeLocalPhoneInput(tagPhoneInput);
              const phoneHelper = phoneDigits.length === 0
                ? ""
                : phoneDigits.length < 10
                  ? `${phoneDigits.length}/10 digits entered`
                  : !isValidGhanaPhone(phoneDigits)
                    ? "Enter a valid Ghana phone number, e.g. 0551234567"
                    : "";

              const applyLabel = isEditingExisting
                ? "Update"
                : isSingle
                ? "Add"
                : `Apply to ${activeIndices.length}`;

              return (
                <>
                  {isEditingExisting && (
                    <TouchableOpacity
                      onPress={cancelTag}
                      style={s.tagModalCloseX}
                      hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                    >
                      <Ionicons name="close" size={18} color={colors.textMuted} />
                    </TouchableOpacity>
                  )}
                  <View style={s.tagModalHeader}>
                    <View style={s.tagModalIconWrap}>
                      <Ionicons name="call" size={20} color={colors.white} />
                    </View>
                    <Text style={s.tagModalTitle}>{title}</Text>
                    <Text style={s.tagModalSub}>{subtitle}</Text>
                  </View>
                  <Input
                    label="Recipient Phone"
                    placeholder="e.g. 0551234567"
                    value={tagPhoneInput}
                    onChangeText={(text) => {
                      const next = sanitizeLocalPhoneInput(text);
                      setTagPhoneInput(next);
                      setTagPhoneError(next.length === 10 && !isValidGhanaPhone(next) ? "Enter a valid 10-digit Ghana phone number" : "");
                    }}
                    keyboardType="phone-pad"
                    maxLength={10}
                    autoFocus
                    error={tagPhoneError}
                    leftIcon={<Ionicons name="call-outline" size={18} color={colors.textMuted} />}
                  />
                  {!!phoneHelper && !tagPhoneError && (
                    <View style={s.phoneHelperRow}>
                      <Ionicons name="information-circle-outline" size={14} color={colors.textMuted} />
                      <Text style={s.phoneHelperText}>{phoneHelper}</Text>
                    </View>
                  )}
                  <View style={s.tagModalBtnRow}>
                    {!isEditingExisting && (
                      <TouchableOpacity onPress={cancelTag} style={s.tagModalCancel}>
                        <Text style={s.tagModalCancelText}>{cancelLabel}</Text>
                      </TouchableOpacity>
                    )}
                    {isEditingExisting ? (
                      <TouchableOpacity
                        onPress={() => {
                          applyTag("");
                        }}
                        style={s.tagModalClear}
                      >
                        <Text style={s.tagModalClearText}>Clear</Text>
                      </TouchableOpacity>
                    ) : null}
                    <TouchableOpacity
                      onPress={() => applyTag()}
                      style={[s.tagModalApply, !isValidGhanaPhone(tagPhoneInput) && s.tagModalApplyDisabled]}
                      disabled={!isValidGhanaPhone(tagPhoneInput)}
                    >
                      <Text style={s.tagModalApplyText}>{applyLabel}</Text>
                    </TouchableOpacity>
                  </View>
                </>
              );
            })()}
          </Pressable>
        </Pressable>
        </KeyboardAvoidingView>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, width: "100%", alignSelf: "stretch", backgroundColor: colors.background },
  scroll: { flex: 1 },
  // Header
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 16, gap: 4 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 20, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  // Cards
  body: { padding: 16, gap: 16 },
  card: { backgroundColor: colors.white, borderRadius: 16, padding: 16, gap: 14 },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  cardIconWrap: { width: 34, height: 34, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  optionalTag: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.textMuted, backgroundColor: colors.surface, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  headerAction: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.primary },
  photoCountBadge: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10, borderWidth: 1, borderColor: colors.accentLighter },
  photoCountText: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.primary },
  // Photo grid
  photoGrid: { flexDirection: "row", flexWrap: "wrap", gap: PHOTO_GAP, justifyContent: "flex-start" },
  photoItem: { position: "relative", borderRadius: 12, overflow: "hidden", borderWidth: 2, borderColor: "transparent" },
  photoImg: { borderRadius: 12 },
  photoRemove: { position: "absolute", top: 4, right: 4 },
  photoRemoveBg: { width: 22, height: 22, borderRadius: 11, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "center", alignItems: "center" },
  photoSelected: { opacity: 0.7, borderWidth: 2, borderColor: colors.primary },
  selectCircle: { position: "absolute", top: 6, left: 6, width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: colors.white, backgroundColor: "rgba(0,0,0,0.3)", justifyContent: "center", alignItems: "center" },
  selectCircleActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  addMoreBtn: { borderRadius: 12, borderWidth: 2, borderColor: colors.border, borderStyle: "dashed", justifyContent: "center", alignItems: "center", backgroundColor: colors.surface, gap: 4 },
  addMoreText: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.primary },
  newBadge: { position: "absolute", top: 4, left: 4, backgroundColor: colors.primary, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  newBadgeText: { fontFamily: fontFamily.bold, fontSize: 8, color: colors.white, letterSpacing: 0.5 },
  galleryLink: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  galleryLinkText: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.primary },
  // Recipient row (under each tile)
  recipientRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, paddingTop: 2, paddingBottom: 4, flexWrap: "wrap" },
  recipientRowText: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.primary, textAlign: "center" },
  recipientRowMuted: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, textAlign: "center" },
  recipientRowRequired: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.error, textAlign: "center" },
  saveHelper: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 4 },
  saveHelperText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.error },
  // Footer
  footer: { paddingHorizontal: 16, paddingTop: 12, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.border, shadowColor: colors.dark, shadowOffset: { width: 0, height: -2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 12 },
  selectActionRow: { flexDirection: "row", gap: 10 },
  tagRecipientBar: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: colors.primary, paddingVertical: 16, borderRadius: 24 },
  tagRecipientText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  removeSelectedBar: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: colors.error, paddingVertical: 16, borderRadius: 24 },
  removeSelectedText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  // Lightbox
  lightbox: { flex: 1, backgroundColor: "rgba(0,0,0,0.95)", justifyContent: "center" },
  lightboxTop: { position: "absolute", top: 50, left: 20, right: 20, flexDirection: "row", justifyContent: "space-between", alignItems: "center", zIndex: 10 },
  lightboxCounter: { fontFamily: fontFamily.medium, fontSize: 14, color: "rgba(255,255,255,0.7)" },
  lightboxAction: { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.15)", justifyContent: "center", alignItems: "center" },
  lightboxImage: { width: "100%", height: "65%" },
  lightboxPhonePill: { position: "absolute", bottom: 80, alignSelf: "center", flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: "rgba(234,88,12,0.95)" },
  lightboxPhonePillText: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.white },
  phoneHelperRow: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: -8 },
  phoneHelperText: { flex: 1, fontFamily: fontFamily.medium, fontSize: 11, color: colors.textMuted },
  // Tag modal
  tagModalAvoider: { flex: 1 },
  tagModalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "center", alignItems: "center", paddingHorizontal: 24 },
  tagModalCard: { width: "100%", backgroundColor: colors.white, borderRadius: 20, padding: 20, gap: 14 },
  tagModalHeader: { alignItems: "center", gap: 6 },
  tagModalIconWrap: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.primary, justifyContent: "center", alignItems: "center", marginBottom: 4 },
  tagModalTitle: { fontFamily: fontFamily.bold, fontSize: 17, color: colors.dark, textAlign: "center" },
  tagModalSub: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, textAlign: "center" },
  tagModalBtnRow: { flexDirection: "row", gap: 10, marginTop: 6 },
  tagModalCancel: { flex: 1, paddingVertical: 12, borderRadius: 24, alignItems: "center", justifyContent: "center", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  tagModalCancelText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.textMuted },
  tagModalClear: { flex: 1, paddingVertical: 12, borderRadius: 24, alignItems: "center", justifyContent: "center", backgroundColor: "#fee2e2", borderWidth: 1, borderColor: "#fca5a5" },
  tagModalClearText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.error },
  tagModalApply: { flex: 1, paddingVertical: 12, borderRadius: 24, alignItems: "center", justifyContent: "center", backgroundColor: colors.primary },
  tagModalApplyDisabled: { opacity: 0.4 },
  tagModalApplyText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  tagModalCloseX: { position: "absolute", top: 12, right: 12, width: 32, height: 32, borderRadius: 16, backgroundColor: colors.surface, justifyContent: "center", alignItems: "center", zIndex: 2 },
  // Loading skeleton
  loadingBlock: { borderRadius: 8, backgroundColor: colors.neutral200 },
  loadingTitle: { width: 126, height: 20, backgroundColor: "rgba(255,255,255,0.2)" },
  loadingSubtitle: { width: 184, height: 12, marginTop: 8, backgroundColor: "rgba(255,255,255,0.12)" },
  loadingCard: { backgroundColor: colors.white, borderRadius: 16, padding: 16, gap: 14 },
  loadingCardHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  loadingIcon: { width: 34, height: 34, borderRadius: 10, backgroundColor: colors.neutral100 },
  loadingOptionalPill: { width: 58, height: 20, borderRadius: 10, backgroundColor: colors.surface, marginLeft: "auto" },
  loadingInputLabel: { width: 96, height: 11 },
  loadingInput: { height: 56, borderRadius: 16, backgroundColor: colors.neutral100, borderWidth: 1, borderColor: colors.neutral200 },
  loadingActionText: { width: 42, height: 12, borderRadius: 6, backgroundColor: colors.neutral200 },
  loadingPhotoCount: { width: 32, height: 26, borderRadius: 13, backgroundColor: colors.warmSurface },
  loadingPhotoGrid: { flexDirection: "row", flexWrap: "wrap", gap: PHOTO_GAP },
  loadingPhotoTile: { width: (SCREEN_WIDTH - 32 - 32 - PHOTO_GAP * 2) / 3, gap: 5 },
  loadingPhotoThumb: { height: (SCREEN_WIDTH - 32 - 32 - PHOTO_GAP * 2) / 3, borderRadius: 12, backgroundColor: colors.neutral100 },
  loadingPhotoCaption: { width: "70%", height: 10, borderRadius: 5, backgroundColor: colors.neutral200, alignSelf: "center" },
  loadingGalleryLink: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  loadingTinyIcon: { width: 16, height: 16, borderRadius: 8, backgroundColor: colors.neutral200 },
  loadingSaveButton: { height: 52, borderRadius: 24, backgroundColor: colors.neutral200 },
});
