import { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  Dimensions,
  Alert,
  Linking,
  Image,
  Modal,
} from "react-native";
import { router, useLocalSearchParams, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import ConfirmDialog from "../../../src/components/common/ConfirmDialog";
import { ListSkeleton } from "../../../src/components/common/ShimmerLoading";
import ErrorState from "../../../src/components/common/ErrorState";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { spacing, borderRadius } from "../../../src/constants/spacing";
import { getShipment, deleteShipment } from "../../../src/api/v1/vendor/shipments";
import { showSuccess, showError, getErrorMessage } from "../../../src/utils/toast";
import { formatDateTimeAmPm, formatPhone, formatLocation, formatCurrency } from "../../../src/utils/format";
import { shipmentStatusConfig, itemStatusConfig, type ShipmentStatus, type ItemStatus } from "../../../src/constants/statuses";
import type { ChargeLine, DeliveryEtaInfo } from "../../../src/types/vendor";

function activeCharge(line: ChargeLine): boolean {
  return line.status !== "cancelled" && line.status !== "waived";
}

function latestCharge(lines: ChargeLine[]): ChargeLine | null {
  return [...lines].sort((a, b) => {
    const aTime = new Date(a.created_at || 0).getTime();
    const bTime = new Date(b.created_at || 0).getTime();
    if (aTime !== bTime) return bTime - aTime;
    return Number(b.id || 0) - Number(a.id || 0);
  })[0] || null;
}

const { width } = Dimensions.get("window");
const UNPROCESSED_PHOTO_GAP = 6;

type UnprocessedPhoto = {
  key: string;
  uri: string;
  recipientPhone: string | null;
};

type PackagePhotoPreview = {
  uri: string;
  context: "package" | "standalone";
};

function getPhotoUri(photo: any): string | null {
  if (typeof photo === "string") return photo || null;
  return photo?.thumbnail_url || photo?.url || photo?.uri || null;
}

function getUnprocessedPhotos(items: any[]): UnprocessedPhoto[] {
  if (!Array.isArray(items)) return [];
  return items.flatMap((item: any, itemIndex: number) => {
    const images = Array.isArray(item?.images) ? item.images : [];
    return images.flatMap((photo: any, photoIndex: number) => {
      const uri = getPhotoUri(photo);
      if (!uri) return [];
      const photoObject = photo && typeof photo === "object" ? photo : null;
      const photoId = photoObject?.id ?? null;
      const itemId = item?.id ?? itemIndex;
      return [{
        key: `${itemId}-${photoId ?? photoIndex}-${photoIndex}`,
        uri,
        recipientPhone: photoObject?.recipient_phone ?? null,
      }];
    });
  });
}

const TIMELINE_STATUSES: ShipmentStatus[] = [
  "draft", "submitted", "processing",
  "pickup_assigned", "picked_up", "in_transit", "out_for_delivery", "delivered",
];

function formatHeroDate(value?: string | null): string {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";

  return date.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function getField(obj: any, ...keys: string[]): any {
  for (const key of keys) {
    if (key.includes('.')) {
      const val = key.split('.').reduce((o: any, k: string) => o?.[k], obj);
      if (val !== undefined) return val;
    } else if (obj?.[key] !== undefined) return obj[key];
  }
  return undefined;
}

function getItemHandoff(item: any): any | null {
  return item?.handoff || item?.courier_handoff || item?.delivery?.handoff || null;
}

function getItemEta(item: any): DeliveryEtaInfo | null {
  return item?.eta || item?.delivery_eta || item?.delivery?.eta || null;
}

function etaDisplayText(eta: DeliveryEtaInfo | null): string | null {
  if (!eta) return null;
  const etaDate = eta.expected_delivery_at_iso || eta.expected_delivery_at;
  if (!etaDate) return null;

  return `ETA ${formatDateTimeAmPm(etaDate)}`;
}

function delayReasonText(eta: DeliveryEtaInfo | null): string | null {
  if (!eta?.last_reason) return null;
  return `Delayed: ${eta.last_reason}`;
}

function etaTone(eta: DeliveryEtaInfo | null): { color: string; bg: string; icon: keyof typeof Ionicons.glyphMap } {
  if (eta?.is_overdue || eta?.last_reason || eta?.tone === "amber" || eta?.tone === "rose") {
    return { color: colors.primary, bg: colors.warmSurface, icon: "time-outline" };
  }

  return { color: "#2563eb", bg: "#eff6ff", icon: "time-outline" };
}

function formatRiderLine(handoff: any): string | null {
  const name =
    handoff?.sent_by_name ||
    handoff?.rider_name ||
    handoff?.driver_name ||
    handoff?.rider?.name ||
    handoff?.driver?.name;
  const phone =
    handoff?.sent_by_phone ||
    handoff?.rider_phone ||
    handoff?.driver_phone ||
    handoff?.rider?.phone ||
    handoff?.driver?.phone;
  if (!name && !phone) return null;
  return `${name || "Rider"}${phone ? ` · ${formatPhone(phone)}` : ""}`;
}

function getHandoffPhone(handoff: any): string | null {
  return (
    handoff?.sent_by_phone ||
    handoff?.rider_phone ||
    handoff?.driver_phone ||
    handoff?.rider?.phone ||
    handoff?.driver?.phone ||
    null
  );
}

function hasHandoffRider(handoff: any): boolean {
  return !!formatRiderLine(handoff);
}

export default function ShipmentDetailScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const shipmentsRoute = "/(vendor)/(tabs)/shipments" as const;
  const leaveShipmentDetail = () => {
    if (router.canGoBack()) router.back();
    else router.replace(shipmentsRoute as any);
  };
  const [shipment, setShipment] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [handoffProofPreview, setHandoffProofPreview] = useState<string | null>(null);
  const [failedHandoffProofUri, setFailedHandoffProofUri] = useState<string | null>(null);
  const [selectedPackage, setSelectedPackage] = useState<any | null>(null);
  const [packagePhotoPreview, setPackagePhotoPreview] = useState<PackagePhotoPreview | null>(null);
  const [failedPackagePhotoUri, setFailedPackagePhotoUri] = useState<string | null>(null);
  const [photoGridWidth, setPhotoGridWidth] = useState(0);

  const openHandoffProof = (uri: string) => {
    setFailedHandoffProofUri(null);
    setHandoffProofPreview(uri);
  };

  const closeHandoffProof = () => {
    setHandoffProofPreview(null);
    setFailedHandoffProofUri(null);
  };

  const openPackageDetails = (item: any) => {
    setPackagePhotoPreview(null);
    setFailedPackagePhotoUri(null);
    setSelectedPackage(item);
  };

  const openPackagePhoto = (uri: string, context: PackagePhotoPreview["context"]) => {
    setFailedPackagePhotoUri(null);
    setPackagePhotoPreview({ uri, context });
  };

  const closePackagePhoto = () => {
    setPackagePhotoPreview(null);
    setFailedPackagePhotoUri(null);
  };

  const closePackageDetails = () => {
    closePackagePhoto();
    setSelectedPackage(null);
  };

  const handlePackageModalClose = () => {
    if (packagePhotoPreview?.context === "package") {
      closePackagePhoto();
      return;
    }

    closePackageDetails();
  };

  const fetchShipment = async () => {
    setError(null);
    try {
      const res = await getShipment(Number(id));
      setShipment(res.data?.shipment || res.data);
    } catch (err: any) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  // Refresh every time screen comes into focus
  useFocusEffect(
    useCallback(() => {
      fetchShipment();
    }, [id])
  );

  const handleDelete = async () => {
    setActionLoading(true);
    try {
      await deleteShipment(Number(id));
      showSuccess("Shipment deleted");
      router.replace(shipmentsRoute as any);
    } catch (err: any) { showError(getErrorMessage(err)); }
    finally { setActionLoading(false); }
  };

  const handleRequestAgain = () => {
    router.push({
      pathname: "/(vendor)/shipment/create",
      params: { requestAgainShipmentId: String(id) },
    } as any);
  };

  if (loading) {
    return (
      <View style={s.container}>
        <View style={[s.loadingHeader, { paddingTop: insets.top + 8 }]}>
          <View style={s.heroDecor1} />
          <View style={s.heroDecor2} />
          <TouchableOpacity onPress={leaveShipmentDetail} style={s.backBtn}>
            <Ionicons name="arrow-back" size={24} color={colors.white} />
          </TouchableOpacity>
          <View style={s.loadingTitleBlock}>
            <View style={[s.skeletonBlock, { width: 150, height: 22 }]} />
            <View style={[s.skeletonBlock, { width: 112, height: 12, marginTop: 8, opacity: 0.55 }]} />
          </View>
          <View style={s.loadingBadge} />
          <View style={s.loadingSummaryRow}>
            {[0, 1, 2].map((i) => (
              <View key={i} style={s.loadingSummaryCard}>
                <View style={s.loadingSummaryIcon} />
                <View style={s.loadingSummaryAmount} />
                <View style={s.loadingSummaryLabel} />
              </View>
            ))}
          </View>
        </View>
        <View style={s.loadingBody}>
          <View style={s.loadingPickupCard}>
            <View style={s.loadingBodyHeader}>
              <View style={s.loadingBodyIcon} />
              <View style={{ flex: 1 }}>
                <View style={[s.skeletonBlock, { width: 118, height: 13 }]} />
                <View style={[s.skeletonBlock, { width: "82%", height: 12, marginTop: 8, opacity: 0.65 }]} />
              </View>
            </View>
            <View style={[s.skeletonBlock, { width: "68%", height: 10, marginTop: 16, opacity: 0.5 }]} />
          </View>
          <View style={s.loadingPackagesCard}>
            <View style={s.loadingPackagesTitleRow}>
              <View style={[s.skeletonBlock, { width: 82, height: 13 }]} />
              <View style={[s.skeletonBlock, { width: 28, height: 22, borderRadius: 11 }]} />
            </View>
            {[0, 1].map((i) => (
              <View key={i} style={[s.loadingPackageRow, i === 0 && s.loadingPackageDivider]}>
                <View style={s.loadingPackageNumber} />
                <View style={{ flex: 1 }}>
                  <View style={[s.skeletonBlock, { width: "70%", height: 14 }]} />
                  <View style={[s.skeletonBlock, { width: "42%", height: 10, marginTop: 8, opacity: 0.55 }]} />
                  <View style={[s.skeletonBlock, { width: "92%", height: 46, marginTop: 12, borderRadius: 12, opacity: 0.45 }]} />
                </View>
              </View>
            ))}
          </View>
        </View>
      </View>
    );
  }

  if (!shipment && error) {
    return (
      <View style={s.container}>
        <View style={{ paddingTop: insets.top + 16, paddingLeft: 16 }}>
          <TouchableOpacity onPress={leaveShipmentDetail} style={s.backBtn}>
            <Ionicons name="arrow-back" size={22} color={colors.dark} />
          </TouchableOpacity>
        </View>
        <ErrorState
          title="Failed to load"
          message={error}
          onRetry={() => { setLoading(true); fetchShipment(); }}
        />
      </View>
    );
  }

  if (!shipment) return null;

  const status = shipment.status || "";
  const canEdit = shipment.can_edit ?? status === "draft";
  const canDelete = shipment.can_delete ?? status === "draft";
  const canRequestAgain = status === "rejected";
  const isProcessed = shipment.is_processed === true;

  const pickupName = getField(shipment, 'pickup.contact_name', 'pickup_contact_name');
  const pickupPhone = getField(shipment, 'pickup.contact_phone', 'pickup_contact_phone');
  const pickupLocationRaw = getField(shipment, 'pickup.location', 'pickup_town');
  const pickupLocation = typeof pickupLocationRaw === 'object' ? pickupLocationRaw : null;
  const pickupLocationText = pickupLocation ? formatLocation(pickupLocation) : (pickupLocationRaw || "—");
  const pickupInstructions = getField(shipment, 'pickup.instructions', 'pickup_instructions');
  const pickupVehicleSummary = shipment.pickup_vehicle_summary || "";

  const deliveryName = getField(shipment, 'delivery.recipient_name', 'delivery_recipient_name');
  const deliveryPhone = getField(shipment, 'delivery.recipient_phone', 'delivery_recipient_phone');
  const deliveryLocationRaw = getField(shipment, 'delivery.location', 'delivery_town');
  const deliveryLocation = typeof deliveryLocationRaw === 'object' ? deliveryLocationRaw : null;
  const items = shipment.items || [];
  const unprocessedPhotos = getUnprocessedPhotos(items);
  const apiPhotoCount = Number(shipment.total_photos_count || 0);
  const unprocessedPhotoCount = Math.max(Number.isFinite(apiPhotoCount) ? apiPhotoCount : 0, unprocessedPhotos.length);
  const unprocessedPhotoSize = photoGridWidth > 0
    ? Math.max(72, (photoGridWidth - UNPROCESSED_PHOTO_GAP * 2) / 3)
    : 90;
  const hasPackageHandoffs = items.some((item: any) => !!getItemHandoff(item));
  const packageCount = Number(
    shipment.vendor_declared_quantity
    || shipment.total_packages_count
    || items.length
    || shipment.items_count
    || shipment.total_items_count
    || 0
  );
  const shipmentChargeLines: ChargeLine[] = (shipment as any).charges?.lines || [];
  const heroPickupFee = latestCharge(
    shipmentChargeLines.filter((line) => line.status !== "cancelled" && line.charge_type === "pickup_fee")
  );
  const hasHeroPickupFee = Boolean(heroPickupFee);
  const heroPickupAmount = heroPickupFee ? formatCurrency(Number(heroPickupFee.amount || 0), heroPickupFee.currency || "GHS") : "Not set";
  const heroPickupStatus = heroPickupFee?.status === "paid" ? "Paid" : heroPickupFee ? "Due" : "No fee";
  const heroDeliveryFees = shipmentChargeLines.filter(
    (line) => activeCharge(line) && line.charge_type === "delivery_fee" && line.shipment_item_id
  );
  const heroDeliveryFeeTotal = heroDeliveryFees.reduce((sum, line) => sum + Number(line.amount || 0), 0);
  const heroDeliveryFeeAmount = heroDeliveryFees.length
    ? formatCurrency(heroDeliveryFeeTotal, heroDeliveryFees[0]?.currency || "GHS")
    : "Not set";
  const heroDeliveryFeeStatus = !heroDeliveryFees.length
    ? "No fee"
    : heroDeliveryFees.every((line) => line.status === "paid")
      ? "Paid"
      : heroDeliveryFees.some((line) => line.status === "paid")
        ? "Part paid"
        : "Due";

  // Timeline
  const currentIdx = TIMELINE_STATUSES.indexOf(status as ShipmentStatus);
  const timelineEvents = TIMELINE_STATUSES.map((st, i) => ({
    label: shipmentStatusConfig[st]?.label || st,
    status: i < currentIdx ? "completed" as const : i === currentIdx ? "current" as const : "pending" as const,
  }));

  // Friendly status sub-copy. Label + icon come from the canonical config.
  const statusSubs: Record<string, string> = {
    submitted: "Your package is being reviewed.",
    processing: "Our team is preparing your request.",
    pickup_assigned: "A rider has been assigned for pickup.",
    picked_up: "Your packages have been collected.",
    at_warehouse: "Your packages are at our warehouse.",
    sorted: "Sorted for onward routing.",
    in_transit: "Your package is on its way.",
    at_destination: "Your package is at the destination hub.",
    out_for_delivery: "A rider is delivering your package now.",
    handed_to_courier: "Handed to a bus courier for onward delivery.",
    delivered: "Your package has been delivered.",
    cancelled: "This shipment was cancelled.",
    rejected: "This request was rejected.",
  };
  const cfg = shipmentStatusConfig[status as ShipmentStatus];
  const statusInfo = {
    icon: cfg?.icon || "help-outline",
    title: cfg?.label || status,
    sub: statusSubs[status] || "",
    color: cfg?.color || colors.dark,
    bgColor: cfg?.bgColor || colors.neutral100,
  };
  const destinationModeLabel = shipment.destination_mode === "per_item" ? "Multiple drop-off" : "Single destination";

  return (
    <View style={s.container}>
      <ScrollView
        refreshControl={<RefreshControl refreshing={false} onRefresh={fetchShipment} colors={[colors.primary]} />}
        contentContainerStyle={{ paddingBottom: canEdit || canDelete || canRequestAgain ? 116 + insets.bottom : 80, flexGrow: 1, backgroundColor: colors.background }}
      >
        {/* Dark Gradient Header — extends behind the translucent status bar */}
        <LinearGradient
          colors={["#1e293b", "#334155", "#1e293b"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[s.header, { paddingTop: insets.top + 8 }]}
        >
          <View style={s.heroDecor1} />
          <View style={s.heroDecor2} />

          <View style={s.headerTop}>
            <TouchableOpacity onPress={leaveShipmentDetail} style={s.backBtn}>
              <Ionicons name="arrow-back" size={22} color={colors.white} />
            </TouchableOpacity>
            <View style={{ flex: 1 }}>
              <Text style={s.headerTitle}>{shipment.shipment_number}</Text>
              <View style={s.headerMetaRow}>
                <View style={s.headerMetaItem}>
                  <Ionicons name="calendar-outline" size={12} color="rgba(255,255,255,0.55)" />
                  <Text style={s.headerSub} numberOfLines={1}>{formatHeroDate(shipment.created_at)}</Text>
                </View>
                <View style={s.headerMetaItem}>
                  <Ionicons name="git-branch-outline" size={12} color="rgba(255,255,255,0.55)" />
                  <Text style={s.headerSub} numberOfLines={1}>{destinationModeLabel}</Text>
                </View>
              </View>
            </View>
            <View style={s.heroRightStack}>
              <View style={[s.headerStatusPill, { backgroundColor: statusInfo.bgColor }]}>
                <Ionicons name={statusInfo.icon as any} size={13} color={statusInfo.color} />
                <Text style={[s.headerStatusText, { color: statusInfo.color }]} numberOfLines={1}>{statusInfo.title}</Text>
              </View>
            </View>
          </View>

          <View style={s.heroSummaryGrid}>
            <View style={s.heroSummaryCard}>
              <View style={[s.heroSummaryIcon, { backgroundColor: "rgba(96,165,250,0.18)" }]}>
                <Ionicons name="cube" size={18} color="#93c5fd" />
              </View>
              <Text style={s.heroSummaryValue}>{packageCount}</Text>
              <Text style={s.heroSummaryTitle}>
                {packageCount === 1 ? "Package" : "Packages"}
              </Text>
            </View>

            {hasHeroPickupFee ? (
              <View style={s.heroSummaryCard}>
                <View style={[s.heroSummaryIcon, { backgroundColor: "rgba(34,197,94,0.18)" }]}>
                  <Ionicons name="cash" size={18} color="#86efac" />
                </View>
                <Text style={s.heroSummaryAmount} numberOfLines={1} adjustsFontSizeToFit>
                  {heroPickupAmount}
                </Text>
                <Text style={s.heroSummaryTitle}>Pickup Fee · {heroPickupStatus}</Text>
              </View>
            ) : (
              <View style={s.heroSummaryCard}>
                <View style={[s.heroSummaryIcon, { backgroundColor: "rgba(168,85,247,0.18)" }]}>
                  <Ionicons name="git-branch" size={18} color="#d8b4fe" />
                </View>
                <Text style={s.heroSummaryAmount} numberOfLines={1} adjustsFontSizeToFit>
                  {destinationModeLabel}
                </Text>
                <Text style={s.heroSummaryTitle}>Drop-off type</Text>
              </View>
            )}

            <View style={s.heroSummaryCard}>
              <View style={[s.heroSummaryIcon, { backgroundColor: "rgba(251,146,60,0.18)" }]}>
                <Ionicons name="wallet" size={18} color="#fdba74" />
              </View>
              <Text style={s.heroSummaryAmount} numberOfLines={1} adjustsFontSizeToFit>
                {heroDeliveryFeeAmount}
              </Text>
              <Text style={s.heroSummaryTitle}>Delivery Fees · {heroDeliveryFeeStatus}</Text>
            </View>
          </View>
        </LinearGradient>

        <View style={s.body}>
          {/*
            Progress Timeline - hidden for now.
            {status !== "cancelled" && (
              <ProgressCard
                timelineEvents={timelineEvents}
                currentIdx={currentIdx}
                total={TIMELINE_STATUSES.length}
                currentLabel={shipmentStatusConfig[status as ShipmentStatus]?.label || status}
              />
            )}
          */}

          {status === "rejected" && shipment.rejection_reason && (
            <View style={s.rejectionSection}>
              <View style={s.rejectionAccent} />
              <View style={s.rejectionContent}>
                <View style={s.rejectionIcon}>
                  <Ionicons name="alert-circle-outline" size={18} color={colors.error} />
                </View>
                <View style={s.rejectionTextBlock}>
                  <Text style={s.rejectionTitle}>Request rejected</Text>
                  <Text style={s.rejectionBody}>{shipment.rejection_reason}</Text>
                </View>
              </View>
            </View>
          )}

          {/* Packages */}
          {pickupName && (
            <View style={s.pickupInlineSection}>
              <View style={s.pickupInlineHeader}>
                <View style={s.pickupInlineIcon}>
                  <Ionicons name="location-outline" size={18} color={colors.success} />
                </View>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={s.pickupInlineTitle}>Pickup Location</Text>
                  <Text style={s.pickupInlineSummary} numberOfLines={2}>
                    {pickupLocationText}
                  </Text>
                </View>
              </View>
              <View style={s.pickupInlineDetails}>
                <View style={s.pickupInlineRow}>
                  <Ionicons name="person-outline" size={14} color={colors.textMuted} />
                  <Text style={s.pickupInlineValue} numberOfLines={1}>{pickupName}</Text>
                </View>
                {pickupPhone && (
                  <TouchableOpacity style={s.pickupInlineRow} onPress={() => Linking.openURL(`tel:${pickupPhone}`)} activeOpacity={0.7}>
                    <Ionicons name="call-outline" size={14} color={colors.textMuted} />
                    <Text style={[s.pickupInlineValue, { color: colors.primary }]} numberOfLines={1}>
                      {formatPhone(pickupPhone)}
                    </Text>
                  </TouchableOpacity>
                )}
                {pickupInstructions && (
                  <View style={s.pickupInlineRow}>
                    <Ionicons name="document-text-outline" size={14} color={colors.textMuted} />
                    <Text style={s.pickupInlineValue} numberOfLines={2}>{pickupInstructions}</Text>
                  </View>
                )}
                {pickupVehicleSummary && (
                  <View style={s.pickupInlineRow}>
                    <Ionicons name="bicycle-outline" size={14} color={colors.textMuted} />
                    <Text style={s.pickupInlineValue} numberOfLines={2}>
                      <Text style={s.pickupInlineLabel}>Pickup vehicle: </Text>
                      {pickupVehicleSummary}
                    </Text>
                  </View>
                )}
                {shipment.pickup_assignment?.driver_name && (
                  <TouchableOpacity
                    style={s.pickupInlineRow}
                    onPress={shipment.pickup_assignment.driver_phone ? () => Linking.openURL(`tel:${shipment.pickup_assignment.driver_phone}`) : undefined}
                    activeOpacity={shipment.pickup_assignment.driver_phone ? 0.7 : 1}
                  >
                    <Ionicons name="car-outline" size={14} color={colors.textMuted} />
                    <Text style={s.pickupInlineValue} numberOfLines={1}>
                      <Text style={s.pickupInlineLabel}>Pickup rider: </Text>
                      {shipment.pickup_assignment.driver_name}
                      {shipment.pickup_assignment.driver_phone ? ` · ${formatPhone(shipment.pickup_assignment.driver_phone)}` : ""}
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          )}

          <View style={s.packageSection}>
            <View style={s.packageSectionHeader}>
              <View style={{ flex: 1 }}>
                <Text style={s.packageSectionTitle}>{isProcessed ? "Packages" : "Photos"}</Text>
              </View>
              <View style={s.packageSectionCount}>
                <Text style={s.packageSectionCountText}>
                  {isProcessed ? items.length : unprocessedPhotoCount}
                </Text>
              </View>
            </View>

            {isProcessed && items.map((item: any, idx: number) => {
              const itemCfg = itemStatusConfig[item.status as ItemStatus];
              const handoff = getItemHandoff(item);
              const handoffRiderLine = formatRiderLine(handoff);
              const handoffPhone = getHandoffPhone(handoff);
              const itemDelivery = item.delivery || null;
              const recipientName = itemDelivery?.recipient_name || item.delivery_recipient_name || deliveryName;
              const recipientPhone = itemDelivery?.recipient_phone || item.delivery_recipient_phone || deliveryPhone;
              const locationValue =
                itemDelivery?.location ||
                item.delivery_location ||
                item.delivery_town ||
                (deliveryLocationRaw || null);
              const deliveryLocationText = typeof locationValue === "string" ? locationValue : formatLocation(locationValue);
              const deliveredAt = item.delivered_at || item.delivery?.delivered_at || item.delivery_run_item?.delivered_at || null;
              const itemDeliveryFee = latestCharge(
                shipmentChargeLines.filter(
                  (line) =>
                    activeCharge(line) &&
                    line.charge_type === "delivery_fee" &&
                    Number(line.shipment_item_id) === Number(item.id)
                )
              );
              const itemEta = getItemEta(item);
              const itemEtaText = etaDisplayText(itemEta);
              const itemDelayText = delayReasonText(itemEta);
              const itemEtaTone = etaTone(itemEta);
              return (
              <View key={item.id} style={[s.itemCard, idx < items.length - 1 && s.itemCardDivider]}>
                <View style={s.itemTopRow}>
                  <View style={s.itemIconWrap}>
                    <Text style={s.itemIconNumber}>{idx + 1}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <View style={s.itemTitleRow}>
                      <Text style={s.itemDesc} numberOfLines={2}>{item.description?.trim() || `Package ${idx + 1}`}</Text>
                      <TouchableOpacity onPress={() => openPackageDetails(item)} style={s.itemActionChip}>
                        <Text style={s.itemActionChipText}>View</Text>
                        <Ionicons name="arrow-forward" size={12} color={colors.primary} />
                      </TouchableOpacity>
                    </View>
                    <View style={s.itemMetaRow}>
                      <View style={s.itemMetaItem}>
                        <Ionicons name="layers-outline" size={12} color={colors.textLight} />
                        <Text style={s.itemMetaText}>{item.images?.length || 0} photo{(item.images?.length || 0) === 1 ? "" : "s"}</Text>
                      </View>
                      {itemCfg && (
                        <View style={[s.itemStatusChip, { backgroundColor: itemCfg.bgColor }]}>
                          {itemCfg.icon && <Ionicons name={itemCfg.icon as any} size={11} color={itemCfg.color} />}
                          <Text style={[s.itemStatusChipText, { color: itemCfg.color }]}>{itemCfg.label}</Text>
                        </View>
                      )}
                      {handoff && (
                        <View style={s.itemCourierChip}>
                          <Ionicons name="bus-outline" size={11} color="#7c3aed" />
                          <Text style={s.itemCourierChipText}>Bus Courier</Text>
                        </View>
                      )}
                    </View>
                    {(itemEtaText || itemDelayText) && (
                      <View style={s.itemEtaRow}>
                        {itemEtaText && (
                          <View style={[s.itemEtaPill, { backgroundColor: itemEtaTone.bg }]}>
                            <Ionicons name={itemEtaTone.icon as any} size={11} color={itemEtaTone.color} />
                            <Text style={[s.itemEtaText, { color: itemEtaTone.color }]}>{itemEtaText}</Text>
                          </View>
                        )}
                        {itemDelayText && (
                          <View style={s.itemDelayPill}>
                            <Ionicons name="alert-circle-outline" size={11} color={colors.primary} />
                            <Text style={s.itemDelayText}>{itemDelayText}</Text>
                          </View>
                        )}
                      </View>
                    )}
                  </View>
                </View>
                {(recipientName || recipientPhone || deliveryLocationText !== "—" || itemDeliveryFee || deliveredAt) && (
                  <View style={s.packageDetailsList}>
                    {(recipientName || recipientPhone) && (
                      <View style={s.packageDetailRow}>
                        <View style={s.packageDetailIcon}>
                          <Ionicons name="person-outline" size={13} color={colors.primary} />
                        </View>
                        <View style={{ flex: 1, minWidth: 0 }}>
                          <Text style={s.packageDetailLabel}>Recipient</Text>
                          <Text style={s.packageDetailValue} numberOfLines={1}>
                            {recipientName || "Recipient"}{recipientPhone ? ` · ${formatPhone(recipientPhone)}` : ""}
                          </Text>
                        </View>
                      </View>
                    )}
                    {deliveryLocationText !== "—" && (
                      <View style={s.packageDetailRow}>
                        <View style={s.packageDetailIcon}>
                          <Ionicons name="location-outline" size={13} color={colors.primary} />
                        </View>
                        <View style={{ flex: 1, minWidth: 0 }}>
                          <Text style={s.packageDetailLabel}>Delivery Location</Text>
                          <Text style={s.packageDetailValue} numberOfLines={2}>
                            {deliveryLocationText}
                          </Text>
                        </View>
                      </View>
                    )}
                    {handoff && (
                      <View style={s.packageDetailRow}>
                        <View style={s.packageDetailIcon}>
                          <Ionicons name="bus-outline" size={13} color={colors.primary} />
                        </View>
                        <View style={{ flex: 1, minWidth: 0 }}>
                          <Text style={s.packageDetailLabel}>Delivery Path</Text>
                          <Text style={s.packageDetailValue} numberOfLines={2}>
                            {handoff.bus_station ? `Sent via Bus Courier · ${handoff.bus_station}` : "Sent via Bus Courier"}
                          </Text>
                        </View>
                      </View>
                    )}
                    {handoffRiderLine && (
                      <TouchableOpacity
                        style={s.packageDetailRow}
                        onPress={handoffPhone ? () => Linking.openURL(`tel:${handoffPhone}`) : undefined}
                        activeOpacity={handoffPhone ? 0.7 : 1}
                      >
                        <View style={s.packageDetailIcon}>
                          <Ionicons name="bicycle-outline" size={13} color={colors.primary} />
                        </View>
                        <View style={{ flex: 1, minWidth: 0 }}>
                          <Text style={s.packageDetailLabel}>Sent By</Text>
                          <Text style={s.packageDetailValue} numberOfLines={1}>
                            {handoffRiderLine}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    )}
                    {item.status === "delivered" && deliveredAt && (
                      <View style={s.packageDetailRow}>
                        <View style={s.packageDetailIcon}>
                          <Ionicons name="checkmark-done-outline" size={13} color={colors.success} />
                        </View>
                        <View style={{ flex: 1, minWidth: 0 }}>
                          <Text style={s.packageDetailLabel}>Delivered</Text>
                          <Text style={s.packageDetailValue} numberOfLines={1}>
                            {formatDateTimeAmPm(deliveredAt)}
                          </Text>
                        </View>
                      </View>
                    )}
                    {itemDeliveryFee && (
                      <View style={s.packageDetailRow}>
                        <View style={s.packageDetailIcon}>
                          <Ionicons name="cash-outline" size={13} color={colors.primary} />
                        </View>
                        <View style={{ flex: 1, minWidth: 0 }}>
                          <Text style={s.packageDetailLabel}>Delivery Fee</Text>
                          <Text style={s.packageDetailValue} numberOfLines={1}>
                            {formatCurrency(Number(itemDeliveryFee.amount || 0), itemDeliveryFee.currency)}
                          </Text>
                        </View>
                      </View>
                    )}
                  </View>
                )}
              </View>
              );
            })}

            {isProcessed && items.length === 0 && (
              <View style={s.emptyItems}>
                <Ionicons name="cube-outline" size={32} color={colors.neutral300} />
                <Text style={s.emptyItemsText}>No packages yet</Text>
              </View>
            )}

            {!isProcessed && (
              <View>
                <Text style={s.photoCountText}>
                  {unprocessedPhotoCount} photo{unprocessedPhotoCount === 1 ? "" : "s"} uploaded
                </Text>
                {unprocessedPhotos.length > 0 && (
                  <View style={s.photoGrid} onLayout={(e) => setPhotoGridWidth(e.nativeEvent.layout.width)}>
                    {unprocessedPhotos.map((photo) => (
                      <View key={photo.key} style={[s.photoTile, { width: unprocessedPhotoSize }]}>
                        <TouchableOpacity activeOpacity={0.84} onPress={() => openPackagePhoto(photo.uri, "standalone")}>
                          <Image
                            source={{ uri: photo.uri }}
                            style={[s.photoThumb, { width: unprocessedPhotoSize, height: unprocessedPhotoSize }]}
                            resizeMode="cover"
                          />
                        </TouchableOpacity>
                        {photo.recipientPhone ? (
                          <View style={s.recipientRow}>
                            <Text style={s.recipientRowText} numberOfLines={1} adjustsFontSizeToFit>
                              {formatPhone(photo.recipientPhone)}
                            </Text>
                          </View>
                        ) : null}
                      </View>
                    ))}
                  </View>
                )}
              </View>
            )}
          </View>

          {/* Delivery Destination */}
          {deliveryName && (
            <LocationCard
              type="delivery"
              icon="home"
              iconBg="#3b82f6"
              title="Delivery Destination"
              badge={shipment.destination_mode !== "per_item" ? (shipment.delivery_preference === "self_pickup" ? "Recipient Collects" : "Deliver to Recipient") : undefined}
              name={deliveryName}
              phone={deliveryPhone}
              location={deliveryLocation}
            />
          )}

          {/* Delivery Notes */}
          {shipment.sender_notes ? (
            <View style={s.card}>
              <View style={s.cardHeader}>
                <View style={[s.cardIconWrap, { backgroundColor: "#fef3c7" }]}>
                  <Ionicons name="document-text" size={18} color="#d97706" />
                </View>
                <Text style={s.cardTitle}>Delivery Notes</Text>
              </View>
              <Text style={s.notesText}>{shipment.sender_notes}</Text>
            </View>
          ) : null}

          {/* Collection Status (self_pickup) */}
          {shipment.delivery_preference === "self_pickup" && shipment.collection && (
            <View style={[s.card, { borderWidth: 1.5, borderColor: shipment.collection.status === "collected" ? colors.success : colors.primary }]}>
              <View style={s.cardHeader}>
                <View style={[s.cardIconWrap, { backgroundColor: shipment.collection.status === "collected" ? colors.success : colors.primary }]}>
                  <Ionicons name={shipment.collection.status === "collected" ? "checkmark-circle" : "business"} size={18} color={colors.white} />
                </View>
                <Text style={s.cardTitle}>
                  {shipment.collection.status === "collected" ? "Collected" : "Ready for Collection"}
                </Text>
              </View>
              <InfoRow label="Warehouse" value={shipment.collection.warehouse_name} />
              <InfoRow label="Address" value={shipment.collection.warehouse_address} />
              {shipment.collection.warehouse_phone && (
                <TouchableOpacity onPress={() => Linking.openURL(`tel:${shipment.collection.warehouse_phone}`)}>
                  <InfoRow label="Phone" value={formatPhone(shipment.collection.warehouse_phone)} />
                </TouchableOpacity>
              )}
              {shipment.collection.ready_at && (
                <InfoRow label="Ready Since" value={formatDateTimeAmPm(shipment.collection.ready_at)} />
              )}
              {shipment.collection.status === "collected" && shipment.collection.collected_at && (
                <>
                  <InfoRow label="Collected At" value={formatDateTimeAmPm(shipment.collection.collected_at)} />
                  {shipment.collection.collected_by_name && (
                    <InfoRow label="Collected By" value={shipment.collection.collected_by_name} />
                  )}
                </>
              )}
            </View>
          )}

          {/* Bus Courier Handoff (AGENTS.md Appendix C — "Courier Handoff Info") */}
          {shipment.courier_handoff && !hasPackageHandoffs && (
            <View style={[s.card, { borderWidth: 1.5, borderColor: "#7c3aed" }]}>
              <View style={s.cardHeader}>
                <View style={[s.cardIconWrap, { backgroundColor: "#ede9fe" }]}>
                  <Ionicons name="bus" size={18} color="#7c3aed" />
                </View>
                <Text style={s.cardTitle}>Sent via Bus Courier</Text>
              </View>
              {shipment.courier_handoff.bus_station && (
                <InfoRow label="Station" value={shipment.courier_handoff.bus_station} />
              )}
              {hasHandoffRider(shipment.courier_handoff) && (
                <TouchableOpacity
                  onPress={getHandoffPhone(shipment.courier_handoff) ? () => Linking.openURL(`tel:${getHandoffPhone(shipment.courier_handoff)}`) : undefined}
                  activeOpacity={getHandoffPhone(shipment.courier_handoff) ? 0.7 : 1}
                >
                  <InfoRow label="Sent By" value={formatRiderLine(shipment.courier_handoff) || "Rider"} />
                </TouchableOpacity>
              )}
              {shipment.courier_handoff.courier_phone && (
                <TouchableOpacity onPress={() => Linking.openURL(`tel:${shipment.courier_handoff.courier_phone}`)}>
                  <InfoRow label="Bus Rider Number" value={formatPhone(shipment.courier_handoff.courier_phone)} />
                </TouchableOpacity>
              )}
              {shipment.courier_handoff.vehicle_number && (
                <InfoRow label="Vehicle" value={shipment.courier_handoff.vehicle_number} />
              )}
              {shipment.courier_handoff.handed_off_at && (
                <InfoRow label="Handed off" value={formatDateTimeAmPm(shipment.courier_handoff.handed_off_at)} />
              )}
              {shipment.courier_handoff.proof_photo_url && (
                <TouchableOpacity
                  activeOpacity={0.85}
                  style={s.handoffProofBlock}
                  onPress={() => openHandoffProof(shipment.courier_handoff.proof_photo_url)}
                >
                  <Text style={s.handoffProofLabel}>Rider Proof Photo</Text>
                  <Image
                    source={{ uri: shipment.courier_handoff.proof_photo_url }}
                    style={s.handoffProofImage}
                    resizeMode="cover"
                  />
                  <Text style={s.handoffProofHint}>Tap to view full photo</Text>
                </TouchableOpacity>
              )}
            </View>
          )}

        </View>
      </ScrollView>

      {(canEdit || canDelete || canRequestAgain) && (
        <View style={[s.footerActions, { paddingBottom: insets.bottom + 12 }]}>
          {canRequestAgain && (
            <TouchableOpacity
              onPress={handleRequestAgain}
              style={[s.footerActionBtn, s.footerRequestAgainBtn]}
              activeOpacity={0.85}
            >
              <Ionicons name="refresh" size={18} color={colors.white} />
              <Text style={s.footerRequestAgainText}>Request Again</Text>
            </TouchableOpacity>
          )}
          {canEdit && (
            <TouchableOpacity
              onPress={() =>
                router.replace({
                  pathname: "/(vendor)/shipment/[id]/edit",
                  params: { id: String(id) },
                } as any)
              }
              style={[s.footerActionBtn, s.footerEditBtn]}
              activeOpacity={0.85}
            >
              <Ionicons name="create-outline" size={18} color={colors.white} />
              <Text style={s.footerEditText}>Edit Parcel</Text>
            </TouchableOpacity>
          )}
          {canDelete && (
            <TouchableOpacity
              onPress={() => setShowDelete(true)}
              style={[s.footerActionBtn, s.footerDeleteBtn]}
              activeOpacity={0.85}
              disabled={actionLoading}
            >
              <Ionicons name="trash-outline" size={18} color={colors.error} />
              <Text style={s.footerDeleteText}>Delete</Text>
            </TouchableOpacity>
          )}
        </View>
      )}

      <Modal visible={!!handoffProofPreview} transparent animationType="fade" onRequestClose={closeHandoffProof}>
        <View style={s.lightbox}>
          <View style={[s.lightboxHeader, { top: insets.top + 12 }]}>
            <Text style={s.lightboxCounter}>Bus courier proof</Text>
            <TouchableOpacity
              onPress={closeHandoffProof}
              style={s.lightboxClose}
              accessibilityRole="button"
              accessibilityLabel="Close bus courier proof photo"
            >
              <Ionicons name="close" size={24} color={colors.white} />
            </TouchableOpacity>
          </View>
          {handoffProofPreview && failedHandoffProofUri === handoffProofPreview ? (
            <View style={s.lightboxError}>
              <Ionicons name="image-outline" size={42} color="rgba(255,255,255,0.72)" />
              <Text style={s.lightboxErrorTitle}>Photo unavailable</Text>
              <Text style={s.lightboxErrorText}>This proof photo could not be loaded.</Text>
              <TouchableOpacity onPress={closeHandoffProof} style={s.lightboxErrorButton}>
                <Text style={s.lightboxErrorButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          ) : handoffProofPreview ? (
            <Image
              source={{ uri: handoffProofPreview }}
              style={s.lightboxImage}
              resizeMode="contain"
              onError={() => setFailedHandoffProofUri(handoffProofPreview)}
            />
          ) : null}
        </View>
      </Modal>

      <Modal visible={!!selectedPackage} transparent animationType="slide" onRequestClose={handlePackageModalClose}>
        {packagePhotoPreview?.context === "package" ? (
          <View style={s.lightbox}>
            <View style={[s.lightboxHeader, { top: insets.top + 12 }]}>
              <Text style={s.lightboxCounter}>Package photo</Text>
              <TouchableOpacity
                onPress={closePackagePhoto}
                style={s.lightboxClose}
                accessibilityRole="button"
                accessibilityLabel="Close package photo"
              >
                <Ionicons name="close" size={24} color={colors.white} />
              </TouchableOpacity>
            </View>
            {failedPackagePhotoUri === packagePhotoPreview.uri ? (
              <View style={s.lightboxError}>
                <Ionicons name="image-outline" size={42} color="rgba(255,255,255,0.72)" />
                <Text style={s.lightboxErrorTitle}>Photo unavailable</Text>
                <Text style={s.lightboxErrorText}>This photo could not be loaded.</Text>
                <TouchableOpacity onPress={closePackagePhoto} style={s.lightboxErrorButton}>
                  <Text style={s.lightboxErrorButtonText}>Back to package</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <Image
                source={{ uri: packagePhotoPreview.uri }}
                style={s.lightboxImage}
                resizeMode="contain"
                onError={() => setFailedPackagePhotoUri(packagePhotoPreview.uri)}
              />
            )}
          </View>
        ) : (
        <View style={s.packageModalOverlay}>
          <TouchableOpacity style={s.packageModalScrim} activeOpacity={1} onPress={closePackageDetails} />
          {selectedPackage && (() => {
            const item = selectedPackage;
            const itemCfg = itemStatusConfig[item.status as ItemStatus];
            const itemDelivery = item.delivery || null;
            const recipientName = itemDelivery?.recipient_name || item.delivery_recipient_name || deliveryName;
            const recipientPhone = itemDelivery?.recipient_phone || item.delivery_recipient_phone || deliveryPhone;
            const locationValue =
              itemDelivery?.location ||
              item.delivery_location ||
              item.delivery_town ||
              (deliveryLocationRaw || null);
            const deliveryLocationText = typeof locationValue === "string" ? locationValue : formatLocation(locationValue);
            const itemDeliveryFee = latestCharge(
              shipmentChargeLines.filter(
                (line) =>
                  activeCharge(line) &&
                  line.charge_type === "delivery_fee" &&
                  Number(line.shipment_item_id) === Number(item.id)
              )
            );
            const deliveredAt = item.delivered_at || item.delivery?.delivered_at || item.delivery_run_item?.delivered_at || null;
            const images = Array.isArray(item.images) ? item.images : [];
            const handoff = getItemHandoff(item);
            const handoffRiderLine = formatRiderLine(handoff);
            const itemEta = getItemEta(item);
            const itemEtaText = etaDisplayText(itemEta);
            const itemDelayText = delayReasonText(itemEta);

            return (
              <View style={s.packageModalSheet}>
                <View style={s.packageModalHandle} />
                <View style={s.packageModalHeader}>
                  <View style={{ flex: 1, minWidth: 0 }}>
                    <Text style={s.packageModalKicker}>Package Details</Text>
                    <Text style={s.packageModalTitle} numberOfLines={2}>
                      {item.description?.trim() || "Package"}
                    </Text>
                    {handoff && (
                      <View style={s.packageModalCourierPill}>
                        <Ionicons name="bus-outline" size={12} color="#7c3aed" />
                        <Text style={s.packageModalCourierPillText}>Sent via Bus Courier</Text>
                      </View>
                    )}
                  </View>
                  <TouchableOpacity
                    onPress={closePackageDetails}
                    style={s.packageModalClose}
                    accessibilityRole="button"
                    accessibilityLabel="Close package details"
                  >
                    <Ionicons name="close" size={20} color={colors.dark} />
                  </TouchableOpacity>
                </View>

                <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.packageModalContent}>
                  <View style={s.packageModalMeta}>
                    {itemCfg && (
                      <View style={s.packageModalMetaItem}>
                        <Text style={s.packageModalMetaLabel}>Status</Text>
                        <Text style={s.packageModalStatusValue} numberOfLines={1} adjustsFontSizeToFit>
                          {itemCfg.label}
                        </Text>
                      </View>
                    )}
                    {item.tracking_code && (
                      <View style={s.packageModalMetaItem}>
                        <Text style={s.packageModalMetaLabel}>Tracking</Text>
                        <Text style={s.packageModalTrackingValue} numberOfLines={1} adjustsFontSizeToFit>
                          {item.tracking_code}
                        </Text>
                      </View>
                    )}
                    {item.status === "delivered" && deliveredAt && (
                      <View style={s.packageModalMetaItem}>
                        <Text style={s.packageModalMetaLabel}>Delivered</Text>
                        <Text style={s.packageModalTrackingValue} numberOfLines={1} adjustsFontSizeToFit>
                          {formatDateTimeAmPm(deliveredAt)}
                        </Text>
                      </View>
                    )}
                  </View>

                  <View style={s.packageModalPanel}>
                    {(recipientName || recipientPhone) && (
                      <ModalInfoRow icon="person-outline" label="Recipient" value={`${recipientName || "Recipient"}${recipientPhone ? ` · ${formatPhone(recipientPhone)}` : ""}`} />
                    )}
                    {deliveryLocationText !== "—" && (
                      <ModalInfoRow icon="location-outline" label="Delivery Location" value={deliveryLocationText} />
                    )}
                    {itemDelivery?.instructions || item.delivery_instructions ? (
                      <ModalInfoRow icon="chatbubble-outline" label="Instructions" value={itemDelivery?.instructions || item.delivery_instructions} />
                    ) : null}
                    {itemEtaText ? (
                      <ModalInfoRow icon="time-outline" label="Expected Delivery" value={itemEtaText.replace(/^ETA\s+/, "")} />
                    ) : null}
                    {itemDelayText ? (
                      <ModalInfoRow icon="alert-circle-outline" label="Delay Reason" value={itemDelayText.replace(/^Delayed:\s+/, "")} />
                    ) : null}
                    {itemDeliveryFee && (
                      <ModalInfoRow icon="cash-outline" label="Delivery Fee" value={formatCurrency(Number(itemDeliveryFee.amount || 0), itemDeliveryFee.currency)} last />
                    )}
                  </View>

                  {images.length > 0 && (
                    <View style={s.packageModalPanel}>
                      <Text style={s.packageModalSectionTitle}>Photos</Text>
                      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                        {images.map((img: any, photoIdx: number) => {
                          const uri = getPhotoUri(img);
                          if (!uri) return null;
                          return (
                            <TouchableOpacity key={img?.id || photoIdx} onPress={() => openPackagePhoto(uri, "package")} activeOpacity={0.84}>
                              <Image source={{ uri }} style={s.packageModalPhoto} resizeMode="cover" />
                            </TouchableOpacity>
                          );
                        })}
                      </ScrollView>
                    </View>
                  )}

                  {handoff && (
                    <View style={s.packageModalPanel}>
                      <Text style={s.packageModalSectionTitle}>Bus Courier</Text>
                      {handoff.bus_station && <ModalInfoRow icon="bus-outline" label="Station" value={handoff.bus_station} />}
                      {handoffRiderLine && <ModalInfoRow icon="bicycle-outline" label="Sent By" value={handoffRiderLine} />}
                      {handoff.courier_phone && <ModalInfoRow icon="call-outline" label="Bus Rider Number" value={formatPhone(handoff.courier_phone)} />}
                      {handoff.vehicle_number && <ModalInfoRow icon="car-outline" label="Vehicle" value={handoff.vehicle_number} />}
                      {handoff.handed_off_at && <ModalInfoRow icon="time-outline" label="Handed Off" value={formatDateTimeAmPm(handoff.handed_off_at)} last={!handoff.proof_photo_url} />}
                      {handoff.proof_photo_url && (
                        <TouchableOpacity activeOpacity={0.84} onPress={() => openPackagePhoto(handoff.proof_photo_url, "package")}>
                          <Image source={{ uri: handoff.proof_photo_url }} style={s.packageModalProof} resizeMode="cover" />
                        </TouchableOpacity>
                      )}
                    </View>
                  )}
                </ScrollView>
              </View>
            );
          })()}
        </View>
        )}
      </Modal>

      <Modal visible={packagePhotoPreview?.context === "standalone"} transparent animationType="fade" onRequestClose={closePackagePhoto}>
        <View style={s.lightbox}>
          <View style={[s.lightboxHeader, { top: insets.top + 12 }]}>
            <Text style={s.lightboxCounter}>Package photo</Text>
            <TouchableOpacity
              onPress={closePackagePhoto}
              style={s.lightboxClose}
              accessibilityRole="button"
              accessibilityLabel="Close package photo"
            >
              <Ionicons name="close" size={24} color={colors.white} />
            </TouchableOpacity>
          </View>
          {packagePhotoPreview && failedPackagePhotoUri === packagePhotoPreview.uri ? (
            <View style={s.lightboxError}>
              <Ionicons name="image-outline" size={42} color="rgba(255,255,255,0.72)" />
              <Text style={s.lightboxErrorTitle}>Photo unavailable</Text>
              <Text style={s.lightboxErrorText}>This photo could not be loaded.</Text>
              <TouchableOpacity onPress={closePackagePhoto} style={s.lightboxErrorButton}>
                <Text style={s.lightboxErrorButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          ) : packagePhotoPreview?.context === "standalone" ? (
            <Image
              source={{ uri: packagePhotoPreview.uri }}
              style={s.lightboxImage}
              resizeMode="contain"
              onError={() => setFailedPackagePhotoUri(packagePhotoPreview.uri)}
            />
          ) : null}
        </View>
      </Modal>

      <ConfirmDialog visible={showDelete} type="error" title="Delete Package" message="This action cannot be undone. Are you sure?" confirmText="Delete" onConfirm={handleDelete} onCancel={() => setShowDelete(false)} />
    </View>
  );
}

function LocationCard({ type, icon, iconBg, title, name, phone, location, instructions, landmark, canEdit, onEdit, badge }: {
  type: "pickup" | "delivery";
  icon: keyof typeof Ionicons.glyphMap;
  iconBg: string;
  title: string;
  name?: string;
  phone?: string;
  location?: any;
  instructions?: string;
  landmark?: string;
  canEdit?: boolean;
  onEdit?: () => void;
  badge?: string;
}) {
  const [expanded, setExpanded] = useState(false);

  // Build location string
  const locationParts: string[] = [];
  if (location?.town) locationParts.push(location.town);
  if (location?.district) locationParts.push(location.district);
  if (location?.region) locationParts.push(location.region);
  const locationStr = locationParts.join(', ') || '—';

  return (
    <View style={s.card}>
      <TouchableOpacity onPress={() => setExpanded(!expanded)} activeOpacity={0.7}>
        <View style={s.cardHeader}>
          <View style={[s.cardIconWrap, { backgroundColor: iconBg }]}>
            <Ionicons name={icon} size={18} color={colors.white} />
          </View>
          <Text style={[s.cardTitle, { flex: 1 }]}>{title}</Text>
          {canEdit && (
            <TouchableOpacity onPress={onEdit} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <Text style={s.editLinkText}>Edit</Text>
            </TouchableOpacity>
          )}
          <View style={s.expandIconBtn}>
            <Ionicons name={expanded ? "chevron-up" : "chevron-down"} size={16} color={colors.primary} />
          </View>
        </View>
        <Text style={s.locSummary}>{locationStr}</Text>
      </TouchableOpacity>

      {expanded && (
        <View style={s.locDetails}>
          {name && <IconRow icon="person-outline" label={type === "pickup" ? "Contact" : "Recipient"} value={name} />}
          {phone && <IconRow icon="call-outline" label="Phone" value={formatPhone(phone)} />}
          {locationStr !== '—' && <IconRow icon="navigate-outline" label="Location" value={locationStr} />}
          {landmark && <IconRow icon="flag-outline" label="Landmark" value={landmark} />}
          {instructions && <IconRow icon="document-text-outline" label="Instructions" value={instructions} />}
          {badge && <IconRow icon="car-outline" label="Delivery Method" value={badge} />}
        </View>
      )}
    </View>
  );
}

function IconRow({ icon, label, value }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string }) {
  return (
    <View style={s.iconRow}>
      <Ionicons name={icon} size={16} color={colors.textMuted} style={{ marginTop: 2 }} />
      <View style={{ flex: 1 }}>
        <Text style={s.iconRowLabel}>{label}</Text>
        <Text style={s.iconRowValue}>{value}</Text>
      </View>
    </View>
  );
}

function ModalInfoRow({ icon, label, value, last }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string; last?: boolean }) {
  return (
    <View style={[s.packageModalInfoRow, last && { borderBottomWidth: 0 }]}>
      <View style={s.packageModalInfoIcon}>
        <Ionicons name={icon} size={14} color={colors.primary} />
      </View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.packageModalInfoLabel}>{label}</Text>
        <Text style={s.packageModalInfoValue}>{value}</Text>
      </View>
    </View>
  );
}

function ProgressCard({ timelineEvents, currentIdx, total, currentLabel }: {
  timelineEvents: { label: string; status: "completed" | "current" | "pending" }[];
  currentIdx: number;
  total: number;
  currentLabel: string;
}) {
  const [expanded, setExpanded] = useState(false);
  const progress = Math.max(currentIdx, 0) / (total - 1);

  return (
    <View style={s.card}>
      <TouchableOpacity onPress={() => setExpanded(!expanded)} activeOpacity={0.7}>
        <View style={s.cardHeader}>
          <View style={s.cardIconWrap}>
            <Ionicons name="git-network-outline" size={18} color={colors.white} />
          </View>
          <Text style={[s.cardTitle, { flex: 1 }]}>PARCEL PROGRESS</Text>
          <View style={s.stepBadge}>
            <Text style={s.stepBadgeText}>{Math.max(currentIdx + 1, 1)} / {total}</Text>
          </View>
          <View style={s.expandIconBtn}>
            <Ionicons name={expanded ? "chevron-up" : "chevron-down"} size={16} color={colors.primary} />
          </View>
        </View>

        {/* Progress bar */}
        <View style={s.progressBarBg}>
          <View style={[s.progressBarFill, { width: `${Math.max(progress * 100, 5)}%` }]} />
        </View>

        {/* Current status summary */}
        <View style={s.currentStatusRow}>
          <View style={[s.currentDot, { backgroundColor: colors.primary }]} />
          <Text style={s.currentStatusLabel}>{currentLabel}</Text>
          <Text style={s.currentStatusSub}>{Math.round(progress * 100)}% complete</Text>
        </View>
      </TouchableOpacity>

      {/* Expanded timeline */}
      {expanded && (
        <View style={s.timelineWrap}>
          {timelineEvents.map((ev, i) => (
            <View key={i} style={s.timelineRow}>
              <View style={s.timelineDotCol}>
                <View style={[
                  s.timelineDot,
                  ev.status === "completed" && s.timelineDotDone,
                  ev.status === "current" && s.timelineDotCurrent,
                ]}>
                  {ev.status === "completed" && <Ionicons name="checkmark" size={12} color={colors.white} />}
                  {ev.status === "current" && <View style={s.timelineDotInner} />}
                </View>
                {i < timelineEvents.length - 1 && (
                  <View style={[s.timelineLine, ev.status === "completed" && s.timelineLineDone]} />
                )}
              </View>
              <Text style={[
                s.timelineLabel,
                ev.status === "completed" && { color: colors.success, fontFamily: fontFamily.semibold },
                ev.status === "current" && { color: colors.dark, fontFamily: fontFamily.bold },
              ]}>{ev.label}</Text>
            </View>
          ))}
        </View>
      )}
    </View>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={s.infoRow}>
      <Text style={s.infoLabel}>{label}</Text>
      <Text style={s.infoValue}>{value}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f1f5f9" },
  headerPlaceholder: { height: 100, backgroundColor: "#1e293b" },
  loadingHeader: { position: "relative", minHeight: 300, backgroundColor: "#1e293b", paddingHorizontal: 20, paddingBottom: 20, overflow: "hidden" },
  loadingTitleBlock: { position: "absolute", left: 68, top: 54 },
  loadingBadge: { position: "absolute", right: 20, top: 58, width: 92, height: 28, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.16)" },
  loadingSummaryRow: { position: "absolute", left: 20, right: 20, bottom: 20, flexDirection: "row", gap: 8 },
  loadingSummaryCard: { flex: 1, minHeight: 92, borderRadius: 12, borderWidth: 1, borderColor: "rgba(255,255,255,0.09)", backgroundColor: "rgba(255,255,255,0.07)", alignItems: "center", justifyContent: "center", gap: 8 },
  loadingSummaryIcon: { width: 28, height: 28, borderRadius: 9, backgroundColor: "rgba(255,255,255,0.18)" },
  loadingSummaryAmount: { width: "58%", height: 16, borderRadius: 8, backgroundColor: "rgba(255,255,255,0.22)" },
  loadingSummaryLabel: { width: "74%", height: 9, borderRadius: 5, backgroundColor: "rgba(255,255,255,0.14)" },
  loadingBody: { padding: 16, gap: 16 },
  loadingPickupCard: { borderRadius: 16, borderWidth: 1, borderColor: colors.neutral200, backgroundColor: colors.white, padding: 14 },
  loadingBodyHeader: { flexDirection: "row", gap: 10, alignItems: "flex-start" },
  loadingBodyIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: colors.neutral100 },
  loadingPackagesCard: { borderRadius: 16, borderWidth: 1, borderColor: colors.neutral200, backgroundColor: colors.white, paddingHorizontal: 14, paddingTop: 14 },
  loadingPackagesTitleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingBottom: 10 },
  loadingPackageRow: { marginHorizontal: -14, paddingHorizontal: 14, paddingVertical: 16, flexDirection: "row", gap: 10 },
  loadingPackageDivider: { borderBottomWidth: 1, borderBottomColor: colors.neutral200 },
  loadingPackageNumber: { width: 38, height: 38, borderRadius: 10, backgroundColor: "#dbeafe" },
  skeletonBlock: { borderRadius: 8, backgroundColor: colors.neutral200 },
  // Header
  header: { paddingHorizontal: 20, paddingBottom: 20, gap: 10, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  heroDecor2: { position: "absolute", bottom: -60, left: -40, width: width * 0.4, height: width * 0.4, borderWidth: 40, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.2 },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  heroRightStack: { alignItems: "flex-end" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 16, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  headerMetaRow: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginTop: 4 },
  headerMetaItem: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 },
  headerStatusPill: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, marginTop: 1 },
  headerStatusText: { fontFamily: fontFamily.semibold, fontSize: 11 },
  footerActions: { position: "absolute", left: 0, right: 0, bottom: 0, flexDirection: "row", gap: 10, paddingHorizontal: 16, paddingTop: 12, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.neutral200, shadowColor: colors.black, shadowOpacity: 0.08, shadowRadius: 16, shadowOffset: { width: 0, height: -6 }, elevation: 12 },
  footerActionBtn: { minHeight: 52, borderRadius: borderRadius["3xl"], flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  footerEditBtn: { flex: 1, backgroundColor: colors.dark },
  footerDeleteBtn: { width: 118, borderWidth: 1, borderColor: "#fecaca", backgroundColor: "#fff7f7" },
  footerRequestAgainBtn: { flex: 1, backgroundColor: colors.primary },
  footerEditText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  footerDeleteText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.error },
  footerRequestAgainText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  addItemBox: { width: 58, alignItems: "center", gap: 4, backgroundColor: "rgba(255,255,255,0.08)", borderRadius: 12, paddingVertical: 10, borderWidth: 1, borderColor: "rgba(255,255,255,0.1)" },
  addItemBoxIcon: { width: 32, height: 32, borderRadius: 10, backgroundColor: colors.primary, justifyContent: "center", alignItems: "center" },
  addItemBoxText: { fontFamily: fontFamily.medium, fontSize: 9, color: "rgba(255,255,255,0.7)" },
  statusCard: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "rgba(255,255,255,0.08)", borderRadius: 12, padding: 14, marginTop: 4 },
  statusIconWrap: { width: 40, height: 40, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.15)", justifyContent: "center", alignItems: "center" },
  statusTitle: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  statusSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  heroSummaryGrid: { flexDirection: "row", gap: 8, marginTop: 4 },
  heroSummaryCard: { flex: 1, minHeight: 92, backgroundColor: "rgba(255,255,255,0.07)", borderRadius: 12, borderWidth: 1, borderColor: "rgba(255,255,255,0.09)", paddingHorizontal: 6, paddingVertical: 9, alignItems: "center", justifyContent: "center", gap: 3 },
  heroSummaryIcon: { width: 28, height: 28, borderRadius: 9, justifyContent: "center", alignItems: "center" },
  heroSummaryValue: { fontFamily: fontFamily.extrabold, fontSize: 24, color: colors.white, lineHeight: 28 },
  heroSummaryAmount: { width: "100%", fontFamily: fontFamily.extrabold, fontSize: 22, color: colors.white, lineHeight: 26, textAlign: "center" },
  heroSummaryTitle: { fontFamily: fontFamily.bold, fontSize: 9, color: "rgba(255,255,255,0.82)", textAlign: "center" },
  // Body
  body: { padding: 16, gap: 16 },
  card: { backgroundColor: colors.white, borderRadius: 16, padding: 16, gap: 10 },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 4 },
  cardIconWrap: { width: 34, height: 34, borderRadius: 10, backgroundColor: colors.dark, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, letterSpacing: 0.5, textTransform: "uppercase" },
  notesText: { fontFamily: fontFamily.regular, fontSize: 14, color: colors.text, lineHeight: 22 },
  rejectionSection: { position: "relative", overflow: "hidden", borderWidth: 1, borderColor: colors.neutral200, borderRadius: 16, backgroundColor: colors.white, shadowColor: colors.black, shadowOpacity: 0.04, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1 },
  rejectionAccent: { position: "absolute", left: 0, top: 0, bottom: 0, width: 4, backgroundColor: colors.error },
  rejectionContent: { flexDirection: "row", alignItems: "flex-start", gap: 11, paddingVertical: 14, paddingLeft: 16, paddingRight: 14 },
  rejectionIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: "#fee2e2", justifyContent: "center", alignItems: "center" },
  rejectionTextBlock: { flex: 1, minWidth: 0 },
  rejectionTitle: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  rejectionBody: { marginTop: 4, fontFamily: fontFamily.regular, fontSize: 13, color: colors.textMuted, lineHeight: 19 },
  pickupInlineSection: { borderWidth: 1, borderColor: colors.neutral200, borderRadius: 16, padding: 14, backgroundColor: colors.white, shadowColor: colors.black, shadowOpacity: 0.04, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1, gap: 10 },
  pickupInlineHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  pickupInlineIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: "#dcfce7", justifyContent: "center", alignItems: "center" },
  pickupInlineTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, textTransform: "uppercase", letterSpacing: 0.4 },
  pickupInlineSummary: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.dark, marginTop: 3, lineHeight: 18 },
  pickupInlineDetails: { borderLeftWidth: 2, borderLeftColor: colors.neutral200, marginLeft: 17, paddingLeft: 18, gap: 8 },
  pickupInlineRow: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  pickupInlineLabel: { fontFamily: fontFamily.semibold, color: colors.dark },
  pickupInlineValue: { flex: 1, fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, lineHeight: 17 },
  // Timeline
  stepBadge: { backgroundColor: colors.surface, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  stepBadgeText: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.dark },
  progressBarBg: { height: 6, backgroundColor: colors.neutral200, borderRadius: 3, marginTop: 14, marginBottom: 12 },
  progressBarFill: { height: 6, backgroundColor: colors.success, borderRadius: 3 },
  currentStatusRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  currentDot: { width: 10, height: 10, borderRadius: 5 },
  currentStatusLabel: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.dark, flex: 1 },
  currentStatusSub: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted },
  timelineWrap: { marginTop: 14, borderTopWidth: 1, borderTopColor: colors.neutral100, paddingTop: 14 },
  timelineRow: { flexDirection: "row", alignItems: "flex-start", minHeight: 34 },
  timelineDotCol: { width: 28, alignItems: "center" },
  timelineDot: { width: 22, height: 22, borderRadius: 11, backgroundColor: colors.neutral200, justifyContent: "center", alignItems: "center" },
  timelineDotDone: { backgroundColor: colors.success },
  timelineDotCurrent: { backgroundColor: colors.dark, borderWidth: 3, borderColor: colors.neutral200 },
  timelineDotInner: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.white },
  timelineLine: { width: 2, flex: 1, backgroundColor: colors.neutral200, marginVertical: 2 },
  timelineLineDone: { backgroundColor: colors.success },
  timelineLabel: { fontFamily: fontFamily.regular, fontSize: 13, color: colors.textMuted, marginLeft: 10, marginTop: 2 },
  // Location cards
  locTitleRow: { flexDirection: "row", alignItems: "center" },
  locSummary: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: 2 },
  expandIconBtn: { width: 28, height: 28, borderRadius: 14, backgroundColor: colors.warmSurface, justifyContent: "center", alignItems: "center", borderWidth: 1, borderColor: colors.accentLighter },
  editLinkText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.primary, textDecorationLine: "underline", marginLeft: 10 },
  locDetails: { marginTop: 12, borderTopWidth: 1, borderTopColor: colors.neutral100, paddingTop: 12, gap: 12 },
  iconRow: { flexDirection: "row", gap: 10, alignItems: "flex-start" },
  iconRowLabel: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.5 },
  iconRowValue: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.dark, marginTop: 1 },
  // Info rows
  infoRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  infoLabel: { fontFamily: fontFamily.regular, fontSize: 13, color: colors.textMuted },
  infoValue: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.dark, flex: 1, textAlign: "right" },
  // Items
  packageSection: { gap: 4, borderWidth: 1, borderColor: colors.neutral200, borderRadius: 16, paddingHorizontal: 14, paddingTop: 14, backgroundColor: colors.white, shadowColor: colors.black, shadowOpacity: 0.04, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1 },
  packageSectionHeader: { flexDirection: "row", alignItems: "center", gap: 10, paddingBottom: 10 },
  packageSectionTitle: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, textTransform: "uppercase", letterSpacing: 0.4 },
  packageSectionCount: { minWidth: 30, height: 26, borderRadius: 13, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.neutral200, justifyContent: "center", alignItems: "center", paddingHorizontal: 9 },
  packageSectionCountText: { fontFamily: fontFamily.bold, fontSize: 12, color: colors.primary },
  addItemBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 12, paddingVertical: 6, borderRadius: borderRadius["3xl"], marginLeft: "auto" },
  addItemBtnPill: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 10, paddingVertical: 4, borderRadius: borderRadius["3xl"], borderWidth: 1, borderColor: colors.accentLighter },
  addItemPillText: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.primary },
  addItemText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.primary },
  itemCard: { marginHorizontal: -14, paddingHorizontal: 14, paddingVertical: 16 },
  itemCardDivider: { borderBottomWidth: 1, borderBottomColor: colors.neutral200 },
  itemStatusChip: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  itemStatusChipText: { fontFamily: fontFamily.semibold, fontSize: 10, letterSpacing: 0.3 },
  itemCourierChip: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6, backgroundColor: "#ede9fe" },
  itemCourierChipText: { fontFamily: fontFamily.semibold, fontSize: 10, color: "#7c3aed", letterSpacing: 0.2 },
  itemDesc: { flex: 1, fontFamily: fontFamily.semibold, fontSize: 13, color: colors.dark },
  itemMeta: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 2 },
  itemQty: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted },
  itemTracking: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.primary },
  itemTopRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  itemIconWrap: { width: 38, height: 38, borderRadius: 10, backgroundColor: "#dbeafe", justifyContent: "center", alignItems: "center" },
  itemIconNumber: { fontFamily: fontFamily.bold, fontSize: 15, color: colors.primary },
  itemTitleRow: { position: "relative", paddingRight: 82, minHeight: 20 },
  itemMetaRow: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 8, marginTop: 0 },
  itemMetaItem: { flexDirection: "row", alignItems: "center", gap: 3 },
  itemMetaText: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted },
  itemEtaRow: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 6, marginTop: 7 },
  itemEtaPill: { flexDirection: "row", alignItems: "center", gap: 4, alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  itemEtaText: { fontFamily: fontFamily.semibold, fontSize: 10.5 },
  itemDelayPill: { flexDirection: "row", alignItems: "center", gap: 4, alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6, backgroundColor: colors.warmSurface },
  itemDelayText: { fontFamily: fontFamily.semibold, fontSize: 10.5, color: colors.primary },
  packageDetailsList: { marginTop: 12, backgroundColor: "rgba(255,255,255,0.55)", borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4, borderWidth: 1, borderColor: colors.neutral100 },
  packageDetailRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 7 },
  packageDetailIcon: { width: 24, height: 24, borderRadius: 8, backgroundColor: "#eff6ff", justifyContent: "center", alignItems: "center" },
  packageDetailLabel: { fontFamily: fontFamily.semibold, fontSize: 10, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.4 },
  packageDetailValue: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.dark, marginTop: 1 },
  itemActionChip: { position: "absolute", top: -4, right: 0, flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 10, paddingVertical: 6, borderRadius: borderRadius["3xl"] },
  itemActionChipText: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.primary },
  packageModalOverlay: { flex: 1, justifyContent: "flex-end" },
  packageModalScrim: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(15,23,42,0.45)" },
  packageModalSheet: { maxHeight: "86%", backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingTop: 10, paddingHorizontal: 16, paddingBottom: 22 },
  packageModalHandle: { alignSelf: "center", width: 42, height: 4, borderRadius: 2, backgroundColor: colors.neutral300, marginBottom: 12 },
  packageModalHeader: { flexDirection: "row", alignItems: "flex-start", gap: 12, marginBottom: 14 },
  packageModalKicker: { fontFamily: fontFamily.semibold, fontSize: 10, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.5 },
  packageModalTitle: { fontFamily: fontFamily.bold, fontSize: 17, color: colors.dark, marginTop: 2 },
  packageModalCourierPill: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 5, marginTop: 8, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, backgroundColor: "#ede9fe" },
  packageModalCourierPillText: { fontFamily: fontFamily.semibold, fontSize: 11, color: "#7c3aed" },
  packageModalClose: { width: 34, height: 34, borderRadius: 17, backgroundColor: colors.white, justifyContent: "center", alignItems: "center", borderWidth: 1, borderColor: colors.neutral200 },
  packageModalContent: { gap: 12, paddingBottom: 20 },
  packageModalMeta: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  packageModalMetaItem: { flexGrow: 1, flexBasis: "31%", minHeight: 58, borderRadius: 12, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.neutral100, paddingHorizontal: 8, paddingVertical: 10, justifyContent: "center", overflow: "hidden" },
  packageModalMetaLabel: { fontFamily: fontFamily.semibold, fontSize: 10, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.4 },
  packageModalMetaValue: { fontFamily: fontFamily.bold, fontSize: 13, color: colors.dark, marginTop: 4 },
  packageModalTrackingValue: { width: "100%", fontFamily: fontFamily.bold, fontSize: 12, color: colors.dark, marginTop: 4 },
  packageModalStatusValue: { width: "100%", fontFamily: fontFamily.bold, fontSize: 12, color: colors.dark, marginTop: 4 },
  packageModalPanel: { backgroundColor: colors.white, borderRadius: 14, borderWidth: 1, borderColor: colors.neutral100, paddingHorizontal: 12, paddingVertical: 6 },
  packageModalInfoRow: { flexDirection: "row", gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  packageModalInfoIcon: { width: 26, height: 26, borderRadius: 8, backgroundColor: "#eff6ff", justifyContent: "center", alignItems: "center" },
  packageModalInfoLabel: { fontFamily: fontFamily.semibold, fontSize: 10, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.4 },
  packageModalInfoValue: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.dark, marginTop: 2, lineHeight: 18 },
  packageModalSectionTitle: { fontFamily: fontFamily.bold, fontSize: 12, color: colors.dark, textTransform: "uppercase", letterSpacing: 0.4, marginVertical: 8 },
  packageModalPhoto: { width: 92, height: 92, borderRadius: 12, backgroundColor: colors.neutral200, marginRight: 10, marginBottom: 8 },
  packageModalProof: { height: 170, borderRadius: 12, backgroundColor: colors.neutral200, marginTop: 8, marginBottom: 8 },
  itemDeleteChip: { backgroundColor: "#fef2f2" },
  imageBadge: { flexDirection: "row", alignItems: "center", gap: 3, backgroundColor: colors.surface, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  imageBadgeText: { fontFamily: fontFamily.medium, fontSize: 10, color: colors.textMuted },
  // Actions
  actionsCard: { backgroundColor: colors.white, borderRadius: 16, overflow: "hidden" },
  actionBtn: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 14, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  actionBtnIcon: { width: 36, height: 36, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  actionBtnText: { fontFamily: fontFamily.medium, fontSize: 14, color: colors.dark, flex: 1 },
  emptyItems: { alignItems: "center", paddingVertical: 24, gap: 8 },
  emptyItemsText: { fontFamily: fontFamily.regular, fontSize: 13, color: colors.textMuted },
  addFirstBtn: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: colors.primary, paddingHorizontal: 16, paddingVertical: 10, borderRadius: borderRadius["3xl"], marginTop: 8 },
  addFirstText: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.white },
  // Photos grid (unprocessed state)
  photoCountText: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.textMuted, marginBottom: 10 },
  photoGrid: { flexDirection: "row", flexWrap: "wrap", gap: UNPROCESSED_PHOTO_GAP, marginBottom: 12 },
  photoTile: {},
  photoThumb: { borderRadius: 10, backgroundColor: colors.neutral200 },
  recipientRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, paddingTop: 2, paddingBottom: 4, flexWrap: "wrap" },
  recipientRowText: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.primary, textAlign: "center", maxWidth: "100%" },
  recipientRowMuted: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, textAlign: "center" },
  handoffProofBlock: { marginTop: 6, borderTopWidth: 1, borderTopColor: "#ede9fe", paddingTop: 12, gap: 8 },
  handoffProofLabel: { fontFamily: fontFamily.semibold, fontSize: 12, color: "#7c3aed", textTransform: "uppercase", letterSpacing: 0.5 },
  handoffProofImage: { width: "100%", height: 180, borderRadius: 12, backgroundColor: colors.neutral200 },
  handoffProofHint: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted },
  lightbox: { flex: 1, backgroundColor: "rgba(0,0,0,0.95)", justifyContent: "center" },
  lightboxHeader: { position: "absolute", left: 0, right: 0, flexDirection: "row", justifyContent: "center", alignItems: "center", zIndex: 10 },
  lightboxCounter: { fontFamily: fontFamily.medium, fontSize: 14, color: "rgba(255,255,255,0.7)" },
  lightboxClose: { position: "absolute", right: 20, width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.15)", justifyContent: "center", alignItems: "center" },
  lightboxImage: { width: "100%", height: "65%" },
  lightboxError: { alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 28 },
  lightboxErrorTitle: { fontFamily: fontFamily.bold, fontSize: 17, color: colors.white },
  lightboxErrorText: { fontFamily: fontFamily.regular, fontSize: 13, lineHeight: 19, color: "rgba(255,255,255,0.68)", textAlign: "center" },
  lightboxErrorButton: { marginTop: 10, minHeight: 42, borderRadius: 21, paddingHorizontal: 20, alignItems: "center", justifyContent: "center", backgroundColor: colors.primary },
  lightboxErrorButtonText: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.white },
  // Info banner
  infoBanner: { flexDirection: "row", alignItems: "flex-start", gap: 8, backgroundColor: "#eff6ff", borderRadius: 10, padding: 12 },
  infoBannerText: { fontFamily: fontFamily.regular, fontSize: 13, color: "#3b82f6", flex: 1, lineHeight: 18 },
});
