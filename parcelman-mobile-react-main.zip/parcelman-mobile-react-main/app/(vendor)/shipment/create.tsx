import { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  Dimensions,
  Modal,
  Pressable,
  FlatList,
  KeyboardAvoidingView,
  Keyboard,
  Platform,
  ActivityIndicator,
  TextInput,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import Input from "../../../src/components/common/Input";
import Button from "../../../src/components/common/Button";
import PickupVehicleRequestCard, { type PickupVehicleSelection } from "../../../src/components/vendor/PickupVehicleRequestCard";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { spacing } from "../../../src/constants/spacing";
import { useAuthStore } from "../../../src/stores/auth.store";
import type { PickupVehicleTypeOption } from "../../../src/stores/vendor.store";
import { isValidGhanaPhone, sanitizeLocalPhoneInput, toApiPhone, toLocalPhone } from "../../../src/utils/format";
import { showSuccess, showError, getErrorMessage } from "../../../src/utils/toast";
import { compressToUnder2MB, compressMany } from "../../../src/utils/image";
import { captureSinglePhoto } from "../../../src/utils/cameraCapture";
import { getShipment } from "../../../src/api/v1/vendor/shipments";
import { searchLocations } from "../../../src/api/v1/vendor/locations";
import api from "../../../src/api/client";

interface TaggedPhoto {
  uri: string;
  recipientPhone: string | null;
  reusedImageId?: number | null;
}

interface LocationSuggestion {
  id: number;
  name: string;
  display?: string;
  district?: { id: number; name: string };
  region?: { id: number; name: string };
}

const MAX_PHOTOS = 300;
const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");
const PHOTO_GAP = 4;

function locationPart(value: any): string {
  if (!value) return "";
  if (typeof value === "string") return value;
  if (typeof value === "object") return String(value.name || value.town || value.display || "").trim();
  return String(value).trim();
}

function formatPickupLocationValue(value: any): string {
  if (!value) return "";
  if (typeof value === "string") return value;

  const direct = locationPart(value.display || value.name || value.town);
  const district = locationPart(value.district);
  const region = locationPart(value.region);
  const parts = [direct, district, region].filter(Boolean);

  if (parts.length > 0) return parts.join(", ");
  return locationPart(value);
}

export default function CreateShipmentScreen() {
  const insets = useSafeAreaInsets();
  const shipmentsRoute = "/(vendor)/(tabs)/shipments" as const;
  const leaveCreate = () => {
    if (router.canGoBack()) router.back();
    else router.replace(shipmentsRoute as any);
  };
  const params = useLocalSearchParams<{ requestAgainShipmentId?: string }>();
  const requestAgainShipmentId = Array.isArray(params.requestAgainShipmentId)
    ? params.requestAgainShipmentId[0]
    : params.requestAgainShipmentId;
  const user = useAuthStore((s) => s.user) as any;
  const [loading, setLoading] = useState(false);
  const [prefillLoading, setPrefillLoading] = useState(false);

  const [pickupTown, setPickupTown] = useState("");
  const [pickupLocationQuery, setPickupLocationQuery] = useState("");
  const [pickupLocationResults, setPickupLocationResults] = useState<LocationSuggestion[]>([]);
  const [pickupLocationOpen, setPickupLocationOpen] = useState(false);
  const [pickupLocationLoading, setPickupLocationLoading] = useState(false);
  const [photos, setPhotos] = useState<TaggedPhoto[]>([]);
  const [totalPackageQty, setTotalPackageQty] = useState("");
  const [senderNotes, setSenderNotes] = useState("");
  const [pickupVehicles, setPickupVehicles] = useState<PickupVehicleSelection[]>([]);
  const [pickupVehicleTypes, setPickupVehicleTypes] = useState<PickupVehicleTypeOption[]>([]);
  const [step, setStep] = useState<"details" | "photos" | "review">("details");
  const [gridWidth, setGridWidth] = useState(0);
  const photoSize = gridWidth > 0 ? (gridWidth - PHOTO_GAP * 2) / 3 : 90;
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const openLightbox = (i: number) => { setLightboxIndex(i); setLightboxOpen(true); };
  const closeLightbox = () => setLightboxOpen(false);
  const [selectMode, setSelectMode] = useState(false);
  const lightboxRef = useRef<FlatList>(null);
  const scrollRef = useRef<ScrollView>(null);
  const pickupLocationTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pickupLocationRequestRef = useRef(0);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [fieldPositions, setFieldPositions] = useState({ pickupTown: 0, senderNotes: 0 });
  const [keyboardVisible, setKeyboardVisible] = useState(false);

  // Phone tagging modal state.
  // `tagTargetIndices` = array of photo indices the modal will apply the phone to.
  // When null, the modal is in select-mode bulk and applies to the `selected` set.
  const [tagModalOpen, setTagModalOpen] = useState(false);
  const [tagPhoneInput, setTagPhoneInput] = useState("");
  const [tagPhoneError, setTagPhoneError] = useState("");
  const [tagTargetIndices, setTagTargetIndices] = useState<number[] | null>(null);

  useEffect(() => {
    const showSub = Keyboard.addListener("keyboardDidShow", () => {
      setKeyboardVisible(true);
    });
    const hideSub = Keyboard.addListener("keyboardDidHide", () => {
      setKeyboardVisible(false);
    });

    return () => {
      showSub.remove();
      hideSub.remove();
      if (pickupLocationTimeoutRef.current) clearTimeout(pickupLocationTimeoutRef.current);
    };
  }, []);

  useEffect(() => {
    if (!requestAgainShipmentId) return;

    let cancelled = false;

    const loadRejectedRequest = async () => {
      setPrefillLoading(true);
      try {
        const res = await getShipment(Number(requestAgainShipmentId));
        if (cancelled) return;

        const source = (res as any)?.data?.shipment || (res as any)?.data || res;
        if (!source || source.status !== "rejected") {
          showError("Only rejected requests can be requested again.");
          return;
        }

        const pickupLocation = formatPickupLocationValue(
          source.pickup_town ||
          source.pickup?.location ||
          source.pickup_location ||
          ""
        );
        setPickupTown(pickupLocation);
        setPickupLocationQuery(pickupLocation);
        setSenderNotes(source.sender_notes || "");

        const copiedVehicles = Array.isArray(source.pickup_vehicles)
          ? source.pickup_vehicles
              .map((vehicle: any) => ({
                vehicle_type_id: Number(vehicle.vehicle_type_id || vehicle.pickup_vehicle_type_id || vehicle.id || 0),
                quantity: Number(vehicle.quantity || 0),
              }))
              .filter((vehicle: PickupVehicleSelection) => vehicle.vehicle_type_id && vehicle.quantity > 0)
          : [];
        setPickupVehicles(copiedVehicles);

        const copiedPhotos: TaggedPhoto[] = [];
        const items = Array.isArray(source.items) ? source.items : [];
        items.forEach((item: any) => {
          const images = Array.isArray(item.images) ? item.images : [];
          images.forEach((image: any) => {
            const url = image.url || image.uri;
            if (!url || !image.id) return;
            copiedPhotos.push({
              uri: url,
              recipientPhone: image.recipient_phone ? toLocalPhone(image.recipient_phone) : null,
              reusedImageId: Number(image.id),
            });
          });
        });

        setPhotos(copiedPhotos);
        const copiedQty = Number(source.vendor_declared_quantity || source.total_packages_count || copiedPhotos.length || items.length || 0);
        if (copiedQty > 0) setTotalPackageQty(String(copiedQty));
        setStep("details");
      } catch (err: any) {
        if (!cancelled) showError(getErrorMessage(err, "Could not load rejected request."));
      } finally {
        if (!cancelled) setPrefillLoading(false);
      }
    };

    loadRejectedRequest();

    return () => {
      cancelled = true;
    };
  }, [requestAgainShipmentId]);

  const readLocationResults = (res: any): LocationSuggestion[] => {
    if (Array.isArray(res?.data?.locations)) return res.data.locations;
    if (Array.isArray(res?.locations)) return res.locations;
    if (Array.isArray(res?.data)) return res.data;
    if (Array.isArray(res)) return res;
    return [];
  };

  const handlePickupLocationChange = (text: string) => {
    setPickupLocationQuery(text);
    setPickupTown(text.trim());

    if (pickupLocationTimeoutRef.current) clearTimeout(pickupLocationTimeoutRef.current);
    const query = text.trim();
    pickupLocationRequestRef.current += 1;
    const requestId = pickupLocationRequestRef.current;

    if (query.length < 2) {
      setPickupLocationResults([]);
      setPickupLocationOpen(false);
      setPickupLocationLoading(false);
      return;
    }

    setPickupLocationLoading(true);
    pickupLocationTimeoutRef.current = setTimeout(async () => {
      try {
        const res = await searchLocations(query);
        if (requestId !== pickupLocationRequestRef.current) return;
        const results = readLocationResults(res).slice(0, 5);
        setPickupLocationResults(results);
        setPickupLocationOpen(results.length > 0);
      } catch {
        if (requestId === pickupLocationRequestRef.current) {
          setPickupLocationResults([]);
          setPickupLocationOpen(false);
        }
      } finally {
        if (requestId === pickupLocationRequestRef.current) setPickupLocationLoading(false);
      }
    }, 250);
  };

  const selectPickupLocation = (location: LocationSuggestion) => {
    if (pickupLocationTimeoutRef.current) clearTimeout(pickupLocationTimeoutRef.current);
    pickupLocationRequestRef.current += 1;
    setPickupLocationQuery(location.display || location.name);
    setPickupTown(location.name || location.display || "");
    setPickupLocationResults([]);
    setPickupLocationOpen(false);
    setPickupLocationLoading(false);
  };

  const takePhoto = async () => {
    if (photos.length >= MAX_PHOTOS) {
      Alert.alert("Limit reached", `Maximum ${MAX_PHOTOS} photos allowed.`);
      return;
    }
    const capturedUri = await captureSinglePhoto({ quality: 0.7, simulatorBehavior: 'choice' });
    if (!capturedUri) return;

    const compressedUri = await compressToUnder2MB(capturedUri);
    const newPhoto: TaggedPhoto = { uri: compressedUri, recipientPhone: null };
    const newIndex = photos.length;
    setPhotos((prev) => [...prev, newPhoto].slice(0, MAX_PHOTOS));
    // Prompt for recipient phone immediately after capture.
    setTimeout(() => openTagModal([newIndex]), 80);
  };

  const pickFromGallery = async () => {
    const remaining = MAX_PHOTOS - photos.length;
    if (remaining <= 0) {
      Alert.alert("Limit reached", `Maximum ${MAX_PHOTOS} photos allowed.`);
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsMultipleSelection: true,
      quality: 0.7,
      selectionLimit: remaining,
    });
    if (!result.canceled && result.assets.length > 0) {
      const startIdx = photos.length;
      const count = Math.min(result.assets.length, remaining);
      const originalUris = result.assets.slice(0, count).map((a) => a.uri);
      const compressedUris = await compressMany(originalUris);
      const newPhotos: TaggedPhoto[] = compressedUris.map((uri) => ({
        uri,
        recipientPhone: null,
      }));
      const newIndices = Array.from({ length: count }, (_, i) => startIdx + i);
      setPhotos((prev) => [...prev, ...newPhotos].slice(0, MAX_PHOTOS));
      // Prompt to tag the newly imported photos with a recipient.
      setTimeout(() => openTagModal(newIndices), 80);
    }
  };

  const removePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
    if (lightboxOpen) {
      if (lightboxIndex >= photos.length - 1) setLightboxIndex(Math.max(0, photos.length - 2));
      if (photos.length <= 1) setLightboxOpen(false);
    }
  };

  const toggleSelect = (index: number) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  };

  const removeSelected = () => {
    setPhotos((prev) => prev.filter((_, i) => !selected.has(i)));
    setSelected(new Set());
    setSelectMode(false);
  };

  const clearAllPhotos = () => {
    Alert.alert("Clear All", `Remove all ${photos.length} photos?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Clear All", style: "destructive", onPress: () => { setPhotos([]); setSelectMode(false); setSelected(new Set()); } },
    ]);
  };

  // Phone tagging modal — three entry points:
  // - Single photo: tap a tile's chip/badge → pre-fills with that photo's phone
  // - Auto-prompt: after camera/gallery add → pre-fills empty
  // - Select-mode bulk: no arg → applies to the `selected` set
  const openTagModal = (arg?: number | number[]) => {
    let indices: number[] | null = null;
    if (typeof arg === "number") indices = [arg];
    else if (Array.isArray(arg)) indices = arg;

    setTagTargetIndices(indices);

    const sourceIndices = indices ?? Array.from(selected);
    const phones = sourceIndices.map((i) => sanitizeLocalPhoneInput(photos[i]?.recipientPhone || ""));
    const unique = new Set(phones);
    setTagPhoneInput(unique.size === 1 ? Array.from(unique)[0] : "");
    setTagPhoneError("");

    setTagModalOpen(true);
  };

  const applyTag = () => {
    const phoneRaw = sanitizeLocalPhoneInput(tagPhoneInput);
    if (!isValidGhanaPhone(phoneRaw)) {
      setTagPhoneError("Enter a valid 10-digit Ghana phone number");
      return;
    }
    const phone = phoneRaw.length > 0 ? phoneRaw : null;
    const wasSelectModeBulk = tagTargetIndices === null;
    setPhotos((prev) => {
      if (tagTargetIndices !== null) {
        const set = new Set(tagTargetIndices);
        return prev.map((p, i) => (set.has(i) ? { ...p, recipientPhone: phone } : p));
      }
      return prev.map((p, i) => (selected.has(i) ? { ...p, recipientPhone: phone } : p));
    });
    setTagModalOpen(false);
    setTagPhoneInput("");
    setTagPhoneError("");
    setTagTargetIndices(null);
    if (wasSelectModeBulk) {
      setSelected(new Set());
      setSelectMode(false);
    }
  };

  const cancelTag = () => {
    setTagModalOpen(false);
    setTagPhoneInput("");
    setTagPhoneError("");
    setTagTargetIndices(null);
  };

  const allTagged = photos.length > 0 && photos.every((p) => !!p.recipientPhone);
  const untaggedCount = photos.filter((p) => !p.recipientPhone).length;

  const pickupVehicleCount = pickupVehicles.reduce((sum, vehicle) => sum + Number(vehicle.quantity || 0), 0);
  const pickupVehicleSummary = pickupVehicleCount > 0
    ? pickupVehicles
        .map((vehicle) => {
          const type = pickupVehicleTypes.find((candidate) => Number(candidate.id) === Number(vehicle.vehicle_type_id));
          return `${vehicle.quantity} ${type?.name || "Vehicle"}`;
        })
        .join(", ")
    : "No specific vehicle";

  const handleDetailsContinue = () => {
    if (!pickupTown.trim()) {
      showError("Please enter a pickup location");
      return;
    }
    setStep("photos");
  };

  const handlePhotosContinue = () => {
    if (photos.length === 0) {
      showError("Please take at least one photo of your packages");
      return;
    }
    if (!allTagged) {
      showError("Every photo needs a recipient phone");
      return;
    }
    if (!totalPackageQty.trim()) {
      setTotalPackageQty(String(photos.length));
    }
    setStep("review");
  };

  const scrollToField = (key: "pickupTown" | "senderNotes") => {
    const y = fieldPositions[key];
    requestAnimationFrame(() => {
      scrollRef.current?.scrollTo({ y: Math.max(0, y - 24), animated: true });
    });
  };

  const scrollBottomPadding = keyboardVisible ? Math.max(360, insets.bottom + 24) : 24;
  const headerHeight = insets.top + 12 + 36 + 16;
  const emptyPhotosHeight = Math.max(420, SCREEN_HEIGHT - headerHeight);

  const handleSubmit = async () => {
    if (photos.length === 0) {
      showError("Please take at least one photo of your packages");
      return;
    }
    if (!allTagged) {
      showError("Every photo needs a recipient phone");
      return;
    }
    if (!pickupTown.trim()) {
      showError("Please enter a pickup location");
      return;
    }
    const declaredQty = Number(totalPackageQty);
    if (!Number.isInteger(declaredQty) || declaredQty < 1) {
      showError("Enter the total package quantity");
      return;
    }
    setLoading(true);
    try {
      const formData = new FormData();
      // Always "single" — admin splits photos into packages during processing.
      formData.append("destination_mode", "single");
      formData.append("pickup_contact_name", user?.name || "Vendor");
      formData.append("pickup_contact_phone", toApiPhone(user?.phone || ""));
      formData.append("pickup_contact_phone_confirm", toApiPhone(user?.phone || ""));
      if (pickupTown.trim()) formData.append("pickup_town", pickupTown.trim());
      if (senderNotes.trim()) formData.append("sender_notes", senderNotes.trim());
      formData.append("vendor_declared_quantity", String(declaredQty));
      if (pickupVehicles.length > 0) {
        formData.append("pickup_vehicles", JSON.stringify(pickupVehicles));
      }

      let uploadIndex = 0;
      let reusedIndex = 0;
      photos.forEach((photo, i) => {
        if (photo.reusedImageId) {
          formData.append(`items[0][reused_image_ids][${reusedIndex}]`, String(photo.reusedImageId));
          if (photo.recipientPhone) {
            formData.append(`items[0][reused_image_phones][${reusedIndex}]`, toApiPhone(photo.recipientPhone));
          }
          reusedIndex += 1;
          return;
        }

        formData.append(`items[0][images][${uploadIndex}]`, {
          uri: photo.uri,
          name: `photo_${i}.jpg`,
          type: "image/jpeg",
        } as any);
        if (photo.recipientPhone) {
          formData.append(`items[0][phones][${uploadIndex}]`, toApiPhone(photo.recipientPhone));
        }
        uploadIndex += 1;
      });

      const res = await api.post("/vendor/shipments", formData, {
        headers: { "Content-Type": "multipart/form-data" },
        timeout: 120000,
      });

      const shipmentId = (res as any)?.data?.shipment?.id || (res as any)?.data?.id;
      showSuccess("Package request submitted");
      if (shipmentId) {
        router.replace({
          pathname: "/(vendor)/shipment/[id]",
          params: { id: String(shipmentId) },
        } as any);
      } else {
        router.replace(shipmentsRoute as any);
      }
    } catch (err: any) {
      if (__DEV__) console.log("[Create] Error:", JSON.stringify(err, null, 2));
      showError(getErrorMessage(err, "Failed to submit. Please try again."));
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={s.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      {/* Header — extends behind the translucent status bar for a seamless top */}
      <LinearGradient
        colors={["#1e293b", "#334155", "#1e293b"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[s.header, { paddingTop: insets.top + 12 }]}
      >
        <View style={s.headerRow}>
          <TouchableOpacity onPress={leaveCreate} style={s.backBtn}>
            <Ionicons name="arrow-back" size={22} color={colors.white} />
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={s.headerTitle}>{requestAgainShipmentId ? "Request Again" : "Send a Package"}</Text>
            <Text style={s.headerSub}>
              {prefillLoading ? "Loading previous request..." : "Set pickup, add photos, then review"}
            </Text>
          </View>
        </View>
      </LinearGradient>

      <View style={s.main}>
        <ScrollView
          ref={scrollRef}
          style={s.scroll}
          contentContainerStyle={{ paddingBottom: scrollBottomPadding, flexGrow: 1 }}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="interactive"
          automaticallyAdjustKeyboardInsets={Platform.OS === "ios"}
          showsVerticalScrollIndicator={false}
        >
          {step === "details" ? (
            /* Step 1: Pickup details */
            <View style={s.body}>
              <View
                style={s.card}
                onLayout={(e) => {
                  const y = e.nativeEvent.layout.y;
                  setFieldPositions((prev) => ({ ...prev, pickupTown: y }));
                }}
              >
                <View style={s.cardHeader}>
                  <View style={s.cardTitleBlock}>
                    <Text style={s.cardTitle}>Pickup Location <Text style={s.requiredMark}>*</Text></Text>
                    <Text style={s.cardSubtext}>Where should we pick up these packages?</Text>
                  </View>
                </View>
                <View style={s.locationCombo}>
                  <View style={[s.locationInputWrap, pickupLocationOpen && s.locationInputWrapOpen]}>
                    <Ionicons name="location-outline" size={18} color={colors.textMuted} style={s.locationInputIcon} />
                    <TextInput
                      style={s.locationInputText}
                      placeholder="Where should we pick up? e.g. Lapaz"
                      placeholderTextColor={colors.textLight}
                      value={pickupLocationQuery}
                      onChangeText={handlePickupLocationChange}
                      onFocus={() => {
                        scrollToField("pickupTown");
                        if (pickupLocationResults.length > 0) setPickupLocationOpen(true);
                      }}
                      onBlur={() => setTimeout(() => setPickupLocationOpen(false), 140)}
                    />
                    {pickupLocationLoading && (
                      <ActivityIndicator size="small" color={colors.primary} style={s.locationInputLoader} />
                    )}
                  </View>
                  {pickupLocationOpen && (
                    <View style={s.locationResults}>
                      {pickupLocationResults.map((location) => (
                        <TouchableOpacity
                          key={`${location.id}-${location.name}`}
                          style={s.locationResultItem}
                          onPress={() => selectPickupLocation(location)}
                          activeOpacity={0.75}
                        >
                          <Text style={s.locationResultText} numberOfLines={2}>
                            {location.display || [location.name, location.district?.name, location.region?.name].filter(Boolean).join(", ")}
                          </Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  )}
                </View>
              </View>

              <PickupVehicleRequestCard
                selections={pickupVehicles}
                onChange={setPickupVehicles}
                onTypesLoaded={setPickupVehicleTypes}
                collapsible={false}
              />
            </View>
          ) : step === "review" ? (
            /* Step 3: Review and submit */
            <View style={s.body}>
              <View style={s.reviewHeaderCard}>
                <View style={s.reviewHeaderIcon}>
                  <Ionicons name="checkmark-circle" size={22} color={colors.white} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.reviewHeaderTitle}>Review your request</Text>
                  <Text style={s.reviewHeaderText}>Confirm the details before submitting.</Text>
                </View>
              </View>

              <View style={s.card}>
                <View style={s.reviewSectionHeader}>
                  <View>
                    <Text style={s.cardTitle}>Pickup</Text>
                    <Text style={s.cardSubtext}>
                      {pickupVehicles.length > 0 ? "Location and vehicle request" : "Pickup location"}
                    </Text>
                  </View>
                  <TouchableOpacity onPress={() => setStep("details")} style={s.reviewEditBtn}>
                    <Ionicons name="pencil" size={13} color={colors.primary} />
                    <Text style={s.reviewEditText}>Edit</Text>
                  </TouchableOpacity>
                </View>
                <View style={s.reviewRows}>
                  <View style={s.reviewRow}>
                    <Ionicons name="location-outline" size={16} color={colors.textMuted} />
                    <View style={{ flex: 1 }}>
                      <Text style={s.reviewLabel}>Pickup Location</Text>
                      <Text style={s.reviewValue}>{pickupLocationQuery || pickupTown || "Not set"}</Text>
                    </View>
                  </View>
                  {pickupVehicles.length > 0 && (
                    <View style={s.reviewRow}>
                      <Ionicons name="bicycle-outline" size={16} color={colors.textMuted} />
                      <View style={{ flex: 1 }}>
                        <Text style={s.reviewLabel}>Vehicle Request</Text>
                        <Text style={s.reviewValue}>{pickupVehicleSummary}</Text>
                      </View>
                    </View>
                  )}
                </View>
              </View>

              <View style={s.card}>
                <View style={s.reviewSectionHeader}>
                  <View>
                    <Text style={s.cardTitle}>Photos</Text>
                    <Text style={s.cardSubtext}>Package photos and recipient phone tags</Text>
                  </View>
                  <TouchableOpacity onPress={() => setStep("photos")} style={s.reviewEditBtn}>
                    <Ionicons name="pencil" size={13} color={colors.primary} />
                    <Text style={s.reviewEditText}>Edit</Text>
                  </TouchableOpacity>
                </View>
                <View style={s.reviewRows}>
                  <View style={s.reviewRow}>
                    <Ionicons name="camera-outline" size={16} color={colors.textMuted} />
                    <View style={{ flex: 1 }}>
                      <Text style={s.reviewLabel}>Photos Uploaded</Text>
                      <Text style={s.reviewValue}>{photos.length} photo{photos.length === 1 ? "" : "s"}</Text>
                    </View>
                  </View>
                  <View style={s.reviewRow}>
                    <Ionicons name="call-outline" size={16} color={colors.textMuted} />
                    <View style={{ flex: 1 }}>
                      <Text style={s.reviewLabel}>Recipient Phones</Text>
                      <Text style={s.reviewValue}>
                        {photos.filter((photo) => !!photo.recipientPhone).length} tagged
                      </Text>
                    </View>
                  </View>
                </View>
              </View>

              <View style={s.card}>
                <View style={s.cardHeader}>
                  <View style={s.cardTitleBlock}>
                    <Text style={s.cardTitle}>Total Packages Quantity <Text style={s.requiredMark}>*</Text></Text>
                    <Text style={s.cardSubtext}>Confirm the number of packages ParcelMan should expect.</Text>
                  </View>
                </View>
                <Input
                  placeholder="How many packages in total?"
                  value={totalPackageQty}
                  onChangeText={setTotalPackageQty}
                  keyboardType="number-pad"
                  leftIcon={<Ionicons name="calculator-outline" size={18} color={colors.textMuted} />}
                />
              </View>
            </View>
          ) : photos.length === 0 ? (
            /* Step 2a: Empty photos state */
            <View style={[s.emptyStateShell, { minHeight: emptyPhotosHeight }]}>
              <View style={s.emptyState}>
                <View style={s.emptyIconWrap}>
                  <Ionicons name="camera" size={56} color={colors.primary} />
                </View>
                <Text style={s.emptyTitle}>Take photos of your packages</Text>
                <Text style={s.emptySub}>
                  Take clear photos of each package you want to send.{"\n"}These photos are proof that the request has started — our record and yours.
                </Text>

                <TouchableOpacity style={s.bigCameraBtn} onPress={takePhoto} activeOpacity={0.8}>
                  <LinearGradient
                    colors={[colors.primary, colors.primaryLight]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={s.bigCameraBtnInner}
                  >
                    <Ionicons name="camera" size={24} color={colors.white} />
                    <Text style={s.bigCameraBtnText}>Open Camera</Text>
                  </LinearGradient>
                </TouchableOpacity>

                <TouchableOpacity style={s.galleryLink} onPress={pickFromGallery}>
                  <Ionicons name="images-outline" size={18} color={colors.primary} />
                  <Text style={s.galleryLinkText}>Choose from gallery</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : (
            /* Step 2b: Photos grid */
            <View style={s.body}>
              <View style={s.photoSummary}>
                <View style={[s.photoSummaryIcon, { backgroundColor: colors.success }]}>
                  <Ionicons name="location" size={18} color={colors.white} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.photoSummaryTitle} numberOfLines={1}>Pickup: {pickupLocationQuery || pickupTown}</Text>
                  <Text style={s.photoSummaryText}>Tap Edit to change pickup or vehicle request</Text>
                </View>
                <TouchableOpacity onPress={() => setStep("details")} style={s.editPhotosBtn}>
                  <Ionicons name="pencil" size={14} color={colors.primary} />
                  <Text style={s.editPhotosBtnText}>Edit</Text>
                </TouchableOpacity>
              </View>

              <View style={s.photosHeader}>
                <Text style={s.photosTitle}>Your Photos</Text>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  {selectMode ? (
                    <TouchableOpacity onPress={() => { setSelectMode(false); setSelected(new Set()); }}>
                      <Text style={s.headerAction}>Cancel</Text>
                    </TouchableOpacity>
                  ) : (
                    <>
                      <TouchableOpacity onPress={() => setSelectMode(true)}>
                        <Text style={s.headerAction}>Select</Text>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={clearAllPhotos}>
                        <Text style={[s.headerAction, { color: colors.error }]}>Clear</Text>
                      </TouchableOpacity>
                    </>
                  )}
                  <View style={s.photoCountBadge}>
                    <Text style={s.photoCountText}>{photos.length}/{MAX_PHOTOS}</Text>
                  </View>
                </View>
              </View>

              <View style={s.photoGrid} onLayout={(e) => setGridWidth(e.nativeEvent.layout.width)}>
                {photos.map((photo, i) => (
                  <View key={i} style={{ width: photoSize }}>
                    <TouchableOpacity
                      style={[s.photoItem, { width: photoSize, height: photoSize }, selectMode && selected.has(i) && s.photoSelected]}
                      onPress={() => selectMode ? toggleSelect(i) : openLightbox(i)}
                      onLongPress={async () => {
                        const Haptics = await import("expo-haptics");
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                        if (!selectMode) { setSelectMode(true); setSelected(new Set([i])); }
                        else { toggleSelect(i); }
                      }}
                      delayLongPress={300}
                      activeOpacity={0.8}
                    >
                      <Image source={{ uri: photo.uri }} style={[s.photoImg, { width: photoSize, height: photoSize }]} />
                      {selectMode && (
                        <View style={[s.selectCircle, selected.has(i) && s.selectCircleActive]}>
                          {selected.has(i) && <Ionicons name="checkmark" size={14} color={colors.white} />}
                        </View>
                      )}
                      {!selectMode && (
                        <TouchableOpacity style={s.photoRemove} onPress={() => removePhoto(i)}>
                          <View style={s.photoRemoveBg}>
                            <Ionicons name="close" size={14} color={colors.white} />
                          </View>
                        </TouchableOpacity>
                      )}
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={s.recipientRow}
                      onPress={() => !selectMode && openTagModal(i)}
                      disabled={selectMode}
                      activeOpacity={0.7}
                    >
                      {photo.recipientPhone ? (
                        <Text style={s.recipientRowText}>{photo.recipientPhone}</Text>
                      ) : (
                        <>
                          <Ionicons name="alert-circle" size={12} color={colors.error} />
                          <Text style={s.recipientRowRequired}>Required</Text>
                        </>
                      )}
                    </TouchableOpacity>
                  </View>
                ))}

                {/* Add more button inline */}
                <TouchableOpacity style={[s.addMoreBtn, { width: photoSize, height: photoSize }]} onPress={takePhoto} activeOpacity={0.7}>
                  <Ionicons name="camera-outline" size={24} color={colors.primary} />
                  <Text style={s.addMoreText}>Add</Text>
                </TouchableOpacity>
              </View>

              <TouchableOpacity style={s.galleryLink} onPress={pickFromGallery}>
                <Ionicons name="images-outline" size={18} color={colors.primary} />
                <Text style={s.galleryLinkText}>Choose from gallery</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>

        {/* Footer */}
        {!keyboardVisible &&
          ((selectMode && selected.size > 0) ||
            step === "details" ||
            step === "review" ||
            (step === "photos" && photos.length > 0)) && (
          <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
            {selectMode && selected.size > 0 ? (
              <View style={s.selectActionRow}>
                <TouchableOpacity onPress={() => openTagModal()} style={s.tagRecipientBar}>
                  <Ionicons name="call" size={16} color={colors.white} />
                  <Text style={s.tagRecipientText}>Tag Recipient</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={removeSelected} style={s.removeSelectedBar}>
                  <Ionicons name="trash-outline" size={16} color={colors.white} />
                  <Text style={s.removeSelectedText}>Remove</Text>
                </TouchableOpacity>
              </View>
            ) : step === "details" ? (
              <Button
                title="Continue to Photos"
                onPress={handleDetailsContinue}
                disabled={!pickupTown.trim()}
                height={52}
                leftIcon={<Ionicons name="arrow-forward" size={18} color={colors.white} />}
              />
            ) : step === "photos" ? (
              <View style={{ gap: 8 }}>
                {!allTagged && (
                  <View style={s.continueHelper}>
                    <Ionicons name="alert-circle" size={14} color={colors.error} />
                    <Text style={s.continueHelperText}>
                      Tag {untaggedCount} more photo{untaggedCount !== 1 ? "s" : ""} with a recipient to continue
                    </Text>
                  </View>
                )}
                <Button
                  title="Review Request"
                  onPress={handlePhotosContinue}
                  disabled={!allTagged || selectMode}
                  height={52}
                  leftIcon={<Ionicons name="arrow-forward" size={18} color={colors.white} />}
                />
              </View>
            ) : (
              <Button
                title={loading ? "Submitting..." : "Submit Request"}
                onPress={handleSubmit}
                loading={loading}
                disabled={loading || !pickupTown.trim() || !Number.isInteger(Number(totalPackageQty)) || Number(totalPackageQty) < 1}
                height={52}
                leftIcon={!loading ? <Ionicons name="paper-plane" size={18} color={colors.white} style={{ transform: [{ rotate: "-12deg" }] }} /> : undefined}
              />
            )}
          </View>
        )}
      </View>


      {/* Lightbox - Swipeable */}
      <Modal visible={lightboxOpen} transparent animationType="fade" onRequestClose={closeLightbox}>
        <View style={s.lightbox}>
          <View style={s.lightboxTop}>
            <Text style={s.lightboxCounter}>{lightboxIndex + 1} / {photos.length}</Text>
            <View style={{ flexDirection: "row", gap: 16 }}>
              <TouchableOpacity onPress={() => removePhoto(lightboxIndex)} style={s.lightboxAction}>
                <Ionicons name="trash-outline" size={20} color="#fca5a5" />
              </TouchableOpacity>
              <TouchableOpacity onPress={closeLightbox} style={s.lightboxAction}>
                <Ionicons name="close" size={24} color={colors.white} />
              </TouchableOpacity>
            </View>
          </View>
          <FlatList
            ref={lightboxRef}
            data={photos}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            initialScrollIndex={lightboxIndex}
            getItemLayout={(_, index) => ({ length: SCREEN_WIDTH, offset: SCREEN_WIDTH * index, index })}
            onMomentumScrollEnd={(e) => {
              if (!lightboxOpen) return;
              const idx = Math.round(e.nativeEvent.contentOffset.x / SCREEN_WIDTH);
              setLightboxIndex(idx);
            }}
            keyExtractor={(_, i) => String(i)}
            renderItem={({ item: photo }) => (
              <View style={{ width: SCREEN_WIDTH, justifyContent: "center", alignItems: "center" }}>
                <Image source={{ uri: photo.uri }} style={s.lightboxImage} resizeMode="contain" />
              </View>
            )}
          />
          {photos[lightboxIndex]?.recipientPhone ? (
            <View style={s.lightboxPhonePill}>
              <Ionicons name="call" size={12} color={colors.white} />
              <Text style={s.lightboxPhonePillText}>{photos[lightboxIndex].recipientPhone}</Text>
            </View>
          ) : null}
        </View>
      </Modal>

      {/* Tag recipient phone modal */}
      <Modal visible={tagModalOpen} transparent animationType="fade" onRequestClose={cancelTag}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 12 : 0}
          style={s.tagModalAvoider}
        >
        <Pressable style={s.tagModalOverlay} onPress={cancelTag}>
          <Pressable style={s.tagModalCard} onPress={(e) => e.stopPropagation()}>
            {(() => {
              const activeIndices = tagTargetIndices ?? Array.from(selected);
              const isSingle = activeIndices.length === 1;
              const existingPhone = isSingle ? photos[activeIndices[0]]?.recipientPhone : null;
              const isEditingExisting = isSingle && !!existingPhone;

              const title = isEditingExisting
                ? "Edit Recipient Phone"
                : isSingle
                ? "Add Recipient Phone"
                : `Same recipient for ${activeIndices.length} photos?`;

              const subtitle = isSingle
                ? "Every package needs a recipient phone so we know who it's going to."
                : "Every photo needs a recipient. The same phone will apply to all selected — you can change any one later.";

              const cancelLabel = "Cancel";
              const phoneDigits = sanitizeLocalPhoneInput(tagPhoneInput);
              const phoneHelper = phoneDigits.length === 0
                ? ""
                : phoneDigits.length < 10
                  ? `${phoneDigits.length}/10 digits entered`
                  : !isValidGhanaPhone(phoneDigits)
                    ? "Enter a valid Ghana phone number, e.g. 0551234567"
                    : "";

              const applyLabel = isEditingExisting
                ? "Update"
                : isSingle
                ? "Add"
                : `Apply to ${activeIndices.length}`;

              return (
                <>
                  {isEditingExisting && (
                    <TouchableOpacity
                      onPress={cancelTag}
                      style={s.tagModalCloseX}
                      hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                    >
                      <Ionicons name="close" size={18} color={colors.textMuted} />
                    </TouchableOpacity>
                  )}
                  <View style={s.tagModalHeader}>
                    <View style={s.tagModalIconWrap}>
                      <Ionicons name="call" size={20} color={colors.white} />
                    </View>
                    <Text style={s.tagModalTitle}>{title}</Text>
                    <Text style={s.tagModalSub}>{subtitle}</Text>
                  </View>
                  <Input
                    label="Recipient Phone"
                    placeholder="e.g. 0551234567"
                    value={tagPhoneInput}
                    onChangeText={(text) => {
                      const next = sanitizeLocalPhoneInput(text);
                      setTagPhoneInput(next);
                      setTagPhoneError(next.length === 10 && !isValidGhanaPhone(next) ? "Enter a valid 10-digit Ghana phone number" : "");
                    }}
                    keyboardType="phone-pad"
                    maxLength={10}
                    autoFocus
                    error={tagPhoneError}
                    leftIcon={<Ionicons name="call-outline" size={18} color={colors.textMuted} />}
                  />
                  {!!phoneHelper && !tagPhoneError && (
                    <View style={s.phoneHelperRow}>
                      <Ionicons name="information-circle-outline" size={14} color={colors.textMuted} />
                      <Text style={s.phoneHelperText}>{phoneHelper}</Text>
                    </View>
                  )}
                  <View style={s.tagModalBtnRow}>
                    {!isEditingExisting && (
                      <TouchableOpacity onPress={cancelTag} style={s.tagModalCancel}>
                        <Text style={s.tagModalCancelText}>{cancelLabel}</Text>
                      </TouchableOpacity>
                    )}
                    <TouchableOpacity
                      onPress={() => applyTag()}
                      style={[s.tagModalApply, !isValidGhanaPhone(tagPhoneInput) && s.tagModalApplyDisabled]}
                      disabled={!isValidGhanaPhone(tagPhoneInput)}
                    >
                      <Text style={s.tagModalApplyText}>{applyLabel}</Text>
                    </TouchableOpacity>
                  </View>
                </>
              );
            })()}
          </Pressable>
        </Pressable>
        </KeyboardAvoidingView>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  main: { flex: 1 },
  scroll: { flex: 1 },
  // Header
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 16, gap: 4 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 20, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 },
  // Empty state
  emptyStateShell: { paddingHorizontal: 16, paddingVertical: 16, justifyContent: "center" },
  emptyState: { alignItems: "center", justifyContent: "center", paddingHorizontal: 24, gap: 12 },
  emptyIconWrap: { width: 100, height: 100, borderRadius: 50, backgroundColor: colors.warmSurface, justifyContent: "center", alignItems: "center", marginBottom: 8 },
  emptyTitle: { fontFamily: fontFamily.bold, fontSize: 20, color: colors.dark, textAlign: "center" },
  emptySub: { fontFamily: fontFamily.regular, fontSize: 14, color: colors.textMuted, textAlign: "center", lineHeight: 22 },
  bigCameraBtn: { width: "100%", marginTop: 12 },
  bigCameraBtnInner: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, paddingVertical: 16, borderRadius: 24 },
  bigCameraBtnText: { fontFamily: fontFamily.bold, fontSize: 16, color: colors.white },
  galleryLink: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, marginTop: 8 },
  galleryLinkText: { fontFamily: fontFamily.medium, fontSize: 14, color: colors.primary },
  // Photo summary (details step)
  photoSummary: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.white, borderRadius: 14, padding: 14, borderLeftWidth: 4, borderLeftColor: colors.success },
  photoSummaryIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.success, justifyContent: "center", alignItems: "center" },
  photoSummaryTitle: { fontFamily: fontFamily.semibold, fontSize: 15, color: colors.dark },
  photoSummaryText: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted },
  editPhotosBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, borderWidth: 1, borderColor: colors.accentLighter },
  editPhotosBtnText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.primary },
  optionalTag: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.textMuted, backgroundColor: colors.surface, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  // Cards
  card: { backgroundColor: colors.white, borderRadius: 16, padding: 16, gap: 14 },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  cardIconWrap: { width: 34, height: 34, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  cardTitleBlock: { flex: 1, gap: 3 },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  cardSubtext: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, lineHeight: 16 },
  requiredMark: { color: colors.error },
  locationCombo: {},
  locationInputWrap: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.warmSurface,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
    borderBottomWidth: 2,
    borderBottomColor: colors.primary,
  },
  locationInputWrapOpen: {
    borderBottomWidth: 0,
  },
  locationInputIcon: { marginLeft: 12 },
  locationInputText: {
    flex: 1,
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.dark,
    paddingVertical: 14,
    paddingLeft: 14,
    paddingRight: 12,
  },
  locationInputLoader: { marginRight: 12 },
  locationResults: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderTopWidth: 0,
    borderBottomLeftRadius: 14,
    borderBottomRightRadius: 14,
    shadowColor: colors.dark,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 6,
    overflow: "hidden",
  },
  locationResultItem: { paddingHorizontal: 14, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: colors.neutral100 },
  locationResultText: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.text, lineHeight: 18 },
  // Review
  reviewHeaderCard: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.dark, borderRadius: 16, padding: 16 },
  reviewHeaderIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.success, justifyContent: "center", alignItems: "center" },
  reviewHeaderTitle: { fontFamily: fontFamily.bold, fontSize: 17, color: colors.white },
  reviewHeaderText: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.72)", marginTop: 2 },
  reviewSectionHeader: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 12 },
  reviewEditBtn: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, backgroundColor: colors.warmSurface, borderWidth: 1, borderColor: colors.accentLighter },
  reviewEditText: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.primary },
  reviewRows: { gap: 10 },
  reviewRow: { flexDirection: "row", alignItems: "flex-start", gap: 10, paddingTop: 2 },
  reviewLabel: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.textMuted, textTransform: "uppercase", letterSpacing: 0.3 },
  reviewValue: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.dark, marginTop: 2, lineHeight: 19 },
  // Photos grid
  body: { padding: 16, gap: 12 },
  photosHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  photosTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.dark },
  photoCountBadge: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.warmSurface, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10, borderWidth: 1, borderColor: colors.accentLighter },
  photoCountText: { fontFamily: fontFamily.semibold, fontSize: 12, color: colors.primary },
  photoGrid: { flexDirection: "row", flexWrap: "wrap", gap: PHOTO_GAP, justifyContent: "flex-start" },
  photoItem: { position: "relative", borderRadius: 12, overflow: "hidden", borderWidth: 2, borderColor: "transparent" },
  photoImg: { borderRadius: 12 },
  photoRemove: { position: "absolute", top: 4, right: 4 },
  photoRemoveBg: { width: 22, height: 22, borderRadius: 11, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "center", alignItems: "center" },
  addMoreBtn: { borderRadius: 12, borderWidth: 2, borderColor: colors.border, borderStyle: "dashed", justifyContent: "center", alignItems: "center", backgroundColor: colors.surface, gap: 4 },
  addMoreText: { fontFamily: fontFamily.medium, fontSize: 11, color: colors.primary },
  galleryRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 10, backgroundColor: colors.white, borderRadius: 12, borderWidth: 1, borderColor: colors.border },
  galleryRowText: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.primary },
  // Footer
  footer: {
    paddingHorizontal: 16,
    paddingTop: 12,
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    shadowColor: colors.dark,
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 12,
  },
  // Modal
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  modalSheet: { backgroundColor: colors.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingBottom: 34, paddingTop: 12, maxHeight: "85%" },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: colors.neutral300, alignSelf: "center", marginBottom: 4 },
  sheetHeader: { alignItems: "center", gap: 4, marginBottom: 4 },
  sheetIconWrap: { width: 48, height: 48, borderRadius: 24, backgroundColor: colors.success, justifyContent: "center", alignItems: "center", marginBottom: 4 },
  sheetTitle: { fontFamily: fontFamily.bold, fontSize: 20, color: colors.dark },
  sheetSub: { fontFamily: fontFamily.regular, fontSize: 13, color: colors.textMuted },
  goBackBtn: { alignItems: "center", paddingVertical: 8 },
  goBackText: { fontFamily: fontFamily.medium, fontSize: 14, color: colors.textMuted },
  // Header actions
  headerAction: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.primary },
  selectActionRow: { flexDirection: "row", gap: 10 },
  tagRecipientBar: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: colors.primary, paddingVertical: 16, borderRadius: 24 },
  tagRecipientText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  removeSelectedBar: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: colors.error, paddingVertical: 16, borderRadius: 24 },
  removeSelectedText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  // Recipient row under each photo tile
  recipientRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, paddingTop: 2, paddingBottom: 4, flexWrap: "wrap" },
  recipientRowText: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.primary, textAlign: "center" },
  recipientRowMuted: { fontFamily: fontFamily.regular, fontSize: 11, color: colors.textMuted, textAlign: "center" },
  recipientRowRequired: { fontFamily: fontFamily.semibold, fontSize: 11, color: colors.error, textAlign: "center" },
  continueHelper: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 4 },
  continueHelperText: { fontFamily: fontFamily.medium, fontSize: 12, color: colors.error },
  phoneHelperRow: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: -8 },
  phoneHelperText: { flex: 1, fontFamily: fontFamily.medium, fontSize: 11, color: colors.textMuted },
  // Tag recipient modal
  tagModalAvoider: { flex: 1 },
  tagModalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "center", alignItems: "center", paddingHorizontal: 24 },
  tagModalCard: { width: "100%", backgroundColor: colors.white, borderRadius: 20, padding: 20, gap: 14 },
  tagModalHeader: { alignItems: "center", gap: 6 },
  tagModalIconWrap: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.primary, justifyContent: "center", alignItems: "center", marginBottom: 4 },
  tagModalTitle: { fontFamily: fontFamily.bold, fontSize: 17, color: colors.dark, textAlign: "center" },
  tagModalSub: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, textAlign: "center" },
  tagModalBtnRow: { flexDirection: "row", gap: 10, marginTop: 6 },
  tagModalCancel: { flex: 1, paddingVertical: 12, borderRadius: 24, alignItems: "center", justifyContent: "center", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  tagModalCancelText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.textMuted },
  tagModalClear: { flex: 1, paddingVertical: 12, borderRadius: 24, alignItems: "center", justifyContent: "center", backgroundColor: "#fee2e2", borderWidth: 1, borderColor: "#fca5a5" },
  tagModalClearText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.error },
  tagModalApply: { flex: 1, paddingVertical: 12, borderRadius: 24, alignItems: "center", justifyContent: "center", backgroundColor: colors.primary },
  tagModalApplyDisabled: { opacity: 0.4 },
  tagModalApplyText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
  tagModalCloseX: { position: "absolute", top: 12, right: 12, width: 32, height: 32, borderRadius: 16, backgroundColor: colors.surface, justifyContent: "center", alignItems: "center", zIndex: 2 },
  // Lightbox phone pill
  lightboxPhonePill: { position: "absolute", bottom: 80, alignSelf: "center", flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: "rgba(234,88,12,0.95)" },
  lightboxPhonePillText: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.white },
  // Select mode
  photoSelected: { opacity: 0.7, borderWidth: 2, borderColor: colors.primary },
  selectCircle: { position: "absolute", top: 6, left: 6, width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: colors.white, backgroundColor: "rgba(0,0,0,0.3)", justifyContent: "center", alignItems: "center" },
  selectCircleActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  // Lightbox
  lightbox: { flex: 1, backgroundColor: "rgba(0,0,0,0.95)", justifyContent: "center" },
  lightboxTop: { position: "absolute", top: 50, left: 20, right: 20, flexDirection: "row", justifyContent: "space-between", alignItems: "center", zIndex: 10 },
  lightboxCounter: { fontFamily: fontFamily.medium, fontSize: 14, color: "rgba(255,255,255,0.7)" },
  lightboxAction: { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.15)", justifyContent: "center", alignItems: "center" },
  lightboxImage: { width: "100%", height: "65%" },
  lightboxNav: { position: "absolute", bottom: 60, left: 0, right: 0, flexDirection: "row", justifyContent: "center", gap: 40 },
  lightboxNavBtn: { width: 50, height: 50, borderRadius: 25, backgroundColor: "rgba(255,255,255,0.15)", justifyContent: "center", alignItems: "center" },
});
