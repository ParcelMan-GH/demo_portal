import { useCallback, useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  RefreshControl,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { router, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import EmptyState from "../../src/components/common/EmptyState";
import ShimmerLoading from "../../src/components/common/ShimmerLoading";
import { colors } from "../../src/constants/colors";
import { fontFamily } from "../../src/constants/typography";
import { formatCurrency } from "../../src/utils/format";
import { getEarningsSummary, getEarnings, getPayouts } from "../../src/api/v1/vendor/earnings";
import type {
  EarningsSummary,
  VendorEarning,
  VendorPayout,
} from "../../src/types/vendor";
import { showError, getErrorMessage } from "../../src/utils/toast";

const { width } = Dimensions.get("window");

type Tab = "earnings" | "payouts";

export default function EarningsScreen() {
  const insets = useSafeAreaInsets();
  const accountRoute = "/(vendor)/(tabs)/account" as const;
  const leaveEarnings = () => {
    if (router.canGoBack()) router.back();
    else router.replace(accountRoute as any);
  };

  const [tab, setTab] = useState<Tab>("earnings");
  const [summary, setSummary] = useState<EarningsSummary | null>(null);
  const [earnings, setEarnings] = useState<VendorEarning[]>([]);
  const [payouts, setPayouts] = useState<VendorPayout[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const currency = summary?.currency || "GHS";

  const fetchAll = useCallback(async () => {
    try {
      const [summaryRes, earningsRes, payoutsRes] = await Promise.all([
        getEarningsSummary(),
        getEarnings({ limit: 50 }),
        getPayouts({ limit: 50 }),
      ]);
      const sd = (summaryRes.data as any)?.summary || summaryRes.data;
      setSummary(sd as EarningsSummary);
      const ed = (earningsRes.data as any) || {};
      setEarnings(ed.earnings || ed.items || ed.data || []);
      const pd = (payoutsRes.data as any) || {};
      setPayouts(pd.payouts || pd.items || pd.data || []);
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  useFocusEffect(
    useCallback(() => {
      fetchAll();
    }, [fetchAll])
  );

  const onRefresh = () => {
    setRefreshing(true);
    fetchAll();
  };

  return (
    <View style={s.container}>
      <LinearGradient
        colors={["#1e293b", "#334155", "#1e293b"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[s.header, { paddingTop: insets.top + 12 }]}
      >
        <View style={s.heroDecor1} />
        <View style={s.heroDecor2} />

        <View style={s.headerRow}>
          <TouchableOpacity onPress={leaveEarnings} style={s.backBtn}>
            <Ionicons name="arrow-back" size={20} color={colors.white} />
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={s.headerTitle}>Earnings</Text>
            <Text style={s.headerSub}>
              Track parcel earnings, payout progress, and money awaiting settlement.
            </Text>
          </View>
        </View>

        <View style={s.heroStatsGrid}>
          <HeroStatCard
            icon="wallet-outline"
            iconBg="rgba(96,165,250,0.18)"
            iconColor="#93c5fd"
            label="Awaiting Payout"
            value={loading && !summary ? "—" : formatCurrency(summary?.available_balance || 0, currency)}
          />
          <HeroStatCard
            icon="trending-up"
            iconBg="rgba(251,146,60,0.18)"
            iconColor="#fdba74"
            label="Lifetime earnings"
            value={formatCurrency(summary?.total_earned || 0, currency)}
          />
          <HeroStatCard
            icon="checkmark-circle"
            iconBg="rgba(34,197,94,0.18)"
            iconColor="#86efac"
            label="Paid out"
            value={formatCurrency(summary?.total_paid || 0, currency)}
          />
        </View>
      </LinearGradient>

      {!loading && !summary?.payout_account?.is_set ? (
        <TouchableOpacity
          style={s.payoutNotice}
          onPress={() =>
            router.push({
              pathname: "/(vendor)/profile/payout-account",
              params: { returnTo: "earnings" },
            } as any)
          }
          activeOpacity={0.78}
        >
          <View style={s.payoutNoticeIcon}>
            <Ionicons name="card-outline" size={18} color={colors.primary} />
          </View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={s.payoutNoticeTitle}>Set payout account</Text>
            <Text style={s.payoutNoticeText}>Add your MoMo account so commission payouts go to the right number.</Text>
          </View>
          <Ionicons name="chevron-forward" size={18} color={colors.textMuted} />
        </TouchableOpacity>
      ) : null}

      {/* Tabs */}
      <View style={s.tabRow}>
        <TabButton
          label="Earnings"
          active={tab === "earnings"}
          count={earnings.length}
          onPress={() => setTab("earnings")}
        />
        <TabButton
          label="Payouts"
          active={tab === "payouts"}
          count={payouts.length}
          onPress={() => setTab("payouts")}
        />
      </View>

      {/* Body */}
      <View style={s.body}>
        {loading ? (
          <EarningsListSkeleton />
        ) : tab === "earnings" ? (
          <FlatList
            data={earnings}
            keyExtractor={(item) => String(item.id)}
            renderItem={({ item }) => (
              <EarningRow
                earning={item}
                currency={currency}
              />
            )}
            contentContainerStyle={s.list}
            ItemSeparatorComponent={null}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} />
            }
            ListEmptyComponent={
              <EmptyState
                icon="trending-up-outline"
                title="No earnings yet"
                subtitle="You'll see earnings here once your delivered parcels are processed."
              />
            }
          />
        ) : (
          <FlatList
            data={payouts}
            keyExtractor={(item) => String(item.id)}
            renderItem={({ item }) => (
              <PayoutRow
                payout={item}
                currency={currency}
              />
            )}
            contentContainerStyle={s.list}
            ItemSeparatorComponent={null}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} />
            }
            ListEmptyComponent={
              <EmptyState
                icon="wallet-outline"
                title="No payouts yet"
                subtitle="Your payout history will appear here once we process payments."
              />
            }
          />
        )}
      </View>
    </View>
  );
}

function HeroStatCard({
  icon,
  iconBg,
  iconColor,
  label,
  value,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  iconBg: string;
  iconColor: string;
  label: string;
  value: string;
}) {
  return (
    <View style={s.heroStatCard}>
      <View style={[s.heroStatIcon, { backgroundColor: iconBg }]}>
        <Ionicons name={icon} size={18} color={iconColor} />
      </View>
      <Text style={s.statValue} numberOfLines={1} adjustsFontSizeToFit>
        {value}
      </Text>
      <Text style={s.statLabel} numberOfLines={1}>{label}</Text>
    </View>
  );
}

function TabButton({
  label,
  active,
  count,
  onPress,
}: {
  label: string;
  active: boolean;
  count: number;
  onPress: () => void;
}) {
  return (
    <TouchableOpacity style={[s.tabBtn, active && s.tabBtnActive]} onPress={onPress} activeOpacity={0.7}>
      <Text style={[s.tabBtnText, active && s.tabBtnTextActive]}>{label}</Text>
      <View style={[s.tabBadge, active && s.tabBadgeActive]}>
        <Text style={[s.tabBadgeText, active && s.tabBadgeTextActive]}>{count}</Text>
      </View>
      {active ? <View style={s.tabActiveLine} /> : null}
    </TouchableOpacity>
  );
}

function earningStatusChip(status: VendorEarning["status"]) {
  switch (status) {
    case "paid":
      return { bg: "#dcfce7", fg: colors.success, label: "Paid" };
    case "approved":
    default:
      return { bg: "#fef3c7", fg: "#d97706", label: "Approved" };
  }
}

function payoutStatusChip(status: VendorPayout["status"]) {
  switch (status) {
    case "confirmed":
      return { bg: "#dcfce7", fg: colors.success, label: "Confirmed" };
    case "sent":
      return { bg: "#dbeafe", fg: "#3b82f6", label: "Sent" };
    case "pending":
    default:
      return { bg: "#fef3c7", fg: "#d97706", label: "Pending" };
  }
}

function methodLabel(method: VendorPayout["payment_method"]): string {
  switch (method) {
    case "momo":
      return "Mobile Money";
    case "bank":
      return "Bank Transfer";
    case "cash":
      return "Cash";
    default:
      return method;
  }
}

function methodIcon(method: VendorPayout["payment_method"]): keyof typeof Ionicons.glyphMap {
  switch (method) {
    case "momo":
      return "arrow-down-circle-outline";
    case "bank":
      return "card-outline";
    case "cash":
      return "cash-outline";
    default:
      return "arrow-down-circle-outline";
  }
}

function formatEarningsDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function EarningsListSkeleton() {
  return (
    <View style={s.skeletonList}>
      {[0, 1, 2, 3, 4].map((item) => (
        <View key={item} style={s.row}>
          <ShimmerLoading width={24} height={24} borderRadius={12} />
          <View style={{ flex: 1, gap: 7 }}>
            <ShimmerLoading width={item % 2 === 0 ? "58%" : "46%"} height={14} borderRadius={7} />
            <ShimmerLoading width={item % 2 === 0 ? "76%" : "64%"} height={11} borderRadius={6} />
          </View>
          <View style={s.skeletonRight}>
            <ShimmerLoading width={74} height={14} borderRadius={7} />
            <ShimmerLoading width={38} height={10} borderRadius={5} />
          </View>
        </View>
      ))}
    </View>
  );
}

function EarningRow({
  earning,
  currency,
}: {
  earning: VendorEarning;
  currency: string;
}) {
  const chip = earningStatusChip(earning.status);
  return (
    <View style={s.row}>
      <View style={s.rowIconWrap}>
        <Ionicons name="wallet-outline" size={18} color={colors.text} />
      </View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.rowTitle} numberOfLines={1}>
          {earning.shipment_number || `Earning #${earning.id}`}
        </Text>
        <Text style={s.rowSub} numberOfLines={1}>
          {formatEarningsDate(earning.created_at)}
        </Text>
      </View>
      <View style={s.rowRight}>
        <Text style={s.rowAmount}>{formatCurrency(earning.amount, currency)}</Text>
        <Text style={[s.rowStatus, { color: chip.fg }]}>{chip.label}</Text>
      </View>
    </View>
  );
}

function PayoutRow({
  payout,
  currency,
}: {
  payout: VendorPayout;
  currency: string;
}) {
  const chip = payoutStatusChip(payout.status);
  return (
    <View style={s.row}>
      <View style={s.rowIconWrap}>
        <Ionicons name={methodIcon(payout.payment_method)} size={18} color={colors.text} />
      </View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.rowTitle} numberOfLines={1}>
          Payout to {methodLabel(payout.payment_method)}
        </Text>
        <Text style={s.rowSub} numberOfLines={1}>
          {formatEarningsDate(payout.created_at)}
          {payout.payment_phone ? ` · ${payout.payment_phone}` : payout.payment_reference ? ` · Ref ${payout.payment_reference}` : ""}
        </Text>
      </View>
      <View style={s.rowRight}>
        <Text style={s.rowAmount}>{formatCurrency(payout.amount, currency)}</Text>
        <Text style={[s.rowStatus, { color: chip.fg }]}>{chip.label}</Text>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  // Header
  header: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 20, gap: 16, overflow: "hidden" },
  heroDecor1: {
    position: "absolute",
    top: -50,
    right: -30,
    width: width * 0.5,
    height: width * 0.5,
    borderWidth: 50,
    borderColor: "rgba(255,255,255,0.03)",
    borderRadius: width * 0.25,
    transform: [{ rotate: "20deg" }],
  },
  heroDecor2: {
    position: "absolute",
    bottom: -60,
    left: -40,
    width: width * 0.4,
    height: width * 0.4,
    borderWidth: 40,
    borderColor: "rgba(255,255,255,0.02)",
    borderRadius: width * 0.2,
  },
  headerRow: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  backBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
  },
  headerTitle: { fontFamily: fontFamily.bold, fontSize: 18, color: colors.white },
  headerSub: {
    fontFamily: fontFamily.regular,
    fontSize: 12,
    lineHeight: 18,
    color: "rgba(255,255,255,0.62)",
    marginTop: 3,
  },
  heroStatsGrid: { flexDirection: "row", gap: 8, marginTop: 4 },
  heroStatCard: {
    flex: 1,
    minHeight: 92,
    borderRadius: 12,
    paddingHorizontal: 6,
    paddingVertical: 9,
    backgroundColor: "rgba(255,255,255,0.07)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.09)",
    alignItems: "center",
    justifyContent: "center",
    gap: 3,
  },
  heroStatIcon: {
    width: 28,
    height: 28,
    borderRadius: 9,
    justifyContent: "center",
    alignItems: "center",
  },
  statValue: { width: "100%", fontFamily: fontFamily.extrabold, fontSize: 20, color: colors.white, lineHeight: 24, textAlign: "center" },
  statLabel: { fontFamily: fontFamily.bold, fontSize: 9, color: "rgba(255,255,255,0.82)", textAlign: "center" },
  payoutNotice: {
    marginHorizontal: 16,
    marginTop: 12,
    marginBottom: 6,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.accentLighter,
    backgroundColor: colors.white,
    padding: 14,
  },
  payoutNoticeIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.warmSurface, alignItems: "center", justifyContent: "center" },
  payoutNoticeTitle: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  payoutNoticeText: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted, lineHeight: 17 },
  // Tabs
  tabRow: {
    flexDirection: "row",
    gap: 4,
    paddingHorizontal: 4,
    paddingVertical: 4,
    marginHorizontal: 16,
    marginTop: 2,
    borderRadius: 14,
    backgroundColor: colors.neutral100,
    borderWidth: 1,
    borderColor: colors.border,
  },
  tabBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    minHeight: 40,
    borderRadius: 11,
    position: "relative",
  },
  tabBtnActive: {
    backgroundColor: colors.white,
    shadowColor: colors.black,
    shadowOpacity: 0.05,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
    elevation: 1,
  },
  tabBtnText: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.textMuted },
  tabBtnTextActive: { color: colors.primary },
  tabBadge: {
    minWidth: 20,
    height: 18,
    paddingHorizontal: 5,
    borderRadius: 9,
    backgroundColor: colors.white,
    justifyContent: "center",
    alignItems: "center",
  },
  tabBadgeActive: { backgroundColor: colors.warmSurface },
  tabBadgeText: { fontFamily: fontFamily.semibold, fontSize: 10, color: colors.textMuted },
  tabBadgeTextActive: { color: colors.primary },
  tabActiveLine: { position: "absolute", left: "35%", right: "35%", bottom: 5, height: 2, borderRadius: 1, backgroundColor: colors.primary },
  // Body / list
  body: { flex: 1 },
  list: { flexGrow: 1, paddingHorizontal: 16, paddingTop: 8, paddingBottom: 40 },
  row: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral200,
  },
  rowIconWrap: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: "transparent",
    justifyContent: "center",
    alignItems: "center",
  },
  rowTitle: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.dark, lineHeight: 19 },
  rowSub: { fontFamily: fontFamily.regular, fontSize: 12, color: colors.textMuted, marginTop: 2, lineHeight: 17 },
  rowRight: { alignItems: "flex-end", gap: 3, paddingTop: 1, maxWidth: 112 },
  rowAmount: { fontFamily: fontFamily.bold, fontSize: 14, color: colors.dark },
  rowStatus: { fontFamily: fontFamily.semibold, fontSize: 10, letterSpacing: 0.3 },
  skeletonList: { flexGrow: 1, paddingHorizontal: 16, paddingTop: 8, paddingBottom: 40 },
  skeletonRight: { alignItems: "flex-end", gap: 7, paddingTop: 1 },
});
