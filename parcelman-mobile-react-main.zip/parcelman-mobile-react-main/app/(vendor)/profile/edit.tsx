import { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import Input from "../../../src/components/common/Input";
import Button from "../../../src/components/common/Button";
import { colors } from "../../../src/constants/colors";
import { fontFamily, fontSize } from "../../../src/constants/typography";
import { useAuthStore } from "../../../src/stores/auth.store";
import { updateProfile } from "../../../src/api/v1/vendor/profile";
import { showSuccess, showError, getErrorMessage } from "../../../src/utils/toast";

const { width } = Dimensions.get("window");

export default function EditProfileScreen() {
  const insets = useSafeAreaInsets();
  const accountRoute = "/(vendor)/(tabs)/account" as const;
  const user = useAuthStore((s) => s.user) as any;
  const setUser = useAuthStore((s) => s.setUser);

  const [name, setName] = useState(user?.name || "");
  const [businessName, setBusinessName] = useState(user?.business_name || "");
  const [email, setEmail] = useState(user?.email || "");
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const leaveEditProfile = () => {
    if (router.canGoBack()) router.back();
    else router.replace(accountRoute as any);
  };

  const handleSave = async () => {
    setLoading(true);
    setErrors({});
    try {
      const res = await updateProfile({
        name: name.trim(),
        business_name: businessName.trim() || undefined,
        email: email.trim() || undefined,
      });
      setUser((res.data as any)?.user || (res.data as any)?.vendor || res.data);
      showSuccess("Profile updated!");
      router.replace(accountRoute as any);
    } catch (err: any) {
      if (err?.errors) {
        const fieldErrors: Record<string, string> = {};
        for (const [key, messages] of Object.entries(err.errors)) {
          fieldErrors[key] = (messages as string[])[0];
        }
        setErrors(fieldErrors);
      }
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={s.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={0}
    >
      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + 20, flexGrow: 1, backgroundColor: colors.background }}
        automaticallyAdjustKeyboardInsets={Platform.OS === "ios"}
        keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Hero Header — extends behind the translucent status bar */}
        <LinearGradient
          colors={["#1e293b", "#334155", "#1e293b"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[s.hero, { paddingTop: insets.top + 12 }]}
        >
          <View style={s.heroDecor1} />
          <View style={s.heroDecor2} />

          <View style={s.headerRow}>
            <TouchableOpacity onPress={leaveEditProfile} style={s.backBtn}>
              <Ionicons name="arrow-back" size={22} color={colors.white} />
            </TouchableOpacity>
            <View style={s.headerCopy}>
              <Text style={s.headerTitle}>Edit Profile</Text>
              <Text style={s.headerSub}>Update your personal and business details</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Form */}
        <View style={s.body}>
          <View style={s.card}>
            <View style={s.cardHeader}>
              <View style={s.cardIconWrap}>
                <Ionicons name="person" size={16} color={colors.white} />
              </View>
              <Text style={s.cardTitle}>PERSONAL INFORMATION</Text>
            </View>

            <Input
              label="Full Name"
              required
              value={name}
              onChangeText={setName}
              error={errors.name}
              autoCapitalize="words"
              leftIcon={<Ionicons name="person-outline" size={18} color={colors.textMuted} />}
            />
            <Input
              label="Business Name"
              value={businessName}
              onChangeText={setBusinessName}
              error={errors.business_name}
              autoCapitalize="words"
              leftIcon={<Ionicons name="business-outline" size={18} color={colors.textMuted} />}
            />
            <Input
              label="Email Address"
              value={email}
              onChangeText={setEmail}
              error={errors.email}
              keyboardType="email-address"
              autoCapitalize="none"
              leftIcon={<Ionicons name="mail-outline" size={18} color={colors.textMuted} />}
            />
          </View>
        </View>
      </ScrollView>

      {/* Save Button */}
      <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
        <Button
          title="Save Changes"
          onPress={handleSave}
          loading={loading}
          disabled={!name.trim()}
          height={50}
          leftIcon={<Ionicons name="checkmark" size={18} color={colors.white} />}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  // Hero
  hero: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 24, gap: 16, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  heroDecor2: { position: "absolute", bottom: -60, left: -40, width: width * 0.4, height: width * 0.4, borderWidth: 40, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.2 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerCopy: { flex: 1, minWidth: 0 },
  headerTitle: { fontFamily: fontFamily.semibold, fontSize: 18, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.55)", marginTop: 2 },
  // Body
  body: { padding: 16 },
  card: { backgroundColor: colors.white, borderRadius: 16, padding: 16, gap: 16 },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 4 },
  cardIconWrap: { width: 30, height: 30, borderRadius: 8, backgroundColor: colors.dark, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.dark, letterSpacing: 0.5 },
  // Footer
  footer: { paddingHorizontal: 16, paddingTop: 12, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.border },
});
