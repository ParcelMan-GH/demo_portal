import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import Input from "../../../src/components/common/Input";
import Button from "../../../src/components/common/Button";
import { colors } from "../../../src/constants/colors";
import { fontFamily } from "../../../src/constants/typography";
import { getPayoutAccount, updatePayoutAccount } from "../../../src/api/v1/vendor/profile";
import { useAuthStore } from "../../../src/stores/auth.store";
import { getErrorMessage, showError, showSuccess } from "../../../src/utils/toast";
import { isValidGhanaPhone, sanitizeLocalPhoneInput, toApiPhone, toLocalPhone } from "../../../src/utils/format";
import type { PayoutMomoNetwork, VendorPayoutAccount } from "../../../src/types/vendor";

const { width } = Dimensions.get("window");

const NETWORKS: Array<{ value: PayoutMomoNetwork; label: string }> = [
  { value: "mtn", label: "MTN MoMo" },
  { value: "telecel", label: "Telecel Cash" },
  { value: "airteltigo", label: "AirtelTigo Money" },
];

export default function PayoutAccountScreen() {
  const insets = useSafeAreaInsets();
  const { returnTo } = useLocalSearchParams<{ returnTo?: string }>();
  const fallbackRoute = returnTo === "earnings" ? "/(vendor)/earnings" : "/(vendor)/(tabs)/account";
  const setUser = useAuthStore((s) => s.setUser);
  const [network, setNetwork] = useState<PayoutMomoNetwork>("mtn");
  const [accountName, setAccountName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [phoneError, setPhoneError] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const leavePayoutAccount = () => {
    if (router.canGoBack()) router.back();
    else router.replace(fallbackRoute as any);
  };

  const loadAccount = useCallback(async () => {
    try {
      const res = await getPayoutAccount();
      const account = ((res.data as any)?.payout_account || {}) as VendorPayoutAccount;
      if (account.network) setNetwork(account.network);
      setAccountName(account.account_name || "");
      setAccountNumber(sanitizeLocalPhoneInput(toLocalPhone(account.account_number)));
    } catch (err: any) {
      showError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAccount();
  }, [loadAccount]);

  const phoneDigits = sanitizeLocalPhoneInput(accountNumber);
  const phoneHelper = phoneDigits.length === 0
    ? ""
    : phoneDigits.length < 10
      ? `${phoneDigits.length}/10 digits entered`
      : !isValidGhanaPhone(phoneDigits)
        ? "Enter a valid Ghana phone number, e.g. 0551234567"
        : "";
  const canSave = accountName.trim().length > 0 && isValidGhanaPhone(phoneDigits) && !saving;

  const handleSave = async () => {
    const cleanPhone = sanitizeLocalPhoneInput(accountNumber);
    if (!isValidGhanaPhone(cleanPhone)) {
      setPhoneError("Enter a valid 10-digit Ghana phone number");
      return;
    }

    setSaving(true);
    try {
      const res = await updatePayoutAccount({
        payout_momo_network: network,
        payout_account_name: accountName.trim(),
        payout_account_number: toApiPhone(cleanPhone),
      });
      const user = (res.data as any)?.user;
      if (user) setUser(user);
      showSuccess("Payout account updated");
      router.replace(fallbackRoute as any);
    } catch (err: any) {
      if (err?.errors?.payout_account_number?.[0]) {
        setPhoneError(err.errors.payout_account_number[0]);
      }
      showError(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={s.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={0}
    >
      <ScrollView
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
        automaticallyAdjustKeyboardInsets={Platform.OS === "ios"}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 96, flexGrow: 1 }}
      >
        <LinearGradient
          colors={["#1e293b", "#334155", "#1e293b"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[s.hero, { paddingTop: insets.top + 12 }]}
        >
          <View style={s.heroDecor1} />
          <View style={s.heroDecor2} />
          <View style={s.headerRow}>
            <TouchableOpacity onPress={leavePayoutAccount} style={s.backBtn}>
              <Ionicons name="arrow-back" size={22} color={colors.white} />
            </TouchableOpacity>
            <View style={s.headerCopy}>
              <Text style={s.headerTitle}>Payout Account</Text>
              <Text style={s.headerSub}>Set the MoMo account for commission payouts.</Text>
            </View>
          </View>
        </LinearGradient>

        <View style={s.body}>
          {loading ? (
            <View style={s.loadingCard}>
              <ActivityIndicator color={colors.primary} />
              <Text style={s.loadingText}>Loading payout account...</Text>
            </View>
          ) : (
            <View style={s.card}>
              <View style={s.cardHeader}>
                <View style={s.cardIconWrap}>
                  <Ionicons name="card" size={16} color={colors.white} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.cardTitle}>MOMO ACCOUNT</Text>
                  <Text style={s.cardSub}>Use the name and number registered on the wallet.</Text>
                </View>
              </View>

              <View>
                <Text style={s.label}>Network <Text style={s.required}>*</Text></Text>
                <View style={s.networkGrid}>
                  {NETWORKS.map((item) => {
                    const active = network === item.value;
                    return (
                      <TouchableOpacity
                        key={item.value}
                        onPress={() => setNetwork(item.value)}
                        style={[s.networkChip, active && s.networkChipActive]}
                        activeOpacity={0.75}
                      >
                        <Text style={[s.networkText, active && s.networkTextActive]}>{item.label}</Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </View>

              <Input
                label="Account Name"
                required
                value={accountName}
                onChangeText={setAccountName}
                autoCapitalize="words"
                placeholder="Name on MoMo account"
                leftIcon={<Ionicons name="person-outline" size={18} color={colors.textMuted} />}
              />

              <Input
                label="Account Number"
                required
                value={accountNumber}
                onChangeText={(text) => {
                  const next = sanitizeLocalPhoneInput(text);
                  setAccountNumber(next);
                  setPhoneError(next.length === 10 && !isValidGhanaPhone(next) ? "Enter a valid 10-digit Ghana phone number" : "");
                }}
                keyboardType="phone-pad"
                maxLength={10}
                placeholder="0551234567"
                error={phoneError}
                leftIcon={<Ionicons name="call-outline" size={18} color={colors.textMuted} />}
              />
              {!!phoneHelper && !phoneError && (
                <View style={s.phoneHelperRow}>
                  <Ionicons name="information-circle-outline" size={14} color={colors.textMuted} />
                  <Text style={s.phoneHelperText}>{phoneHelper}</Text>
                </View>
              )}
            </View>
          )}
        </View>
      </ScrollView>

      <View style={[s.footer, { paddingBottom: insets.bottom + 12 }]}>
        <Button
          title="Save Payout Account"
          onPress={handleSave}
          loading={saving}
          disabled={!canSave}
          height={50}
          leftIcon={<Ionicons name="checkmark" size={18} color={colors.white} />}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  hero: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 24, gap: 16, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  heroDecor2: { position: "absolute", bottom: -60, left: -40, width: width * 0.4, height: width * 0.4, borderWidth: 40, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.2 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerCopy: { flex: 1, minWidth: 0 },
  headerTitle: { fontFamily: fontFamily.semibold, fontSize: 18, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.58)", marginTop: 2 },
  body: { padding: 16 },
  card: { backgroundColor: colors.white, borderRadius: 16, padding: 16, gap: 16 },
  loadingCard: { backgroundColor: colors.white, borderRadius: 16, padding: 20, alignItems: "center", gap: 10 },
  loadingText: { fontFamily: fontFamily.medium, fontSize: 13, color: colors.textMuted },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 4 },
  cardIconWrap: { width: 30, height: 30, borderRadius: 8, backgroundColor: colors.primary, justifyContent: "center", alignItems: "center" },
  cardTitle: { fontFamily: fontFamily.bold, fontSize: 11, color: colors.dark, letterSpacing: 0.5 },
  cardSub: { marginTop: 2, fontFamily: fontFamily.medium, fontSize: 12, color: colors.textMuted },
  label: { fontFamily: fontFamily.medium, fontSize: 14, color: colors.dark, marginBottom: 8 },
  required: { color: colors.error },
  networkGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  networkChip: { paddingHorizontal: 12, paddingVertical: 10, borderRadius: 12, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface },
  networkChipActive: { borderColor: colors.primary, backgroundColor: colors.warmSurface },
  networkText: { fontFamily: fontFamily.semibold, fontSize: 13, color: colors.text },
  networkTextActive: { color: colors.primaryDark },
  phoneHelperRow: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: -8 },
  phoneHelperText: { flex: 1, fontFamily: fontFamily.medium, fontSize: 11, color: colors.textMuted },
  footer: { position: "absolute", left: 0, right: 0, bottom: 0, paddingHorizontal: 16, paddingTop: 12, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.border },
});
