# Parcelman Mobile App — Build Plan (Vendor + Driver)

## Context

Build a dual-role React Native (Expo) mobile app. The app opens as the vendor experience by default (vendors see NO "vendor" terminology — just normal user language). A small link allows switching to driver login. The `userType` ('vendor' | 'driver') controls the entire app experience.

**UI inspiration**: `K:\PROJECTS\MOBILE\shaxi-driver` (Expo 55 + React Native + NativeWind + Zustand)
**Backend API**: `K:\PROJECTS\LARAVEL\parcelman` (56 API endpoints: 30 vendor + 26 driver)
**Push notifications**: FCM v1 via `expo-notifications` + backend `PushNotificationService`

---

## Tech Stack

| Layer | Technology | Reference |
|-------|-----------|-----------|
| Framework | Expo 55 + React Native | shaxi-driver |
| Language | TypeScript | shaxi-driver |
| Routing | expo-router (file-based) | shaxi-driver |
| Styling | NativeWind (Tailwind CSS for RN) | shaxi-driver |
| State | Zustand | shaxi-driver |
| HTTP | Axios | shaxi-driver |
| Forms | react-hook-form + zod | shaxi-driver |
| Push | expo-notifications | shaxi-driver |
| GPS | expo-location | shaxi-driver |
| Auth tokens | expo-secure-store | shaxi-driver |
| UI effects | expo-linear-gradient, expo-haptics | shaxi-driver |
| Camera | expo-camera (barcode scanning) | NEW |
| Images | expo-image-picker | NEW |

---

## Parcelman Color Palette

Derived from the Parcelman logo (orange/golden delivery brand) and the web login pages:

```
Brand (Orange/Golden):
  primary:       '#ea580c'   (main orange — CTAs, links, active states)
  primaryLight:  '#f97316'   (bright orange — hover, secondary buttons)
  primaryDark:   '#c2410c'   (deep orange — pressed states)

Gradient (Rust tones — used on brand panels):
  gradientStart: '#7c2d12'   (dark rust)
  gradientMid:   '#9a3412'   (medium rust)
  gradientEnd:   '#c2410c'   (burnt orange)
  Brand gradient:  ['#7c2d12', '#9a3412', '#c2410c'] (150deg)
  Button gradient: ['#ea580c', '#f97316'] (135deg, horizontal)

Accents:
  accentLight:   '#fdba74'   (light amber — decorative, badges)
  accentLighter: '#fed7aa'   (pale peach — subtle backgrounds)
  warmSurface:   '#fff7ed'   (warm off-white — cards on brand)

Neutrals (Slate):
  dark:          '#0f172a'   (slate-900 — headings, primary text)
  darkAlt:       '#1e293b'   (slate-800)
  text:          '#334155'   (slate-700 — body text)
  textMuted:     '#64748b'   (slate-500 — secondary text)
  textLight:     '#94a3b8'   (slate-400 — placeholders)
  surface:       '#f8fafc'   (slate-50 — input backgrounds)
  background:    '#f1f5f9'   (slate-100 — page background)
  border:        '#e2e8f0'   (slate-200 — borders)
  card:          '#ffffff'   (white — cards)

Focus states:
  focusBorder:   'rgba(249,115,22,0.6)'   (60% primaryLight)
  focusShadow:   'rgba(249,115,22,0.12)'  (12% primaryLight)
```

Semantic: success `#10b981`, error `#E74C3C`, warning `#FACC15`, info `#60A5FA`
Font: "Plus Jakarta Sans" (regular, medium, semibold, bold, extrabold) — same as web login pages

---

## Directory Structure

```
K:\PROJECTS\MOBILE\parcelman\
├── app/
│   ├── _layout.tsx                     # Root: fonts, hydrate, push, Toast
│   ├── index.tsx                       # Splash → auth check → route
│   ├── (auth)/
│   │   ├── _layout.tsx                 # Stack (no header)
│   │   ├── phone.tsx                   # Vendor: phone input + "Login as Driver" link
│   │   ├── verify.tsx                  # OTP verify (6-digit)
│   │   ├── register.tsx                # Vendor registration (new users)
│   │   └── driver-login.tsx            # Driver: email + password
│   ├── (vendor)/
│   │   ├── _layout.tsx                 # Stack wrapper
│   │   ├── (tabs)/
│   │   │   ├── _layout.tsx             # Bottom tabs: Home, Shipments, Alerts, Account
│   │   │   ├── home.tsx                # Dashboard
│   │   │   ├── shipments.tsx           # Shipment list
│   │   │   ├── notifications.tsx       # Notifications
│   │   │   └── account.tsx             # Profile/settings
│   │   ├── shipment/
│   │   │   ├── create.tsx              # Multi-step create (4 steps)
│   │   │   ├── [id].tsx                # Shipment detail
│   │   │   ├── [id]/edit.tsx           # Edit (draft only)
│   │   │   ├── [id]/item-add.tsx       # Add item
│   │   │   └── [id]/item-[itemId].tsx  # Edit item
│   │   └── profile/
│   │       └── edit.tsx                # Edit profile
│   └── (driver)/
│       ├── _layout.tsx                 # Stack wrapper
│       ├── (tabs)/
│       │   ├── _layout.tsx             # Bottom tabs: Home, Pickups, Transports, Deliveries, Account
│       │   ├── home.tsx                # Dashboard
│       │   ├── pickups.tsx             # Pickup list
│       │   ├── transports.tsx          # Transport list
│       │   ├── deliveries.tsx          # Delivery list
│       │   └── account.tsx             # Profile/settings
│       ├── pickup/
│       │   ├── [id].tsx                # Pickup detail + action buttons
│       │   └── [id]/confirm-items.tsx  # Item confirmation + photos
│       ├── transport/
│       │   ├── [id].tsx                # Transport detail
│       │   └── [id]/scanner.tsx        # QR/barcode scanner
│       ├── delivery/
│       │   ├── [id].tsx                # Delivery run (stops list)
│       │   └── [id]/stop-[stopId].tsx  # Stop confirm (code + photo)
│       └── profile/
│           ├── edit.tsx                # Edit profile
│           └── change-password.tsx     # Change password
├── src/
│   ├── api/
│   │   ├── client.ts                   # Axios instance (token interceptor, 401 logout)
│   │   └── v1/
│   │       ├── auth.ts                 # Vendor: sendOtp, verifyPhone, register
│   │       ├── driver-auth.ts          # Driver: login, logout
│   │       ├── vendor/
│   │       │   ├── profile.ts          # GET/PUT profile, POST fcm-token
│   │       │   ├── shipments.ts        # CRUD + submit
│   │       │   ├── shipment-items.ts   # CRUD + image upload/delete
│   │       │   ├── locations.ts        # regions, districts, search
│   │       │   └── notifications.ts    # list, mark-read, mark-all-read
│   │       └── driver/
│   │           ├── profile.ts          # GET/PUT, change-password, fcm-token
│   │           ├── pickups.ts          # list, show, en-route, arrive, confirm-item, confirm-pickup
│   │           ├── transports.ts       # list, show, start-loading, scan-load, depart, arrive
│   │           ├── deliveries.ts       # list, show, arrive-stop, confirm-stop, fail-stop
│   │           └── notifications.ts    # list, mark-read, mark-all-read
│   ├── components/
│   │   ├── common/                     # Ported from shaxi-driver (color swap only)
│   │   │   ├── AppBar.tsx, Button.tsx, OutlinedButton.tsx
│   │   │   ├── Input.tsx, PhoneInput.tsx, OtpInput.tsx
│   │   │   ├── StatusBadge.tsx         # Extended with 13 shipment + 6 pickup statuses
│   │   │   ├── Toast.tsx, EmptyState.tsx, LoadingIndicator.tsx
│   │   │   ├── ShimmerLoading.tsx, ConfirmDialog.tsx, Dropdown.tsx
│   │   │   ├── ImagePickerButton.tsx   # NEW: image picker for items/photos
│   │   │   ├── SearchInput.tsx         # NEW: debounced search
│   │   │   ├── FilterChips.tsx         # NEW: status filter pills
│   │   │   ├── StepIndicator.tsx       # NEW: multi-step form progress
│   │   │   └── TimelineView.tsx        # NEW: shipment/pickup status timeline
│   │   ├── vendor/                     # ShipmentCard, ItemCard, DashboardStats, LocationPicker
│   │   └── driver/                     # PickupCard, TransportCard, DeliveryCard, ActionButton, PhotoCapture
│   ├── constants/
│   │   ├── colors.ts                   # Parcelman palette
│   │   ├── spacing.ts                  # Copy from shaxi-driver
│   │   ├── typography.ts               # Copy from shaxi-driver (Plus Jakarta Sans font)
│   │   ├── theme.ts                    # Barrel export
│   │   ├── api.ts                      # API_BASE_URL
│   │   ├── storage-keys.ts             # AUTH_TOKEN, USER_DATA, USER_TYPE
│   │   └── statuses.ts                 # Status config maps (colors, labels, icons)
│   ├── stores/
│   │   ├── auth.store.ts               # user, token, userType, hydrate, login, logout
│   │   ├── vendor.store.ts             # shipments cache, dashboard stats
│   │   ├── driver.store.ts             # active tasks, online status
│   │   ├── notification.store.ts       # notifications, unreadCount
│   │   └── location.store.ts           # GPS tracking state
│   ├── hooks/
│   │   ├── useRefreshOnFocus.ts, usePagination.ts
│   │   ├── useImagePicker.ts, useCamera.ts
│   │   └── useNotifications.ts
│   ├── types/
│   │   ├── api.ts                      # ApiResponse<T>, PaginatedResponse<T>
│   │   ├── vendor.ts                   # Vendor, Shipment, ShipmentItem
│   │   ├── driver.ts                   # Driver, PickupAssignment, TransportManifest, DeliveryRun
│   │   ├── notification.ts             # NotificationLog
│   │   └── location.ts                 # Region, District, Location
│   └── utils/
│       ├── secure-storage.ts           # Copy from shaxi-driver
│       ├── toast.ts                    # Copy from shaxi-driver
│       ├── format.ts                   # Date, currency, phone formatters
│       └── routing.ts                  # Navigation helpers
├── assets/images/                      # logo.png, splash.png
├── global.css                          # NativeWind globals
├── tailwind.config.js                  # Parcelman-themed
├── app.config.js                       # Expo config
└── tsconfig.json
```

---

## Component Port Map (shaxi-driver → parcelman)

| Parcelman Component | Shaxi Source | Changes |
|---|---|---|
| Button.tsx | `src/components/common/Button.tsx` | Replace shaxi colors → parcelman orange/golden |
| Input.tsx | `src/components/common/Input.tsx` | Color swap to orange focus states |
| PhoneInput.tsx | `src/components/common/PhoneInput.tsx` | Color swap |
| OtpInput.tsx | `src/components/common/OtpInput.tsx` | Color swap |
| AppBar.tsx | `src/components/common/AppBar.tsx` | Color swap |
| Toast.tsx | `src/components/common/Toast.tsx` | Color swap |
| EmptyState.tsx | `src/components/common/EmptyState.tsx` | No changes |
| ShimmerLoading.tsx | `src/components/common/ShimmerLoading.tsx` | No changes |
| ConfirmDialog.tsx | `src/components/common/ConfirmDialog.tsx` | Color swap |
| Dropdown.tsx | `src/components/common/Dropdown.tsx` | Color swap |
| LoadingIndicator.tsx | `src/components/common/LoadingIndicator.tsx` | No changes |
| spacing.ts | `src/constants/spacing.ts` | Copy verbatim |
| typography.ts | `src/constants/typography.ts` | Update to Plus Jakarta Sans font |
| secure-storage.ts | `src/utils/secure-storage.ts` | Copy verbatim |
| toast.ts | `src/utils/toast.ts` | Copy verbatim |
| auth.store.ts | `src/stores/auth.store.ts` | Add `userType` field |
| client.ts | `src/api/client.ts` | Change baseURL to parcelman |

---

## API Endpoint Summary

### Vendor (30 endpoints)

**Auth (unauthenticated)**:
- `POST /api/v1/auth/vendor/send-otp` — {phone}
- `POST /api/v1/auth/vendor/verify-phone` — {phone, otp, fcm_token?}
- `POST /api/v1/auth/vendor/register` — {name, business_name?, phone, email?, fcm_token?}
- `POST /api/v1/auth/vendor/logout`

**Profile**: GET/PUT `/api/v1/vendor/profile`, POST `/api/v1/vendor/fcm-token`

**Locations**: GET `locations` (all regions→districts→towns for local cache), GET `regions`, GET `regions/{id}/districts`, GET `locations/search?q=`

**Shipments**: GET (list, filterable, paginated), POST (create), GET/{id}, PUT/{id}, DELETE/{id}, POST/{id}/submit

**Items**: POST (add), PUT (update), DELETE, POST images, DELETE image


**Earnings**: GET `earnings/summary` (balance + stats), GET `earnings` (paginated list), GET `payouts` (paginated list)

**Notifications**: GET (list), POST/{id}/read, POST/read-all

### Driver (26 endpoints)

**Auth**: POST `/api/v1/driver/login` — {identifier, password, fcm_token?}, POST logout

> **Driver login accepts email OR phone** under the single `identifier` field (e.g. `"driver@example.com"` or `"0241234567"`). The legacy `email` key is still accepted as a fallback so old app builds keep working, but new code should send `identifier` and label the input "Email or Phone". Phone input is normalized via the Ghana PhoneHelper before lookup.

**Profile**: GET/PUT profile, PUT change-password, POST fcm-token

**Pickups**: GET list, GET/{id}, POST en-route, POST arrive {lat,lng}, POST items/{id}/confirm {qty,photos}, POST confirm-pickup

**Transports**: GET list, GET/{id}, POST start-loading, POST scan-load {tracking_code}, POST depart, POST arrive

**Deliveries**: GET list, GET/{id}, POST stops/{id}/arrive, POST stops/{id}/confirm {verification_code,lat,lng,proof_photo,items[]}, POST stops/{id}/fail {reason}

**Notifications**: GET list, POST/{id}/read, POST/read-all

---

## Implementation Phases

### Phase 1: Project Scaffold + Design System

**Goal**: Expo project + all config + design tokens + common components

1. `npx create-expo-app@latest parcelman --template blank-typescript`
2. Install all dependencies (see tech stack)
3. Set up: `app.config.js`, `tailwind.config.js`, `global.css`, `tsconfig.json`, `babel.config.js`, `metro.config.js`
4. Create `src/constants/` — colors.ts (parcelman palette), spacing.ts, typography.ts, theme.ts, api.ts, storage-keys.ts, statuses.ts
5. Port all 11 common components from shaxi-driver (color swap)
6. Create 6 new common components: ImagePickerButton, SearchInput, FilterChips, StepIndicator, TimelineView, TabBar (custom bottom tab)

**Key reference files**:
- `K:/PROJECTS/MOBILE/shaxi-driver/app.config.js`
- `K:/PROJECTS/MOBILE/shaxi-driver/tailwind.config.js`
- `K:/PROJECTS/MOBILE/shaxi-driver/src/constants/*.ts`
- `K:/PROJECTS/MOBILE/shaxi-driver/src/components/common/*.tsx`

### Phase 2: Auth Infrastructure

**Goal**: Dual-auth system (vendor OTP + driver email/password)

1. Create `src/stores/auth.store.ts` — extend shaxi pattern with `userType: 'vendor' | 'driver' | null`
2. Create `src/api/client.ts` — Axios instance, token interceptor, 401 auto-logout
3. Create `src/api/v1/auth.ts` — vendor: sendOtp, verifyPhone, register, logout
4. Create `src/api/v1/driver-auth.ts` — driver: login, logout
5. Create `src/utils/secure-storage.ts`, `src/utils/toast.ts`
6. Create `src/types/api.ts`, `src/types/vendor.ts`, `src/types/driver.ts`
7. Create `app/_layout.tsx` — fonts, hydrate, push setup, Toast provider
8. Create `app/index.tsx` — splash → check auth → route to correct group

**Auth flow**:
- Splash → hydrate from storage → if authenticated: route to `(vendor)` or `(driver)` based on `userType`
- Splash → not authenticated → route to `(auth)/phone`

### Phase 3: Auth Screens (4 screens)

1. **`app/(auth)/phone.tsx`** — Vendor phone input
   - Parcelman logo, "Welcome" title, PhoneInput (Ghana +233), "Send Code" gradient button
   - Bottom: small muted "Are you a driver? **Log in here**" link → driver-login
   - Ref: `shaxi-driver/app/(auth)/phone.tsx`

2. **`app/(auth)/verify.tsx`** — OTP verification
   - AppBar with back, masked phone, OtpInput (6 digits, auto-submit + haptics), resend countdown
   - On success: if user_exists → login → vendor home; else → register
   - Ref: `shaxi-driver/app/(auth)/verify.tsx`

3. **`app/(auth)/register.tsx`** — Vendor registration
   - Name, Business Name (optional), Email (optional), "Create Account" button
   - POST register → login → vendor home

4. **`app/(auth)/driver-login.tsx`** — Driver email+password
   - "Driver Login" title, email input, password input (show/hide), "Login" button
   - Bottom: "Not a driver? **Go back**" link
   - POST login → login with userType='driver' → driver home

### Phase 4: Vendor Screens (~12 screens)

**Tab bar**: Home | Shipments | Alerts | Account

**4.1 Dashboard** (`home.tsx`):
- Greeting "Hello, {name}", 3 stat cards (Total Shipments, Active), quick actions, recent 5 shipments
- API: GET shipments?limit=5

**4.2 Shipment List** (`shipments.tsx`):
- SearchInput, FilterChips (All/Draft/Submitted/In Progress/Delivered), FlatList + pagination, FAB "+"
- API: GET shipments with filters
- Card: shipment_number, StatusBadge, destination mode, items count, created date

**4.3 Create Shipment** (`shipment/create.tsx`) — 2-step form (simplified photo-based flow):
- Step 1: Photos — take/pick photos, optionally tag each with a recipient phone number (see Appendix I)
- Step 2: Details — pickup town (free text), sender notes (optional)
- NO destination mode picker — admin decides single vs per_item later
- NO delivery address fields — admin fills these in during processing
- NO delivery notes field
- API: single POST with all photos as `items[0][images][]` + optional `items[0][phones][]` → auto-submitted
- See Appendix H for exact payload

**4.4 Shipment Detail** (`shipment/[id].tsx`):
- Status badge, TimelineView, pickup/delivery info cards, items list
- Actions: Edit/Submit/Delete (draft), Cancel (submitted)

**4.5 Edit Shipment** (`shipment/[id]/edit.tsx`): Pre-populated form, draft only

**4.6 Add/Edit Item** (`item-add.tsx`, `item-[itemId].tsx`): Description, qty, up to 5 images, delivery fields if per_item



**4.9 Notifications** (`notifications.tsx`): List with unread dots, "Mark all read", tap → navigate

**4.10 Account** (`account.tsx`): Profile header, menu (Edit Profile, About, Terms, Logout)

**4.11 Edit Profile** (`profile/edit.tsx`): Name, business name, email → PUT profile

### Phase 5: Driver Screens (~13 screens)

**Tab bar**: Home | Pickups | Transports | Deliveries | Account

**5.1 Dashboard** (`home.tsx`): Greeting, active tasks summary, quick actions, stats

**5.2 Pickup List** (`pickups.tsx`): FilterChips (Assigned/En Route/Arrived/Completed), PickupCard

**5.3 Pickup Detail** (`pickup/[id].tsx`):
- Status badge, TimelineView (Assigned→En Route→Arrived→Picking Up→Completed)
- Shipment info, pickup location (tappable for maps), items list
- Action buttons per status: "Start En Route" → "I've Arrived" → "Confirm Items" → "Complete Pickup"

**5.4 Item Confirmation** (`pickup/[id]/confirm-items.tsx`):
- Per item: expected qty, actual qty input, photo capture, notes
- POST confirm per item, then POST confirm-pickup when all done

**5.5 Transport List** (`transports.tsx`): TransportCard (manifest ID, origin, destination, status)

**5.6 Transport Detail** (`transport/[id].tsx`):
- Status, timeline, items list (scan status)
- Actions: "Start Loading" → "Scan Item" → "Depart" → "Arrive"

**5.7 QR Scanner** (`transport/[id]/scanner.tsx`):
- Full-screen camera with barcode overlay, scan → POST scan-load, haptic + toast on success

**5.8 Delivery List** (`deliveries.tsx`): DeliveryCard (run ID, stops count, progress)

**5.9 Delivery Run Detail** (`delivery/[id].tsx`): Stops list, per-stop actions

**5.10 Stop Confirmation** (`delivery/[id]/stop-[stopId].tsx`):
- Verification code input, proof photo capture, item qty confirmation
- "Confirm" → POST confirm-stop; "Failed" → reason input → POST fail-stop

**5.11 Account + Edit Profile + Change Password**: Same pattern as vendor

### Phase 6: Push Notifications

1. In `_layout.tsx` after auth: request permissions → get expo push token → POST fcm-token
2. Foreground handler: show in-app toast (not system notification)
3. Tap handler: parse notification `type` → navigate to relevant screen
4. Background handler via `expo-task-manager`

**Notification type → screen mapping**:
- `shipment_status_changed` → vendor shipment/[id]
- `_sent`, `_*` → vendor [id]
- `pickup_assigned` → driver pickup/[id]
- `transport_assigned` → driver transport/[id]
- `delivery_*` → driver delivery/[id]

### Phase 7: Polish

1. Network status banner (offline indicator) via `@react-native-community/netinfo`
2. Pull-to-refresh on all lists
3. 3-state screens: ShimmerLoading → EmptyState → Content
4. Validation errors from backend mapped to form fields
5. Haptics: OTP entry, action presses, barcode scans, pull-to-refresh

---

## Config Requirements for Push Notifications

The backend FCM v1 API is already fully set up:
- Service account JSON at `storage/app/firebase/firestore.json`
- `PushNotificationService` handles token → OAuth2 → FCM send
- Events + listeners already fire for all shipment/pickup/transport/delivery changes

**What's needed for mobile**:
1. Firebase project must have the Expo app registered (bundle ID: `com.parcelman.app`)
2. `google-services.json` (Android) and `GoogleService-Info.plist` (iOS) in project root
3. The `firebase_web_api_key`, `firebase_messaging_sender_id`, `firebase_app_id` platform settings must be configured
4. The Expo push token from `expo-notifications` needs to be sent as the `fcm_token` to the backend

---

## Verification Checklist

### Auth
- [ ] Fresh install → splash → vendor phone screen
- [ ] Phone → OTP → verify → new user → register → vendor home
- [ ] Phone → OTP → existing user → vendor home
- [ ] "Login as Driver" → email+password → driver home
- [ ] Logout vendor → back to phone screen
- [ ] Logout driver → back to phone screen (default)
- [ ] Kill + reopen → restores correct auth state

### Vendor
- [ ] Dashboard shows stats + recent shipments
- [ ] Create shipment: 4-step form → save draft → submit
- [ ] Shipment list: search, filter, pagination, pull-to-refresh
- [ ] Shipment detail: status timeline, items
- [ ] Edit shipment (draft only)
- [ ] Delete shipment (draft only)
- [ ] Notifications: list, mark read, navigate on tap
- [ ] Edit profile: update name/business/email

### Driver
- [ ] Dashboard shows active task counts
- [ ] Pickup flow: list → detail → en-route → arrive → confirm items → complete
- [ ] Item confirmation: qty + photos
- [ ] Transport flow: list → detail → start loading → scan items → depart → arrive
- [ ] Barcode scanner works
- [ ] Delivery flow: list → run detail → arrive at stop → confirm (code + photo) or fail
- [ ] Notifications work
- [ ] Change password

### Push
- [ ] Permission prompt on first auth
- [ ] FCM token sent to backend
- [ ] Foreground: in-app toast
- [ ] Background: system notification
- [ ] Tap notification → correct screen

---

## Appendix A — Shipment Display Logic (Unprocessed vs Processed)

Vendors submit shipments by uploading photos only. At submission time, there are no package descriptions, no quantities, no detailed breakdown. The admin fills all that in later. The mobile app needs to handle two states:

1. **Unprocessed** — vendor just submitted photos, admin hasn't reviewed
2. **Processed** — admin has split photos into packages, added descriptions, destinations, etc.

### How to Detect

The API returns an explicit flag — use `shipment.is_processed` (boolean). Do NOT detect from item descriptions.

### Shipment List Screen

| Field | Unprocessed | Processed |
|-------|------------|-----------|
| Subtitle | "5 photos uploaded" (`total_photos_count`) | "3 packages" (`items_count`) |
| Icon | `camera-outline` | `cube-outline` |
| Both | Hidden when count is 0 | Hidden when count is 0 |

### Shipment Detail Screen — Unprocessed

- Header meta: "X photos uploaded"
- Photos card: flat grid of all photos from `shipment.items.flatMap(i => i.images)`
- Pickup location, destination mode, sender notes still shown
- No package breakdown; no Add/Edit/Delete item buttons

### Shipment Detail Screen — Processed

- Header meta: "X packages"
- Packages card: per-package cards with description, qty, status, tracking code, photos
- Per-item mode: also recipient name + destination town per card
- Cards are read-only ("View" only — no edit/delete; vendors do not manage items manually anymore)

### API Response Fields

```json
{
  "is_processed": false,
  "items_count": 1,
  "total_photos_count": 5
}
```

### Key Rules

- Vendor terminology: **"photos"** and **"packages"** — never **"items"**
- Hide count meta entirely when 0
- All photos for unprocessed display: `shipment.items.flatMap(i => i.images)`; do not read only `items[0].images` because tagged photos can be regrouped across multiple item rows before the shipment is fully processed
- `total_photos_count` for unprocessed display, `items_count` for processed display

---

## Appendix B — Delivery Preference (replaces `fulfillment_type` for vendors)

Backend split the old `fulfillment_type` field into two concepts:

1. **`delivery_preference`** — vendor's choice (vendor-facing)
   - `deliver` — Deliver to the recipient's address (default)
   - `self_pickup` — Recipient collects from the warehouse
2. **`fulfillment_type`** — admin routing decision (read-only)
   - `warehouse` — Standard pipeline
   - `direct` — Driver goes vendor → recipient directly
   - Set by admin, NOT vendor

### Vendor Payload

```json
{
  "destination_mode": "single",
  "delivery_preference": "deliver"
}
```

- Send `delivery_preference`, never `fulfillment_type`, on create/update
- Defaults to `deliver` if omitted
- For per_item destination mode, set `delivery_preference` on each item; not at shipment level

### Vendor UI

| Value | Label |
|-------|-------|
| `deliver` | Deliver to Recipient |
| `self_pickup` | Recipient Collects |

Do NOT show "Direct Delivery" — admin-only.

### TypeScript Types

```typescript
type DeliveryPreference = 'deliver' | 'self_pickup';
type FulfillmentType = 'warehouse' | 'direct'; // read-only

interface Shipment {
  destination_mode: 'single' | 'per_item';
  delivery_preference: DeliveryPreference | null;
  fulfillment_type: FulfillmentType | null;
}

interface ShipmentItem {
  delivery_preference: DeliveryPreference | null;
  fulfillment_type: FulfillmentType | null;
}
```

### Self-Pickup Collection Object

When `fulfillment_type === 'self_pickup'` and shipment has reached warehouse:

```json
{
  "collection": {
    "status": "ready",        // or "collected"
    "warehouse_name": "Accra Main Hub",
    "warehouse_address": "Circle, Accra",
    "warehouse_phone": "+233501234567",
    "ready_at": "...",
    "collected_at": null,     // populated when collected
    "collected_by_name": null
  }
}
```

---

## Appendix C — Delivery Confirmation (Package-Level)

### OTP Verification & Admin Settings

Two platform settings control OTP behavior (configurable by super admin):

| Setting | Effect on Driver App | Default |
|---------|---------------------|---------|
| `delivery.allow_skip_verification` | When ON: show "Skip verification" toggle. When OFF: hide toggle, show "Call admin" banner instead | OFF |
| `delivery.show_otp_to_vendor` | When ON: vendor sees OTP code in shipment detail (`delivery_verification.code`). When OFF: `delivery_verification` is `null` | OFF |

**Driver app reads** `allow_skip_verification` from the delivery run response:
```json
{
  "id": 555,
  "run_number": "DRN-2026-0042",
  "allow_skip_verification": false,
  ...
}
```

**When `allow_skip_verification = false`** (default):
- Hide the skip verification toggle
- Show OTP code input only
- Show "Can't get the code?" banner with call button:
  - If `warehouse.contact_phone` exists → "Call the warehouse" + phone button
  - If no warehouse phone → "Call admin to get the verification code" (no phone button)

**When `allow_skip_verification = true`**:
- Show the skip verification toggle (existing behavior)
- Driver can skip OTP with a reason
- Delivery flagged for review

**Vendor app reads** `delivery_verification` from shipment detail (when `show_otp_to_vendor` is enabled):
```json
{
  "delivery_verification": {
    "code": "4821",
    "expires_at": "2026-04-17T14:00:00+00:00",
    "sent_at": "2026-04-16T14:00:00+00:00"
  }
}
```
When disabled or no active OTP: `"delivery_verification": null`

### Courier Handoff Info (Vendor Shipment Response)

When a shipment's items have been handed off to a bus courier, the vendor sees:

```json
{
  "courier_handoff": {
    "status": "handed_off",
    "bus_station": "Accra Station",
    "courier_name": "Gucci",
    "courier_phone": "+233549771816",
    "vehicle_number": "GN 1439-13",
    "handed_off_at": "2026-04-17T13:34:00+00:00"
  }
}
```

When no handoff: `"courier_handoff": null`

Only populated when shipment status is `handed_to_courier` or `delivered`.

**Vendor app should show**: A card with bus station name, courier details (name, phone — tappable to call, vehicle number), and handoff time. The vendor can call the courier to check on their package.

The Parcelman system handles **sealed parcels**. Drivers do NOT open or inspect items inside sealed packages — they only confirm how many packages they handed over. The number of physical packages (`total_packages`) may differ from `items.length`.

### Use This Endpoint (NOT the legacy item-level one)

**`POST /api/v1/driver/deliveries/{run}/stops/{stop}/confirm-packages`** (multipart/form-data)

| Field | Type | Required | Notes |
|-------|------|----------|-------|
| `verification_code` | string (4 digits) | Yes unless skipping | OTP from recipient |
| `skip_verification` | boolean | No | Skip OTP if SMS not received |
| `skip_reason` | string (max 500) | Yes if `skip_verification=true` | Why skipped |
| `packages_delivered` | integer (min 0) | Yes | Sealed packages handed over |
| `latitude` | numeric | Yes | GPS at delivery |
| `longitude` | numeric | Yes | GPS at delivery |
| `proof_photo` | file (image, max 12MB) | Yes | Mandatory even if verification skipped |
| `delivery_notes` | string (max 1000) | No | Remarks |
| `in_field_delivery_fee` | numeric ≥ 0 | No | **NEW** — delivery fee the driver collected from the recipient on arrival. Only recorded when at least one package was delivered. Creates paid recipient→parcelman package-level charges at `at_delivery` stage, split equally across delivered package items when a stop has multiple. |

**Note**: OTP is **4 digits** (not 6). Mobile app already updated.

### Backend Logic

- `packages_delivered >= total_packages` → All items marked **delivered**
- `packages_delivered === 0` → All items marked **failed**
- `0 < packages_delivered < total_packages` → Stop flagged as **partial** for warehouse review

### OTP Flow

1. Admin dispatches run → recipients get SMS: "Your parcel is on its way!"
2. Driver taps **"I've Arrived"** → OTP generated and SMS-ed to recipient at that moment
3. Recipient shares OTP verbally → driver enters → confirm
4. If SMS fails: driver toggles "Skip verification" + provides reason; proof photo still mandatory

### Stop Object Shape (from `GET .../deliveries/{run}`)

```json
{
  "id": 9,
  "recipient_name": "Ama Mensah",
  "recipient_phone": "+233241234567",
  "status": "pending",
  "total_packages": 2,
  "location": { "town": "Osu", "landmark": "...", "latitude": "...", "longitude": "..." },
  "verification": { "code_sent_at": null, "attempts": 0, "max_attempts": 5 },
  "items": [
    {
      "shipment_item_id": 14,
      "shipment_number": "PCM-2026-00014",
      "description": "LED TV 50-inch",
      "tracking_code": "TRK5PNQ13E",
      "expected_quantity": 1,
      "delivered_quantity": 0,
      "status": "out_for_delivery",
      "recipient_name": "Ama Mensah",           // NEW — actual recipient for this package
      "recipient_phone": "+233241234567",        // NEW — recipient phone
      "delivery_town": "Kumasi",                 // NEW — delivery destination
      "vendor": {
        "name": "Tony Mensa",
        "phone": "+233542796510",
        "business_name": "TM Venture"
      }
    }
  ]
}
```

### UI Rules

- **Show**: recipient + address + `total_packages` ("X package(s) to deliver") + read-only items list + sender card (under Info tab, below recipient details)
- **Do NOT show**: per-item confirmation inputs
- **Confirm Delivery button**: disabled until at least one proof photo is taken
- **Sender card**: deduplicate by phone/name, tappable phone opens dialer, hidden when no vendor data
- **In-field delivery fee capture** (optional):
  - Include an optional **"Delivery fee collected (GHS)"** number input on the confirm-delivery card
  - Intended for stops where the price wasn't locked in at warehouse receiving (remote / unfamiliar destinations), so the driver negotiates and records on-site
  - Only send `in_field_delivery_fee` in the request body when the driver actually enters an amount
  - Backend records it as paid `recipient → parcelman` package-level delivery charge(s) at `at_delivery` stage; a blank field skips the ledger entry
  - Backend ignores this amount when `packages_delivered = 0` (no point billing a failed stop)

### Other Delivery Endpoints

- `GET /api/v1/driver/deliveries` — List runs
- `GET /api/v1/driver/deliveries/{run}` — Run with stops + items + vendor info
- `POST .../stops/{stop}/arrive` — Mark arrival (triggers OTP)
- `POST .../stops/{stop}/fail` — Mark failed: `{ reason, notes? }`

### Legacy Endpoint (do NOT use)

`POST .../stops/{stop}/confirm` — item-level confirmation, kept for the web app's backwards compatibility. Mobile uses `confirm-packages` only.

### Bus Courier Handoff Endpoint

**`POST /api/v1/driver/deliveries/{run}/stops/{stop}/confirm-handoff`** (multipart/form-data)

For out-of-town deliveries where the driver hands packages to a bus station courier instead of delivering directly.

| Field | Type | Required | Notes |
|-------|------|----------|-------|
| `bus_station_name` | string (max 255) | No | **NEW** — free-text name of the bus station where the handoff happened (e.g. `"Accra Neoplan Station"`). Driver types this in the field; there is no pre-selected station anymore. Persisted on the delivery run stop so the vendor sees it in their `courier_handoff` response. |
| `courier_name` | string (max 255) | No | Bus driver's name |
| `courier_phone` | string (max 20) | No | Bus driver's phone |
| `vehicle_number` | string (max 50) | No | Bus vehicle registration |
| `latitude` | numeric | No | GPS at handoff |
| `longitude` | numeric | No | GPS at handoff |
| `proof_photo` | file (image, max 12MB) | **Yes** | Photo of handoff/slip |
| `station_fee` | numeric ≥ 0 | No | Fee the driver paid to the bus courier. Recorded as a paid expense charge (parcelman → station) on each shipment handed off. Split equally if multiple shipments share the handoff. |

**Only `proof_photo` is required.** The courier's phone and vehicle number are typically visible in the handoff photo itself (a station slip, a photo of the bus rear, etc.), so the backend does not force the driver to retype them. Any field that is sent is still stored; omitted fields are stored as `NULL`.

The response message, the `DeliveryRunStop.proof` note, and the `ShipmentItemTracking` note all degrade gracefully — if courier details are missing, they fall back to `"handed to courier (details on proof photo)"` rather than rendering empty parentheses.

**No OTP needed** — this is a handoff, not a final delivery.

**Stop status**: `handed_off` (not `delivered` — admin confirms delivery later via phone call to recipient)

**Shipment status**: `handed_to_courier`

### How `delivery_method` Works

Each stop has a `delivery_method` field in the response:

| Value | Meaning | Confirm Endpoint |
|-------|---------|-----------------|
| `direct` | Normal delivery to recipient (default) | `confirm-packages` |
| `bus_handoff` | Hand to bus courier for onward delivery | `confirm-handoff` |

```json
{
  "stops": [
    {
      "id": 9,
      "delivery_method": "bus_handoff",
      "recipient_name": "Ama Mensah",
      "recipient_phone": "+233241234567",
      "status": "pending",
      ...
      "handoff": null
    }
  ]
}
```

After handoff:
```json
{
  "status": "handed_off",
  "handoff": {
    "courier_name": "Gucci",
    "courier_phone": "+233549771816",
    "vehicle_number": "GN 1439-13",
    "handed_off_at": "2026-04-16T14:30:00+00:00"
  }
}
```

### Mobile UI Rules for Bus Handoff

- Check `stop.delivery_method` — if `"bus_handoff"`:
  - Show **"BUS COURIER HANDOFF"** card (violet theme) instead of OTP verification card
  - **Bus station name** text input at the top of the card — optional, free-text. The station is decided in the field, not preselected. Placeholder like `"e.g. Accra Neoplan Station"`. If you want to keep a local history of stations the driver has typed before and offer autocomplete, do it client-side — the backend does not keep a station list.
  - 3 fields: Courier Name, Courier Phone, Vehicle Number — **all optional**, label them clearly so drivers know they can skip when the info is already captured in the photo
  - **Proof photo is required** — the button stays disabled until a photo is captured
  - Button: **"Confirm Handoff"** (violet gradient) instead of "Confirm Delivery"
  - No OTP input, no packages stepper, no skip verification
- **Station fee capture** (optional):
  - Include an optional **"Amount paid to bus courier (GHS)"** number input below the 3 courier-info fields
  - Leave blank by default — only send `station_fee` in the request body when the driver actually enters an amount
  - This feeds the backend's charges ledger as a `parcelman → station` expense line; leaving it blank skips recording an expense
- **"I've Arrived"** still works the same (but OTP SMS is NOT sent for bus_handoff stops)
- Set by admin when creating/dispatching the delivery run, or driver can see it's pre-set

---

## Appendix C.2 — Vendor-visible charges on a shipment

The vendor shipment response (`GET /api/v1/vendor/shipments` and `GET /api/v1/vendor/shipments/{id}`) now includes a `charges` object that captures the full pricing story for the shipment from pickup through delivery.

### Response shape

```json
{
  "id": 23,
  "shipment_number": "PCM-2026-00023",
  ...
  "charges": {
    "lines": [
      {
        "id": 12,
        "shipment_item_id": null,
        "charge_type": "pickup_fee",
        "payer_type": "vendor",
        "due_stage": "at_pickup",
        "amount": 15.00,
        "currency": "GHS",
        "status": "paid",
        "paid_at": "2026-04-23T10:42:00+00:00",
        "payment_method": "cash",
        "notes": null,
        "created_at": "2026-04-23T10:30:00+00:00"
      },
      {
        "id": 17,
        "shipment_item_id": 41,
        "charge_type": "delivery_fee",
        "payer_type": "recipient",
        "due_stage": "before_delivery",
        "amount": 25.00,
        "currency": "GHS",
        "status": "pending",
        "paid_at": null,
        "payment_method": null,
        "notes": "Quoted to recipient over phone",
        "created_at": "2026-04-23T14:05:00+00:00"
      }
    ],
    "totals": {
      "currency": "GHS",
      "total": 40.00,
      "paid": 15.00,
      "outstanding": 25.00
    }
  }
}
```

### What the fields mean

| Field | Meaning |
|---|---|
| `lines[]` | Every charge on the shipment **except internal expenses** — vendors never see station-fee or other parcelman-paid expense lines |
| `charge_type` | One of `pickup_fee` (vendor pays), `delivery_fee` (recipient pays), `handling_fee`, `other` |
| `payer_type` | `vendor` or `recipient`. `parcelman` payer lines are hidden from this endpoint. |
| `due_stage` | When the charge is expected: `at_pickup` / `at_receiving` / `before_delivery` / `at_delivery` / `at_handoff` |
| `status` | `draft` / `pending` / `paid` / `waived` / `cancelled` |
| `shipment_item_id` | If not `null`, this line is per-package (typically a delivery fee). `null` = shipment-level (typically the pickup fee). |
| `totals.outstanding` | Sum of non-paid, non-cancelled, non-waived lines that the vendor and/or recipient still owe |

### Mobile UI suggestions

- On the shipment detail screen, show a **"Pricing" card** with `totals.outstanding` prominently if > 0, otherwise show `totals.paid` as "Paid in full".
- List each `lines[]` row with its `charge_type`, `amount`, and a coloured pill for `status` (amber `pending`, green `paid`, grey `waived/cancelled`).
- Group lines by `due_stage` if helpful (e.g., "At pickup", "Before delivery", "At delivery").
- Do not expose admin-only knobs — this is a read-only summary for the vendor. They can't pay charges through the app.
- Don't worry about the backend omitting station fees; the endpoint already strips those out.

---

## Appendix D — Package Custody (Scan & Claim)

Drivers physically pick packages they want to deliver from the warehouse floor. They scan each package's barcode/QR label to "claim" it. Replaces pre-assigned sort batches — drivers self-serve and the system records custody.

### Driver Flow

1. **Scan** packages at warehouse → camera scanner → each scan claims the label
2. **My Packages** → list of currently-held labels, grouped by tracking code
3. **Start Deliveries** → backend groups by recipient phone/town → returns `delivery_run_id` → existing delivery flow takes over
4. **Release** any time before delivery → label goes back to "unclaimed"

### Endpoints

#### Scan & Claim
**`POST /api/v1/driver/scan-claim`**

```json
{ "barcode": "TRKRNDOBJCW-003", "latitude": 5.6, "longitude": -0.18, "notes": "Shelf A2" }
```

- Success (200): returns `data.label` with full info
- Already claimed by you (200, message contains "already"): treat as duplicate, do NOT increment count
- Claimed by another driver (409 with `claimed_by`): show name, blocked
- Not found (404): bad barcode

#### My Packages
**`GET /api/v1/driver/my-packages`**

Query params:
- `from_date`, `to_date` (YYYY-MM-DD) — filter by claim date
- `limit` (default 50, max 100), `offset`

```json
{
  "data": {
    "packages": [{
      "barcode": "TRKRNDOBJCW-001",
      "label_index": 1,
      "labels_total": 10,
      "label_type": "unit",
      "shipment_number": "PCM-2026-00045",
      "description": "Fridge",
      "tracking_code": "TRKRNDOBJCW",
      "recipient_name": "Mark Asante",
      "recipient_phone": "+233241234567",
      "delivery_town": "Madina",
      "claimed_at": "2026-04-04T08:30:00+00:00",
      "in_delivery_run": false
    }],
    "total": 25, "limit": 50, "offset": 0, "has_more": false
  }
}
```

- `in_delivery_run: true` — already part of an active run; cannot release; show as "In Delivery" badge
- `active_delivery_run` field has been removed — do NOT use it; rely on per-label `in_delivery_run` flag

#### Release
**`POST /api/v1/driver/release-package`** — `{ barcode, notes? }`. Only works for labels not yet in a delivery run.

#### Package History
**`GET /api/v1/driver/package-history/{barcode}`** — returns `label` + `history` (claimed/released events).

#### Start Deliveries
**`POST /api/v1/driver/start-deliveries`** — `{ warehouse_id? }` (auto-detected if omitted)

```json
{
  "data": {
    "delivery_run_id": 15,
    "run_number": "DR-2026-WH002-0012",
    "stops_count": 3,
    "packages_count": 8,
    "existing": false
  }
}
```

Backend:
- Returns existing run if driver already has an active one (`existing: true`)
- Filters out labels already in active runs — only new claims become stops
- Groups by recipient phone (primary) → town (fallback) → "Unknown destination" stop

### Mobile UI Rules

**Scan screen:**
- Full-screen camera (`expo-camera` `CameraView`)
- Toast overlay (success/warning/error) — stays until next scan
- Vibration feedback (`Vibration.vibrate(100)` for success, `[0,100,50,100]` for error) — `expo-haptics` does NOT work in Expo Go
- Sound beeps via `expo-av` require a dev client build (not Expo Go); skip until then
- Debounce same barcode within 3 seconds; track all scanned barcodes in a Set so re-scans don't increment count
- Show count as **"X labels scanned"** (not "packages") — labels are the scanned unit
- Offline queue: failed scans stored in `AsyncStorage` under `@parcelman/scan_queue`, flushed on next success or screen mount

**My Packages screen:**
- Group by `tracking_code` — one card per package, not per label
- Each group shows: description, route label → town, "X of Y labels", claimed timestamp
- For `delivery_method = "bus_handoff"`, show `Bus Station → town` before a run exists; the actual station name is still entered later by the driver during handoff confirmation
- Mixed status: amber "X in delivery" badge when some labels are in a run and some aren't
- All-in-delivery: green badge + dimmed card; release button hidden
- Status filters: **Available** (default) / **In Delivery** / **All** — counts are label-level
- Date filters: **Today** (default) / **All Time** / **Custom** (date range picker)
- Search: client-side over description, tracking code, recipient, town
- "Start Deliveries" is a **slide-to-confirm** (not a tap button) — drivers hit buttons by mistake
- If all labels are in delivery and none available, button becomes "View Deliveries" → goes to `/(driver)/(tabs)/deliveries`

**Package detail screen** (`/packages/[barcode]`):
- Receives `tracking_code` (named `barcode` in route param for backwards compat)
- Shows all labels in that group with per-label release
- Route-aware summary and detail card; bus-handoff packages should clearly show they are for a bus station even before the real station is captured
- Recipient phone remains tappable when available
- Custody history timeline (claimed/released events with driver name + timestamp)
- Auto-navigates back when last label released

### Important Rules

- A label can only be claimed by one driver at a time
- Claiming is idempotent — re-scanning by the same driver is safe
- Barcode formats: `TRKXYZ` (sealed package, 1 label) or `TRKXYZ-001` (unit label, part of a set)
- Newly scanned labels auto-join the active delivery run if one exists (backend behavior)
- `expo-notifications` crashes in Expo Go SDK 53+ — guard with `Constants.appOwnership === 'expo'` check before importing

---

## Appendix E — Driver Tab Bar

Order: **Home — Pickups — [Scan] — Transports — Account**

- "Scan" is the centered orange circle FAB-style button (54px), white scan icon, no label
- "Deliveries" is hidden from the tab bar (`href: null`) — accessible via Quick Actions on Home and from the My Packages "View Deliveries" button
- Badges on Pickups/Transports use `"status[]": "assigned"` (array form — Laravel rejects scalar `status` with 422)

### Driver capabilities

The driver profile response includes `task_capabilities: string[]`. Possible values:

| Value | Meaning |
|---|---|
| `pickup` | Driver collects shipments from vendors |
| `transport` | Driver moves items between warehouses via transport manifests |
| `delivery` | Driver delivers direct to recipients (last-mile) |
| `bus_handoff` | **NEW** — Driver is dedicated to bus-station handoffs. A bus_handoff delivery run consolidates all `delivery_method = bus_handoff` packages into a single stop; driver picks the actual bus station in the field and records it at handoff time. |

A driver can have any combination of capabilities. The UI can use these to hide or label surfaces that don't apply (e.g., a bus-handoff-only driver may not want to see direct-delivery flows).

---

## Appendix F — Driver Home Layout

**Hero**: minimal — logo (left), spacer, notification icon (with unread badge), profile icon. No greeting, no stats, no driver badge.

**Quick Actions**:
- Full-width orange gradient "Scan Packages" hero button (primary)
- 2x2 grid below: My Packages, Deliveries, Pickups, Transports — each with icon, title, count badge

**Today's Summary** (single card, list style with dividers):
- Pickups pending
- Transports pending
- Packages scanned (today)
- Deliveries made (stops completed, green)
- Deliveries remaining (stops left)
- Deliveries failed (only if > 0, red)

All counts are **stop-level** (not run-level) — drivers measure their day in deliveries, not runs.

---

## Appendix G — Vendor Edit Shipment

Endpoint: **`PUT /api/v1/vendor/shipments/{id}`** (multipart/form-data)

| Field | Type | Notes |
|-------|------|-------|
| `pickup_town` | string | optional |
| `sender_notes` | string | optional |
| `new_photos[]` | file[] | new photos to add (max 2MB each, jpeg/png/webp) |
| `new_photos_phones[]` | string[] | recipient phone per new photo (optional, same index as new_photos) |
| `remove_photo_ids[]` | integer[] | IDs of existing photos to delete |

Single request handles all changes (photos add/remove with phone tags, pickup town, notes). The mobile app no longer uses the old `updateShipment` JSON helper — it uses `api.put` directly with FormData.

UI: single-page form (not the old 4-step wizard).
- **NO destination mode picker** — removed from edit screen
- **NO delivery address fields** — admin manages these
- **NO delivery notes field** — removed
- Vendor can only edit: pickup town, sender notes, add/remove photos

### Photo Display on Edit Screen

When loading the shipment for editing, existing photos include `recipient_phone`:

```json
{
  "images": [
    {
      "id": 1,
      "url": "https://storage.example.com/...",
      "original_name": "photo1.jpg",
      "recipient_phone": "+233551234567",
      ...
    },
    {
      "id": 2,
      "url": "https://storage.example.com/...",
      "original_name": "photo2.jpg",
      "recipient_phone": null,
      ...
    }
  ]
}
```

**Edit screen should:**
1. Show existing photos in a grid with phone badge overlay (same as create screen)
2. Show the tagged phone number under/on each existing photo
3. Allow removing photos (adds to `remove_photo_ids[]`)
4. Allow adding new photos with phone tags (appends to `new_photos[]` + `new_photos_phones[]`)
5. Existing photo phone tags are **read-only** — to change a phone, remove the photo and re-add it

### FormData Construction for Edit

```typescript
// Existing photos to remove
removeIds.forEach(id => formData.append('remove_photo_ids[]', String(id)));

// New photos with phone tags
newPhotos.forEach((photo, i) => {
  formData.append(`new_photos[${i}]`, { uri: photo.uri, name: `photo_${i}.jpg`, type: 'image/jpeg' });
  if (photo.recipientPhone) {
    formData.append(`new_photos_phones[${i}]`, photo.recipientPhone);
  }
});

// Other fields
if (pickupTown) formData.append('pickup_town', pickupTown);
if (senderNotes) formData.append('sender_notes', senderNotes);
```

---

## Appendix H — Vendor Create Shipment Payload

**`POST /api/v1/vendor/shipments`** (multipart/form-data)

| Field | Type | Required | Notes |
|-------|------|----------|-------|
| `destination_mode` | string | Yes | Always send `"single"` — admin changes if needed |
| `pickup_contact_name` | string | Yes | Auto-filled from vendor's name |
| `pickup_contact_phone` | string | Yes | Auto-filled, in `+233...` format |
| `pickup_contact_phone_confirm` | string | Yes | Same as `pickup_contact_phone` |
| `pickup_town` | string | optional | Free text |
| `sender_notes` | string | optional | Free text notes |
| `items[0][images][N]` | file | Yes | Photos as file objects (`uri`, `name`, `type: "image/jpeg"`), indexed 0, 1, 2... |
| `items[0][phones][N]` | string | No | Recipient phone per photo (optional, same index as images). Tags the photo with a recipient for admin grouping. |

All photos go onto a single `items[0]` at submission time. Admin processes/splits them into individual packages later.

No drafts: every shipment is submitted on creation. The vendor detail screen no longer has a "Submit Parcel" bar.

### Fields REMOVED from Create/Edit UI

These fields are **NOT shown** on the vendor mobile app — admin manages them on the backend:

- **Destination mode picker** (single vs per_item) — always send `"single"`, admin changes later
- **Delivery address fields** (recipient name, phone, region, district, town, landmark, instructions) — admin fills these during processing
- **Delivery notes** — removed from UI
- **Drop-off type dropdown** — removed

---

## Appendix I — Photo Recipient Phone Tagging

Vendors can tag each photo with a recipient phone number during upload. This helps the admin group photos by recipient when processing the shipment.

### How It Works

Each photo has an **optional** `recipient_phone` field. The `phones[]` array in the request maps 1:1 with the `images[]` array by index:

```
items[0][images][0] = photo_file_1       →  recipient_phone = phones[0]
items[0][images][1] = photo_file_2       →  recipient_phone = phones[1]
items[0][images][2] = photo_file_3       →  recipient_phone = phones[2] (or null if missing)
items[0][phones][0] = "0551234567"
items[0][phones][1] = "0551234567"       // same phone = same recipient
items[0][phones][2] = "0209876543"       // different phone = different recipient
```

- If `phones` array is shorter than `images`, remaining photos get `null`
- If `phones` is omitted entirely, all photos get `null`
- Phones are auto-formatted by the backend (Ghana format)

### Image Object in Responses

Every image in API responses now includes `recipient_phone`:

```json
{
  "id": 1,
  "url": "https://storage.example.com/...",
  "original_name": "fridge.jpg",
  "size": 245760,
  "size_human": "240.00 KB",
  "recipient_phone": "+233551234567",
  "expires_at": "2026-04-16T12:00:00Z"
}
```

`recipient_phone` is `null` when no phone was tagged.

### TypeScript Type Update

```typescript
interface ShipmentItemImage {
  id: number;
  url: string;
  original_name: string;
  size: number;
  size_human: string;
  recipient_phone: string | null;  // NEW
  expires_at: string | null;
}
```

### Mobile UI Recommendation

Use the existing **select mode** pattern (long-press → select photos → action):

1. After taking photos, show the grid as today
2. Long-press a photo → enters select mode (existing pattern used for bulk delete)
3. Select one or more photos → tap **"Tag Recipient"** (new action alongside "Delete")
4. Enter phone number → all selected photos get tagged
5. Tagged photos show a **phone badge** overlay (last 4 digits, e.g. `📱4567`)
6. Tap a tagged photo's badge to edit/remove the phone
7. Untagged photos are fine — they use the shipment-level delivery recipient

### Local State Change

```typescript
// Before
const [photos, setPhotos] = useState<string[]>([]);

// After
interface TaggedPhoto {
  uri: string;
  recipientPhone: string | null;
}
const [photos, setPhotos] = useState<TaggedPhoto[]>([]);
```

### FormData Construction Change

```typescript
// Before
photos.forEach((uri, i) => {
  formData.append(`items[0][images][${i}]`, { uri, name: `photo_${i}.jpg`, type: 'image/jpeg' });
});

// After
photos.forEach((photo, i) => {
  formData.append(`items[0][images][${i}]`, { uri: photo.uri, name: `photo_${i}.jpg`, type: 'image/jpeg' });
  if (photo.recipientPhone) {
    formData.append(`items[0][phones][${i}]`, photo.recipientPhone);
  }
});
```

### Edit Shipment

### Edit Shipment — Phone Tags on New Photos

The edit endpoint (`PUT /api/v1/vendor/shipments/{id}`) supports `new_photos_phones[]` for tagging new photos with recipient phones (same index mapping as `new_photos[]`).

Existing photos show `recipient_phone` in the response — these are **read-only**. To change a tag, the vendor removes the photo and re-adds it with the new phone.

See **Appendix G** for full edit payload and FormData construction.
