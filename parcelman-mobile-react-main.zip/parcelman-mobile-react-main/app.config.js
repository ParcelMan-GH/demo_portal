module.exports = {
  expo: {
    name: "ParcelMan Express",
    slug: "parcelman",
    version: "1.0.1",
    orientation: "portrait",
    icon: "./assets/images/icon.jpg",
    scheme: "parcelman",
    userInterfaceStyle: "light",
    newArchEnabled: true,
    splash: {
      image: "./assets/images/logo.png",
      resizeMode: "contain",
      backgroundColor: "#FFFFFF",
    },
    assetBundlePatterns: ["**/*"],
    ios: {
      supportsTablet: false,
      bundleIdentifier: "com.parcelman.parcelman",
      buildNumber: "12",
      googleServicesFile: "./GoogleService-Info.plist",
    },
    android: {
      versionCode: 12,
      adaptiveIcon: {
        foregroundImage: "./assets/android-icon-foreground.png",
        backgroundImage: "./assets/android-icon-background.png",
        monochromeImage: "./assets/android-icon-monochrome.png",
      },
      package: "com.parcelman.parcelman",
      googleServicesFile: "./google-services.json",
      softwareKeyboardLayoutMode: "resize",
      permissions: [
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.ACCESS_COARSE_LOCATION",
        "android.permission.CAMERA",
        "android.permission.READ_EXTERNAL_STORAGE",
        "android.permission.WRITE_EXTERNAL_STORAGE",
        "android.permission.VIBRATE",
      ],
      usesClearTextTraffic: true,
    },
    plugins: [
      "expo-router",
      [
        "expo-splash-screen",
        {
          image: "./assets/images/logo.png",
          imageWidth: 132,
          resizeMode: "contain",
          backgroundColor: "#FFFFFF",
        },
      ],
      "expo-font",
      "expo-secure-store",
      "expo-camera",
      "@react-native-firebase/app",
      "@react-native-firebase/messaging",
      [
        "expo-build-properties",
        {
          android: { newArchEnabled: true },
          ios: {
            deploymentTarget: "15.1",
          },
        },
      ],
      [
        "expo-location",
        {
          locationAlwaysAndWhenInUsePermission:
            "Allow ParcelMan Express to use your location for pickup and delivery tracking.",
        },
      ],
      [
        "expo-image-picker",
        {
          photosPermission:
            "Allow ParcelMan Express to access your photos for shipment item images.",
          cameraPermission:
            "Allow ParcelMan Express to use your camera for taking photos of items and delivery proof.",
        },
      ],
      [
        "expo-notifications",
        {
          icon: "./assets/images/icon.jpg",
          color: "#ea580c",
        },
      ],
      "./plugins/withGradlePropertiesFixes",
      "./plugins/withFirebasePodfileFix",
      "./plugins/withIphoneOnlyIos",
      "./plugins/withPrebuiltFrameworkDsyms",
    ],
    experiments: {
      typedRoutes: true,
    },
    extra: {
      eas: {
        projectId: "569dccd9-dc21-46f2-87f0-f878b4d0005c",
      },
      router: {
        origin: false,
      },
      API_BASE_URL: process.env.API_BASE_URL || "https://parcelmanexpress.com",
    },
  },
};
