import { useState, useCallback } from 'react';
import { Alert } from 'react-native';
import { useCameraPermissions, CameraView } from 'expo-camera';

export function useCamera() {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);

  const ensurePermission = useCallback(async (): Promise<boolean> => {
    if (permission?.granted) return true;
    const result = await requestPermission();
    if (!result.granted) {
      Alert.alert('Permission needed', 'Camera permission is required for scanning.');
      return false;
    }
    return true;
  }, [permission, requestPermission]);

  const resetScan = useCallback(() => {
    setScanned(false);
  }, []);

  return {
    hasPermission: permission?.granted ?? false,
    ensurePermission,
    scanned,
    setScanned,
    resetScan,
    CameraView,
  };
}
