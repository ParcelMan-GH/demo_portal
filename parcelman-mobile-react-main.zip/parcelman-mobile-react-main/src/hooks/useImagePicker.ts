import { useState } from 'react';
import * as ImagePicker from 'expo-image-picker';
import { Alert } from 'react-native';
import { compressToUnder2MB, compressMany } from '../utils/image';
import { captureSinglePhoto } from '../utils/cameraCapture';

export function useImagePicker(maxImages = 5) {
  const [images, setImages] = useState<string[]>([]);

  const pickFromGallery = async () => {
    if (images.length >= maxImages) {
      Alert.alert('Limit reached', `Maximum ${maxImages} images allowed.`);
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsMultipleSelection: true,
      quality: 0.8,
      selectionLimit: maxImages - images.length,
    });
    if (!result.canceled) {
      const compressed = await compressMany(result.assets.map((a) => a.uri));
      setImages((prev) => [...prev, ...compressed].slice(0, maxImages));
    }
  };

  const takePhoto = async () => {
    if (images.length >= maxImages) {
      Alert.alert('Limit reached', `Maximum ${maxImages} images allowed.`);
      return;
    }
    const capturedUri = await captureSinglePhoto({ quality: 0.8, simulatorBehavior: 'choice' });
    if (!capturedUri) return;

    const compressed = await compressToUnder2MB(capturedUri);
    setImages((prev) => [...prev, compressed].slice(0, maxImages));
  };

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const clearImages = () => setImages([]);

  return { images, setImages, pickFromGallery, takePhoto, removeImage, clearImages };
}
