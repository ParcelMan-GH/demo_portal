import { useEffect, useRef } from 'react';
import { Platform } from 'react-native';
import Constants from 'expo-constants';
import * as Device from 'expo-device';
import { router } from 'expo-router';
import { useAuthStore } from '../stores/auth.store';
import { showToast } from '../components/common/Toast';
import { formatVendorNotificationCopy } from '../utils/notificationCopy';

const isExpoGo = Constants.appOwnership === 'expo';

type FirebaseMessagingModule = typeof import('@react-native-firebase/messaging').default;

export function getRouteForNotification(type: string, data: Record<string, unknown>): string | null {
  const value = (key: string): string | null => {
    const raw = data?.[key];
    return typeof raw === 'string' || typeof raw === 'number' ? String(raw) : null;
  };

  switch (type) {
    case 'shipment_status':
    case 'shipment_status_changed':
    case 'shipment_ready_for_collection':
    case 'shipment_collected':
    case 'walkin_shipment_received':
    case 'shipment_rejected':
      return value('shipment_id') ? `/(vendor)/shipment/${value('shipment_id')}` : null;
    case 'driver_assigned':
    case 'pickup_assigned':
      return value('pickup_id') || value('assignment_id')
        ? `/(driver)/pickup/${value('pickup_id') || value('assignment_id')}`
        : null;
    case 'transport_assigned':
      return value('transport_id') || value('manifest_id')
        ? `/(driver)/transport/${value('transport_id') || value('manifest_id')}`
        : null;
    case 'delivery_assigned':
      return value('delivery_run_id') ? `/(driver)/delivery/${value('delivery_run_id')}` : null;
    case 'package_transfer':
      return '/(driver)/package-transfers';
    default:
      return null;
  }
}

export function useNotifications() {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const userType = useAuthStore((s) => s.userType);
  const notificationListener = useRef<any>(null);
  const responseListener = useRef<any>(null);
  const tokenRefreshListener = useRef<null | (() => void)>(null);
  const lastHandledResponse = useRef<string | null>(null);

  useEffect(() => {
    if (!isAuthenticated || Platform.OS === 'web' || isExpoGo) return;

    let Notifications: typeof import('expo-notifications') | null = null;
    let active = true;

    (async () => {
      try {
        // Dynamically import to avoid Expo Go crash
        Notifications = await import('expo-notifications');
        if (!active) return;

        // Set foreground handler
        Notifications.setNotificationHandler({
          handleNotification: async () => ({
            shouldShowAlert: false,
            shouldShowBanner: false,
            shouldShowList: false,
            shouldPlaySound: false,
            shouldSetBadge: false,
          }),
        });

        // Foreground: show in-app toast
        notificationListener.current = Notifications.addNotificationReceivedListener(
          (notification) => {
            const { body, data } = notification.request.content;
            if (body) {
              const type = data?.type;
              const route = typeof type === 'string'
                ? getRouteForNotification(type, data as Record<string, unknown>)
                : null;
              showToast(
                'info',
                userType === 'vendor' ? formatVendorNotificationCopy(body) : body,
                route ? { actionLabel: 'Open notification', onPress: () => router.push(route as any) } : undefined,
              );
            }
          },
        );

        // Tap: navigate to relevant screen
        const handleResponse = (response: import('expo-notifications').NotificationResponse) => {
          const requestId = response.notification.request.identifier;
          if (lastHandledResponse.current === requestId) return;
          lastHandledResponse.current = requestId;
          const data = response.notification.request.content.data as Record<string, unknown>;
          const type = data?.type;
          if (typeof type === 'string') {
            const route = getRouteForNotification(type, data);
            if (route) {
              router.push(route as any);
            }
          }
        };

        responseListener.current = Notifications.addNotificationResponseReceivedListener(handleResponse);
        const initialResponse = await Notifications.getLastNotificationResponseAsync();
        if (!active) return;
        if (initialResponse) {
          handleResponse(initialResponse);
          await Notifications.clearLastNotificationResponseAsync();
          if (!active) return;
        }

        // Token registration can involve permission prompts and network I/O, so
        // keep it after tap routing is ready.
        await registerForPush(Notifications, () => active);
        if (!active) return;

        const messagingMod = await import('@react-native-firebase/messaging');
        if (!active) return;
        tokenRefreshListener.current = messagingMod.default().onTokenRefresh((token) => {
          if (active) uploadToken(token).catch(() => {});
        });
      } catch {
        // expo-notifications not available (Expo Go SDK 53+)
        console.log('[Notifications] Not available in this environment');
      }
    })();

    return () => {
      active = false;
      notificationListener.current?.remove();
      responseListener.current?.remove();
      tokenRefreshListener.current?.();
      notificationListener.current = null;
      responseListener.current = null;
      tokenRefreshListener.current = null;
    };
  }, [isAuthenticated, userType]);

  async function registerForPush(
    Notifications: typeof import('expo-notifications'),
    isActive: () => boolean,
  ) {
    try {
      if (!Device.isDevice) return;

      const existingPermission = await Notifications.getPermissionsAsync() as { granted?: boolean };
      if (!isActive()) return;
      const existing = existingPermission.granted ? 'granted' : 'denied';
      let finalStatus = existing;
      if (existing !== 'granted') {
        const requestedPermission = await Notifications.requestPermissionsAsync() as { granted?: boolean };
        if (!isActive()) return;
        finalStatus = requestedPermission.granted ? 'granted' : 'denied';
      }
      if (finalStatus !== 'granted') return;

      const messagingMod = await import('@react-native-firebase/messaging');
      const messaging: FirebaseMessagingModule = messagingMod.default;

      if (Platform.OS === 'ios') {
        await messaging().registerDeviceForRemoteMessages();
      }

      const token = await messaging().getToken();
      if (!token || !isActive()) return;

      await uploadToken(token);
    } catch {
      // Non-critical
    }
  }

  async function uploadToken(token: string) {
    const { updateFcmToken } = await import('../api/v1/vendor/profile');
    const { updateDriverFcmToken } = await import('../api/v1/driver/profile');

    if (userType === 'vendor') {
      await updateFcmToken(token);
    } else if (userType === 'driver') {
      await updateDriverFcmToken(token);
    }
  }
}
