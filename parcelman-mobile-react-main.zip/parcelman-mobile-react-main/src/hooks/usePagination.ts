import { useState, useCallback } from 'react';

interface UsePaginationOptions {
  limit?: number;
}

export function usePagination({ limit = 20 }: UsePaginationOptions = {}) {
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  const reset = useCallback(() => {
    setOffset(0);
    setHasMore(true);
  }, []);

  const onLoadMore = useCallback(() => {
    if (!hasMore || isLoadingMore) return;
    setOffset((prev) => prev + limit);
  }, [hasMore, isLoadingMore, limit]);

  const updatePagination = useCallback(
    (total: number, currentItems: number) => {
      setHasMore(offset + currentItems < total);
      setIsLoadingMore(false);
    },
    [offset],
  );

  return {
    offset,
    limit,
    hasMore,
    isLoadingMore,
    setIsLoadingMore,
    reset,
    onLoadMore,
    updatePagination,
  };
}
