import { View, Text, StyleSheet } from 'react-native';
import { fontFamily, fontSize } from '../../constants/typography';
import { spacing, borderRadius } from '../../constants/spacing';
import {
  shipmentStatusConfig,
  pickupStatusConfig,
  transportStatusConfig,
  deliveryRunStatusConfig,
  deliveryStopStatusConfig,
} from '../../constants/statuses';
import { colors } from '../../constants/colors';

const allConfigs = {
  ...shipmentStatusConfig,
  ...pickupStatusConfig,
  ...transportStatusConfig,
  ...deliveryRunStatusConfig,
  ...deliveryStopStatusConfig,
};

const readableStatusStyles: Record<string, { color: string; bgColor: string }> = {
  assigned: { color: '#1e40af', bgColor: '#dbeafe' },
  submitted: { color: '#1e40af', bgColor: '#dbeafe' },
  out_for_delivery: { color: '#c2410c', bgColor: '#ffedd5' },
  partially_delivered: { color: '#92400e', bgColor: '#fef3c7' },
  en_route: { color: '#c2410c', bgColor: '#ffedd5' },
  arrived: { color: '#c2410c', bgColor: '#ffedd5' },
  picked_up: { color: '#c2410c', bgColor: '#ffedd5' },
  pickup_assigned: { color: '#c2410c', bgColor: '#ffedd5' },
  picking_up: { color: '#c2410c', bgColor: '#ffedd5' },
  loading: { color: '#c2410c', bgColor: '#ffedd5' },
  in_transit: { color: '#c2410c', bgColor: '#ffedd5' },
  at_destination: { color: '#c2410c', bgColor: '#ffedd5' },
  delivered: { color: '#047857', bgColor: '#dcfce7' },
  handed_off: { color: '#047857', bgColor: '#dcfce7' },
  completed: { color: '#047857', bgColor: '#dcfce7' },
  received: { color: '#047857', bgColor: '#dcfce7' },
  accepted: { color: '#047857', bgColor: '#dcfce7' },
  failed: { color: '#b91c1c', bgColor: '#fee2e2' },
  cancelled: { color: '#b91c1c', bgColor: '#fee2e2' },
  rejected: { color: '#b91c1c', bgColor: '#fee2e2' },
  draft: { color: colors.text, bgColor: colors.neutral100 },
  pending: { color: colors.text, bgColor: colors.neutral100 },
};

interface StatusBadgeProps {
  status: string;
  label?: string;
}

export default function StatusBadge({ status, label }: StatusBadgeProps) {
  if (!status) {
    return (
      <View style={[styles.badge, { backgroundColor: colors.neutral100 }]}>
        <Text style={[styles.text, { color: colors.textMuted }]}>{label || '—'}</Text>
      </View>
    );
  }

  const config = (allConfigs as any)[status] || {
    label: status.replace(/_/g, ' ').replace(/\b\w/g, (c: string) => c.toUpperCase()),
    color: colors.textMuted,
    bgColor: colors.neutral100,
  };
  const readable = readableStatusStyles[status] || { color: config.color, bgColor: config.bgColor };

  return (
    <View style={[styles.badge, { backgroundColor: readable.bgColor }]}>
      <Text style={[styles.text, { color: readable.color }]}>
        {label || config.label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
    alignSelf: 'flex-start',
  },
  text: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.labelSm,
    includeFontPadding: false,
  },
});
