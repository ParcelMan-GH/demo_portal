import { useRef, useState, useEffect } from 'react';
import {
  View,
  TextInput,
  StyleSheet,
  Pressable,
  Text,
  Platform,
} from 'react-native';
import * as Haptics from 'expo-haptics';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { borderRadius, spacing } from '../../constants/spacing';

interface OtpInputProps {
  length?: number;
  value: string;
  onChangeText: (text: string) => void;
  onComplete?: (code: string) => void;
  error?: string;
  autoFocus?: boolean;
}

export default function OtpInput({
  length = 6,
  value,
  onChangeText,
  onComplete,
  error,
  autoFocus = true,
}: OtpInputProps) {
  const inputRef = useRef<TextInput>(null);
  const [isFocused, setIsFocused] = useState(false);
  const completedRef = useRef(false);

  useEffect(() => {
    if (autoFocus) {
      // Longer delay for Android to ensure keyboard is ready
      const delay = Platform.OS === 'android' ? 600 : 300;
      setTimeout(() => inputRef.current?.focus(), delay);
    }
  }, []);

  useEffect(() => {
    if (value.length === length && !completedRef.current) {
      completedRef.current = true;
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      onComplete?.(value);
    }
    if (value.length < length) {
      completedRef.current = false;
    }
  }, [value, length]);

  const handlePress = () => {
    inputRef.current?.focus();
  };

  const handleChange = (text: string) => {
    // Handle paste: take only digits
    const cleaned = text.replace(/[^0-9]/g, '');
    const trimmed = cleaned.slice(0, length);

    if (trimmed.length > value.length) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    onChangeText(trimmed);
  };

  const digits = value.split('').concat(Array(length - value.length).fill(''));

  return (
    <View>
      <Pressable onPress={handlePress} style={styles.container}>
        {digits.map((digit, index) => {
          const isActive = isFocused && index === value.length;
          const isFilled = digit !== '';
          const hasError = !!error;

          return (
            <View
              key={index}
              style={[
                styles.box,
                isActive && styles.boxFocused,
                hasError && styles.boxError,
              ]}
            >
              {isActive && <View style={styles.cursor} />}
              <Text style={styles.digit}>{digit}</Text>

              <View
                style={[
                  styles.bottomBorder,
                  {
                    backgroundColor: hasError
                      ? colors.error
                      : isActive || isFilled
                        ? colors.primary
                        : colors.neutral300,
                    height: isActive ? 3 : 2,
                  },
                ]}
              />
            </View>
          );
        })}
      </Pressable>

      {/* Real input — positioned off-screen but still focusable */}
      <TextInput
        ref={inputRef}
        value={value}
        onChangeText={handleChange}
        keyboardType="number-pad"
        maxLength={length}
        style={styles.hiddenInput}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        autoComplete="sms-otp"
        textContentType="oneTimeCode"
        caretHidden
        selectionColor="transparent"
        importantForAutofill="yes"
      />

      {error && <Text style={styles.errorText}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: spacing.md,
  },
  box: {
    flex: 1,
    height: 56,
    backgroundColor: `${colors.primary}1A`,
    borderTopLeftRadius: borderRadius.sm,
    borderTopRightRadius: borderRadius.sm,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  boxFocused: {
    backgroundColor: `${colors.primary}26`,
  },
  boxError: {
    backgroundColor: `${colors.error}1A`,
  },
  digit: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.headingMd,
    color: colors.dark,
  },
  cursor: {
    position: 'absolute',
    width: 2,
    height: 24,
    backgroundColor: colors.primary,
  },
  bottomBorder: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  hiddenInput: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    opacity: 0,
    fontSize: 1,
    color: 'transparent',
  },
  errorText: {
    fontFamily: fontFamily.regular,
    fontSize: 10,
    color: colors.error,
    marginTop: spacing.md,
    textAlign: 'center',
  },
});
