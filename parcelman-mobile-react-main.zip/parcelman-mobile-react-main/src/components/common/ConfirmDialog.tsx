import { useState } from 'react';
import {
  View, Text, Modal, StyleSheet, TouchableOpacity, ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { fontFamily } from '../../constants/typography';

type DialogType = 'warning' | 'error' | 'success' | 'info';

interface ConfirmDialogProps {
  visible: boolean;
  type?: DialogType;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void | Promise<void>;
  onCancel: () => void;
  loading?: boolean;
}

const typeConfig: Record<DialogType, {
  icon: keyof typeof Ionicons.glyphMap;
  iconBg: string;
  iconColor: string;
  confirmBg: string;
}> = {
  warning: {
    icon: 'alert-circle',
    iconBg: colors.warningLight,
    iconColor: colors.warningDark,
    confirmBg: colors.warningDark,
  },
  error: {
    icon: 'close-circle',
    iconBg: colors.errorLight,
    iconColor: colors.error,
    confirmBg: colors.error,
  },
  success: {
    icon: 'checkmark-circle',
    iconBg: colors.successLight,
    iconColor: colors.success,
    confirmBg: colors.success,
  },
  info: {
    icon: 'information-circle',
    iconBg: colors.infoLight,
    iconColor: colors.infoDark,
    confirmBg: colors.infoDark,
  },
};

export default function ConfirmDialog({
  visible, type = 'warning', title, message,
  confirmText = 'Confirm', cancelText = 'Cancel',
  onConfirm, onCancel, loading = false,
}: ConfirmDialogProps) {
  const [asyncLoading, setAsyncLoading] = useState(false);
  const config = typeConfig[type];
  const isLoading = loading || asyncLoading;

  const handleConfirm = async () => {
    const result = onConfirm();
    if (result instanceof Promise) {
      setAsyncLoading(true);
      try { await result; } catch {} finally { setAsyncLoading(false); }
    }
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <View style={s.overlay}>
        <View style={s.dialog}>
          <View style={[s.iconWrap, { backgroundColor: config.iconBg }]}>
            <Ionicons name={config.icon} size={32} color={config.iconColor} />
          </View>

          <View style={{ height: 16 }} />

          <Text style={s.title}>{title}</Text>
          <View style={{ height: 8 }} />
          <Text style={s.message}>{message}</Text>

          <View style={{ height: 24 }} />

          <View style={s.buttons}>
            <TouchableOpacity style={s.cancelBtn} onPress={onCancel} disabled={isLoading}>
              <Text style={s.cancelText}>{cancelText}</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[s.confirmBtn, { backgroundColor: config.confirmBg }]}
              onPress={handleConfirm}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator size="small" color={colors.white} />
              ) : (
                <Text style={s.confirmText}>{confirmText}</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  dialog: {
    width: '100%',
    backgroundColor: colors.white,
    borderRadius: 24,
    padding: 24,
    alignItems: 'center',
  },
  iconWrap: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontFamily: fontFamily.bold,
    fontSize: 18,
    color: colors.dark,
    textAlign: 'center',
  },
  message: {
    fontFamily: fontFamily.regular,
    fontSize: 14,
    color: colors.neutral600,
    textAlign: 'center',
    lineHeight: 20,
  },
  buttons: {
    gap: 10,
    width: '100%',
  },
  cancelBtn: {
    paddingVertical: 14,
    borderRadius: 24,
    borderWidth: 1.5,
    borderColor: colors.neutral300,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelText: {
    fontFamily: fontFamily.semibold,
    fontSize: 14,
    color: colors.dark,
  },
  confirmBtn: {
    paddingVertical: 14,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmText: {
    fontFamily: fontFamily.semibold,
    fontSize: 14,
    color: colors.white,
  },
});
