import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { spacing } from '../../constants/spacing';

interface StepIndicatorProps {
  steps: string[];
  currentStep: number;
}

export default function StepIndicator({ steps, currentStep }: StepIndicatorProps) {
  return (
    <View style={styles.container}>
      {steps.map((step, index) => {
        const isCompleted = index < currentStep;
        const isCurrent = index === currentStep;
        const isLast = index === steps.length - 1;

        return (
          <View key={index} style={styles.stepRow}>
            <View style={styles.stepItem}>
              <View
                style={[
                  styles.circle,
                  isCompleted && styles.circleCompleted,
                  isCurrent && styles.circleCurrent,
                ]}
              >
                <Text
                  style={[
                    styles.circleText,
                    (isCompleted || isCurrent) && styles.circleTextActive,
                  ]}
                >
                  {isCompleted ? '✓' : String(index + 1)}
                </Text>
              </View>
              <Text
                style={[
                  styles.stepLabel,
                  (isCompleted || isCurrent) && styles.stepLabelActive,
                ]}
                numberOfLines={1}
              >
                {step}
              </Text>
            </View>

            {!isLast && (
              <View
                style={[
                  styles.line,
                  isCompleted && styles.lineCompleted,
                ]}
              />
            )}
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.lg,
  },
  stepRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepItem: {
    alignItems: 'center',
    gap: spacing.sm,
  },
  circle: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.neutral200,
    justifyContent: 'center',
    alignItems: 'center',
  },
  circleCompleted: {
    backgroundColor: colors.success,
  },
  circleCurrent: {
    backgroundColor: colors.primary,
  },
  circleText: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.labelSm,
    color: colors.textMuted,
  },
  circleTextActive: {
    color: colors.white,
  },
  stepLabel: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.labelXs,
    color: colors.textMuted,
    textAlign: 'center',
    maxWidth: 60,
  },
  stepLabelActive: {
    fontFamily: fontFamily.medium,
    color: colors.dark,
  },
  line: {
    flex: 1,
    height: 2,
    backgroundColor: colors.neutral200,
    marginHorizontal: spacing.sm,
    marginBottom: 18,
  },
  lineCompleted: {
    backgroundColor: colors.success,
  },
});
