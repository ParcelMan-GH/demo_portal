import { Text, StyleSheet, View } from "react-native";
import { colors } from "../../constants/colors";
import { fontFamily } from "../../constants/typography";

interface DateGroupHeaderProps {
  label: string;
}

export default function DateGroupHeader({ label }: DateGroupHeaderProps) {
  return (
    <View style={s.wrap}>
      <Text style={s.label}>{label}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: {
    alignSelf: "flex-start",
    marginTop: 4,
    marginBottom: 0,
  },
  label: {
    fontFamily: fontFamily.semibold,
    fontSize: 11,
    color: colors.primary,
    textTransform: "uppercase",
    letterSpacing: 0,
  },
});
