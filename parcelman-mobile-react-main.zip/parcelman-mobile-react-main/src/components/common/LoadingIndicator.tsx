import { ActivityIndicator } from 'react-native';
import { colors } from '../../constants/colors';

interface LoadingIndicatorProps {
  size?: number;
  color?: string;
}

export default function LoadingIndicator({
  size = 20,
  color = colors.white,
}: LoadingIndicatorProps) {
  return <ActivityIndicator size={size} color={color} />;
}
