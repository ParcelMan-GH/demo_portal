import { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Modal,
  FlatList,
  StyleSheet,
  ViewStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { borderRadius, spacing } from '../../constants/spacing';

interface DropdownOption {
  label: string;
  value: string | number;
}

interface DropdownProps {
  label?: string;
  required?: boolean;
  placeholder?: string;
  options: DropdownOption[];
  value: string | number | null;
  onSelect: (value: string | number) => void;
  error?: string;
  containerStyle?: ViewStyle;
}

export default function Dropdown({
  label,
  required = false,
  placeholder = 'Select an option',
  options,
  value,
  onSelect,
  error,
  containerStyle,
}: DropdownProps) {
  const [visible, setVisible] = useState(false);
  const selectedOption = options.find((o) => o.value === value);

  return (
    <View style={[styles.container, containerStyle]}>
      {label && (
        <Text style={styles.label}>
          {label}
          {required && <Text style={styles.required}> *</Text>}
        </Text>
      )}

      <TouchableOpacity
        style={[styles.trigger, error ? styles.triggerError : undefined]}
        onPress={() => setVisible(true)}
        activeOpacity={0.7}
      >
        <Text style={[styles.triggerText, !selectedOption && styles.placeholder]}>
          {selectedOption?.label || placeholder}
        </Text>
        <Ionicons name="chevron-down" size={20} color={colors.textMuted} />
      </TouchableOpacity>

      {error && <Text style={styles.errorText}>{error}</Text>}

      <Modal visible={visible} transparent animationType="fade" onRequestClose={() => setVisible(false)}>
        <TouchableOpacity
          style={styles.overlay}
          activeOpacity={1}
          onPress={() => setVisible(false)}
        >
          <View style={styles.dropdown}>
            <FlatList
              data={options}
              keyExtractor={(item) => String(item.value)}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.option,
                    item.value === value && styles.optionSelected,
                  ]}
                  onPress={() => {
                    onSelect(item.value);
                    setVisible(false);
                  }}
                >
                  <Text
                    style={[
                      styles.optionText,
                      item.value === value && styles.optionTextSelected,
                    ]}
                  >
                    {item.label}
                  </Text>
                  {item.value === value && (
                    <Ionicons name="checkmark" size={20} color={colors.primary} />
                  )}
                </TouchableOpacity>
              )}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
  },
  label: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.bodySm,
    color: colors.dark,
    marginBottom: spacing.sm,
  },
  required: {
    color: colors.error,
  },
  trigger: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.warmSurface,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
    borderBottomWidth: 2,
    borderBottomColor: colors.primary,
    paddingVertical: 14,
    paddingHorizontal: 12,
  },
  triggerError: {
    borderBottomColor: colors.error,
  },
  triggerText: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.dark,
    flex: 1,
  },
  placeholder: {
    color: colors.textLight,
  },
  errorText: {
    fontFamily: fontFamily.regular,
    fontSize: 10,
    color: colors.error,
    marginTop: spacing.sm,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    padding: 32,
  },
  dropdown: {
    backgroundColor: colors.white,
    borderRadius: borderRadius.xl,
    maxHeight: 300,
    overflow: 'hidden',
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.neutral100,
  },
  optionSelected: {
    backgroundColor: colors.warmSurface,
  },
  optionText: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.dark,
  },
  optionTextSelected: {
    fontFamily: fontFamily.medium,
    color: colors.primary,
  },
});
