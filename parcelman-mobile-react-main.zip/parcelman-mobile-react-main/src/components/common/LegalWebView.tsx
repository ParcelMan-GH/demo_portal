import { useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Dimensions } from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { WebView } from "react-native-webview";
import { colors } from "../../constants/colors";
import { fontFamily } from "../../constants/typography";
import { API_BASE_URL } from "../../constants/api";

const { width } = Dimensions.get("window");

type Props = {
  /** Path on the Parcelman web app, e.g. "privacy-policy" or "terms-of-service". */
  slug: string;
  title: string;
  subtitle?: string;
  /** Fallback route if there is no back stack. */
  fallbackRoute: string;
};

export default function LegalWebView({ slug, title, subtitle, fallbackRoute }: Props) {
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  // Bumped on retry to force a fresh WebView mount (and reload).
  const [reloadKey, setReloadKey] = useState(0);

  // `app=1` tells the web layout to drop its header/footer chrome so the page
  // sits cleanly inside the native screen (which provides its own back header).
  const uri = `${API_BASE_URL}/${slug}?app=1`;

  const goBack = () => {
    if (router.canGoBack()) router.back();
    else router.replace(fallbackRoute as any);
  };

  return (
    <View style={s.container}>
      {/* Hero Header — extends behind the translucent status bar */}
      <LinearGradient
        colors={["#1e293b", "#334155", "#1e293b"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[s.hero, { paddingTop: insets.top + 12 }]}
      >
        <View style={s.heroDecor1} />
        <View style={s.heroDecor2} />

        <View style={s.headerRow}>
          <TouchableOpacity onPress={goBack} style={s.backBtn} accessibilityLabel="Go back">
            <Ionicons name="arrow-back" size={22} color={colors.white} />
          </TouchableOpacity>
          <View style={s.headerCopy}>
            <Text style={s.headerTitle}>{title}</Text>
            {!!subtitle && <Text style={s.headerSub}>{subtitle}</Text>}
          </View>
        </View>
      </LinearGradient>

      {/* Web content */}
      <View style={s.body}>
        {error ? (
          <View style={s.stateWrap}>
            <Ionicons name="cloud-offline-outline" size={40} color={colors.textMuted} />
            <Text style={s.stateTitle}>Couldn't load this page</Text>
            <Text style={s.stateText}>Check your internet connection and try again.</Text>
            <TouchableOpacity
              style={s.retryBtn}
              onPress={() => {
                setError(false);
                setLoading(true);
                setReloadKey((k) => k + 1);
              }}
            >
              <Text style={s.retryText}>Retry</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            <WebView
              key={reloadKey}
              source={{ uri }}
              originWhitelist={["*"]}
              onLoadEnd={() => setLoading(false)}
              onError={() => {
                setLoading(false);
                setError(true);
              }}
              onHttpError={(e) => {
                // Only treat a failure of the main document as an error,
                // not a subresource (fonts, CDN scripts, etc.).
                const failedUrl = e.nativeEvent?.url || "";
                if (failedUrl.includes(`/${slug}`)) {
                  setLoading(false);
                  setError(true);
                }
              }}
              style={s.webview}
            />
            {loading && (
              <View style={s.loadingWrap} pointerEvents="none">
                <ActivityIndicator size="large" color={colors.primary} />
              </View>
            )}
          </>
        )}
      </View>

      {/* Safe-area filler at the bottom */}
      <View style={{ height: insets.bottom, backgroundColor: colors.background }} />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  hero: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 24, gap: 16, overflow: "hidden" },
  heroDecor1: { position: "absolute", top: -50, right: -30, width: width * 0.5, height: width * 0.5, borderWidth: 50, borderColor: "rgba(255,255,255,0.03)", borderRadius: width * 0.25, transform: [{ rotate: "20deg" }] },
  heroDecor2: { position: "absolute", bottom: -60, left: -40, width: width * 0.4, height: width * 0.4, borderWidth: 40, borderColor: "rgba(255,255,255,0.02)", borderRadius: width * 0.2 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.1)", justifyContent: "center", alignItems: "center" },
  headerCopy: { flex: 1, minWidth: 0 },
  headerTitle: { fontFamily: fontFamily.semibold, fontSize: 18, color: colors.white },
  headerSub: { fontFamily: fontFamily.regular, fontSize: 12, color: "rgba(255,255,255,0.55)", marginTop: 2 },
  body: { flex: 1, backgroundColor: colors.white },
  webview: { flex: 1, backgroundColor: colors.white },
  loadingWrap: { ...StyleSheet.absoluteFillObject, justifyContent: "center", alignItems: "center", backgroundColor: colors.white },
  stateWrap: { flex: 1, justifyContent: "center", alignItems: "center", paddingHorizontal: 32, gap: 8 },
  stateTitle: { fontFamily: fontFamily.semibold, fontSize: 16, color: colors.text, marginTop: 8 },
  stateText: { fontFamily: fontFamily.regular, fontSize: 13, color: colors.textMuted, textAlign: "center" },
  retryBtn: { marginTop: 16, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 10, backgroundColor: colors.primary },
  retryText: { fontFamily: fontFamily.semibold, fontSize: 14, color: colors.white },
});
