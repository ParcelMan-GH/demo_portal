import { useRef, useState, useEffect } from "react";
import { View, Text, StyleSheet, Animated, PanResponder, ActivityIndicator } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { colors } from "../../constants/colors";
import { fontFamily } from "../../constants/typography";

const THUMB_SIZE = 52;
const TRACK_HEIGHT = 56;

interface SlideToConfirmProps {
  title: string;
  onConfirm: () => void;
  loading?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
}

export default function SlideToConfirm({ title, onConfirm, loading, icon = "arrow-forward" }: SlideToConfirmProps) {
  const translateX = useRef(new Animated.Value(0)).current;
  const [trackWidth, setTrackWidth] = useState(0);
  const triggered = useRef(false);

  // When loading finishes, reset the thumb
  useEffect(() => {
    if (!loading && triggered.current) {
      triggered.current = false;
      Animated.spring(translateX, { toValue: 0, useNativeDriver: true }).start();
    }
  }, [loading]);

  const getMax = () => Math.max(trackWidth - THUMB_SIZE - 8, 0);

  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => !loading && !triggered.current,
    onStartShouldSetPanResponderCapture: () => !loading && !triggered.current,
    onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dx) > 5 && !loading && !triggered.current,
    onMoveShouldSetPanResponderCapture: (_, g) =>
      Math.abs(g.dx) > Math.abs(g.dy) && Math.abs(g.dx) > 4 && !loading && !triggered.current,
    onPanResponderTerminationRequest: () => false,
    onShouldBlockNativeResponder: () => true,
    onPanResponderMove: (_, gestureState) => {
      if (triggered.current || loading) return;
      const max = getMax();
      const x = Math.max(0, Math.min(gestureState.dx, max));
      translateX.setValue(x);
    },
    onPanResponderRelease: (_, gestureState) => {
      if (triggered.current || loading) return;
      const max = getMax();
      if (max > 0 && gestureState.dx >= max * 0.75) {
        triggered.current = true;
        Animated.spring(translateX, { toValue: max, useNativeDriver: true }).start(() => {
          onConfirm();
        });
      } else {
        Animated.spring(translateX, { toValue: 0, useNativeDriver: true, friction: 5 }).start();
      }
    },
  });

  const max = getMax();
  const textOpacity = translateX.interpolate({
    inputRange: [0, max > 0 ? max * 0.4 : 1],
    outputRange: [1, 0],
    extrapolate: "clamp",
  });

  return (
    <View
      style={[s.track, loading && s.trackLoading]}
      onLayout={(e) => setTrackWidth(e.nativeEvent.layout.width)}
      {...(!loading ? panResponder.panHandlers : {})}
    >
      <LinearGradient
        colors={loading ? ["#94a3b8", "#94a3b8"] : [colors.primary, colors.primaryLight]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={s.trackGradient}
      />
      <Animated.Text style={[s.trackText, { opacity: loading ? 1 : textOpacity }]}>
        {loading ? "Processing..." : title}
      </Animated.Text>
      {loading ? (
        <View style={[s.thumb, s.thumbLoading]}>
          <ActivityIndicator size="small" color={colors.primary} />
        </View>
      ) : (
        <Animated.View
          style={[s.thumb, { transform: [{ translateX }] }]}
        >
          <Ionicons name={icon} size={22} color={colors.primary} />
        </Animated.View>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  track: {
    height: TRACK_HEIGHT,
    borderRadius: TRACK_HEIGHT / 2,
    overflow: "hidden",
    justifyContent: "center",
  },
  trackLoading: {
    opacity: 0.85,
  },
  trackGradient: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: TRACK_HEIGHT / 2,
  },
  trackText: {
    fontFamily: fontFamily.semibold,
    fontSize: 15,
    color: "rgba(255,255,255,0.9)",
    textAlign: "center",
    marginLeft: THUMB_SIZE,
  },
  thumb: {
    position: "absolute",
    left: 4,
    width: THUMB_SIZE - 8,
    height: THUMB_SIZE - 8,
    borderRadius: (THUMB_SIZE - 8) / 2,
    backgroundColor: colors.white,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 3,
  },
  thumbLoading: {
    left: 4,
  },
});
