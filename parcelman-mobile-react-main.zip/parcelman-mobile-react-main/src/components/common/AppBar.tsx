import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { spacing } from '../../constants/spacing';
import { ReactNode } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

interface AppBarProps {
  title?: string;
  showBack?: boolean;
  onBackPress?: () => void;
  actions?: ReactNode;
  backgroundColor?: string;
  titleColor?: string;
}

export default function AppBar({
  title,
  showBack = false,
  onBackPress,
  actions,
  backgroundColor = 'transparent',
  titleColor = colors.dark,
}: AppBarProps) {
  const insets = useSafeAreaInsets();

  const handleBack = () => {
    if (onBackPress) {
      onBackPress();
    } else {
      router.back();
    }
  };

  return (
    <View style={[styles.container, { backgroundColor, paddingTop: insets.top }]}>
      <View style={styles.content}>
        <View style={styles.leading}>
          {showBack && (
            <TouchableOpacity onPress={handleBack} style={styles.backButton}>
              <Ionicons name="arrow-back" size={24} color={titleColor} />
            </TouchableOpacity>
          )}
        </View>

        {title && (
          <Text style={[styles.title, { color: titleColor }]} numberOfLines={1}>
            {title}
          </Text>
        )}

        <View style={styles.actions}>{actions}</View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    elevation: 0,
  },
  content: {
    height: 56,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
  },
  leading: {
    width: 40,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    flex: 1,
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.titleMd,
    textAlign: 'center',
  },
  actions: {
    width: 40,
    alignItems: 'flex-end',
  },
});
