import {
  TouchableOpacity,
  Text,
  View,
  ActivityIndicator,
  StyleSheet,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { colors } from '../../constants/colors';
import { fontFamily } from '../../constants/typography';
import { borderRadius } from '../../constants/spacing';
import { ReactNode } from 'react';

interface ButtonProps {
  title: string;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  height?: number;
  style?: ViewStyle;
  textStyle?: TextStyle;
  gradientColors?: readonly [string, string];
}

export default function Button({
  title,
  onPress,
  loading = false,
  disabled = false,
  leftIcon,
  rightIcon,
  height = 50,
  style,
  textStyle,
  gradientColors = colors.buttonGradient,
}: ButtonProps) {
  const isDisabled = disabled || loading;
  const backgroundColor = gradientColors[0] || colors.primary;

  const inner = loading ? (
    <ActivityIndicator size={20} color={colors.white} />
  ) : (
    <View style={styles.content}>
      {leftIcon && <View style={styles.iconLeft}>{leftIcon}</View>}
      <Text style={[styles.text, textStyle]}>{title}</Text>
      {rightIcon && <View style={styles.iconRight}>{rightIcon}</View>}
    </View>
  );

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={isDisabled}
      activeOpacity={1}
      style={[
        styles.buttonWrap,
        styles.buttonSurface,
        { height, backgroundColor },
        isDisabled && styles.disabledWrap,
        style,
      ]}
    >
      {inner}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  buttonWrap: {
    width: '100%',
  },
  disabledWrap: {
    opacity: 0.6,
  },
  buttonSurface: {
    borderRadius: borderRadius['3xl'],
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    shadowColor: colors.dark,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    color: colors.white,
    fontFamily: fontFamily.medium,
    fontSize: 14,
    letterSpacing: 0.5,
  },
  iconLeft: {
    marginRight: 8,
  },
  iconRight: {
    marginLeft: 8,
  },
});
