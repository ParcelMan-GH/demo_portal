import { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  StyleSheet,
  Alert,
  ScrollView,
  Modal,
  Pressable,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { compressToUnder2MB, compressMany } from '../../utils/image';
import { captureSinglePhoto, isIosSimulator } from '../../utils/cameraCapture';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { borderRadius, spacing } from '../../constants/spacing';

interface ImagePickerButtonProps {
  images: string[];
  onImagesChange: (images: string[]) => void;
  maxImages?: number;
  label?: string;
}

export default function ImagePickerButton({
  images,
  onImagesChange,
  maxImages = 5,
  label = 'Add Photos',
}: ImagePickerButtonProps) {
  const [showPicker, setShowPicker] = useState(false);

  const pickImage = async () => {
    setShowPicker(false);
    if (images.length >= maxImages) {
      Alert.alert('Limit reached', `You can only add up to ${maxImages} images.`);
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsMultipleSelection: true,
      quality: 0.8,
      selectionLimit: maxImages - images.length,
    });

    if (!result.canceled) {
      const compressed = await compressMany(result.assets.map((a) => a.uri));
      if (compressed.length > 0) {
        onImagesChange([...images, ...compressed].slice(0, maxImages));
      }
    }
  };

  const takePhoto = async () => {
    setShowPicker(false);
    if (images.length >= maxImages) {
      Alert.alert('Limit reached', `You can only add up to ${maxImages} images.`);
      return;
    }

    const capturedUri = await captureSinglePhoto({ quality: 0.6, simulatorBehavior: 'sample' });
    if (!capturedUri) return;

    const compressed = await compressToUnder2MB(capturedUri);
    onImagesChange([...images, compressed].slice(0, maxImages));
  };

  const removeImage = (index: number) => {
    onImagesChange(images.filter((_, i) => i !== index));
  };

  return (
    <View style={styles.container}>
      {label && (
        <Text style={styles.label}>
          {label} ({images.length}/{maxImages})
        </Text>
      )}

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.scroll}>
        {images.map((uri, index) => (
          <View key={index} style={styles.imageWrapper}>
            <Image source={{ uri }} style={styles.image} />
            <TouchableOpacity
              style={styles.removeBtn}
              onPress={() => removeImage(index)}
            >
              <Ionicons name="close-circle" size={22} color={colors.error} />
            </TouchableOpacity>
          </View>
        ))}

        {images.length < maxImages && (
          <TouchableOpacity style={styles.addButton} onPress={() => setShowPicker(true)}>
            <Ionicons name="camera-outline" size={28} color={colors.primary} />
            <Text style={styles.addText}>Add</Text>
          </TouchableOpacity>
        )}
      </ScrollView>

      {/* Custom bottom sheet picker */}
      <Modal visible={showPicker} transparent animationType="slide" onRequestClose={() => setShowPicker(false)}>
        <Pressable style={styles.overlay} onPress={() => setShowPicker(false)}>
          <View style={styles.sheet}>
            <View style={styles.sheetHandle} />
            <Text style={styles.sheetTitle}>Add Photo</Text>
            <Text style={styles.sheetSub}>Choose where to get your photo from</Text>

            <View style={styles.sheetOptions}>
              <TouchableOpacity style={styles.sheetOption} onPress={takePhoto} activeOpacity={0.7}>
                <View style={[styles.sheetOptionIcon, { backgroundColor: '#dbeafe' }]}>
                  <Ionicons name="camera" size={24} color="#3b82f6" />
                </View>
                <Text style={styles.sheetOptionTitle}>{isIosSimulator() ? 'Test Camera' : 'Camera'}</Text>
                <Text style={styles.sheetOptionSub}>{isIosSimulator() ? 'Use the built-in test photo' : 'Take a new photo'}</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.sheetOption} onPress={pickImage} activeOpacity={0.7}>
                <View style={[styles.sheetOptionIcon, { backgroundColor: '#dcfce7' }]}>
                  <Ionicons name="images" size={24} color="#16a34a" />
                </View>
                <Text style={styles.sheetOptionTitle}>Gallery</Text>
                <Text style={styles.sheetOptionSub}>Choose from library</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.sheetCancel} onPress={() => setShowPicker(false)}>
              <Text style={styles.sheetCancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
  },
  label: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.bodySm,
    color: colors.dark,
    marginBottom: spacing.md,
  },
  scroll: {
    flexDirection: 'row',
    overflow: 'visible',
    paddingTop: 8,
    paddingRight: 8,
  },
  imageWrapper: {
    position: 'relative',
    marginRight: spacing.lg,
  },
  image: {
    width: 80,
    height: 80,
    borderRadius: borderRadius.lg,
  },
  removeBtn: {
    position: 'absolute',
    top: -6,
    right: -6,
    backgroundColor: colors.white,
    borderRadius: 11,
  },
  addButton: {
    width: 80,
    height: 80,
    borderRadius: borderRadius.lg,
    borderWidth: 2,
    borderColor: colors.border,
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.surface,
  },
  addText: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.labelSm,
    color: colors.primary,
    marginTop: 2,
  },
  // Bottom sheet
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: colors.white,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingBottom: 34,
    paddingTop: 12,
  },
  sheetHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.neutral300,
    alignSelf: 'center',
    marginBottom: 16,
  },
  sheetTitle: {
    fontFamily: fontFamily.bold,
    fontSize: 20,
    color: colors.dark,
    textAlign: 'center',
  },
  sheetSub: {
    fontFamily: fontFamily.regular,
    fontSize: 13,
    color: colors.textMuted,
    textAlign: 'center',
    marginTop: 4,
    marginBottom: 20,
  },
  sheetOptions: {
    flexDirection: 'row',
    gap: 12,
  },
  sheetOption: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 16,
    paddingVertical: 20,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 6,
  },
  sheetOptionIcon: {
    width: 52,
    height: 52,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  sheetOptionTitle: {
    fontFamily: fontFamily.semibold,
    fontSize: 15,
    color: colors.dark,
  },
  sheetOptionSub: {
    fontFamily: fontFamily.regular,
    fontSize: 11,
    color: colors.textMuted,
  },
  sheetCancel: {
    marginTop: 16,
    paddingVertical: 14,
    borderRadius: 12,
    backgroundColor: colors.surface,
    alignItems: 'center',
  },
  sheetCancelText: {
    fontFamily: fontFamily.medium,
    fontSize: 15,
    color: colors.textMuted,
  },
});
