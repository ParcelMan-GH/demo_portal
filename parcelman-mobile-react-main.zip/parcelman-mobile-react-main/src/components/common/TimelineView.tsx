import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { spacing } from '../../constants/spacing';

interface TimelineEvent {
  label: string;
  timestamp?: string | null;
  icon?: keyof typeof Ionicons.glyphMap;
  status: 'completed' | 'current' | 'pending';
}

interface TimelineViewProps {
  events: TimelineEvent[];
}

export default function TimelineView({ events }: TimelineViewProps) {
  return (
    <View style={styles.container}>
      {events.map((event, index) => {
        const isLast = index === events.length - 1;
        const dotColor =
          event.status === 'completed'
            ? colors.success
            : event.status === 'current'
              ? colors.primary
              : colors.neutral300;

        return (
          <View key={index} style={styles.row}>
            {/* Dot and line */}
            <View style={styles.dotColumn}>
              <View style={[styles.dot, { backgroundColor: dotColor }]}>
                {event.status === 'completed' && (
                  <Ionicons name="checkmark" size={10} color={colors.white} />
                )}
              </View>
              {!isLast && (
                <View
                  style={[
                    styles.line,
                    {
                      backgroundColor:
                        event.status === 'completed' ? colors.success : colors.neutral200,
                    },
                  ]}
                />
              )}
            </View>

            {/* Content */}
            <View style={styles.content}>
              <Text
                style={[
                  styles.label,
                  event.status === 'pending' && styles.labelPending,
                  event.status === 'current' && styles.labelCurrent,
                ]}
              >
                {event.label}
              </Text>
              {event.timestamp && (
                <Text style={styles.timestamp}>{event.timestamp}</Text>
              )}
            </View>
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: spacing.md,
  },
  row: {
    flexDirection: 'row',
    minHeight: 40,
  },
  dotColumn: {
    width: 24,
    alignItems: 'center',
  },
  dot: {
    width: 18,
    height: 18,
    borderRadius: 9,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 2,
  },
  line: {
    width: 2,
    flex: 1,
    marginVertical: 2,
  },
  content: {
    flex: 1,
    paddingLeft: spacing.lg,
    paddingBottom: spacing.xl,
  },
  label: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.bodyMd,
    color: colors.dark,
  },
  labelPending: {
    color: colors.textMuted,
    fontFamily: fontFamily.regular,
  },
  labelCurrent: {
    color: colors.primary,
    fontFamily: fontFamily.semibold,
  },
  timestamp: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodySm,
    color: colors.textMuted,
    marginTop: 2,
  },
});
