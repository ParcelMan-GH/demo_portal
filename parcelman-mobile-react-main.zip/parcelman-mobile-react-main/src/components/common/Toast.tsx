import { useEffect, useRef, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, Animated, Pressable,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../constants/colors';
import { borderRadius, spacing } from '../../constants/spacing';
import { fontFamily, fontSize } from '../../constants/typography';

type ToastType = 'success' | 'error' | 'info' | 'warning';

interface ToastData {
  type: ToastType;
  message: string;
  id: number;
  onPress?: () => void;
  actionLabel?: string;
}

interface ToastOptions {
  onPress?: () => void;
  actionLabel?: string;
}

let globalShowToast: ((type: ToastType, message: string, options?: ToastOptions) => void) | null = null;

export function showToast(type: ToastType, message: string, options?: ToastOptions) {
  globalShowToast?.(type, message, options);
}

const toastConfig: Record<ToastType, {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
}> = {
  success: {
    label: 'Success',
    icon: 'checkmark-circle',
  },
  error: {
    label: 'Error',
    icon: 'alert-circle',
  },
  info: {
    label: 'Update',
    icon: 'information-circle',
  },
  warning: {
    label: 'Warning',
    icon: 'warning',
  },
};

function ToastItem({ toast, onDismiss }: { toast: ToastData; onDismiss: () => void }) {
  const slideAnim = useRef(new Animated.Value(-100)).current;
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dismissedRef = useRef(false);
  const config = toastConfig[toast.type];

  const dismiss = useCallback(() => {
    if (dismissedRef.current) return;
    dismissedRef.current = true;
    if (timerRef.current) clearTimeout(timerRef.current);

    Animated.timing(slideAnim, {
      toValue: -120,
      duration: 180,
      useNativeDriver: true,
    }).start(() => onDismiss());
  }, [onDismiss, slideAnim]);

  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: 0,
      useNativeDriver: true,
      tension: 80,
      friction: 12,
    }).start();

    timerRef.current = setTimeout(() => {
      dismiss();
    }, 4000);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [dismiss, slideAnim]);

  return (
    <Animated.View
      style={[
        styles.toast,
        {
          transform: [{ translateY: slideAnim }],
        },
      ]}
    >
      <View style={styles.toastContent}>
        <Pressable
          accessibilityHint={toast.onPress ? 'Opens the related work' : undefined}
          accessibilityLabel={toast.onPress ? toast.actionLabel || 'Open notification' : undefined}
          accessibilityRole={toast.onPress ? 'button' : undefined}
          disabled={!toast.onPress}
          onPress={() => {
            toast.onPress?.();
            dismiss();
          }}
          style={styles.actionContent}
        >
          <View style={styles.iconWrap}>
            <Ionicons name={config.icon} size={22} color={colors.white} />
          </View>
          <View style={styles.textWrap}>
            <Text style={styles.toastTitle} numberOfLines={1}>
              {config.label}
            </Text>
            <Text style={styles.toastText} numberOfLines={3}>
              {toast.message}
            </Text>
          </View>
        </Pressable>
        <Pressable
          accessibilityLabel="Dismiss toast"
          accessibilityRole="button"
          hitSlop={10}
          onPress={dismiss}
          style={styles.closeButton}
        >
          <Ionicons name="close" size={18} color={colors.white} />
        </Pressable>
      </View>
    </Animated.View>
  );
}

export default function ToastProvider() {
  const insets = useSafeAreaInsets();
  const [toasts, setToasts] = useState<ToastData[]>([]);
  const idRef = useRef(0);

  const addToast = useCallback((type: ToastType, message: string, options?: ToastOptions) => {
    const id = ++idRef.current;
    setToasts((prev) => [...prev.slice(-1), { type, message, id, ...options }]);
  }, []);

  useEffect(() => {
    globalShowToast = addToast;
    return () => { globalShowToast = null; };
  }, [addToast]);

  const removeToast = (id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  if (toasts.length === 0) return null;

  return (
    <View style={[styles.container, { top: insets.top + spacing.md }]} pointerEvents="box-none">
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onDismiss={() => removeToast(toast.id)} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: spacing.xl,
    right: spacing.xl,
    zIndex: 99999,
    elevation: 99999,
  },
  toast: {
    flexDirection: 'row',
    minHeight: 76,
    backgroundColor: colors.primary,
    borderRadius: borderRadius.xl,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.primaryLight,
    boxShadow: '0 14px 28px rgba(124, 45, 18, 0.32)',
    elevation: 12,
  },
  toastContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.lg,
  },
  actionContent: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  iconWrap: {
    width: 38,
    height: 38,
    borderRadius: borderRadius.full,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.18)',
  },
  textWrap: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  toastTitle: {
    color: colors.white,
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodyMd,
    lineHeight: 20,
  },
  toastText: {
    color: 'rgba(255,255,255,0.94)',
    fontFamily: fontFamily.medium,
    fontSize: fontSize.bodyMd,
    lineHeight: 20,
  },
  closeButton: {
    width: 32,
    height: 32,
    marginLeft: spacing.md,
    borderRadius: borderRadius.full,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.16)',
  },
});
