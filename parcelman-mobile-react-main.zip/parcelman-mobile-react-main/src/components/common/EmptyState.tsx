import { Image, View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { spacing } from '../../constants/spacing';

const illustrations = {
  logistics: require('../../../assets/images/empty-states/undraw-logistics.png'),
  deliveries: require('../../../assets/images/empty-states/undraw-deliveries.png'),
  deliveryLocation: require('../../../assets/images/empty-states/undraw-delivery-location.png'),
  deliveryTruck: require('../../../assets/images/empty-states/undraw-delivery-truck.png'),
  packages: require('../../../assets/images/empty-states/undraw-heavy-lifting.png'),
  team: require('../../../assets/images/empty-states/undraw-team-up.png'),
  notifications: require('../../../assets/images/empty-states/undraw-notifications.png'),
  mailbox: require('../../../assets/images/empty-states/undraw-empty-mailbox.png'),
  onTheWay: require('../../../assets/images/empty-states/undraw-on-the-way.png'),
};

interface EmptyStateProps {
  icon?: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle?: string;
  illustration?: keyof typeof illustrations;
  compact?: boolean;
  minHeight?: number;
  actionLabel?: string;
  onAction?: () => void;
}

export default function EmptyState({
  title,
  subtitle,
  illustration = 'logistics',
  compact = false,
  minHeight,
  actionLabel,
  onAction,
}: EmptyStateProps) {
  return (
    <View style={[styles.container, compact && styles.containerCompact, minHeight ? { minHeight } : null]}>
      <View style={[styles.illustration, compact && styles.illustrationCompact]}>
        <Image source={illustrations[illustration]} style={styles.illustrationImage} resizeMode="contain" />
      </View>
      <View style={styles.copy}>
        <Text style={styles.title}>{title}</Text>
        {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
      </View>
      {actionLabel && onAction ? (
        <TouchableOpacity style={styles.actionBtn} onPress={onAction} activeOpacity={0.82}>
          <Ionicons name="arrow-forward" size={18} color={colors.white} />
          <Text style={styles.actionText}>{actionLabel}</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    flexGrow: 1,
    minHeight: 300,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.transparent,
    paddingVertical: spacing['4xl'],
    paddingHorizontal: 22,
    gap: 16,
  },
  containerCompact: {
    flexGrow: 0,
    minHeight: 220,
    paddingVertical: spacing['3xl'],
  },
  illustration: {
    width: '100%',
    height: 150,
    alignItems: 'center',
    justifyContent: 'center',
  },
  illustrationCompact: {
    height: 112,
  },
  illustrationImage: {
    width: '100%',
    height: '100%',
  },
  copy: {
    alignItems: 'center',
    gap: 7,
  },
  title: {
    fontFamily: fontFamily.bold,
    fontSize: 20,
    color: colors.dark,
    textAlign: 'center',
  },
  subtitle: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.bodyMd,
    color: colors.textMuted,
    textAlign: 'center',
    lineHeight: 21,
  },
  actionBtn: {
    minWidth: 212,
    height: 54,
    borderRadius: 27,
    backgroundColor: colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.28,
    shadowRadius: 16,
    elevation: 6,
  },
  actionText: {
    fontFamily: fontFamily.bold,
    fontSize: 15,
    color: colors.white,
  },
});
