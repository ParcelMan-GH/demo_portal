import { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ViewStyle,
} from 'react-native';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { spacing } from '../../constants/spacing';
import { sanitizeLocalPhoneInput } from '../../utils/format';

interface PhoneInputProps {
  value: string;
  onChangeText: (text: string) => void;
  error?: string;
  label?: string;
  required?: boolean;
  readOnly?: boolean;
  containerStyle?: ViewStyle;
  placeholder?: string;
}

export default function PhoneInput({
  value,
  onChangeText,
  error,
  label,
  required = false,
  readOnly = false,
  containerStyle,
  placeholder = '0241234567',
}: PhoneInputProps) {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <View style={[styles.container, containerStyle]}>
      {label && (
        <Text style={styles.label}>
          {label}
          {required && <Text style={styles.required}> *</Text>}
        </Text>
      )}

      <View style={styles.inputWrapper}>
        <View style={styles.prefix}>
          <Text style={styles.flag}>🇬🇭</Text>
        </View>

        <TextInput
          style={styles.input}
          value={value}
          onChangeText={(text) => onChangeText(sanitizeLocalPhoneInput(text))}
          placeholder={placeholder}
          placeholderTextColor={colors.textLight}
          keyboardType="phone-pad"
          maxLength={10}
          editable={!readOnly}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
        />

        {error && <View style={styles.errorBorder} />}
      </View>

      {error && <Text style={styles.errorText}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
  },
  label: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.bodySm,
    color: colors.dark,
    marginBottom: spacing.sm,
  },
  required: {
    color: colors.error,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.warmSurface,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
    borderBottomWidth: 2,
    borderBottomColor: colors.primary,
    position: 'relative',
  },
  prefix: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: spacing.lg,
    paddingRight: spacing.sm,
  },
  flag: {
    fontSize: 18,
  },
  input: {
    flex: 1,
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    color: colors.dark,
    paddingVertical: spacing.xl,
    paddingRight: spacing.lg,
  },
  errorBorder: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: colors.error,
  },
  errorText: {
    fontFamily: fontFamily.regular,
    fontSize: 10,
    color: colors.error,
    marginTop: spacing.sm,
  },
});
