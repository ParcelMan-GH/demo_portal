import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import StatusBadge from '../common/StatusBadge';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { spacing, borderRadius } from '../../constants/spacing';
import { formatLocation } from '../../utils/format';

interface PickupCardProps {
  pickup: any;
  onPress: () => void;
}

export default function PickupCard({ pickup, onPress }: PickupCardProps) {
  const shipment = pickup.shipment;
  const contactName = shipment?.pickup?.contact_name || shipment?.pickup_contact_name;
  const location = shipment?.pickup?.location;

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.header}>
        <Text style={styles.number}>{shipment?.shipment_number || pickup.shipment_number || `Pickup #${pickup.id}`}</Text>
        <StatusBadge status={pickup.status} />
      </View>
      {contactName && (
        <View style={styles.row}>
          <Ionicons name="person-outline" size={16} color={colors.textMuted} />
          <Text style={styles.detail} numberOfLines={2}>{contactName}</Text>
        </View>
      )}
      {location && (
        <View style={styles.row}>
          <Ionicons name="location-outline" size={16} color={colors.textMuted} />
          <Text style={styles.detail} numberOfLines={2}>{formatLocation(location)}</Text>
        </View>
      )}
      <View style={styles.row}>
        <Ionicons name="cube-outline" size={16} color={colors.textMuted} />
        <Text style={styles.detail}>{shipment?.items?.length || 0} items</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.xl,
    padding: spacing.xl,
    gap: spacing.md,
    shadowColor: colors.dark,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  number: { fontFamily: fontFamily.semibold, fontSize: fontSize.titleMd, color: colors.dark },
  row: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm },
  detail: { flex: 1, minWidth: 0, fontFamily: fontFamily.medium, fontSize: fontSize.bodyMd, lineHeight: 20, color: colors.text },
});
