import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import StatusBadge from '../common/StatusBadge';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { spacing, borderRadius } from '../../constants/spacing';
import type { TransportManifest } from '../../types/driver';

interface TransportCardProps {
  transport: TransportManifest;
  onPress: () => void;
}

export default function TransportCard({ transport, onPress }: TransportCardProps) {
  const containerCount = transport.containers?.length || 0;
  const itemCount = transport.containers?.reduce((sum, container) => sum + Number(container.item_quantity || 0), 0)
    || transport.items?.length
    || 0;

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.header}>
        <Text style={styles.number}>{transport.manifest_number}</Text>
        <StatusBadge status={transport.status} />
      </View>
      <View style={styles.row}>
        <Ionicons name="arrow-forward-outline" size={14} color={colors.textMuted} />
        <Text style={styles.detail}>
          {transport.origin_warehouse?.name || 'Origin'} → {transport.destination_warehouse?.name || 'Destination'}
        </Text>
      </View>
      {containerCount > 0 ? (
        <View style={styles.row}>
          <Ionicons name="file-tray-stacked-outline" size={14} color={colors.textMuted} />
          <Text style={styles.detail}>
            {containerCount} {containerCount === 1 ? 'container' : 'containers'} · {itemCount} {itemCount === 1 ? 'item' : 'items'}
          </Text>
        </View>
      ) : null}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.xl,
    padding: spacing.xl,
    gap: spacing.md,
    shadowColor: colors.dark,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  number: { fontFamily: fontFamily.semibold, fontSize: fontSize.titleMd, color: colors.dark },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  detail: { fontFamily: fontFamily.regular, fontSize: fontSize.bodySm, color: colors.text, flex: 1 },
});
