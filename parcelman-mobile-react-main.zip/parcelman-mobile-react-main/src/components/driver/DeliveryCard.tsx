import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import StatusBadge from '../common/StatusBadge';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { spacing, borderRadius } from '../../constants/spacing';
import type { DeliveryRun } from '../../types/driver';

interface DeliveryCardProps {
  delivery: DeliveryRun;
  onPress: () => void;
}

export default function DeliveryCard({ delivery, onPress }: DeliveryCardProps) {
  const totalStops = delivery.stops?.length || 0;
  const deliveredStops = delivery.stops?.filter((s) => s.status === 'delivered').length || 0;
  const progress = totalStops > 0 ? deliveredStops / totalStops : 0;

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.header}>
        <Text style={styles.number}>{delivery.run_number}</Text>
        <StatusBadge status={delivery.status} />
      </View>
      <View style={styles.row}>
        <Ionicons name="navigate-outline" size={14} color={colors.textMuted} />
        <Text style={styles.detail}>{totalStops} stops</Text>
      </View>

      {/* Progress bar */}
      <View style={styles.progressContainer}>
        <View style={styles.progressBg}>
          <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
        </View>
        <Text style={styles.progressText}>{deliveredStops}/{totalStops}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.xl,
    padding: spacing.xl,
    gap: spacing.md,
    shadowColor: colors.dark,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  number: { fontFamily: fontFamily.semibold, fontSize: fontSize.titleMd, color: colors.dark },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  detail: { fontFamily: fontFamily.regular, fontSize: fontSize.bodySm, color: colors.text },
  progressContainer: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  progressBg: { flex: 1, height: 6, backgroundColor: colors.neutral200, borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: colors.success, borderRadius: 3 },
  progressText: { fontFamily: fontFamily.medium, fontSize: fontSize.labelSm, color: colors.textMuted },
});
