import { View, Text, Image, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { spacing, borderRadius } from '../../constants/spacing';
import { compressToUnder2MB } from '../../utils/image';
import { captureSinglePhoto, isIosSimulator } from '../../utils/cameraCapture';

interface PhotoCaptureProps {
  photo: string | null;
  onPhotoChange: (uri: string | null) => void;
  label?: string;
}

export default function PhotoCapture({
  photo,
  onPhotoChange,
  label = 'Proof Photo',
}: PhotoCaptureProps) {
  const handleCapture = async () => {
    const capturedUri = await captureSinglePhoto({ quality: 0.7, simulatorBehavior: 'sample' });
    if (!capturedUri) return;

    const compressed = await compressToUnder2MB(capturedUri);
    onPhotoChange(compressed);
  };

  const handlePick = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.7,
    });
    if (!result.canceled) {
      const compressed = await compressToUnder2MB(result.assets[0].uri);
      onPhotoChange(compressed);
    }
  };

  const handlePress = () => {
    if (photo) {
      Alert.alert('Photo', 'What would you like to do?', [
        { text: isIosSimulator() ? 'Retake Test Photo' : 'Retake', onPress: handleCapture },
        { text: 'Remove', onPress: () => onPhotoChange(null), style: 'destructive' },
        { text: 'Cancel', style: 'cancel' },
      ]);
    } else {
      Alert.alert('Add Photo', 'Choose a source', [
        { text: isIosSimulator() ? 'Test Camera' : 'Camera', onPress: handleCapture },
        { text: 'Gallery', onPress: handlePick },
        { text: 'Cancel', style: 'cancel' },
      ]);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <TouchableOpacity style={styles.capture} onPress={handlePress} activeOpacity={0.7}>
        {photo ? (
          <Image source={{ uri: photo }} style={styles.preview} />
        ) : (
          <View style={styles.placeholder}>
            <Ionicons name="camera-outline" size={32} color={colors.primary} />
            <Text style={styles.placeholderText}>Tap to capture</Text>
          </View>
        )}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { width: '100%' },
  label: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.bodySm,
    color: colors.dark,
    marginBottom: spacing.md,
  },
  capture: {
    width: '100%',
    height: 160,
    borderRadius: borderRadius.xl,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: colors.border,
    borderStyle: 'dashed',
  },
  preview: { width: '100%', height: '100%' },
  placeholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.surface,
    gap: spacing.sm,
  },
  placeholderText: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodySm,
    color: colors.textMuted,
  },
});
