import { TouchableOpacity, Text, ActivityIndicator, StyleSheet, ViewStyle } from 'react-native';
import { colors } from '../../constants/colors';
import { fontFamily, fontSize } from '../../constants/typography';
import { borderRadius } from '../../constants/spacing';

interface ActionButtonProps {
  title: string;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  color?: string;
  gradientColors?: [string, string];
  style?: ViewStyle;
}

export default function ActionButton({
  title,
  onPress,
  loading = false,
  disabled = false,
  gradientColors = [colors.primary, colors.primaryLight],
  style,
}: ActionButtonProps) {
  const isDisabled = disabled || loading;
  const backgroundColor = gradientColors[0] || colors.primary;

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={isDisabled}
      activeOpacity={1}
      style={[styles.button, { backgroundColor, opacity: isDisabled ? 0.6 : 1 }, style]}
    >
      {loading ? (
        <ActivityIndicator size={22} color={colors.white} />
      ) : (
        <Text style={styles.text}>{title}</Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    width: '100%',
    height: 56,
    borderRadius: borderRadius['3xl'],
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    shadowColor: colors.dark,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 5,
  },
  text: {
    color: colors.white,
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.bodyLg,
    letterSpacing: 0.5,
  },
});
