import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../api/client';
import type { Shipment } from '../types/vendor';

const PICKUP_VEHICLE_TYPES_CACHE_KEY = 'parcelman.vendor.pickup_vehicle_types';
const PICKUP_VEHICLE_TYPES_STALE_AFTER_MS = 30 * 60 * 1000;

export interface PickupVehicleTypeOption {
  id: number;
  name: string;
  slug?: string;
  capacity_hint?: string | null;
}

type PickupVehicleTypesCache = {
  pickupVehicleTypes: PickupVehicleTypeOption[];
  pickupVehicleTypesFetchedAt: number | null;
};

interface VendorState {
  // Dashboard
  dashboardStats: {
    totalShipments: number;
    activeShipments: number;
  } | null;
  recentShipments: Shipment[];

  // Shipments
  shipments: Shipment[];
  shipmentsTotal: number;
  currentShipment: Shipment | null;

  pickupVehicleTypes: PickupVehicleTypeOption[];
  pickupVehicleTypesFetchedAt: number | null;
  pickupVehicleTypesHydrated: boolean;
  pickupVehicleTypesRefreshing: boolean;

  // Loading
  isLoading: boolean;

  // Actions
  setDashboard: (stats: VendorState['dashboardStats'], recent: Shipment[]) => void;
  setShipments: (shipments: Shipment[], total: number) => void;
  appendShipments: (shipments: Shipment[]) => void;
  setCurrentShipment: (shipment: Shipment | null) => void;
  updateShipmentInList: (shipment: Shipment) => void;
  removeShipmentFromList: (id: number) => void;
  hydratePickupVehicleTypes: () => Promise<void>;
  refreshPickupVehicleTypes: (force?: boolean) => Promise<PickupVehicleTypeOption[]>;
  setLoading: (loading: boolean) => void;
  reset: () => void;
}

let pickupVehicleTypesRefreshPromise: Promise<PickupVehicleTypeOption[]> | null = null;

async function persistPickupVehicleTypes(cache: PickupVehicleTypesCache) {
  await AsyncStorage.setItem(PICKUP_VEHICLE_TYPES_CACHE_KEY, JSON.stringify(cache));
}

export const useVendorStore = create<VendorState>((set, get) => ({
  dashboardStats: null,
  recentShipments: [],
  shipments: [],
  shipmentsTotal: 0,
  currentShipment: null,
  pickupVehicleTypes: [],
  pickupVehicleTypesFetchedAt: null,
  pickupVehicleTypesHydrated: false,
  pickupVehicleTypesRefreshing: false,
  isLoading: false,

  setDashboard: (stats, recent) => set({ dashboardStats: stats, recentShipments: recent }),

  setShipments: (shipments, total) => set({ shipments, shipmentsTotal: total }),
  appendShipments: (newItems) =>
    set((s) => ({ shipments: [...s.shipments, ...newItems] })),
  setCurrentShipment: (shipment) => set({ currentShipment: shipment }),
  updateShipmentInList: (shipment) =>
    set((s) => ({
      shipments: s.shipments.map((sh) => (sh.id === shipment.id ? shipment : sh)),
      currentShipment: s.currentShipment?.id === shipment.id ? shipment : s.currentShipment,
    })),
  removeShipmentFromList: (id) =>
    set((s) => ({
      shipments: s.shipments.filter((sh) => sh.id !== id),
      shipmentsTotal: s.shipmentsTotal - 1,
    })),

  hydratePickupVehicleTypes: async () => {
    try {
      const raw = await AsyncStorage.getItem(PICKUP_VEHICLE_TYPES_CACHE_KEY);
      if (raw) {
        const cached = JSON.parse(raw) as PickupVehicleTypesCache;
        set({
          pickupVehicleTypes: Array.isArray(cached.pickupVehicleTypes) ? cached.pickupVehicleTypes : [],
          pickupVehicleTypesFetchedAt: cached.pickupVehicleTypesFetchedAt || null,
          pickupVehicleTypesHydrated: true,
        });
        return;
      }
    } catch {}

    set({ pickupVehicleTypesHydrated: true });
  },

  refreshPickupVehicleTypes: async (force = false) => {
    const state = get();
    const isFresh = state.pickupVehicleTypesFetchedAt
      && Date.now() - state.pickupVehicleTypesFetchedAt < PICKUP_VEHICLE_TYPES_STALE_AFTER_MS;

    if (!force && isFresh) {
      return state.pickupVehicleTypes;
    }

    if (pickupVehicleTypesRefreshPromise) {
      return pickupVehicleTypesRefreshPromise;
    }

    pickupVehicleTypesRefreshPromise = (async () => {
      set({ pickupVehicleTypesRefreshing: true });
      try {
        const res: any = await api.get('/vendor/pickup-vehicle-types');
        const pickupVehicleTypes = res?.data?.vehicle_types || res?.vehicle_types || [];
        const next = {
          pickupVehicleTypes: Array.isArray(pickupVehicleTypes) ? pickupVehicleTypes : [],
          pickupVehicleTypesFetchedAt: Date.now(),
        };
        await persistPickupVehicleTypes(next);
        set(next);
        return next.pickupVehicleTypes;
      } catch {
        return get().pickupVehicleTypes;
      } finally {
        set({ pickupVehicleTypesRefreshing: false, pickupVehicleTypesHydrated: true });
        pickupVehicleTypesRefreshPromise = null;
      }
    })();

    return pickupVehicleTypesRefreshPromise;
  },

  setLoading: (isLoading) => set({ isLoading }),
  reset: () =>
    set({
      dashboardStats: null,
      recentShipments: [],
      shipments: [],
      shipmentsTotal: 0,
      currentShipment: null,
      isLoading: false,
    }),
}));
