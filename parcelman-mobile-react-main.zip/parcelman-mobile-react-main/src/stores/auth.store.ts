import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getItem, setItem, deleteItem } from '../utils/secure-storage';
import { STORAGE_KEYS } from '../constants/storage-keys';

export type UserType = 'vendor' | 'driver';

interface AuthState {
  user: any | null;
  token: string | null;
  userType: UserType | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (token: string, user: any, userType: UserType) => Promise<void>;
  logout: () => Promise<void>;
  logoutLocal: () => Promise<void>;
  setUser: (user: any) => void;
  hydrate: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: null,
  userType: null,
  isAuthenticated: false,
  isLoading: true,

  login: async (token: string, user: any, userType: UserType) => {
    await setItem(STORAGE_KEYS.AUTH_TOKEN, token);
    await AsyncStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(user));
    await AsyncStorage.setItem(STORAGE_KEYS.USER_TYPE, userType);
    set({ token, user, userType, isAuthenticated: true });
  },

  logout: async () => {
    try {
      // Try to call backend logout
      const userType = await AsyncStorage.getItem(STORAGE_KEYS.USER_TYPE);
      if (userType === 'vendor') {
        const { vendorLogout } = require('../api/v1/auth');
        await vendorLogout().catch(() => {});
      } else if (userType === 'driver') {
        const { driverLogout } = require('../api/v1/driver-auth');
        await driverLogout().catch(() => {});
      }
    } catch {}

    await deleteItem(STORAGE_KEYS.AUTH_TOKEN);
    await AsyncStorage.removeItem(STORAGE_KEYS.USER_DATA);
    await AsyncStorage.removeItem(STORAGE_KEYS.USER_TYPE);
    set({ token: null, user: null, userType: null, isAuthenticated: false });
  },

  logoutLocal: async () => {
    await deleteItem(STORAGE_KEYS.AUTH_TOKEN);
    await AsyncStorage.removeItem(STORAGE_KEYS.USER_DATA);
    await AsyncStorage.removeItem(STORAGE_KEYS.USER_TYPE);
    set({ token: null, user: null, userType: null, isAuthenticated: false });
  },

  setUser: (user: any) => {
    AsyncStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(user));
    set({ user });
  },

  hydrate: async () => {
    try {
      const [token, userData, userType] = await Promise.all([
        getItem(STORAGE_KEYS.AUTH_TOKEN),
        AsyncStorage.getItem(STORAGE_KEYS.USER_DATA),
        AsyncStorage.getItem(STORAGE_KEYS.USER_TYPE),
      ]);

      if (token && userData && userType) {
        const user = JSON.parse(userData);
        set({
          token,
          user,
          userType: userType as UserType,
          isAuthenticated: true,
          isLoading: false,
        });
      } else {
        set({ isLoading: false });
      }
    } catch {
      set({ isLoading: false });
    }
  },
}));
