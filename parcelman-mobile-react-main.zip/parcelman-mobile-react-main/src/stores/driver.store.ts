import { create } from 'zustand';

interface DriverState {
  activePickupsCount: number;
  activeTransportsCount: number;
  activeDeliveriesCount: number;
  isOnline: boolean;

  setActiveCounts: (pickups: number, transports: number, deliveries: number) => void;
  setOnline: (online: boolean) => void;
  reset: () => void;
}

export const useDriverStore = create<DriverState>((set) => ({
  activePickupsCount: 0,
  activeTransportsCount: 0,
  activeDeliveriesCount: 0,
  isOnline: false,

  setActiveCounts: (pickups, transports, deliveries) =>
    set({
      activePickupsCount: pickups,
      activeTransportsCount: transports,
      activeDeliveriesCount: deliveries,
    }),

  setOnline: (isOnline) => set({ isOnline }),

  reset: () =>
    set({
      activePickupsCount: 0,
      activeTransportsCount: 0,
      activeDeliveriesCount: 0,
      isOnline: false,
    }),
}));
