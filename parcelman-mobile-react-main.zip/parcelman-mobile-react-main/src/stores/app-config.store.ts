import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { getProfile } from '../api/v1/vendor/profile';

const CACHE_KEY = 'parcelman.vendor.app_config';
const STALE_AFTER_MS = 6 * 60 * 60 * 1000;

type CachedAppConfig = {
  supportPhone: string | null;
  lastFetchedAt: number | null;
};

interface AppConfigState extends CachedAppConfig {
  hydrated: boolean;
  isRefreshing: boolean;
  hydrate: () => Promise<void>;
  refresh: (force?: boolean) => Promise<void>;
  setFromProfile: (profileData: any) => Promise<void>;
}

let refreshPromise: Promise<void> | null = null;

function readSupportPhone(profileData: any): string | null {
  const value = profileData?.app_config?.support_phone;
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

async function persist(config: CachedAppConfig) {
  await AsyncStorage.setItem(CACHE_KEY, JSON.stringify(config));
}

export const useAppConfigStore = create<AppConfigState>((set, get) => ({
  supportPhone: null,
  lastFetchedAt: null,
  hydrated: false,
  isRefreshing: false,

  hydrate: async () => {
    try {
      const raw = await AsyncStorage.getItem(CACHE_KEY);
      if (raw) {
        const cached = JSON.parse(raw) as CachedAppConfig;
        set({
          supportPhone: cached.supportPhone || null,
          lastFetchedAt: cached.lastFetchedAt || null,
          hydrated: true,
        });
        return;
      }
    } catch {}
    set({ hydrated: true });
  },

  refresh: async (force = false) => {
    const state = get();
    const isFresh = state.lastFetchedAt && Date.now() - state.lastFetchedAt < STALE_AFTER_MS;
    if (!force && isFresh) return;
    if (refreshPromise) return refreshPromise;

    refreshPromise = (async () => {
      set({ isRefreshing: true });
      try {
        const res = await getProfile();
        const supportPhone = readSupportPhone(res.data);
        const next = { supportPhone, lastFetchedAt: Date.now() };
        await persist(next);
        set(next);
      } catch {
        // Keep the cached value if the app is offline or the profile request fails.
      } finally {
        set({ isRefreshing: false });
        refreshPromise = null;
      }
    })();

    return refreshPromise;
  },

  setFromProfile: async (profileData: any) => {
    const supportPhone = readSupportPhone(profileData);
    const next = { supportPhone, lastFetchedAt: Date.now() };
    await persist(next);
    set(next);
  },
}));
