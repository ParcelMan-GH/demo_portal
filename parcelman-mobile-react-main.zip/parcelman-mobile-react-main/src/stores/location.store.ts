import { create } from 'zustand';

interface LocationState {
  latitude: number | null;
  longitude: number | null;
  heading: number | null;
  isTracking: boolean;

  setPosition: (lat: number, lng: number, heading?: number) => void;
  setTracking: (tracking: boolean) => void;
  reset: () => void;
}

export const useLocationStore = create<LocationState>((set) => ({
  latitude: null,
  longitude: null,
  heading: null,
  isTracking: false,

  setPosition: (latitude, longitude, heading) =>
    set({ latitude, longitude, heading: heading ?? null }),

  setTracking: (isTracking) => set({ isTracking }),

  reset: () =>
    set({ latitude: null, longitude: null, heading: null, isTracking: false }),
}));
