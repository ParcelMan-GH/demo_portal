import { create } from 'zustand';
import type { NotificationLog } from '../types/notification';

interface NotificationState {
  notifications: NotificationLog[];
  unreadCount: number;
  total: number;
  isLoading: boolean;

  setNotifications: (items: NotificationLog[], total: number) => void;
  appendNotifications: (items: NotificationLog[]) => void;
  markAsRead: (id: number) => void;
  markAllAsRead: () => void;
  setUnreadCount: (count: number) => void;
  setLoading: (loading: boolean) => void;
  reset: () => void;
}

export const useNotificationStore = create<NotificationState>((set) => ({
  notifications: [],
  unreadCount: 0,
  total: 0,
  isLoading: false,

  setNotifications: (items, total) => {
    const unreadCount = items.filter((n) => !n.read_at).length;
    set({ notifications: items, total, unreadCount });
  },

  appendNotifications: (items) =>
    set((s) => ({
      notifications: [...s.notifications, ...items],
    })),

  markAsRead: (id) =>
    set((s) => ({
      notifications: s.notifications.map((n) =>
        n.id === id ? { ...n, read_at: new Date().toISOString() } : n,
      ),
      unreadCount: Math.max(0, s.unreadCount - 1),
    })),

  markAllAsRead: () =>
    set((s) => ({
      notifications: s.notifications.map((n) => ({
        ...n,
        read_at: n.read_at || new Date().toISOString(),
      })),
      unreadCount: 0,
    })),

  setUnreadCount: (count) => set({ unreadCount: count }),
  setLoading: (isLoading) => set({ isLoading }),
  reset: () => set({ notifications: [], unreadCount: 0, total: 0, isLoading: false }),
}));
