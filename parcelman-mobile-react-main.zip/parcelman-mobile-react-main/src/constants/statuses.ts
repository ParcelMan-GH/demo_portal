import { colors } from './colors';

export type ShipmentStatus =
  | 'draft'
  | 'submitted'
  | 'processing'
  | 'pickup_assigned'
  | 'picked_up'
  | 'at_warehouse'
  | 'sorted'
  | 'in_transit'
  | 'at_destination'
  | 'out_for_delivery'
  | 'handed_to_courier'
  | 'delivered'
  | 'cancelled'
  | 'rejected';

export type PickupStatus = 'assigned' | 'en_route' | 'arrived' | 'picking_up' | 'completed' | 'cancelled';

export type TransportStatus = 'draft' | 'assigned' | 'loading' | 'in_transit' | 'arrived' | 'received' | 'cancelled';

export type DeliveryRunStatus = 'draft' | 'assigned' | 'out_for_delivery' | 'partially_delivered' | 'completed' | 'cancelled';

export type DeliveryStopStatus = 'pending' | 'arrived' | 'delivered' | 'handed_off' | 'failed';

export type ItemStatus =
  | 'pending'
  | 'picked_up'
  | 'at_warehouse'
  | 'sorted'
  | 'in_transit'
  | 'at_destination'
  | 'out_for_delivery'
  | 'handed_to_courier'
  | 'delivered'
  | 'cancelled';

interface StatusConfig {
  label: string;
  color: string;
  bgColor: string;
  icon?: string;
}

export const shipmentStatusConfig: Record<ShipmentStatus, StatusConfig> = {
  draft: { label: 'Draft', color: colors.textMuted, bgColor: colors.neutral100, icon: 'document-text-outline' },
  submitted: { label: 'Submitted', color: colors.info, bgColor: colors.infoLight, icon: 'paper-plane-outline' },
  processing: { label: 'Processing', color: '#d97706', bgColor: '#fef3c7', icon: 'construct-outline' },
  pickup_assigned: { label: 'Pickup Assigned', color: colors.primary, bgColor: colors.warmSurface, icon: 'car-outline' },
  picked_up: { label: 'Picked Up', color: colors.primary, bgColor: colors.warmSurface, icon: 'cube-outline' },
  at_warehouse: { label: 'At Warehouse', color: colors.infoDark, bgColor: colors.infoLight, icon: 'home-outline' },
  sorted: { label: 'Sorted', color: colors.infoDark, bgColor: colors.infoLight, icon: 'layers-outline' },
  in_transit: { label: 'In Transit', color: colors.primaryLight, bgColor: colors.warmSurface, icon: 'airplane-outline' },
  at_destination: { label: 'At Destination', color: colors.primaryDark, bgColor: colors.warmSurface, icon: 'location-outline' },
  out_for_delivery: { label: 'Out for Delivery', color: colors.primaryLight, bgColor: colors.warmSurface, icon: 'bicycle-outline' },
  handed_to_courier: { label: 'Handed to Bus Courier', color: '#7c3aed', bgColor: '#ede9fe', icon: 'bus-outline' },
  delivered: { label: 'Delivered', color: colors.success, bgColor: colors.successLight, icon: 'checkmark-done-outline' },
  cancelled: { label: 'Cancelled', color: colors.error, bgColor: colors.errorLight, icon: 'close-circle-outline' },
  rejected: { label: 'Rejected', color: colors.error, bgColor: colors.errorLight, icon: 'alert-circle-outline' },
};

// Items share the same vocabulary as shipments (aside from pre-submit states).
export const itemStatusConfig: Record<ItemStatus, StatusConfig> = {
  pending: { label: 'Pending', color: colors.textMuted, bgColor: colors.neutral100, icon: 'time-outline' },
  picked_up: { label: 'Picked Up', color: colors.primary, bgColor: colors.warmSurface, icon: 'cube-outline' },
  at_warehouse: { label: 'At Warehouse', color: colors.infoDark, bgColor: colors.infoLight, icon: 'home-outline' },
  sorted: { label: 'Sorted', color: colors.infoDark, bgColor: colors.infoLight, icon: 'layers-outline' },
  in_transit: { label: 'In Transit', color: colors.primaryLight, bgColor: colors.warmSurface, icon: 'airplane-outline' },
  at_destination: { label: 'At Destination', color: colors.primaryDark, bgColor: colors.warmSurface, icon: 'location-outline' },
  out_for_delivery: { label: 'Out for Delivery', color: colors.primaryLight, bgColor: colors.warmSurface, icon: 'bicycle-outline' },
  handed_to_courier: { label: 'Handed to Bus Courier', color: '#7c3aed', bgColor: '#ede9fe', icon: 'bus-outline' },
  delivered: { label: 'Delivered', color: colors.success, bgColor: colors.successLight, icon: 'checkmark-done-outline' },
  cancelled: { label: 'Cancelled', color: colors.error, bgColor: colors.errorLight, icon: 'close-circle-outline' },
};

export const pickupStatusConfig: Record<PickupStatus, StatusConfig> = {
  assigned: { label: 'Assigned', color: colors.info, bgColor: colors.infoLight },
  en_route: { label: 'En Route', color: colors.primaryLight, bgColor: colors.warmSurface },
  arrived: { label: 'Arrived', color: colors.primary, bgColor: colors.warmSurface },
  picking_up: { label: 'Picking Up', color: colors.primaryDark, bgColor: colors.warmSurface },
  completed: { label: 'Completed', color: colors.success, bgColor: colors.successLight },
  cancelled: { label: 'Cancelled', color: colors.error, bgColor: colors.errorLight },
};

export const transportStatusConfig: Record<TransportStatus, StatusConfig> = {
  draft: { label: 'Draft', color: colors.textMuted, bgColor: colors.neutral100 },
  assigned: { label: 'Assigned', color: colors.info, bgColor: colors.infoLight },
  loading: { label: 'Loading', color: colors.primaryLight, bgColor: colors.warmSurface },
  in_transit: { label: 'In Transit', color: colors.primary, bgColor: colors.warmSurface },
  arrived: { label: 'Arrived', color: colors.primaryDark, bgColor: colors.warmSurface },
  received: { label: 'Received', color: colors.success, bgColor: colors.successLight },
  cancelled: { label: 'Cancelled', color: colors.error, bgColor: colors.errorLight },
};

export const deliveryRunStatusConfig: Record<DeliveryRunStatus, StatusConfig> = {
  draft: { label: 'Draft', color: colors.textMuted, bgColor: colors.neutral100 },
  assigned: { label: 'Assigned', color: colors.info, bgColor: colors.infoLight },
  out_for_delivery: { label: 'Out for Delivery', color: colors.primaryLight, bgColor: colors.warmSurface },
  partially_delivered: { label: 'Partially Delivered', color: colors.warning, bgColor: colors.warningLight },
  completed: { label: 'Completed', color: colors.success, bgColor: colors.successLight },
  cancelled: { label: 'Cancelled', color: colors.error, bgColor: colors.errorLight },
};

export const deliveryStopStatusConfig: Record<DeliveryStopStatus, StatusConfig> = {
  pending: { label: 'Pending', color: colors.textMuted, bgColor: colors.neutral100 },
  arrived: { label: 'Arrived', color: colors.primary, bgColor: colors.warmSurface },
  delivered: { label: 'Delivered', color: colors.success, bgColor: colors.successLight },
  handed_off: { label: 'Handed Off', color: colors.success, bgColor: colors.successLight },
  failed: { label: 'Failed', color: colors.error, bgColor: colors.errorLight },
};
