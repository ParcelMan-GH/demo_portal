import { TextStyle } from 'react-native';

export const fontFamily = {
  regular: 'PlusJakartaSans_400Regular',
  medium: 'PlusJakartaSans_500Medium',
  semibold: 'PlusJakartaSans_600SemiBold',
  bold: 'PlusJakartaSans_700Bold',
  extrabold: 'PlusJakartaSans_800ExtraBold',
} as const;

export const fontSize = {
  displayXl: 57,
  displayLg: 48,
  displayMd: 36,
  displaySm: 32,
  displayXs: 28,

  headingLg: 32,
  headingMd: 28,
  headingSm: 24,

  titleLg: 22,
  titleMd: 16,
  titleSm: 14,
  titleXs: 12,

  bodyLg: 16,
  bodyMd: 14,
  bodySm: 12,
  bodyXs: 11,

  labelLg: 14,
  labelMd: 12,
  labelSm: 11,
  labelXs: 10,
} as const;

export const textStyles: Record<string, TextStyle> = {
  displayLg: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.displayXl,
    letterSpacing: -0.25,
    lineHeight: fontSize.displayXl * 1.12,
  },
  displayMd: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.displayLg,
    lineHeight: fontSize.displayLg * 1.15,
  },
  displaySm: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.displayMd,
    lineHeight: fontSize.displayMd * 1.22,
  },

  headingLg: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.headingLg,
    lineHeight: fontSize.headingLg * 1.25,
  },
  headingMd: {
    fontFamily: fontFamily.bold,
    fontSize: fontSize.headingMd,
    lineHeight: fontSize.headingMd * 1.28,
  },
  headingSm: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.headingSm,
    lineHeight: fontSize.headingSm * 1.33,
  },

  titleLg: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.titleLg,
    lineHeight: fontSize.titleLg * 1.27,
  },
  titleMd: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.titleMd,
    letterSpacing: 0.15,
    lineHeight: fontSize.titleMd * 1.5,
  },
  titleSm: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.titleSm,
    letterSpacing: 0.1,
    lineHeight: fontSize.titleSm * 1.43,
  },
  titleXs: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.titleXs,
    letterSpacing: 0.1,
    lineHeight: fontSize.titleXs * 1.43,
  },

  bodyLg: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyLg,
    letterSpacing: 0.5,
    lineHeight: fontSize.bodyLg * 1.5,
  },
  bodyMd: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyMd,
    letterSpacing: 0.25,
    lineHeight: fontSize.bodyMd * 1.43,
  },
  bodySm: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodySm,
    letterSpacing: 0.4,
    lineHeight: fontSize.bodySm * 1.33,
  },
  bodyXs: {
    fontFamily: fontFamily.regular,
    fontSize: fontSize.bodyXs,
    letterSpacing: 0.4,
    lineHeight: fontSize.bodyXs * 1.33,
  },

  labelLg: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.labelLg,
    letterSpacing: 0.1,
    lineHeight: fontSize.labelLg * 1.43,
  },
  labelMd: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.labelMd,
    letterSpacing: 0.5,
    lineHeight: fontSize.labelMd * 1.33,
  },
  labelSm: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.labelSm,
    letterSpacing: 0.5,
    lineHeight: fontSize.labelSm * 1.45,
  },

  button: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.labelMd,
    letterSpacing: 0.5,
    lineHeight: fontSize.labelMd * 1.43,
  },

  overline: {
    fontFamily: fontFamily.semibold,
    fontSize: fontSize.labelXs,
    letterSpacing: 1.5,
    lineHeight: fontSize.labelXs * 1.6,
  },
};
