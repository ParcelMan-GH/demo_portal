export const colors = {
  // ===== Parcelman Brand Colors (Orange/Golden) =====
  primary: '#ea580c',
  primaryLight: '#f97316',
  primaryDark: '#c2410c',

  // Gradient (Rust tones)
  gradientStart: '#7c2d12',
  gradientMid: '#9a3412',
  gradientEnd: '#c2410c',
  brandGradient: ['#7c2d12', '#9a3412', '#c2410c'] as const,
  buttonGradient: ['#ea580c', '#f97316'] as const,

  // Accents
  accentLight: '#fdba74',
  accentLighter: '#fed7aa',
  warmSurface: '#fff7ed',

  // ===== Neutrals (Slate) =====
  dark: '#0f172a',
  darkAlt: '#1e293b',
  text: '#334155',
  textMuted: '#64748b',
  textLight: '#94a3b8',
  surface: '#f8fafc',
  background: '#f1f5f9',
  border: '#e2e8f0',
  card: '#ffffff',

  // ===== Common =====
  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',

  // ===== Focus States =====
  focusBorder: 'rgba(249,115,22,0.6)',
  focusShadow: 'rgba(249,115,22,0.12)',

  // ===== Semantic Colors =====
  error: '#E74C3C',
  errorLight: '#FEE2E2',
  errorDark: '#DC2626',

  success: '#10b981',
  successLight: '#DCFCE7',
  successDark: '#16A34A',

  warning: '#FACC15',
  warningLight: '#FEF3C7',
  warningDark: '#EAB308',

  info: '#60A5FA',
  infoLight: '#DCEEFF',
  infoDark: '#3B82F6',

  // ===== Neutral Grays =====
  neutral900: '#1A1A1A',
  neutral800: '#262626',
  neutral700: '#404040',
  neutral600: '#525252',
  neutral500: '#737373',
  neutral400: '#A3A3A3',
  neutral300: '#D4D4D4',
  neutral200: '#E5E5E5',
  neutral100: '#F5F5F5',

  // ===== Outline =====
  outlineLight: '#E0E0E0',
  outlineVariantLight: '#F5F5F5',
} as const;
