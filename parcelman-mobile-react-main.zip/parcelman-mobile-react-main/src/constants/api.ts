import Constants from 'expo-constants';

export const API_BASE_URL: string =
  (Constants.expoConfig?.extra?.API_BASE_URL as string) || 'https://parcelmanexpress.com';

export const API_TIMEOUT = 45000;
