import api from '../client';
import type { ApiResponse } from '../../types/api';
import type { Driver } from '../../types/driver';

interface DriverLoginResponse {
  token: string;
  user: Driver;
}

export function driverLogin(
  phone: string,
  password: string,
  fcm_token?: string,
): Promise<ApiResponse<DriverLoginResponse>> {
  // Backend accepts `identifier` for phone or email. The mobile app only
  // exposes phone, but we send via the new field name per API contract.
  return api.post('/driver/login', { identifier: phone, password, fcm_token }) as any;
}

export function driverLogout(): Promise<ApiResponse<null>> {
  return api.post('/driver/logout') as any;
}
