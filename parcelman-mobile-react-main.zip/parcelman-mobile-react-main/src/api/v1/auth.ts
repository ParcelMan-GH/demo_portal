import api from '../client';
import type { ApiResponse } from '../../types/api';
import type { Vendor } from '../../types/vendor';

interface SendOtpResponse {
  expires_in: number;
}

interface VerifyPhoneResponse {
  token: string;
  user: Vendor;
  user_exists: boolean;
}

interface RegisterResponse {
  token: string;
  user: Vendor;
}

export function sendOtp(phone: string): Promise<ApiResponse<SendOtpResponse>> {
  return api.post('/auth/vendor/send-otp', { phone }) as any;
}

export function verifyPhone(
  phone: string,
  otp: string,
  fcm_token?: string,
): Promise<ApiResponse<VerifyPhoneResponse>> {
  return api.post('/auth/vendor/verify-phone', { phone, otp, fcm_token }) as any;
}

export function register(data: {
  name: string;
  business_name?: string;
  phone: string;
  email?: string;
  fcm_token?: string;
}): Promise<ApiResponse<RegisterResponse>> {
  return api.post('/auth/vendor/register', data) as any;
}

export function vendorLogout(): Promise<ApiResponse<null>> {
  return api.post('/auth/vendor/logout') as any;
}
