import api from '../../client';
import type { PaginationParams } from '../../../types/api';

export function getTransports(params?: PaginationParams & { status?: string }): Promise<any> {
  return api.get('/driver/transports', { params });
}

export function getTransport(id: number): Promise<any> {
  return api.get(`/driver/transports/${id}`);
}

export function startLoading(id: number): Promise<any> {
  return api.post(`/driver/transports/${id}/start-loading`);
}

export function scanLoad(id: number, trackingCode: string): Promise<any> {
  return api.post(`/driver/transports/${id}/scan-load`, { tracking_code: trackingCode });
}

export function scanContainerLoad(id: number, containerCode: string): Promise<any> {
  return api.post(`/driver/transports/${id}/scan-load`, { container_code: containerCode });
}

export function reportTransportScanIssue(
  id: number,
  data: {
    target_type: 'container' | 'item';
    container_id?: number;
    manifest_item_id?: number;
    reason: string;
    note?: string;
    proof_photo: string;
  },
): Promise<any> {
  const formData = new FormData();
  formData.append('target_type', data.target_type);
  if (data.container_id) formData.append('container_id', String(data.container_id));
  if (data.manifest_item_id) formData.append('manifest_item_id', String(data.manifest_item_id));
  formData.append('reason', data.reason);
  if (data.note) formData.append('note', data.note);
  formData.append('proof_photo', {
    uri: data.proof_photo,
    name: 'transport_scan_issue.jpg',
    type: 'image/jpeg',
  } as any);

  return api.post(`/driver/transports/${id}/scan-issue`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 120000,
  });
}

export function depart(id: number): Promise<any> {
  return api.post(`/driver/transports/${id}/depart`);
}

export function arriveTransport(id: number): Promise<any> {
  return api.post(`/driver/transports/${id}/arrive`);
}
