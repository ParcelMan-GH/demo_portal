import api from '../../client';
import type { ApiResponse } from '../../../types/api';
import type { NotificationLog } from '../../../types/notification';

interface NotificationListResponse {
  items: NotificationLog[];
  pagination: { offset: number; limit: number; total: number; has_more: boolean };
}

export function getDriverNotifications(params?: {
  offset?: number;
  limit?: number;
  is_read?: boolean;
}): Promise<ApiResponse<NotificationListResponse>> {
  return api.get('/driver/notifications', { params }) as any;
}

export function markDriverNotificationAsRead(id: number): Promise<ApiResponse<null>> {
  return api.post(`/driver/notifications/${id}/read`) as any;
}

export function markAllDriverNotificationsAsRead(): Promise<ApiResponse<null>> {
  return api.post('/driver/notifications/read-all') as any;
}
