import api from "../../client";

export type DeliveryFailureReason = {
  id: number;
  label: string;
  type: "not_received" | "issue" | "failed" | "other";
  sort_order?: number;
  is_active?: boolean;
};

export type BusHandoffFollowUp = {
  id: number;
  delivery_run_id?: number | null;
  delivery_run_number?: string | null;
  delivery_run_stop_id?: number | null;
  delivery_run_item_id: number;
  status: string;
  status_label?: string;
  source?: string | null;
  source_label?: string | null;
  target_type?: "recipient" | "vendor" | null;
  target_name?: string | null;
  target_phone?: string | null;
  issue_notes?: string | null;
  confirmation_notes?: string | null;
  code_sent_at?: string | null;
  code_expires_at?: string | null;
  confirmed_at?: string | null;
  confirmed_by_driver?: {
    id?: number;
    name?: string | null;
    phone?: string | null;
  } | null;
  confirmed_by_admin?: {
    id?: number;
    name?: string | null;
  } | null;
  handoff_driver?: {
    id?: number;
    name?: string | null;
    phone?: string | null;
  } | null;
  package?: {
    shipment_number?: string | null;
    tracking_code?: string | null;
    description?: string | null;
    quantity?: number | null;
    status?: string | null;
  };
  recipient?: {
    name?: string | null;
    phone?: string | null;
    town?: string | null;
  };
  vendor?: {
    name?: string | null;
    phone?: string | null;
  } | null;
  handoff?: {
    bus_station?: string | null;
    courier_name?: string | null;
    courier_phone?: string | null;
    vehicle_number?: string | null;
    handed_off_at?: string | null;
    proof_photo_url?: string | null;
  };
  reason?: DeliveryFailureReason | null;
};

export function getBusHandoffs(params?: { status?: string; search?: string; limit?: number; offset?: number }): Promise<any> {
  return api.get("/driver/bus-handoffs", { params });
}

export function getBusHandoff(id: number): Promise<any> {
  return api.get(`/driver/bus-handoffs/${id}`);
}

export function getDeliveryFailureReasons(): Promise<any> {
  return api.get("/driver/delivery-failure-reasons");
}

export function sendBusHandoffConfirmation(id: number, targetType: "recipient" | "vendor"): Promise<any> {
  return api.post(`/driver/bus-handoffs/${id}/send-confirmation`, { target_type: targetType });
}

export function confirmBusHandoffCode(id: number, confirmationCode: string): Promise<any> {
  return api.post(`/driver/bus-handoffs/${id}/confirm-code`, { confirmation_code: confirmationCode });
}

export function reportBusHandoffIssue(id: number, data: { reason_id: number; notes?: string }): Promise<any> {
  return api.post(`/driver/bus-handoffs/${id}/report-issue`, data);
}
