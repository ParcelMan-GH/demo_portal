import api from '../../client';
import type { PaginationParams } from '../../../types/api';
import type { PickupItemConfirmData } from '../../../types/driver';

export function getPickups(params?: PaginationParams & { status?: string }): Promise<any> {
  return api.get('/driver/pickups', { params });
}

export function getPickup(id: number): Promise<any> {
  return api.get(`/driver/pickups/${id}`);
}

export function markEnRoute(id: number): Promise<any> {
  return api.post(`/driver/pickups/${id}/en-route`);
}

export function markArrived(id: number, lat: number, lng: number): Promise<any> {
  return api.post(`/driver/pickups/${id}/arrive`, { latitude: lat, longitude: lng });
}

export function confirmItem(
  pickupId: number,
  itemId: number,
  data: PickupItemConfirmData & { remove_photo_ids?: number[] },
): Promise<any> {
  const formData = new FormData();
  formData.append('confirmed_quantity', String(data.confirmed_quantity));
  if (data.notes) formData.append('notes', data.notes);
  // Photo IDs to remove
  data.remove_photo_ids?.forEach((photoId: number, i: number) => {
    formData.append(`remove_photo_ids[${i}]`, String(photoId));
  });
  // New local photos to upload
  data.photos?.forEach((uri: string, i: number) => {
    formData.append(`photos[${i}]`, {
      uri,
      name: `photo_${i}.jpg`,
      type: 'image/jpeg',
    } as any);
  });

  return api.post(
    `/driver/pickups/${pickupId}/items/${itemId}/confirm`,
    formData,
    { headers: { 'Content-Type': 'multipart/form-data' } },
  );
}

export function confirmPickup(
  id: number,
  driverPickedQuantity: number,
  coords?: { latitude: number; longitude: number },
): Promise<any> {
  const payload: Record<string, number> = {
    driver_picked_quantity: driverPickedQuantity,
  };

  if (coords && Number.isFinite(coords.latitude) && Number.isFinite(coords.longitude)) {
    payload.latitude = coords.latitude;
    payload.longitude = coords.longitude;
  }

  return api.post(`/driver/pickups/${id}/confirm-pickup`, payload);
}
