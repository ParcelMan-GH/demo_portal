import api from '../../client';

export function scanClaim(data: {
  barcode: string;
  latitude?: number;
  longitude?: number;
  notes?: string;
}): Promise<any> {
  return api.post('/driver/scan-claim', data);
}

export function getMyPackages(params?: {
  from_date?: string;
  to_date?: string;
  limit?: number;
  offset?: number;
}): Promise<any> {
  return api.get('/driver/my-packages', { params });
}

export function releasePackage(data: {
  barcode: string;
  notes?: string;
}): Promise<any> {
  return api.post('/driver/release-package', data);
}

export function changePackageLocation(trackingCode: string, data: FormData): Promise<any> {
  return api.post(`/driver/packages/${encodeURIComponent(trackingCode)}/location-change`, data, {
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 120000,
  });
}

export function requestPackageTransfer(trackingCode: string, data: { receiver_phone: string }): Promise<any> {
  return api.post(`/driver/packages/${encodeURIComponent(trackingCode)}/transfer`, data);
}

export function getIncomingPackageTransfers(): Promise<any> {
  return api.get('/driver/package-transfers/incoming');
}

export function getOutgoingPackageTransfers(): Promise<any> {
  return api.get('/driver/package-transfers/outgoing');
}

export function acceptPackageTransfer(transferId: number): Promise<any> {
  return api.post(`/driver/package-transfers/${transferId}/accept`);
}

export function rejectPackageTransfer(transferId: number): Promise<any> {
  return api.post(`/driver/package-transfers/${transferId}/reject`);
}

export function cancelPackageTransfer(transferId: number): Promise<any> {
  return api.post(`/driver/package-transfers/${transferId}/cancel`);
}

export function recallPackageTransfer(transferId: number): Promise<any> {
  return api.post(`/driver/package-transfers/${transferId}/recall`);
}

export function searchDriverLocations(query: string): Promise<any> {
  return api.get('/driver/locations/search', { params: { q: query } });
}

export function getPackageHistory(barcode: string): Promise<any> {
  return api.get(`/driver/package-history/${barcode}`);
}

export function startDeliveries(data?: { warehouse_id?: number; barcodes?: string[] }): Promise<any> {
  return api.post('/driver/start-deliveries', data);
}
