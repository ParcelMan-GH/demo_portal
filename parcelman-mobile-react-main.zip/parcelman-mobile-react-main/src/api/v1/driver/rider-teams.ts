import api from '../../client';

export function getRiderTeams(): Promise<any> {
  return api.get('/driver/rider-teams');
}

export function getRiderTeam(teamId: number | string): Promise<any> {
  return api.get(`/driver/rider-teams/${teamId}`);
}

export function lookupRiderTeamMember(teamId: number | string, phone: string): Promise<any> {
  return api.post(`/driver/rider-teams/${teamId}/members/lookup`, { phone });
}

export function addRiderTeamMember(teamId: number | string, data: { driver_id?: number; phone?: string; role?: 'leader' | 'member' }): Promise<any> {
  return api.post(`/driver/rider-teams/${teamId}/members`, data);
}

export function removeRiderTeamMember(teamId: number | string, driverId: number | string): Promise<any> {
  return api.delete(`/driver/rider-teams/${teamId}/members/${driverId}`);
}

export function getRiderTeamHandovers(params?: { limit?: number }): Promise<any> {
  return api.get('/driver/rider-team-handovers', { params });
}

export function getRiderTeamHandover(handoverId: number | string): Promise<any> {
  return api.get(`/driver/rider-team-handovers/${handoverId}`);
}

export function scanReceiveRiderTeamHandover(handoverId: number | string, barcode: string): Promise<any> {
  return api.post(`/driver/rider-team-handovers/${handoverId}/scan-receive`, { barcode });
}

export function scanReceiveRiderTeam(
  teamId: number | string,
  data: { barcode: string; latitude?: number; longitude?: number },
): Promise<any> {
  return api.post(`/driver/rider-teams/${teamId}/scan-receive`, data);
}

export function allocateRiderTeamHandoverLabels(
  handoverId: number | string,
  data: { driver_id: number; barcodes: string[] },
): Promise<any> {
  return api.post(`/driver/rider-team-handovers/${handoverId}/allocate`, data);
}

export function scanClaimRiderTeamPackage(data: {
  barcode: string;
  latitude?: number;
  longitude?: number;
  notes?: string;
}): Promise<any> {
  return api.post('/driver/rider-team-handovers/scan-claim', data);
}
