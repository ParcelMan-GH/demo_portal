import api from '../../client';
import type { PaginationParams } from '../../../types/api';
import type { FailStopData } from '../../../types/driver';

export function getDeliveryRuns(params?: PaginationParams & { status?: string }): Promise<any> {
  return api.get('/driver/deliveries', { params });
}

export function getDeliveryRun(id: number): Promise<any> {
  return api.get(`/driver/deliveries/${id}`);
}

export interface BusStation {
  id: number;
  name: string;
  location_hint?: string | null;
  sort_order?: number;
}

export interface DeliveryFailureReason {
  id: number;
  label: string;
  slug?: string | null;
  type: 'not_received' | 'issue' | 'failed' | 'other';
  sort_order?: number | null;
  is_active?: boolean;
}

export function getBusStations(): Promise<{
  success: boolean;
  data: { bus_stations: BusStation[] };
}> {
  return api.get('/driver/bus-stations');
}

export function getDeliveryFailureReasons(): Promise<{
  success: boolean;
  data: { reasons: DeliveryFailureReason[] };
}> {
  return api.get('/driver/delivery-failure-reasons');
}

export function arriveAtStop(runId: number, stopId: number): Promise<any> {
  return api.post(`/driver/deliveries/${runId}/stops/${stopId}/arrive`);
}

export interface ConfirmPackagesData {
  verification_code?: string;
  skip_verification?: boolean;
  skip_reason?: string;
  packages_delivered: number;
  latitude?: number;
  longitude?: number;
  proof_photo: string; // local file URI
  delivery_notes?: string;
  in_field_delivery_fee?: number;
}

export function confirmPackages(
  runId: number,
  stopId: number,
  data: ConfirmPackagesData,
): Promise<any> {
  const formData = new FormData();

  if (data.skip_verification) {
    formData.append('skip_verification', 'true');
    formData.append('skip_reason', data.skip_reason || '');
  } else if (data.verification_code) {
    formData.append('verification_code', data.verification_code);
  }

  formData.append('packages_delivered', String(data.packages_delivered));
  if (typeof data.latitude === 'number' && Number.isFinite(data.latitude)) {
    formData.append('latitude', String(data.latitude));
  }
  if (typeof data.longitude === 'number' && Number.isFinite(data.longitude)) {
    formData.append('longitude', String(data.longitude));
  }
  if (data.delivery_notes) formData.append('delivery_notes', data.delivery_notes);
  if (typeof data.in_field_delivery_fee === 'number') {
    formData.append('in_field_delivery_fee', String(data.in_field_delivery_fee));
  }

  if (data.proof_photo) {
    formData.append('proof_photo', {
      uri: data.proof_photo,
      name: 'proof.jpg',
      type: 'image/jpeg',
    } as any);
  }

  return api.post(
    `/driver/deliveries/${runId}/stops/${stopId}/confirm-packages`,
    formData,
    { headers: { 'Content-Type': 'multipart/form-data' } },
  );
}

export function confirmHandoff(
  runId: number,
  stopId: number,
  data: {
    proof_photo: string;
    bus_station_name?: string;
    station_fee?: number;
    courier_name?: string;
    courier_phone?: string;
    vehicle_number?: string;
    latitude?: number;
    longitude?: number;
  },
): Promise<any> {
  const formData = new FormData();
  if (data.bus_station_name) formData.append("bus_station_name", data.bus_station_name);
  if (typeof data.station_fee === "number") formData.append("station_fee", String(data.station_fee));
  if (data.courier_name) formData.append("courier_name", data.courier_name);
  if (data.courier_phone) formData.append("courier_phone", data.courier_phone);
  if (data.vehicle_number) formData.append("vehicle_number", data.vehicle_number);
  if (typeof data.latitude === "number") formData.append("latitude", String(data.latitude));
  if (typeof data.longitude === "number") formData.append("longitude", String(data.longitude));
  formData.append("proof_photo", { uri: data.proof_photo, name: "handoff_proof.jpg", type: "image/jpeg" } as any);
  return api.post(`/driver/deliveries/${runId}/stops/${stopId}/confirm-handoff`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
    timeout: 120000,
  });
}

export function failStop(
  runId: number,
  stopId: number,
  data: FailStopData,
): Promise<any> {
  return api.post(`/driver/deliveries/${runId}/stops/${stopId}/fail`, data);
}

export function updateDeliveryItemEta(
  deliveryRunItemId: number,
  data: { expected_delivery_at: string; reason_id?: number; notes?: string },
): Promise<any> {
  return api.patch(`/driver/delivery-items/${deliveryRunItemId}/eta`, data);
}
