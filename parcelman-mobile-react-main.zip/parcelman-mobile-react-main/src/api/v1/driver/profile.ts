import api from '../../client';
import type { ApiResponse } from '../../../types/api';
import type { Driver } from '../../../types/driver';

export function getDriverProfile(): Promise<ApiResponse<Driver>> {
  return api.get('/driver/profile') as any;
}

export function updateDriverProfile(data: {
  name?: string;
  email?: string;
  phone?: string;
  vehicle_type?: string;
  vehicle_number?: string;
  license_number?: string;
}): Promise<ApiResponse<Driver>> {
  return api.put('/driver/profile', data) as any;
}

export function changePassword(data: {
  current_password: string;
  new_password: string;
  confirm_password: string;
}): Promise<ApiResponse<{ user: Driver }>> {
  return api.put('/driver/change-password', data) as any;
}

export function updateDriverFcmToken(token: string): Promise<ApiResponse<null>> {
  return api.post('/driver/fcm-token', { fcm_token: token }) as any;
}
