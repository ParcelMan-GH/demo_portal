import axios from 'axios';
import { getItem } from '../utils/secure-storage';
import { API_BASE_URL, API_TIMEOUT } from '../constants/api';
import { STORAGE_KEYS } from '../constants/storage-keys';

const api = axios.create({
  baseURL: API_BASE_URL + '/api/v1',
  timeout: API_TIMEOUT,
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  },
});

// Request interceptor: inject auth token
api.interceptors.request.use(
  async (config) => {
    const token = await getItem(STORAGE_KEYS.AUTH_TOKEN);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    if (__DEV__) {
      console.log(`[API] ${config.method?.toUpperCase()} ${config.url}`);
    }
    return config;
  },
  (error) => Promise.reject(error),
);

// Response interceptor: unwrap data, handle 401
api.interceptors.response.use(
  (response) => response.data,
  async (error) => {
    const config = error.config;

    // Auto-retry once on network errors (not on 4xx/5xx)
    if (!error.response && !config._retry && config?.method === 'get') {
      config._retry = true;
      if (__DEV__) {
        console.log(`[API] Retrying ${config.url}...`);
      }
      await new Promise((r) => setTimeout(r, 1500));
      return api(config);
    }

    if (__DEV__) {
      console.log('[API Error]', {
        url: config?.url,
        status: error.response?.status,
        message: error.response?.data?.message || error.message,
      });
    }

    if (error.response?.status === 401 && !config?.url?.includes('logout')) {
      const { useAuthStore } = require('../stores/auth.store');
      useAuthStore.getState().logoutLocal();
    }
    return Promise.reject(error.response?.data || error);
  },
);

export default api;
