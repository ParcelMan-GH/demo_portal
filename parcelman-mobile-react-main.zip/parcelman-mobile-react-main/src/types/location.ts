export interface Region {
  id: number;
  name: string;
}

export interface District {
  id: number;
  region_id: number;
  name: string;
}

export interface Location {
  id: number;
  name: string;
  region_id: number;
  district_id: number;
  latitude: number | null;
  longitude: number | null;
  region?: Region;
  district?: District;
}
