import type {
  PickupStatus,
  TransportStatus,
  DeliveryRunStatus,
  DeliveryStopStatus,
  ItemStatus,
} from '@constants/statuses';

export type TaskCapability = 'pickup' | 'transport' | 'delivery' | 'bus_handoff';
export type DeliveryMethod = 'direct' | 'bus_handoff';

export interface DriverHeldPackage {
  barcode: string;
  label_index: number | null;
  labels_total: number;
  label_type: string;
  shipment_number: string | null;
  description: string | null;
  tracking_code: string | null;
  delivery_method: DeliveryMethod;
  route_label: string;
  recipient_name: string | null;
  recipient_phone: string | null;
  delivery_town: string | null;
  pending_transfer?: {
    id: number;
    status: 'pending' | 'accepted' | 'rejected' | 'cancelled';
    to_driver?: Pick<Driver, 'id' | 'name' | 'phone'> | null;
    from_driver?: Pick<Driver, 'id' | 'name' | 'phone'> | null;
    requested_at?: string | null;
  } | null;
  can_change_location?: boolean;
  can_transfer?: boolean;
  claimed_at?: string | null;
  in_delivery_run?: boolean;
  can_start_delivery?: boolean;
  custody_status?: string | null;
  claim_source?: 'self_scan' | 'rider_team_assigned' | 'rider_team_claimed';
  is_claimed?: boolean;
  team?: { id: number; name: string } | null;
  handover?: { id: number; handover_number: string } | null;
  assigned_by?: Pick<Driver, 'id' | 'name' | 'phone'> | null;
  allocated_at?: string | null;
  member_claimed_at?: string | null;
}

export interface DriverPackageHistoryEvent {
  event_type:
    | 'claimed'
    | 'released'
    | 'transferred'
    | 'delivered'
    | 'returned'
    | 'assigned_to_leader'
    | 'leader_received'
    | 'allocated_to_member'
    | 'member_claimed'
    | 'returned_to_leader'
    | 'returned_to_warehouse'
    | 'recalled';
  driver_name: string | null;
  driver_phone: string | null;
  notes: string | null;
  created_at: string;
}

export interface Driver {
  id: number;
  name: string;
  email: string;
  avatar?: string | null;
  photo_url?: string | null;
  phone: string | null;
  vehicle_type: string | null;
  vehicle_number: string | null;
  license_number: string | null;
  base_location: string | null;
  status: 'available' | 'offline' | 'busy';
  is_active: boolean;
  task_capabilities: TaskCapability[];
  last_login_at: string | null;
  fcm_token: string | null;
  created_at: string;
  updated_at: string;
}

export interface RiderTeamTotals {
  assigned: number;
  received: number;
  distributed: number;
  claimed: number;
  delivered: number;
  failed?: number;
  still_with_leader: number;
  with_receiver?: number;
}

export interface RiderTeamMember {
  id: number;
  role: 'leader' | 'member';
  joined_at?: string | null;
  driver: Pick<Driver, 'id' | 'name' | 'phone' | 'vehicle_type' | 'vehicle_number' | 'is_active'> | null;
}

export interface RiderTeam {
  id: number;
  name: string;
  zone: string | null;
  is_active: boolean;
  role: 'leader' | 'member';
  warehouse?: { id: number; name: string; code: string } | null;
  totals: RiderTeamTotals;
  members?: RiderTeamMember[];
}

export interface RiderTeamHandoverItem {
  id: number;
  barcode: string | null;
  status: string;
  allocated_to?: Pick<Driver, 'id' | 'name' | 'phone'> | null;
  assigned_at?: string | null;
  leader_received_at?: string | null;
  receiver_received_at?: string | null;
  allocated_at?: string | null;
  member_claimed_at?: string | null;
  package?: {
    tracking_code: string | null;
    description: string | null;
    recipient_name: string | null;
    recipient_phone: string | null;
    delivery_town: string | null;
    delivery_landmark?: string | null;
    delivery_instructions?: string | null;
    images?: Array<{
      id: number;
      url: string;
      original_name?: string | null;
      size?: number | null;
      recipient_phone?: string | null;
      source?: string | null;
    }>;
  } | null;
}

export interface RiderTeamHandover {
  id: number;
  handover_number: string;
  status: string;
  team: Pick<RiderTeam, 'id' | 'name' | 'zone'> | null;
  leader: Pick<Driver, 'id' | 'name' | 'phone'> | null;
  counts: RiderTeamTotals;
  created_at: string | null;
  assigned_at: string | null;
  received_at: string | null;
  can_manage?: boolean;
  can_receive?: boolean;
  can_distribute?: boolean;
  items?: RiderTeamHandoverItem[];
}

export interface DirectDeliveryInfo {
  recipient_name: string;
  recipient_phone: string;
  location: {
    region: string;
    district: string;
    town: string;
    latitude: number | null;
    longitude: number | null;
    gh_post_address: string | null;
    landmark: string | null;
  };
  instructions: string | null;
}

export interface AutoDeliveryInfo {
  delivery_run_id: number;
  run_number: string;
  stop_id: number;
  recipient_name: string;
  recipient_phone: string;
  location: any;
  instructions: string | null;
}

export interface PickupAssignment {
  id: number;
  shipment_id: number;
  driver_id: number;
  target_warehouse_id: number | null;
  status: PickupStatus;
  is_direct_delivery: boolean;
  direct_delivery: DirectDeliveryInfo | null;
  assigned_at: string | null;
  en_route_at: string | null;
  arrived_at: string | null;
  picked_up_at: string | null;
  completed_at: string | null;
  driver_picked_quantity: number | null;
  pickup_latitude: number | null;
  pickup_longitude: number | null;
  notes: string | null;
  cancellation_reason: string | null;
  created_at: string;
  updated_at: string;

  // Relations
  shipment?: {
    id: number;
    shipment_number: string;
    pickup_contact_name: string;
    pickup_contact_phone: string;
    pickup_town: string | null;
    pickup_landmark: string | null;
    pickup_instructions: string | null;
    pickup_latitude: number | null;
    pickup_longitude: number | null;
    vendor_declared_quantity?: number | null;
    driver_picked_quantity?: number | null;
    items?: PickupItem[];
  };
}

export interface PickupItem {
  id: number;
  description: string;
  quantity: number;
  status: ItemStatus;
  confirmed_quantity?: number;
  confirmation_notes?: string;
  confirmation_photos?: string[];
}

export interface PickupItemConfirmData {
  confirmed_quantity: number;
  notes?: string;
  photos?: any[];
}

export interface TransportManifest {
  id: number;
  manifest_number: string;
  sort_batch_id: number | null;
  origin_warehouse_id: number | null;
  destination_warehouse_id: number | null;
  assigned_driver_id: number | null;
  status: TransportStatus;
  assigned_at: string | null;
  dispatched_at: string | null;
  arrived_at: string | null;
  received_at: string | null;
  notes: string | null;
  cancellation_reason: string | null;
  created_at: string;
  updated_at: string;

  // Relations
  origin_warehouse?: { id: number; name: string };
  destination_warehouse?: { id: number; name: string };
  items?: TransportManifestItem[];
  containers?: TransportContainer[];
}

export interface TransportContainer {
  id: number;
  container_code: string;
  container_type: string;
  sequence_number: number;
  status: string;
  package_count: number;
  item_quantity: number;
  loaded_at: string | null;
  sealed_at: string | null;
  notes?: string | null;
  items?: TransportManifestItem[];
}

export interface TransportManifestItem {
  id: number;
  transport_manifest_id: number;
  shipment_item_id: number;
  tracking_code: string;
  scanned_at: string | null;
  shipment_item?: {
    id: number;
    description: string;
    quantity: number;
  };
}

export interface DeliveryRun {
  id: number;
  run_number: string;
  sort_batch_id: number | null;
  warehouse_id: number | null;
  assigned_driver_id: number | null;
  status: DeliveryRunStatus;
  is_direct_delivery: boolean;
  assigned_at: string | null;
  dispatched_at: string | null;
  completed_at: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;

  // Relations
  stops?: DeliveryRunStop[];
  warehouse?: { id: number; name: string };
}

export interface DeliveryStopHandoff {
  bus_station: string | null;
  courier_name: string | null;
  courier_phone: string | null;
  vehicle_number: string | null;
  handed_off_at: string | null;
  proof_photo_url: string | null;
  amount_paid: number | null;
  currency: string | null;
}

export interface DeliveryStopFeeSummary {
  status: 'none' | 'collect' | 'partially_paid' | 'paid' | 'waived';
  currency: string;
  total_amount: number;
  paid_amount: number;
  outstanding_amount: number;
  is_paid: boolean;
  can_capture_amount: boolean;
  paid_at: string | null;
  payment_method: string | null;
  notes: string | null;
}

export interface DeliveryRunStop {
  id: number;
  delivery_run_id: number;
  recipient_name: string;
  recipient_phone: string;
  region_id: number | null;
  district_id: number | null;
  town: string | null;
  latitude: number | null;
  longitude: number | null;
  gh_post_address: string | null;
  landmark: string | null;
  status: DeliveryStopStatus;
  arrived_at: string | null;
  delivered_at: string | null;
  delivery_latitude: number | null;
  delivery_longitude: number | null;
  proof_photo_path: string | null;
  failure_reason: string | null;
  failure_notes: string | null;
  created_at: string;
  updated_at: string;
  handoff?: DeliveryStopHandoff | null;
  delivery_fee?: DeliveryStopFeeSummary | null;

  items?: DeliveryRunItem[];
}

export interface DeliveryRunItem {
  id: number;
  delivery_run_stop_id: number;
  shipment_item_id: number;
  delivered_quantity: number | null;
  expected_quantity?: number | null;
  status?: string | null;
  eta?: {
    status: string;
    label: string;
    tone?: string;
    is_overdue?: boolean;
    expected_delivery_at?: string | null;
    expected_delivery_at_iso?: string | null;
    expected_delivery_set_at?: string | null;
    set_by?: string | null;
    can_update?: boolean;
  } | null;
  shipment_item?: {
    id: number;
    description: string;
    quantity: number;
    tracking_code: string | null;
  };
}

export interface ConfirmStopData {
  verification_code: string;
  latitude: number;
  longitude: number;
  proof_photo?: any;
  items: Array<{
    shipment_item_id: number;
    delivered_quantity: number;
  }>;
}

export interface FailStopData {
  reason: string;
  notes?: string;
}
