import type {
  ShipmentStatus,
  ItemStatus,
} from '@constants/statuses';

export interface Vendor {
  id: number;
  name: string;
  business_name: string | null;
  phone: string;
  email: string | null;
  payout_account?: VendorPayoutAccount | null;
  is_active: boolean;
  fcm_token: string | null;
  created_at: string;
  updated_at: string;
}

export type PayoutMomoNetwork = 'mtn' | 'telecel' | 'airteltigo';

export interface VendorPayoutAccount {
  is_set: boolean;
  method: 'momo';
  network: PayoutMomoNetwork | null;
  account_name: string | null;
  account_number: string | null;
  updated_at: string | null;
}

export type DestinationMode = 'single' | 'per_item';
export type DeliveryPreference = 'deliver' | 'self_pickup';
export type FulfillmentType = 'warehouse' | 'direct'; // admin-only, read-only

export interface CollectionInfo {
  status: 'ready' | 'collected';
  warehouse_name: string;
  warehouse_address: string;
  warehouse_phone: string;
  ready_at: string | null;
  collected_at: string | null;
  collected_by_name: string | null;
}

export interface CourierHandoffInfo {
  status?: string;
  bus_station: string | null;
  driver_name?: string | null;
  driver_phone?: string | null;
  rider_name?: string | null;
  rider_phone?: string | null;
  sent_by_name?: string | null;
  sent_by_phone?: string | null;
  courier_name: string | null;
  courier_phone: string | null;
  vehicle_number: string | null;
  handed_off_at: string | null;
  proof_photo_url: string | null;
}

export interface Shipment {
  id: number;
  vendor_id: number;
  shipment_number: string;
  status: ShipmentStatus;
  destination_mode: DestinationMode;
  delivery_preference: DeliveryPreference | null;
  fulfillment_type: FulfillmentType | null;
  collection: CollectionInfo | null;
  vendor_declared_quantity: number | null;
  driver_picked_quantity?: number | null;
  warehouse_received_quantity?: number | null;
  pickup_vehicles?: PickupVehicleRequest[];
  pickup_vehicle_summary?: string | null;

  // Pickup
  pickup_contact_name: string;
  pickup_contact_phone: string;
  pickup_region_id: number | null;
  pickup_district_id: number | null;
  pickup_town: string | null;
  pickup_latitude: number | null;
  pickup_longitude: number | null;
  pickup_gh_post_address: string | null;
  pickup_landmark: string | null;
  pickup_instructions: string | null;

  // Delivery (single mode)
  delivery_recipient_name: string | null;
  delivery_recipient_phone: string | null;
  delivery_region_id: number | null;
  delivery_district_id: number | null;
  delivery_town: string | null;
  delivery_latitude: number | null;
  delivery_longitude: number | null;
  delivery_gh_post_address: string | null;
  delivery_landmark: string | null;
  delivery_instructions: string | null;

  submitted_at: string | null;
  cancelled_at: string | null;
  cancellation_reason: string | null;
  rejected_at?: string | null;
  rejected_by_admin_id?: number | null;
  rejection_reason?: string | null;
  created_at: string;
  updated_at: string;

  // Relations (when included)
  items?: ShipmentItem[];
  pickup_region?: { id: number; name: string } | null;
  pickup_district?: { id: number; name: string } | null;
  delivery_region?: { id: number; name: string } | null;
  delivery_district?: { id: number; name: string } | null;
  charges?: ShipmentCharges | null;
  courier_handoff?: CourierHandoffInfo | null;
}

export interface PickupVehicleRequest {
  id?: number;
  vehicle_type_id: number | null;
  name?: string;
  vehicle_name?: string;
  vehicle_name_snapshot?: string;
  capacity_hint?: string | null;
  quantity: number;
}

export type ChargeType = 'pickup_fee' | 'delivery_fee' | 'handling_fee' | 'other';
export type PayerType = 'vendor' | 'recipient';
export type DueStage =
  | 'at_pickup'
  | 'at_receiving'
  | 'before_delivery'
  | 'at_delivery'
  | 'at_handoff';
export type ChargeStatus = 'draft' | 'pending' | 'paid' | 'waived' | 'cancelled';

export interface ChargeLine {
  id: number;
  shipment_item_id: number | null;
  charge_type: ChargeType;
  payer_type: PayerType;
  due_stage: DueStage;
  amount: number;
  currency: string;
  status: ChargeStatus;
  paid_at: string | null;
  payment_method: string | null;
  notes: string | null;
  created_at: string;
}

export interface ShipmentCharges {
  lines: ChargeLine[];
  totals: {
    currency: string;
    total: number;
    paid: number;
    outstanding: number;
  };
}

export interface DeliveryEtaInfo {
  status: string | null;
  label: string | null;
  tone: string | null;
  is_overdue: boolean;
  expected_delivery_at: string | null;
  expected_delivery_at_iso: string | null;
  expected_delivery_set_at: string | null;
  last_notice_at: string | null;
  last_reason: string | null;
}

export interface ShipmentItem {
  id: number;
  shipment_id: number;
  description: string;
  quantity: number;
  status: ItemStatus;
  tracking_code: string | null;

  // Per-item delivery (per_item mode)
  delivery_recipient_name: string | null;
  delivery_recipient_phone: string | null;
  delivery_region_id: number | null;
  delivery_district_id: number | null;
  delivery_town: string | null;
  delivery_latitude: number | null;
  delivery_longitude: number | null;
  delivery_gh_post_address: string | null;
  delivery_landmark: string | null;
  delivery_instructions: string | null;

  created_at: string;
  updated_at: string;

  images?: ShipmentItemImage[];
  handoff?: CourierHandoffInfo | null;
  eta?: DeliveryEtaInfo | null;
  delivery_eta?: DeliveryEtaInfo | null;
}

export interface ShipmentItemImage {
  id: number;
  url: string;
  original_name?: string;
  size: number;
  size_human?: string;
  recipient_phone: string | null;
  expires_at: string | null;
  // Legacy / optional fields (not always present in new responses)
  shipment_item_id?: number;
  path?: string;
  created_at?: string;
}

// Create/Update DTOs
export interface CreateShipmentData {
  destination_mode: DestinationMode;
  delivery_preference?: DeliveryPreference;
  pickup_contact_name: string;
  pickup_contact_phone: string;
  pickup_contact_phone_confirm: string;
  pickup_region_id?: number;
  pickup_district_id?: number;
  pickup_town?: string;
  pickup_latitude?: number;
  pickup_longitude?: number;
  pickup_gh_post_address?: string;
  pickup_landmark?: string;
  pickup_instructions?: string;
  vendor_declared_quantity?: number;
  pickup_vehicles?: Array<{ vehicle_type_id: number; quantity: number }>;
  // Single destination mode
  delivery_recipient_name?: string;
  delivery_recipient_phone?: string;
  delivery_recipient_phone_confirm?: string;
  delivery_region_id?: number;
  delivery_district_id?: number;
  delivery_town?: string;
  delivery_latitude?: number;
  delivery_longitude?: number;
  delivery_gh_post_address?: string;
  delivery_landmark?: string;
  delivery_instructions?: string;
}

export interface AddItemData {
  description: string;
  quantity?: number;
  images?: any[];
  // Per-item delivery
  delivery_recipient_name?: string;
  delivery_recipient_phone?: string;
  delivery_region_id?: number;
  delivery_district_id?: number;
  delivery_town?: string;
  delivery_latitude?: number;
  delivery_longitude?: number;
  delivery_gh_post_address?: string;
  delivery_landmark?: string;
  delivery_instructions?: string;
}

// ─── Earnings & Payouts ───

export interface EarningsSummary {
  total_earned: number;
  available_balance: number;
  total_paid: number;
  pending_payout: number;
  min_payout: number;
  can_request_payout: boolean;
  currency: string;
  payout_account?: VendorPayoutAccount | null;
}

export interface VendorEarning {
  id: number;
  shipment_number: string;
  amount: number;
  status: 'approved' | 'paid';
  created_at: string;
}

export interface VendorPayout {
  id: number;
  amount: number;
  status: 'pending' | 'sent' | 'confirmed';
  payment_method: 'momo' | 'bank' | 'cash';
  payment_reference: string | null;
  payment_phone: string | null;
  sent_at: string | null;
  confirmed_at: string | null;
  created_at: string;
}
