import { showToast } from '../components/common/Toast';

export function showSuccess(message: string) {
  showToast('success', message);
}

export function showError(message: string) {
  showToast('error', message);
}

export function showInfo(message: string) {
  showToast('info', message);
}

export function showWarning(message: string) {
  showToast('warning', message);
}

export function getErrorMessage(err: any, fallback = 'Something went wrong'): string {
  if (typeof err === 'string') return err;
  if (err?.message) return err.message;
  if (err?.errors) {
    const firstError = Object.values(err.errors).flat()[0];
    if (firstError) return String(firstError);
  }
  return fallback;
}
