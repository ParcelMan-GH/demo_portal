const VENDOR_NOTIFICATION_REPLACEMENTS: Array<[RegExp, string]> = [
  [/^Delivered(\s+—)/, "Parcel Delivered$1"],
  [/^In Transit(\s+—)/, "Parcel in Transit$1"],
  [/\bShipment Picked Up\b/g, "Parcel Picked Up"],
  [/\bShipment at Warehouse\b/g, "Parcel at Warehouse"],
  [/\bShipment Sorted\b/g, "Parcel Sorted"],
  [/\bShipment Cancelled\b/g, "Parcel Cancelled"],
  [/\bShipment Collected\b/g, "Parcel Collected"],
  [/\bShipment Received\b/g, "Parcel Received"],
  [/\bShipment request rejected\b/g, "Parcel request rejected"],
  [/\bYour shipment\b/g, "Your parcel"],
  [/\byour shipment\b/g, "your parcel"],
  [/\bShipment\b/g, "Parcel"],
  [/\bshipment\b/g, "parcel"],
];

export function formatVendorNotificationCopy(value: string | null | undefined): string {
  return VENDOR_NOTIFICATION_REPLACEMENTS.reduce(
    (text, [pattern, replacement]) => text.replace(pattern, replacement),
    value ?? "",
  );
}
