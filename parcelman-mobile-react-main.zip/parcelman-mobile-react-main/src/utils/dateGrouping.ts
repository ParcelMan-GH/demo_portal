export type DateGroupedRow<T> =
  | {
      type: "date";
      key: string;
      dateKey: string;
      label: string;
    }
  | {
      type: "item";
      key: string;
      item: T;
    };

type DateLikeItem = {
  id?: string | number | null;
  created_at?: string | null;
};

function toLocalDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatGroupLabel(date: Date | null): string {
  if (!date) return "Unknown date";

  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);

  const dateKey = toLocalDateKey(date);
  if (dateKey === toLocalDateKey(today)) return "Today";
  if (dateKey === toLocalDateKey(yesterday)) return "Yesterday";

  return date.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function parseCreatedDate(value?: string | null): Date | null {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

export function buildDateGroupedRows<T extends DateLikeItem>(items: T[]): DateGroupedRow<T>[] {
  const rows: DateGroupedRow<T>[] = [];
  let previousDateKey: string | null = null;

  items.forEach((item, index) => {
    const date = parseCreatedDate(item.created_at);
    const dateKey = date ? toLocalDateKey(date) : "unknown";

    if (dateKey !== previousDateKey) {
      rows.push({
        type: "date",
        key: `date-${dateKey}-${index}`,
        dateKey,
        label: formatGroupLabel(date),
      });
      previousDateKey = dateKey;
    }

    rows.push({
      type: "item",
      key: `shipment-${item.id ?? index}`,
      item,
    });
  });

  return rows;
}
