import * as FileSystem from 'expo-file-system';

// Backend caps image uploads at 2MB per image.
const MAX_BYTES = 2 * 1024 * 1024;
let imageManipulatorModule: any | null | undefined;

function getImageManipulator() {
  if (imageManipulatorModule !== undefined) return imageManipulatorModule;

  try {
    imageManipulatorModule = require('expo-image-manipulator');
  } catch {
    // Development builds must include the native module. If not, keep uploads usable
    // and let the backend enforce size limits instead of crashing the screen.
    imageManipulatorModule = null;
  }

  return imageManipulatorModule;
}

async function fileSize(uri: string): Promise<number> {
  try {
    const info = await FileSystem.getInfoAsync(uri);
    if (info.exists && 'size' in info) return (info as any).size ?? 0;
  } catch {}
  return 0;
}

/**
 * If the image is already under 2MB, returns the original URI.
 * Otherwise resizes + compresses down in steps until it fits.
 * Returns the original URI if we can't shrink it enough (rare — will 422 server-side).
 */
export async function compressToUnder2MB(uri: string): Promise<string> {
  const original = await fileSize(uri);
  if (original > 0 && original <= MAX_BYTES) return uri;

  let currentUri = uri;
  // Start with a reasonable resize + compress, then ramp down if still too big.
  const passes: { width: number; compress: number }[] = [
    { width: 1920, compress: 0.75 },
    { width: 1600, compress: 0.6 },
    { width: 1280, compress: 0.5 },
    { width: 1024, compress: 0.4 },
    { width: 800, compress: 0.35 },
  ];

  for (const pass of passes) {
    try {
      const ImageManipulator = getImageManipulator();
      if (!ImageManipulator?.manipulateAsync) return currentUri;

      const result = await ImageManipulator.manipulateAsync(
        currentUri,
        [{ resize: { width: pass.width } }],
        { compress: pass.compress, format: ImageManipulator.SaveFormat.JPEG },
      );
      const size = await fileSize(result.uri);
      if (size > 0 && size <= MAX_BYTES) return result.uri;
      currentUri = result.uri; // keep shrinking from the last attempt
    } catch {
      // If manipulation fails, fall through to the next pass.
    }
  }
  return currentUri;
}

/** Compress many URIs in parallel. Safe to call with already-small images. */
export async function compressMany(uris: string[]): Promise<string[]> {
  return Promise.all(uris.map(compressToUnder2MB));
}
