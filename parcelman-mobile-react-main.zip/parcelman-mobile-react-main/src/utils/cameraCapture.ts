import { Asset } from 'expo-asset';
import * as Device from 'expo-device';
import * as ImagePicker from 'expo-image-picker';
import { Alert, Platform } from 'react-native';

type SimulatorBehavior = 'choice' | 'sample';
type SimulatorChoice = 'sample' | 'library' | 'cancel';

const SIMULATOR_TEST_PHOTO = require('../../assets/images/icon.jpg');

export function isIosSimulator(): boolean {
  return Platform.OS === 'ios' && !Device.isDevice;
}

function chooseSimulatorSource(): Promise<SimulatorChoice> {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (choice: SimulatorChoice) => {
      if (settled) return;
      settled = true;
      resolve(choice);
    };

    Alert.alert(
      'Simulator Camera',
      'The iOS Simulator has no real camera. Use a built-in test photo or choose one from the simulator photo library.',
      [
        { text: 'Use Test Photo', onPress: () => finish('sample') },
        { text: 'Photo Library', onPress: () => finish('library') },
        { text: 'Cancel', style: 'cancel', onPress: () => finish('cancel') },
      ],
      { cancelable: true, onDismiss: () => finish('cancel') },
    );
  });
}

async function pickSingleLibraryImage(quality: number): Promise<string | null> {
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    allowsMultipleSelection: false,
    quality,
  });

  return result.canceled ? null : (result.assets[0]?.uri ?? null);
}

async function getSimulatorSamplePhotoUri(): Promise<string | null> {
  try {
    const asset = Asset.fromModule(SIMULATOR_TEST_PHOTO);
    if (!asset.localUri) {
      await asset.downloadAsync();
    }

    return asset.localUri ?? asset.uri ?? null;
  } catch {
    return null;
  }
}

export async function captureSinglePhoto(options: {
  quality?: number;
  simulatorBehavior?: SimulatorBehavior;
} = {}): Promise<string | null> {
  const quality = options.quality ?? 0.7;
  const simulatorBehavior = options.simulatorBehavior ?? 'choice';

  if (isIosSimulator()) {
    if (simulatorBehavior === 'sample') {
      const sampleUri = await getSimulatorSamplePhotoUri();
      if (sampleUri) return sampleUri;

      Alert.alert(
        'Test photo unavailable',
        'The built-in simulator photo could not be loaded. Choose a photo from the library instead.',
      );
      return pickSingleLibraryImage(quality);
    }

    const choice = await chooseSimulatorSource();
    if (choice === 'cancel') return null;
    if (choice === 'library') return pickSingleLibraryImage(quality);

    const sampleUri = await getSimulatorSamplePhotoUri();
    if (sampleUri) return sampleUri;

    Alert.alert(
      'Test photo unavailable',
      'The built-in simulator photo could not be loaded. Choose a photo from the library instead.',
    );
    return pickSingleLibraryImage(quality);
  }

  const { status } = await ImagePicker.requestCameraPermissionsAsync();
  if (status !== 'granted') {
    Alert.alert('Permission needed', 'Camera permission is required to take photos.');
    return null;
  }

  try {
    const result = await ImagePicker.launchCameraAsync({ quality });
    return result.canceled ? null : (result.assets[0]?.uri ?? null);
  } catch {
    Alert.alert('Camera unavailable', "Couldn't open the camera. Try again.");
    return null;
  }
}
