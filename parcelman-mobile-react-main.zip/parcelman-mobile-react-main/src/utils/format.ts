export function formatCurrency(amount: number | null | undefined, currency = 'GHS'): string {
  if (amount == null) return `${currency} 0.00`;
  return `${currency} ${Number(amount).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}`;
}

export function formatDate(isoString: string | null | undefined): string {
  if (!isoString) return '—';
  const date = new Date(isoString);
  if (isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function formatDateTimeAmPm(isoString: string | null | undefined): string {
  if (!isoString) return '—';
  const date = new Date(isoString);
  if (isNaN(date.getTime())) return '—';
  const result = date.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
  return result.replace(/\bam\b/gi, 'AM').replace(/\bpm\b/gi, 'PM');
}

export function formatDateTime(isoString: string | null | undefined): string {
  if (!isoString) return '—';
  const date = new Date(isoString);
  if (isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatPhone(phone: string | null | undefined): string {
  if (!phone) return '—';
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('233') && cleaned.length === 12) {
    return `+233 ${cleaned.slice(3, 5)} ${cleaned.slice(5, 8)} ${cleaned.slice(8)}`;
  }
  if (cleaned.length === 10 && cleaned.startsWith('0')) {
    return `${cleaned.slice(0, 3)} ${cleaned.slice(3, 6)} ${cleaned.slice(6)}`;
  }
  return phone;
}

export function maskPhone(phone: string | null | undefined): string {
  if (!phone) return '—';
  const hasPlus = phone.startsWith('+');
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('233') && cleaned.length >= 12) {
    return `+233****${cleaned.slice(-3)}`;
  }
  if (cleaned.length >= 6) {
    return `${hasPlus ? '+' : ''}${cleaned.slice(0, 3)}****${cleaned.slice(-3)}`;
  }
  return phone;
}

/**
 * Format a location object (from API) into a readable string.
 * Location shape: { region, district, town, gh_post_address, landmark }
 */
export function formatLocation(location: any): string {
  if (!location) return '—';
  if (typeof location === 'string') return location;
  const parts: string[] = [];
  if (location.town) parts.push(location.town);
  if (location.district) parts.push(location.district);
  if (location.region) parts.push(location.region);
  if (parts.length === 0 && location.gh_post_address) return location.gh_post_address;
  if (parts.length === 0) return '—';
  const result = parts.join(', ');
  if (location.landmark) return `${result} (${location.landmark})`;
  return result;
}

/**
 * Convert any Ghana phone format to local format (0XXXXXXXXX).
 * Accepts: +233XXXXXXXXX, 233XXXXXXXXX, 0XXXXXXXXX, XXXXXXXXX (9 digits)
 */
export function toLocalPhone(phone: string | null | undefined): string {
  if (!phone) return '';
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('233') && cleaned.length === 12) {
    return '0' + cleaned.slice(3);
  }
  if (cleaned.length === 9 && !cleaned.startsWith('0')) {
    return '0' + cleaned;
  }
  return cleaned;
}

const GHANA_LOCAL_MOBILE_RE = /^0(?:2\d|5\d)\d{7}$/;

export function sanitizeLocalPhoneInput(phone: string | null | undefined): string {
  if (!phone) return '';
  return phone.replace(/\D/g, '').slice(0, 10);
}

/**
 * Convert a local Ghana phone number to API format (+233XXXXXXXXX).
 * UI inputs must still collect local 10-digit numbers only.
 */
export function toApiPhone(phone: string | null | undefined): string {
  if (!phone) return '';
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('233') && cleaned.length === 12) {
    return '+' + cleaned;
  }
  if (isValidGhanaPhone(cleaned)) {
    return '+233' + cleaned.slice(1);
  }
  return phone;
}

/**
 * Validate local Ghana mobile format only, e.g. 0241234567.
 */
export function isValidGhanaPhone(phone: string | null | undefined): boolean {
  if (!phone) return false;
  return GHANA_LOCAL_MOBILE_RE.test(phone.replace(/\D/g, ''));
}

export function formatStatus(status: string | null | undefined): string {
  if (!status) return '—';
  return status
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}
