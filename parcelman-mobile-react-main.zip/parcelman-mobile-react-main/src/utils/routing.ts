import { router } from 'expo-router';

export type UserType = 'vendor' | 'driver';

export function getHomeRoute(userType: UserType): string {
  return userType === 'vendor' ? '/(vendor)/(tabs)/home' : '/(driver)/(tabs)/home';
}

export function navigateToHome(userType: UserType) {
  router.replace(getHomeRoute(userType) as any);
}

export function navigateToAuth() {
  router.replace('/(auth)/phone' as any);
}
